import copy
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location("analysis",Path(__file__).with_name("analyse.py"))
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
def fixture():
    rows=[]
    tick=10
    for case in a.CASES:
        for n in a.SIZES:
            for rep in range(4):
                for arm in a.ARMS:
                    ops=30+n*(2 if arm=="EMPTY" else 3 if arm!="ON" else 20)
                    rows.append(dict(case=case,n=n,rep=rep,arm=arm,ops=ops,tick0=tick,tick1=tick,group_tick=tick,left0=9000,left1=9000-ops,result=0,state_same=1))
                tick+=1
    return rows
def raw(rows):
    return "\n".join("[script:4] [0] [I] RRG|"+"|".join(str(k)+"="+str(v) for k,v in r.items()) for r in rows)+"\nRRG_DONE|rows=144"

class Checks(unittest.TestCase):
    def test_complete_artificial_counters_not_claimed_measured(self):
        result=a.report(a.parse(raw(fixture())))
        self.assertTrue(result["aa_exact"])
        self.assertEqual(result["cases"]["absent"]["per_call_min"],17)
        self.assertEqual(result["economic_verdict"],"not_evaluated")
    def test_missing_done_and_rows(self):
        with self.assertRaises(ValueError): a.parse(raw(fixture()).replace("RRG_DONE","NONE"))
        with self.assertRaises(ValueError): a.parse(raw(fixture()[:-1]))
    def test_duplicate_trial_and_field(self):
        rows=fixture(); rows[-1]=copy.deepcopy(rows[-2])
        with self.assertRaises(ValueError): a.report(rows)
        with self.assertRaises(ValueError): a.parse(raw(fixture()).replace("|result=0","|result=0|result=0",1))
    def test_crossing_and_different_group_tick(self):
        rows=fixture(); rows[0]["tick1"]+=1
        with self.assertRaises(ValueError): a.report(rows)
        rows=fixture(); rows[0]["group_tick"]+=1
        with self.assertRaises(ValueError): a.report(rows)
    def test_unequal_aa(self):
        rows=fixture(); row=next(r for r in rows if r["arm"]=="OFFB"); row["ops"]+=1; row["left1"]-=1
        with self.assertRaises(ValueError): a.report(rows)
    def test_mutation_and_bad_counter(self):
        rows=fixture(); rows[0]["state_same"]=0
        with self.assertRaises(ValueError): a.report(rows)
        rows=fixture(); rows[0]["ops"]+=1
        with self.assertRaises(ValueError): a.report(rows)

if __name__=="__main__": unittest.main()
