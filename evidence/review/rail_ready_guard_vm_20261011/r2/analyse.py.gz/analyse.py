"""Parseur fail-closed : compteurs NoAI sur le même tick, pas économie d'empire."""
from collections import defaultdict
import json
from pathlib import Path
import re
import statistics

CASES = ("absent", "search", "c121_prep_build")
SIZES = (1,8,32)
ARMS = ("EMPTY", "OFFA", "ON", "OFFB")
FIELDS = {"case","n","rep","arm","ops","tick0","tick1","group_tick","left0","left1","result","state_same"}
ROW_RE = re.compile(r"RRG\|case=[^\r\n]+")

def parse(raw):
    result = []
    for match in ROW_RE.finditer(raw):
        fields = {}
        for token in match[0].split("|")[1:]:
            key, value = token.split("=",1)
            if key in fields:
                raise ValueError("duplicate field: " + key)
            fields[key] = value if key in ("case","arm") else int(value)
        if set(fields) != FIELDS:
            raise ValueError("unexpected row fields")
        result.append(fields)
    done = re.findall(r"RRG_DONE\|rows=(\d+)",raw)
    if done != ["144"] or len(result) != 144:
        raise ValueError("incomplete or duplicate completion/rows")
    return result

def report(rows):
    groups = defaultdict(dict)
    for row in rows:
        key = row["case"],row["n"],row["rep"]
        if key[0] not in CASES or key[1] not in SIZES or key[2] not in range(4) or row["arm"] not in ARMS:
            raise ValueError("unexpected trial")
        if row["arm"] in groups[key]:
            raise ValueError("duplicate trial")
        if row["result"] != 0 or row["state_same"] != 1:
            raise ValueError("state mutation or a deferral")
        if row["ops"] < 0 or row["ops"] != row["left0"]-row["left1"]:
            raise ValueError("invalid opcode counter")
        if row["tick0"] != row["tick1"] or row["tick0"] != row["group_tick"]:
            raise ValueError("tick crossing: no VM-only interpretation permitted")
        groups[key][row["arm"]] = row
    if len(groups)!=36 or any(set(g)!=set(ARMS) for g in groups.values()):
        raise ValueError("missing group/arm")
    per_group = []
    for (case,n,rep), arms in sorted(groups.items()):
        if len({r["tick0"] for r in arms.values()})!=1:
            raise ValueError("arms on different ticks")
        if arms["OFFA"]["ops"]!=arms["OFFB"]["ops"]:
            raise ValueError("A/A unequal; no overhead attribution")
        off = (arms["OFFA"]["ops"]+arms["OFFB"]["ops"])/2
        empty = arms["EMPTY"]["ops"]
        per_group.append({"case":case,"n":n,"rep":rep,"tick":arms["ON"]["tick0"],
                          "empty_ops":empty,"off_raw_ops":off,"on_raw_ops":arms["ON"]["ops"],
                          "off_net_empty":off-empty,"on_net_empty":arms["ON"]["ops"]-empty,
                          "delta_batch":arms["ON"]["ops"]-off,
                          "delta_per_call":(arms["ON"]["ops"]-off)/n,
                          "raw":arms})
    cases = {}
    for case in CASES:
        data = [r for r in per_group if r["case"]==case]
        sizes = {}
        for n in SIZES:
            units = [r["delta_per_call"] for r in data if r["n"]==n]
            sizes[str(n)] = {"all_unit_deltas":units,"mean":statistics.mean(units),"min":min(units),"max":max(units)}
        units=[r["delta_per_call"] for r in data]
        cases[case] = {"per_call_min":min(units),"per_call_max":max(units),"batches":sizes,
                       "all_exact_zero":all(x==0 for x in units)}
    return {"validation":"valid_isolated_same_tick_vm_measurement", "groups":36,"records":144,
            "state_mutations":0,"deferrals":0,"tick_crossings":0,"aa_exact":True,
            "cases":cases,"per_group":per_group,
            "economic_verdict":"not_evaluated", "global_cpu_cost":"not_measured",
            "scheduler_visit_count":"unknown", "no_bottleneck_claim":True,
            "interpretation":"Fixed synthetic early-return states; no empirical visit weights or economic effect. Repetitions are not games/seeds."}

if __name__=="__main__":
    import sys
    output = report(parse(Path(sys.argv[1]).read_text(encoding="utf-8")))
    print(json.dumps(output,ensure_ascii=False,indent=2))
