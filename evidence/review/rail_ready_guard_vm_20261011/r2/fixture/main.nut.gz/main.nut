/* Detached NoAI fixture. No OpexAI, AAAHogEx or library imports.
 * guard.nut contains the frozen original helper body, with class name only adapted.
 * No callback below the early eligibility guards may be executed.
 */
RAIL_READY_READMISSION <- false;
DECISION_LOG <- false;
function OpexProjectAttemptKey(project) { throw "unexpected economic callback"; }
function OpexAvailableCapital() { throw "unexpected capital callback"; }
function OpexProjectFinanceCapital(project) { throw "unexpected finance callback"; }
function OpexDecide(a, b) { throw "unexpected decision/log callback"; }

function RRCanon(value) {
  local t = typeof value;
  if (t == "null") return "null";
  if (t != "table" && t != "array") return t + ":" + value.tostring();
  local text = t + "[";
  if (t == "array") {
    foreach (v in value) text += RRCanon(v) + ";";
  } else {
    local keys = [];
    foreach (k, v in value) keys.append(k);
    keys.sort();
    foreach (k in keys) text += k + "=" + RRCanon(value[k]) + ";";
  }
  return text + "]";
}

class RRGuardOwner {
  _railSearch = null;
  _projects = null;
  function _railReadyReadmissionShouldDefer(alreadyDeferred);
  function _projectsRankOfAttemptKey(key) { throw "unexpected rank callback"; }
  function Snapshot() { return RRCanon({search = this._railSearch, projects = this._projects}); }
  function Setup(name) {
    this._projects = { best = [{ mode="air", profitAnnual=100, capital=10 }] };
    this._railSearch = null;
    if (name != "absent") {
      this._railSearch = {kind="primary", phase="search", candidate={src=1,dst=2,cargo=0,kind="pax"}};
      if (name == "c121_prep_build") {
        this._railSearch.phase = "build";
        this._railSearch.isC121RailPrep <- true;
        this._railSearch.candidate.railPlan <- {ok=true};
      }
    }
  }
  function Envelope(n, empty) {
    local c77DeferCompletedRail = false;
    local checksum = 0;
    for (local i=0; i<n; i++) {
      local readyReAdmissionDeferred = empty ? false : (RAIL_READY_READMISSION
          && this._railReadyReadmissionShouldDefer(c77DeferCompletedRail));
      if (readyReAdmissionDeferred) checksum++;
    }
    return checksum;
  }
}
require("guard.nut");

class RRGuardOpcodeProbe extends AIController {
  function Start() {
    local owner = RRGuardOwner();
    local cases = ["absent", "search", "c121_prep_build"];
    local sizes = [1,8,32];
    local arms = ["EMPTY", "OFFA", "ON", "OFFB"];
    local rows = 0;
    foreach (name in cases) {
      owner.Setup(name);
      local original = owner.Snapshot();
      foreach (n in sizes) {
        for (local rep=0; rep<4; rep++) {
          /* A functional suspension aligns the isolated measurement group.
           * This fixture has no scheduler, purchases or production tasks. */
          AIController.Sleep(1);
          local groupTick = AIController.GetTick();
          local results = [];
          for (local j=0; j<4; j++) {
            local arm = arms[(j+rep)%4];
            RAIL_READY_READMISSION = arm == "ON";
            local empty = arm == "EMPTY";
            local tick0 = AIController.GetTick();
            local left0 = AIController.GetOpsTillSuspend();
            local result = owner.Envelope(n,empty);
            local left1 = AIController.GetOpsTillSuspend();
            local tick1 = AIController.GetTick();
            if (result != 0 || original != owner.Snapshot()) throw "non-neutral fixture state/result";
            results.append({arm=arm, tick0=tick0, tick1=tick1, left0=left0, left1=left1,
                            ops=left0-left1, result=result});
          }
          /* Logging and mutation checks are outside the measured envelope. */
          foreach (r in results) {
            AILog.Info("RRG|case="+name+"|n="+n+"|rep="+rep+"|arm="+r.arm
              +"|ops="+r.ops+"|tick0="+r.tick0+"|tick1="+r.tick1+"|group_tick="+groupTick
              +"|left0="+r.left0+"|left1="+r.left1+"|result="+r.result+"|state_same=1");
            rows++;
          }
        }
      }
    }
    AILog.Info("RRG_DONE|rows="+rows);
    while (true) AIController.Sleep(1);
  }
}
