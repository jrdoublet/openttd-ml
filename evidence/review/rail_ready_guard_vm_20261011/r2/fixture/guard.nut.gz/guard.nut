function RRGuardOwner::_railReadyReadmissionShouldDefer(alreadyDeferred)
{
  if (!RAIL_READY_READMISSION || this._railSearch == null
      || this._railSearch.kind != "primary" || this._railSearch.phase != "build"
      || this._railSearch.candidate == null
      || (("isC121RailPrep" in this._railSearch)
          && this._railSearch.isC121RailPrep)
      || this._projects == null || !("best" in this._projects)
      || this._projects.best == null || this._projects.best.len() == 0)
    return false;
  local state = this._railSearch;
  local rail = state.candidate;
  local railKey = "rail|" + rail.src + "|" + rail.dst + "|"
      + rail.cargo + "|" + rail.kind;
  local head = this._projects.best[0];
  if (head == null || !("mode" in head)
      || !("profitAnnual" in head) || head.profitAnnual <= 0
      || OpexProjectAttemptKey(head) == railKey) return false;
  local headKey = OpexProjectAttemptKey(head);
  local available = OpexAvailableCapital();
  if (OpexProjectFinanceCapital(head) > available) return false;
  local rank = this._projectsRankOfAttemptKey(railKey);
  if (rank == 0) return false;
  if (("readyReadmissionHeadKey" in state)
      && state.readyReadmissionHeadKey == headKey) return false;
  state.rawset("readyReadmissionHeadKey", headKey);
  if (DECISION_LOG) {
    OpexDecide("RAIL_READY_READMISSION", "action="
        + (alreadyDeferred ? "c77_shared" : "defer")
        + " head=" + headKey + " head_mode=" + head.mode
        + " rail_rank=" + rank + " head_finance="
        + OpexProjectFinanceCapital(head) + " available=" + available);
  }
  return !alreadyDeferred;
}
