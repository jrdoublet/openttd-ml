class RRGuardOpcodeProbeInfo extends AIInfo {
  function GetAuthor() { return "OpenTTD-ML"; }
  function GetName() { return "RRGuardOpcodeProbe"; }
  function GetShortName() { return "RRGV"; }
  function GetDescription() { return "Detached ineligible rail readmission guard VM microbenchmark; no projects"; }
  function GetVersion() { return 1; }
  function GetDate() { return "2026-10-11"; }
  function CreateInstance() { return "RRGuardOpcodeProbe"; }
  function GetAPIVersion() { return "15"; }
}
RegisterAI(RRGuardOpcodeProbeInfo());
