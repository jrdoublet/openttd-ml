"""Small scoped evidence package; reuse the existing review verifier contract."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / "evidence/review/rail_ready_guard_vm_20261011"
DEST.mkdir(exist_ok=True)
assert {p.name for p in DEST.iterdir()} <= {"README.md"}, "Existing package must not be replaced"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")

spec = importlib.util.spec_from_file_location("prior", ROOT / "results/rail_ready_autopsy_20261011_r1/analyse.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
old = ROOT / "results/rail_ready_guard_vm_20261011_r1"
new = ROOT / "results/rail_ready_guard_vm_20261011_r2"
before = json.loads((old / "production_before.json").read_text(encoding="utf-8"))
after = prior.worktree()
allowed_old = {"docs/taches.md", "docs/journaux/journal_2026-10-11.md"}
assert before["head"] == after["head"]
changed = sorted(p for p,h in before["files"].items() if after["files"].get(p) != h)
assert set(changed) == allowed_old, changed
added = set(after["files"]) - set(before["files"])
assert added == {"docs/rail_ready_guard_vm_20261011.md", "evidence/review/rail_ready_guard_vm_20261011/README.md"}, added
for folder in (old, new):
    plan = json.loads((folder / "preregistration.json").read_text(encoding="utf-8"))
    for name, h in plan["fixture"].items():
        assert sha((folder / "fixture" / name).read_bytes()) == h
    for name, h in plan["scripts"].items():
        assert sha((folder / name).read_bytes()) == h
    for asset in plan["assets"]:
        assert sha(Path(asset["path"]).read_bytes()) == asset["sha256"]
    assert sha((ROOT / plan["source_path"]).read_bytes()) == plan["source_file_sha256"]
assert all((old/"fixture"/p.name).read_bytes()==p.read_bytes() for p in (new/"fixture").iterdir())
dump(new/"final_verification.json", {
    "head_unchanged": True, "all_original_files_except_two_documentary_updates_unchanged": True,
    "original_file_count": len(before["files"]), "updated_documents": changed,
    "new_document": sorted(added), "fixtures_scripts_source_and_assets_hashes_verified": True,
    "r1_r2_fixtures_identical": True, "no_production_changes": True,
    "no_commit_or_push": True})
artifacts=[]
names={
    "r1": ["preregistration.json","launch.json","process.json","engine.log","report.md",
           "verification.json","run.py","analyse.py","prepare.py","test_analysis.py"],
    "r2": ["preregistration.json","launch.json","process.json","engine.log","captured_streams.log",
           "analysis.json","verification.json","final_verification.json","run.py","analyse.py","test_analysis.py"]}
for label, folder in (("r1", old),("r2",new)):
    paths=[folder/name for name in names[label]]
    paths.extend(sorted((folder/"fixture").glob("*.nut")))
    for path in paths:
        raw=path.read_bytes()
        packed=gzip.compress(raw,mtime=0)
        dest=DEST/label/(path.relative_to(folder).as_posix()+".gz")
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(packed)
        artifacts.append({"source":path.relative_to(ROOT).as_posix(),
                          "evidence":dest.relative_to(ROOT).as_posix(),
                          "raw_bytes":len(raw),"raw_sha256":sha(raw),
                          "gzip_bytes":len(packed),"gzip_sha256":sha(packed)})
for path in (ROOT/"results/prepare_rail_guard_capture_r2.py", Path(__file__)):
    raw=path.read_bytes(); packed=gzip.compress(raw,mtime=0)
    dest=DEST/(path.name+".gz"); dest.write_bytes(packed)
    artifacts.append({"source":path.relative_to(ROOT).as_posix(),"evidence":dest.relative_to(ROOT).as_posix(),
                      "raw_bytes":len(raw),"raw_sha256":sha(raw),"gzip_bytes":len(packed),"gzip_sha256":sha(packed)})
dump(DEST/"index.json", {"schema":"opex-review-evidence-v1", "artifacts":artifacts,
                         "scope":"Isolated early-return VM guard cost only; r1 invalid preserved; no economic qualification"})
excerpts=json.loads((ROOT/"evidence/review/rail_ready_autopsy_20261011/source_excerpts.json").read_text(encoding="utf-8"))
excerpts["files"]=[r for r in excerpts["files"] if r["bundle_relative_path"]=="ai/OpexAI/task_projects.nut"]
dump(DEST/"source_excerpts.json", excerpts)
shutil.copy2(ROOT/"evidence/review/rail_ready_autopsy_20261011/verify.py", DEST/"verify.py")
print(json.dumps({"archives":len(artifacts),"gzip_bytes":sum(r["gzip_bytes"] for r in artifacts),
                  "preservation":True}))
