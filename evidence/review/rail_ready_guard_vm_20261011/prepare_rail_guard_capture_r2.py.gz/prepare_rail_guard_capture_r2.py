"""Technical capture repair, preserving the invalid first launch verbatim."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent.parent
OLD = ROOT / "results/rail_ready_guard_vm_20261011_r1"
NEW = ROOT / "results/rail_ready_guard_vm_20261011_r2"
NEW.mkdir(exist_ok=False)
shutil.copytree(OLD / "fixture", NEW / "fixture")
for name in ("analyse.py", "test_analysis.py", "production_before.json"):
    shutil.copy2(OLD / name, NEW / name)
source = (OLD / "run.py").read_text(encoding="utf-8")
source = source.replace('"start_ai "+ai+"\\n"', '"script guard-console.log\\nstart_ai "+ai+"\\n"')
source = source.replace('[gui]\\nthreaded_saves', '[gui]\\ndeveloper = 2\\nthreaded_saves')
source = source.replace('"-c","openttdlab.cfg","-d","script=4"', '"-c","openttdlab.cfg","-x","-X","-d","script=4"')
source = source.replace('raw=proc.stdout+"\\n"+proc.stderr',
    '(HERE/"captured_streams.log").write_text(proc.stdout+"\\n"+proc.stderr,encoding="utf-8")\n'
    '        console=run/"guard-console.log"\n'
    '        raw=console.read_text(encoding="utf-8",errors="replace") if console.is_file() else ""')
assert source != (OLD / "run.py").read_text(encoding="utf-8")
(NEW / "run.py").write_text(source, encoding="utf-8")
plan = json.loads((OLD / "preregistration.json").read_text(encoding="utf-8"))
plan["scripts"] = {name: hashlib.sha256((NEW / name).read_bytes()).hexdigest()
                   for name in ("analyse.py", "run.py", "test_analysis.py")}
plan["technical_correction"] = {
    "previous": str(OLD.relative_to(ROOT)),
    "reason": "Empty Windows stdout/stderr capture, no RRG records; invalid, not an economic result",
    "changes": "Built-in console script logfile and developer=2 relay; -x/-X isolate configuration/search",
    "fixture_and_validity_unchanged": True,
    "sources": ["https://raw.githubusercontent.com/OpenTTD/OpenTTD/15.3/src/console_cmds.cpp",
                "https://raw.githubusercontent.com/OpenTTD/OpenTTD/15.3/src/debug.cpp"]}
(NEW / "preregistration.json").write_text(json.dumps(plan,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(NEW)
