# Mesure de la garde de réadmission — essai technique non validé

La mesure attendue est le surcoût VM de l'appel à
`_railReadyReadmissionShouldDefer` lorsqu'il retourne `false`, par rapport au
court-circuit OFF. Aucun résultat d'opcodes n'a été obtenu.

Le script détaché copie le corps complet de la fonction depuis le bundle
historique testé ; seul le nom de classe change. Il ne charge pas OpexAI,
n'achète aucun véhicule et ne construit aucune ligne. Les trois états préparés
sont : absence de recherche, recherche en cours, construction d'un tracé marqué
comme préparation C121. Ils ne représentent pas des parties économiques.

L'unique essai moteur a retourné le code 0, avec un journal d'un seul octet
(retour à la ligne) et aucune ligne `RRG` ni `RRG_DONE`. Il est invalide :
ni l'exécution complète de la fixture ni les compteurs VM ne sont établis.
Les six tests du parseur utilisent des données synthétiques et ne remplacent
pas cette mesure.

Le code officiel OpenTTD 15.3 appelle `CreateConsole` pour l'option `-d` sous
Windows ; cette fonction réouvre les flux sur `CONOUT$`. C'est un mécanisme
compatible avec l'absence de sortie capturée, pas une preuve que la fixture
a fonctionné :

- https://raw.githubusercontent.com/OpenTTD/OpenTTD/15.3/src/openttd.cpp (525–530)
- https://raw.githubusercontent.com/OpenTTD/OpenTTD/15.3/src/os/windows/win32.cpp (101–147)

À la suite de la réserve utilisateur sur la complexité, aucune nouvelle
adaptation du banc ni reprise moteur n'est engagée. Le dossier conserve la
préinscription, les sources, les hashes et l'essai invalide. Aucun défaut ni
politique ne change ; le rôle de cette garde dans la perte AIR demeure non
démontré. Ne pas convertir le code retour 0 ou les tests du parseur en preuve
d'exécution NoAI, de neutralité ou d'effet économique.

Aucun Docker, téléchargement, duel économique, commit ou push dans cette étape.
