"""Fige une fixture NoAI détachée et le pré-enregistrement avant exécution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BUNDLE = ROOT / "results/rail_ready_readmission_A2/rail_ready_readmission_diag_40x5_20261010_r1_bundle"
PATH = BUNDLE / "ai/OpexAI/task_projects.nut"
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
source = PATH.read_text(encoding="utf-8")
start = source.index("function OpexAI::_railReadyReadmissionShouldDefer(alreadyDeferred)")
end = source.index("/* Diagnostics communs", start)
helper = source[start:end].strip() + "\n"
current = (ROOT / "ai/OpexAI/task_projects.nut").read_text(encoding="utf-8")
current_helper = current[current.index("function OpexAI::_railReadyReadmissionShouldDefer(alreadyDeferred)"):current.index("/* Diagnostics communs", current.index("function OpexAI::_railReadyReadmissionShouldDefer(alreadyDeferred)"))].strip() + "\n"
fixture = HERE / "fixture"
fixture.mkdir(exist_ok=True)
guard = fixture / "guard.nut"
if guard.exists():
    raise FileExistsError("fixture already frozen")
guard.write_text(helper.replace("function OpexAI::", "function RRGuardOwner::", 1), encoding="utf-8", newline="")
before_spec = importlib.util.spec_from_file_location("baseline", ROOT / "results/rail_ready_autopsy_20261011_r1/analyse.py")
baseline = importlib.util.module_from_spec(before_spec)
before_spec.loader.exec_module(baseline)
(HERE / "production_before.json").write_text(json.dumps(baseline.worktree(), ensure_ascii=False, indent=2), encoding="utf-8")
cache_raw = subprocess.check_output([str(ROOT / ".venv/Scripts/python.exe"), "-B", "-c", 'from platformdirs import user_cache_dir; print(user_cache_dir(appname="OpenTTDLab",version="0.0.75"))'], text=True).strip()
cache = Path(cache_raw)
assets = [cache / "openttd-15.3-windows-win64.zip", cache / "opengfx-7.1-all.zip"]
assert all(p.is_file() for p in assets)
manifest = {"schema": "rail-ready-guard-vm-prereg-v1", "source_bundle_sha256": "250223deaebfb849cde5717888fd2b16942de22798c1385158d4a5ad51757ff8",
            "source_path": PATH.relative_to(ROOT).as_posix(), "source_file_sha256": sha(PATH),
            "source_helper_sha256": hashlib.sha256(helper.encode()).hexdigest(), "current_helper_identical": helper == current_helper,
            "helper_transformation": "Only class name OpexAI:: -> RRGuardOwner::; complete original body unchanged",
            "cases": ["absent", "search", "c121_prep_build"], "batch_sizes": [1,8,32], "repeats": 4,
            "arms": ["EMPTY","OFFA","ON","OFFB"], "rows_expected": 144, "groups_expected": 36,
            "case_order": "fixed preregistered absent,search,c121_prep_build; batch 1,8,32; rep 0..3",
            "arm_order": "Latin rotation of EMPTY,OFFA,ON,OFFB by rep; all arms in one tick per group",
            "primary_measure": "(ON - mean(OFFA,OFFB))/batch within same tick, after identical-envelope control",
            "baseline_measure": "EMPTY envelope counted in raw records; also subtract from each arm to retain net costs",
            "validity": ["complete 144 unique rows and DONE", "returned false and deep fixture state unchanged",
                         "no measured block crosses a tick", "all four arms in same tick per group", "OFFA and OFFB costs exactly equal",
                         "readmission body source hash checked", "callbacks after guarded early return must never execute"],
            "economic_equivalence": "not evaluated; no project, fleet, scheduler or profit allocation",
            "decision": "additional per-call VM cost establishes only first link; visit frequency and economic effect unknown",
            "opcode_equivalence_margin": "0 opcodes on same inputs/tick; zero overhead claim requires exact equality, not a p-value",
            "no_policy_rerun": True, "no_production_imports": True, "no_docker": True, "no_download": True,
            "native_engine": "cached OpenTTD 15.3 windows-win64", "opengfx": "7.1", "api": "15", "seed": 42,
            "ticks_ceiling": 4000, "timeout_seconds": 60,
            "existing_harness": {"path": "sweeps/rail_magic_opcode_microbench.py", "sha256": sha(ROOT / "sweeps/rail_magic_opcode_microbench.py"),
                                 "reused": "detached fixture packaging, temporary run directory/config/scripts, null drivers, script=4, parser pattern and completion checks; native ZIP/cache adaptation only"},
            "assets": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p)} for p in assets],
            "fixture": {p.name: sha(p) for p in sorted(fixture.glob("*.nut"))},
            "scripts": {p.name: sha(p) for p in sorted(HERE.glob("*.py"))}}
(HERE / "preregistration.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"helper_identical_to_current": helper == current_helper, "rows_planned": 144, "assets_available": True}))
