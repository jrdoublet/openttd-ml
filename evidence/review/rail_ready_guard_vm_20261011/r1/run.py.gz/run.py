"""Adaptation Windows/cache du harnais microbench courant, sans Docker/réseau."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    if (HERE/"engine.log").exists() or (HERE/"launch.json").exists():
        raise FileExistsError("No rerun in an already launched measurement directory")
    plan=json.loads((HERE/"preregistration.json").read_text(encoding="utf-8"))
    assert os.name=="nt", "This frozen adapter is for the cached Windows runtime only"
    old=load(ROOT/plan["existing_harness"]["path"],"existing_microbench")
    assert sha(ROOT/plan["existing_harness"]["path"])==plan["existing_harness"]["sha256"]
    assert old.VERSION=="15.3" and old.OPENGFX=="7.1"
    for name,h in plan["fixture"].items():
        assert sha(HERE/"fixture"/name)==h
    for name,h in plan["scripts"].items():
        assert sha(HERE/name)==h
    for asset in plan["assets"]:
        assert sha(Path(asset["path"]))==asset["sha256"]
    parser=load(HERE/"analyse.py","guard_analyser")
    prehash=sha(HERE/"preregistration.json")
    with tempfile.TemporaryDirectory(prefix="rail-ready-guard-vm-") as root_str:
        temp=Path(root_str).resolve()
        run=temp/"rundir"
        assert run.resolve().is_relative_to(temp)
        for part in ("baseset","scripts","ai"):
            (run/part).mkdir(parents=True)
        # Same cached-assets packaging and null-driver command as the existing
        # microbench, with ZIP extraction for the platform's pinned executable.
        with zipfile.ZipFile(plan["assets"][0]["path"]) as z:
            z.extractall(temp)
        with zipfile.ZipFile(plan["assets"][1]["path"]) as z:
            z.extractall(run/"baseset")
        ai="RRGuardOpcodeProbe"
        with tarfile.open(run/"ai"/(ai+".tar"),"w") as tf:
            tf.add(HERE/"fixture",arcname=ai)
        (run/"scripts/game_start.scr").write_text("start_ai "+ai+"\n",encoding="utf-8")
        (run/"openttdlab.cfg").write_text("[difficulty]\nnumber_towns = 3\nindustry_density = 4\n[economy]\ninflation = false\n[game_creation]\nstarting_year = 1970\nmap_x = 8\nmap_y = 8\n[gui]\nthreaded_saves = false\nautosave = off\n",encoding="utf-8")
        binary=temp/("openttd-"+old.VERSION+"-windows-win64")/"openttd.exe"
        if not binary.is_file():
            raise FileNotFoundError("Expected pinned binary not found in archive")
        cmd=[str(binary),"-g","-G",str(plan["seed"]),"-snull","-mnull",
             "-vnull:ticks="+str(plan["ticks_ceiling"]),"-c","openttdlab.cfg","-d","script=4"]
        launch={"command":cmd,"preregistration_sha256":prehash,"engine_binary_sha256":sha(binary),
                "runtime":"OpenTTD 15.3 native cached Windows / API15 / OpenGFX7.1","no_docker":True,"no_download":True,"no_economic_duel":True}
        (HERE/"launch.json").write_text(json.dumps(launch,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        startup=subprocess.STARTUPINFO()
        startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow=subprocess.SW_HIDE
        try:
            proc=subprocess.run(cmd,cwd=run,text=True,encoding="utf-8",errors="replace",capture_output=True,
                                timeout=plan["timeout_seconds"],startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW)
        except subprocess.TimeoutExpired as exc:
            (HERE/"failure.json").write_text(json.dumps({"status":"timeout","seconds":plan["timeout_seconds"]}),encoding="utf-8")
            raise
        raw=proc.stdout+"\n"+proc.stderr
        (HERE/"engine.log").write_text(raw,encoding="utf-8",newline="")
        (HERE/"process.json").write_text(json.dumps({"exit_code":proc.returncode}),encoding="utf-8")
        if proc.returncode!=0 or "Your script made an error" in raw or "FATAL" in raw:
            raise RuntimeError("Native microbench failed: "+raw[-4500:])
        result=parser.report(parser.parse(raw))
        result["preregistration_sha256"]=prehash
        result["engine_log_sha256"]=sha(HERE/"engine.log")
        (HERE/"analysis.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        print(json.dumps({"validation":result["validation"],"cases":result["cases"]},ensure_ascii=False))

if __name__=="__main__":
    main()
