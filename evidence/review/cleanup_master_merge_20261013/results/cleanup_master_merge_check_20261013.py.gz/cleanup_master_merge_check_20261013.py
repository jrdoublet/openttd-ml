from pathlib import Path
import io
import json
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent / 'c118_c119_merge_stage_20261012'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'sweeps'))
from sweeps.campaign_freeze import parse_ai_setting_specs

incoming = subprocess.check_output(['rtk', 'proxy', 'git', 'show', 'c309272:ai/OpexAI/info.nut'], cwd=ROOT, text=True, encoding='utf-8')
snapshot = ROOT / 'results/master_info_before_cleanup_merge_20261013.nut'
snapshot.write_text(incoming, encoding='utf-8')
expected = parse_ai_setting_specs(snapshot)
for obsolete in ('c118_air_territorial_expansion', 'c119_air_income_model', 'c120_air_territorial_ranking'):
    assert obsolete in expected
    expected.pop(obsolete)
actual = parse_ai_setting_specs(ROOT / 'ai/OpexAI/info.nut')
assert expected == actual
for p in (ROOT / 'ai/OpexAI').glob('*.nut'):
    source = p.read_text(encoding='utf-8')
    for symbol in ('C118_AIR_TERRITORIAL_EXPANSION', 'C119_AIR_INCOME_MODEL', 'C120_', 'c120NewTowns', 'OpexC120', 'AIR_TERRITORIAL_COVERAGE'):
        assert symbol not in source, (p, symbol)
incoming_builder = subprocess.check_output(['rtk', 'proxy', 'git', 'show', 'c309272:ai/OpexAI/projects_builders.nut'], cwd=ROOT, text=True, encoding='utf-8')
removed = '''  if (C118_AIR_TERRITORIAL_EXPANSION) {
    project.c118TownIds <- OpexC118PlanCoverageTowns(plan, catalog.paxCargo);
    local c68 = (("c118C68Economics") in plan) ? plan.c118C68Economics : economics;
    project.c118C68Profit <- c68 != null ? c68.profitAnnual : economics.profitAnnual;
    project.c118C68Roi <- c68 != null ? c68.roi : economics.roi;
  }
'''
assert incoming_builder.count(removed) == 1
assert incoming_builder.replace(removed, '') == (ROOT / 'ai/OpexAI/projects_builders.nut').read_text(encoding='utf-8')

modules = json.loads((ROOT / 'results/cleanup_c120_contracts_20261012.json').read_text(encoding='utf-8'))['modules']
modules += ['test_v159_c117_lean', 'test_v161_fleet_net_marginal']
stream = io.StringIO()
suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('sweeps.' + m) for m in modules)
result = unittest.TextTestRunner(stream=stream, verbosity=1).run(suite)
record = {'modules': modules, 'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped), 'pass': result.wasSuccessful(), 'other_settings_match_origin_master': True, 'merged_builder_equals_origin_without_C118_annotation': True, 'output': stream.getvalue()}
(ROOT / 'results/cleanup_master_merge_contracts_20261013.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(stream.getvalue())
print({k:v for k,v in record.items() if k not in ('modules','output')})
sys.exit(0 if result.wasSuccessful() else 1)
