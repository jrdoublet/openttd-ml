"""Descriptive V216 contrasts using the supplied parser, without new simulation."""
import collections
import importlib.util
import json
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('v216', root / 'v216_facto_analyse.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cells = [('A', 'aaacomplet', 'ref'), ('B', 'aaarail', 'complet'),
         ('C', 'aaacomplet', 'railseul'), ('D', 'aaarail', 'ref')]
out = {}
for cell, kind, policy in cells:
    campaign = f'v216_facto_{kind}_40x3_pc_20261015'
    groups = collections.defaultdict(list)
    seeds = collections.defaultdict(set)
    for path in sorted((root / (campaign + '_engine')).glob(f'{policy}_seed*_r0.log')):
        seed = int(re.search(r'_seed(\d+)_r0', path.name)[1])
        rows, _, _ = module.parse_log(path)
        for mode, cargo, *values in rows:
            key = f'{mode}:{cargo}'
            groups[key].append(values)
            seeds[key].add(seed)
    out[cell] = {}
    for key, rows in groups.items():
        out[cell][key] = {
            'lines': len(rows), 'seeds': len(seeds[key]),
            'revenue_sum_ratio': sum(r[1] for r in rows) / sum(r[0] for r in rows),
            'profit_sum_ratio': sum(r[3] for r in rows) / sum(r[2] for r in rows),
        }
contrasts = {}
for name, a, b in [('our_full_over_rail_aaa_full', 'A', 'C'),
                   ('our_full_over_rail_aaa_rail', 'B', 'D'),
                   ('aaa_full_over_rail_our_full', 'A', 'B'),
                   ('aaa_full_over_rail_our_rail', 'C', 'D')]:
    contrasts[name] = out[a]['rail:PASS']['revenue_sum_ratio'] / out[b]['rail:PASS']['revenue_sum_ratio']
result = {'cells': out, 'rail_pass_revenue_ratio_contrasts': contrasts,
          'warning': 'Descriptive ratios across selected line cohorts; no causal airport or cannibalisation estimate.'}
(root / 'v216_facto_pc_20261015.contrasts.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
