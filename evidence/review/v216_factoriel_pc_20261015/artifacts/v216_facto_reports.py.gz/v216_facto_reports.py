"""Assemble V216 reports from the supplied analysis and existing harness outputs."""
import collections
import contextlib
import importlib.util
import io
import json
import pathlib
import statistics
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('v216_analysis', ROOT / 'v216_facto_analyse.py')
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
DATE = '20261015'
CAMPAIGNS = [
    (f'v216_facto_aaarail_40x3_pc_{DATE}', ('ref', 'complet')),
    (f'v216_facto_aaacomplet_40x3_pc_{DATE}', ('ref', 'railseul')),
]


def load(campaign):
    return json.loads((ROOT / (campaign + '.json')).read_text(encoding='utf-8'))


def healthy(record):
    return (record.get('run_ok') and record.get('game_ok')
            and record.get('horizon_complete')
            and record.get('include_in_economic_stats', True))


def means(data, policy, arm):
    rows = [r for r in data['summary'] if r['duel_policy_id'] == policy and r['arm'] == arm]
    values = [r['profit_year'] for r in rows if healthy(r) and r.get('profit_year') is not None]
    return (statistics.mean(values) if values else None), len(values), len(rows)


def fmt(value):
    return f'{value:,.0f}' if value is not None else 'non disponible'


def exclusions(data):
    lines = []
    for g in data['games']:
        if not g.get('game_ok'):
            detail = '; '.join(f'{a}: {c.get("status")}, {c.get("failure_reason")}'
                               for a, c in g['companies'].items())
            lines.append(f'- {g["policy_id"]}, graine {g["seed"]}, répétition {g["repeat"]}: {detail}.')
    for r in data['summary']:
        if not healthy(r) and not any(not g.get('game_ok') and g['game_id'] == r['game_id'] for g in data['games']):
            lines.append(f'- {r["duel_policy_id"]}, {r["arm"]}, graine {r["seed"]}: {r.get("status")}, {r.get("failure_reason")}.')
    return '\n'.join(lines) or 'Aucune graine exclue ou plantée.'


def campaign_report(campaign, policies):
    data = load(campaign)
    completed = sum(bool(g.get('game_ok')) for g in data['games'])
    buffer = io.StringIO()
    argv = sys.argv
    try:
        sys.argv = ['v216_facto_analyse.py', str(ROOT), campaign, *policies]
        with contextlib.redirect_stdout(buffer):
            analysis.main()
    finally:
        sys.argv = argv
    output = buffer.getvalue()
    (ROOT / (campaign + '.v216.md')).write_text(output, encoding='utf-8')
    launch = (ROOT / (campaign + '.launch.log')).read_text(encoding='utf-8-sig')
    raw = [line for line in launch.splitlines() if line.startswith(('profit_year: delta', 'company_value: ratio', 'paires='))]
    text = [f'# {campaign}', '',
            'Diagnostic factoriel V216 pré-enregistré. Les verdicts bruts du lanceur sont reproduits sans interprétation ni adoption.', '',
            f'Parties saines : {completed}/{len(data["games"])} ; paires complètes : {data["policy_comparison"]["complete_pairs"]}/40.',
            f'Bundle : `{data["source_bundle_sha256"]}` ; manifeste : `{data["manifest_sha256"]}`.', '',
            '```text', *raw, '```', '',
            '| Bras | OpexAI profit_year moyen (£/an) | n | AAAHogEx profit_year moyen (£/an) | n |',
            '|---|---:|---:|---:|---:|']
    for policy in policies:
        op, on, total = means(data, policy, 'OpexAI')
        aa, an, _ = means(data, policy, 'AAAHogEx')
        text.append(f'| {policy} | {fmt(op)} | {on}/{total} | {fmt(aa)} | {an}/{total} |')
    text += ['', 'Moyennes calculées sur les parties saines de chaque bras avec profit annuel présent ; les exclusions du comparatif apparié peuvent donc différer.', '',
             'Graines exclues ou plantées :', '', exclusions(data), '',
             'Le script fourni analyse tous les journaux disponibles, y compris ceux des parties signalées ci-dessus. Les tables suivantes sont sa sortie intégrale, sans filtrage ajouté.', '', output]
    (ROOT / (campaign + '.summary.md')).write_text('\n'.join(text), encoding='utf-8')
    return data


def group_metrics(campaign, policy):
    groups = collections.defaultdict(list)
    rail, air = collections.Counter(), collections.Counter()
    for path in sorted((ROOT / (campaign + '_engine')).glob(f'{policy}_seed*_r0.log')):
        rows, rb, ab = analysis.parse_log(path)
        for mode, cargo, *values in rows:
            groups[(mode.lower(), cargo)].append(values)
        rail.update(rb)
        air.update(ab)
    return groups, rail, air


def ratios(rows, profit=False, median=True):
    if not rows:
        return 'n=0 ; non disponible'
    index = 2 if profit else 0
    med = statistics.median(r[index + 1] / r[index] for r in rows)
    ratio = sum(r[index + 1] for r in rows) / sum(r[index] for r in rows)
    return ((f'n={len(rows)} ; ' if not profit else '')
            + (f'méd. {med:.2f} ; ' if median else '') + f'Σ {ratio:.2f}')


def global_report():
    datasets = {c: campaign_report(c, p) for c, p in CAMPAIGNS}
    f1, f2 = CAMPAIGNS[0][0], CAMPAIGNS[1][0]
    cells = [('A', f2, 'ref', 'Opex complet / AAA complet'),
             ('B', f1, 'complet', 'Opex complet / AAA rail'),
             ('C', f2, 'railseul', 'Opex rail / AAA complet'),
             ('D', f1, 'ref', 'Opex rail / AAA rail')]
    text = ['# V216 — diagnostic factoriel PC', '',
            'Exécution depuis master à la demande utilisateur, SHA `92c86206bcc37086626415f0805f0d4512524111`. Diff `3ad94b5..HEAD` nul pour `ai/`, `sweeps/` et `requirements.txt` ; seul fichier local non suivi : `docs/journaux/journal_2026-10-14_transfert_taches.md`.', '',
            'Contrats exécutés au commit prescrit : 2 235 tests, OK, 3 ignorés. Première tentative limitée par les droits du bac à sable ; réexécution avec accès approprié verte. Premier lancement dans le worktree arrêté avant toute partie ; aucun artefact moteur V216 créé. Reprise sur master, conformément à la nouvelle instruction utilisateur.', '',
            'F1 puis F2, chacun précédé d’un smoke 1×3. Profil 10 CPU, 8 Go et 10 workers ; campagnes principales 40 graines canoniques × 3 ans, une répétition. Diagnostic uniquement : aucune interprétation du verdict du lanceur et aucun défaut modifié.', '',
            'Profit annuel terminal en £/an, décembre 1972. Les ratios suivent exactement le script fourni : lignes construites en 1971 avec au moins 180 jours d’activité avant 1972, revenus annualisés, rail ramené au nombre initial de trains. Les nombres de constructions sont les totaux sur les journaux du bras, dans l’ordre 1970 / 1971 / 1972.', '',
            '| Cellule | Configuration | OpexAI moyen (£/an ; n) | AAAHogEx moyen (£/an ; n) | Rail PASS recette réel/prévu (n ; médiane ; ratio sommes) | Rail PASS profit réel/prévu (médiane ; ratio sommes) | Rail fret recette réel/prévu (n ; ratio sommes) | AIR recette réel/prévu (n ; ratio sommes) | RAIL_BUILD PASS 1970/71/72 | RAIL_BUILD fret 1970/71/72 | AIR_BUILD 1970/71/72 |',
            '|---|---|---:|---:|---|---|---|---|---|---|---|']
    for cell, campaign, policy, label in cells:
        d = datasets[campaign]
        op, on, _ = means(d, policy, 'OpexAI')
        aa, an, _ = means(d, policy, 'AAAHogEx')
        groups, rb, ab = group_metrics(campaign, policy)
        rp = groups[('rail', 'PASS')]
        rf = groups[('rail', 'freight')]
        air = [row for (mode, _), rows in groups.items() if mode == 'air' for row in rows]
        counts = lambda values: ' / '.join(str(values[y]) for y in (1970, 1971, 1972))
        text.append(f'| {cell} | {label} | {fmt(op)} ; {on} | {fmt(aa)} ; {an} | {ratios(rp)} | {ratios(rp, profit=True)} | {ratios(rf, median=False)} | {ratios(air, median=False) if cell in ("A", "B") else "—"} | {counts({y: rb[(y, "PASS")] for y in (1970, 1971, 1972)})} | {counts({y: rb[(y, "freight")] for y in (1970, 1971, 1972)})} | {counts(ab)} |')
    text += ['', 'Moyennes sur les parties saines de chaque bras. Les ratios et constructions incluent tous les journaux, conformément au script fourni ; n désigne ici des lignes, pas des graines indépendantes. Co-localisation observationnelle, sans attribution causale.', '']
    for cell, campaign, policy, _ in cells[:2]:
        text += [f'## Co-localisation — cellule {cell}', '',
                 '| Nombre de villes de la ligne rail PASS avec notre aéroport | Lignes présentes en décembre 1971 | Profit 1972/train médian (£/an) | Moyen (£/an) |',
                 '|---:|---:|---:|---:|']
        res = analysis.coloc(str(ROOT / (campaign + '.jsonl')), policy)
        for k in sorted(res):
            vals = res[k]
            text.append(f'| {k} | {len(vals)} | {statistics.median(vals):.0f} | {statistics.mean(vals):.0f} |')
        if not res:
            text.append('| — | 0 | non disponible | non disponible |')
        text.append('')
    for campaign, _ in CAMPAIGNS:
        d = datasets[campaign]
        text += [f'## Santé et exclusions — {campaign}', '',
                 f'{sum(bool(g.get("game_ok")) for g in d["games"])}/{len(d["games"])} parties saines ; {d["policy_comparison"]["complete_pairs"]}/40 paires complètes.', '', exclusions(d), '',
                 f'Rapport détaillé : [{campaign}.summary.md]({campaign}.summary.md).', '']
    path = ROOT / f'v216_facto_pc_{DATE}.summary.md'
    path.write_text('\n'.join(text), encoding='utf-8')
    print(path)
    print('\n'.join(text))


if __name__ == '__main__':
    if len(sys.argv) > 1:
        for c, p in CAMPAIGNS:
            if c == sys.argv[1]:
                campaign_report(c, p)
                print(ROOT / (c + '.summary.md'))
                break
        else:
            raise SystemExit('unknown campaign')
    else:
        global_report()
