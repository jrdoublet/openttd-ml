# v216_facto_aaacomplet_40x3_pc_20261015

Diagnostic factoriel V216 pré-enregistré. Les verdicts bruts du lanceur sont reproduits sans interprétation ni adoption.

Parties saines : 80/80 ; paires complètes : 40/40.
Bundle : `af92af4176593a1eea498162794d51545dfd6726d607ac3933c2a5c7f62aaf5f` ; manifeste : `286a7981d9a7eac342b7943b28c614c59f5e9b3609d6ab4feeffb101277c9a7d`.

```text
profit_year: delta moyen=-1708628.25 median=-1770299.0 V/D/E=0/40/0 p_wilcoxon=1.8189894035458565e-12 CI95_bootstrap=[-1890747.15, -1526694.3] seuil=83914.602 (pct=4.0)
company_value: ratio des moyennes=0.151115 (-84.888507%), moyenne des ratios=0.160529
paires=40/40 verdict=fail_primary_and_value_guard
```

| Bras | OpexAI profit_year moyen (£/an) | n | AAAHogEx profit_year moyen (£/an) | n |
|---|---:|---:|---:|---:|
| ref | 2,097,865 | 40/40 | 2,006,044 | 40/40 |
| railseul | 389,237 | 40/40 | 3,058,666 | 40/40 |

Moyennes calculées sur les parties saines de chaque bras avec profit annuel présent ; les exclusions du comparatif apparié peuvent donc différer.

Graines exclues ou plantées :

Aucune graine exclue ou plantée.

Le script fourni analyse tous les journaux disponibles, y compris ceux des parties signalées ci-dessus. Les tables suivantes sont sa sortie intégrale, sans filtrage ajouté.

## v216_facto_aaacomplet_40x3_pc_20261015

### policy `ref`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| air | PASS | 298 | 0.57 | 0.58 | 0.53 | 0.55 | 127159 | 69369 |
| rail | PASS | 15 | 0.16 | 0.18 | 0.04 | 0.03 | 12127 | 395 |
| rail | freight | 81 | 0.80 | 0.87 | 0.84 | 0.90 | 26443 | 23762 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 329 | 809 | 516 |
| RAIL_BUILD PASS | 0 | 33 | 79 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 0 | 93 | 67 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 1 | -2509 | -2509 |
| 1 | 9 | 2640 | 2103 |
| 2 | 15 | 3510 | 3840 |

### policy `railseul`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| rail | PASS | 19 | 0.78 | 0.81 | 0.81 | 0.93 | 5188 | 4827 |
| rail | freight | 51 | 1.05 | 1.06 | 1.10 | 1.13 | 27750 | 31234 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 0 | 0 | 0 |
| RAIL_BUILD PASS | 107 | 41 | 50 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 178 | 110 | 129 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 146 | 6708 | 8164 |

