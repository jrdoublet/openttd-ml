## v216_facto_aaacomplet_40x3_pc_20261015

### policy `ref`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| air | PASS | 298 | 0.57 | 0.58 | 0.53 | 0.55 | 127159 | 69369 |
| rail | PASS | 15 | 0.16 | 0.18 | 0.04 | 0.03 | 12127 | 395 |
| rail | freight | 81 | 0.80 | 0.87 | 0.84 | 0.90 | 26443 | 23762 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 329 | 809 | 516 |
| RAIL_BUILD PASS | 0 | 33 | 79 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 0 | 93 | 67 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 1 | -2509 | -2509 |
| 1 | 9 | 2640 | 2103 |
| 2 | 15 | 3510 | 3840 |

### policy `railseul`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| rail | PASS | 19 | 0.78 | 0.81 | 0.81 | 0.93 | 5188 | 4827 |
| rail | freight | 51 | 1.05 | 1.06 | 1.10 | 1.13 | 27750 | 31234 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 0 | 0 | 0 |
| RAIL_BUILD PASS | 107 | 41 | 50 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 178 | 110 | 129 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 146 | 6708 | 8164 |

