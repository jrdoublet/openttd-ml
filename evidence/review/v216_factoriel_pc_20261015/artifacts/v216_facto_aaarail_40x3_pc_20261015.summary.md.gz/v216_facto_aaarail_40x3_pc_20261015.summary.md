# v216_facto_aaarail_40x3_pc_20261015

Diagnostic factoriel V216 pré-enregistré. Les verdicts bruts du lanceur sont reproduits sans interprétation ni adoption.

Parties saines : 80/80 ; paires complètes : 40/40.
Bundle : `af92af4176593a1eea498162794d51545dfd6726d607ac3933c2a5c7f62aaf5f` ; manifeste : `2b96e5899b54e92c0bad5ffbfc1c8054825f1edcd798c586e4d2cda2247290a5`.

```text
profit_year: delta moyen=2967028.7 median=2965043.0 V/D/E=40/0/0 p_wilcoxon=1.8189894035458565e-12 CI95_bootstrap=[2765050.525, 3167651.0] seuil=11931.256000000001 (pct=4.0)
company_value: ratio des moyennes=12.166974 (1116.697407%), moyenne des ratios=14.181493
paires=40/40 verdict=pass
```

| Bras | OpexAI profit_year moyen (£/an) | n | AAAHogEx profit_year moyen (£/an) | n |
|---|---:|---:|---:|---:|
| ref | 298,281 | 40/40 | 1,361,172 | 40/40 |
| complet | 3,265,310 | 40/40 | 1,508,463 | 40/40 |

Moyennes calculées sur les parties saines de chaque bras avec profit annuel présent ; les exclusions du comparatif apparié peuvent donc différer.

Graines exclues ou plantées :

Aucune graine exclue ou plantée.

Le script fourni analyse tous les journaux disponibles, y compris ceux des parties signalées ci-dessus. Les tables suivantes sont sa sortie intégrale, sans filtrage ajouté.

## v216_facto_aaarail_40x3_pc_20261015

### policy `ref`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| rail | PASS | 24 | 1.04 | 1.06 | 1.59 | 1.35 | 5605 | 7555 |
| rail | freight | 50 | 0.72 | 0.73 | 0.74 | 0.75 | 34454 | 25726 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 0 | 0 | 0 |
| RAIL_BUILD PASS | 97 | 43 | 32 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 182 | 100 | 104 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 136 | 10724 | 10659 |

### policy `complet`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| air | PASS | 451 | 0.67 | 0.70 | 0.64 | 0.67 | 118294 | 79254 |
| rail | PASS | 10 | 0.27 | 0.24 | 0.19 | 0.15 | 16753 | 2463 |
| rail | freight | 60 | 0.65 | 0.80 | 0.65 | 0.83 | 21457 | 17882 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 381 | 1089 | 501 |
| RAIL_BUILD PASS | 0 | 13 | 33 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 0 | 61 | 44 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 1 | 2 | 2656 | 2656 |
| 2 | 10 | 1144 | 2010 |

