## v216_facto_aaarail_40x3_pc_20261015

### policy `ref`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| rail | PASS | 24 | 1.04 | 1.06 | 1.59 | 1.35 | 5605 | 7555 |
| rail | freight | 50 | 0.72 | 0.73 | 0.74 | 0.75 | 34454 | 25726 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 0 | 0 | 0 |
| RAIL_BUILD PASS | 97 | 43 | 32 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 182 | 100 | 104 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 0 | 136 | 10724 | 10659 |

### policy `complet`: 40 games

| mode | cargo | n | revenue median | revenue sum ratio | profit median | profit sum ratio | mean pred profit | mean real profit |
|---|---|---|---|---|---|---|---|---|
| air | PASS | 451 | 0.67 | 0.70 | 0.64 | 0.67 | 118294 | 79254 |
| rail | PASS | 10 | 0.27 | 0.24 | 0.19 | 0.15 | 16753 | 2463 |
| rail | freight | 60 | 0.65 | 0.80 | 0.65 | 0.83 | 21457 | 17882 |

| builds | 1970 | 1971 | 1972 |
|---|---|---|---|
| AIR_BUILD | 381 | 1089 | 501 |
| RAIL_BUILD PASS | 0 | 13 | 33 |
| RAIL_BUILD MAIL | 0 | 0 | 0 |
| RAIL_BUILD freight | 0 | 61 | 44 |

| rail PASS lines (Dec 1971) by # of their towns with our airport | lines | 1972 profit/train median | mean |
|---|---|---|---|
| 1 | 2 | 2656 | 2656 |
| 2 | 10 | 1144 | 2010 |

