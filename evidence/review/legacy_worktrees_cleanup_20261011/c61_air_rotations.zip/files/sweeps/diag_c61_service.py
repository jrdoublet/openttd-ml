"""Copy-only bounded C61 service collection using the existing duel collector."""
from __future__ import annotations
import argparse
from collections import defaultdict
from datetime import date
import json
import os
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "sweeps"))
from run_mechanism_fixtures import replace_once, tree_hashes
from harness import parse_fields


def instrument(target):
    shutil.copy2(ROOT / "tests/mechanisms/c61_service_probe.nut", target / "c61_service_probe.nut")
    path = target / "main.nut"
    text = replace_once(path.read_text(encoding="utf-8"), "function OpexAI::Start()",
                        'require("c61_service_probe.nut");\n\nfunction OpexAI::Start()')
    text = replace_once(text, "    this._processEvents();",
                       "    this._processEvents();\n    C61Sample(this._lines, this._catalog);")
    path.write_text(text, encoding="utf-8")


def inspect_log(text, expected):
    rows = []
    foreign = 0
    for line in text.splitlines():
        match = re.search(r"\[script:\d+\]\s*\[(\d+)\].*?C61_(SAMPLE|COVERAGE)\s+(.*)", line)
        if not match:
            continue
        if match[1] != "0":
            foreign += 1
            continue
        rows.append({"kind": match[2], **parse_fields(match[3])})
    coverage = [r for r in rows if r["kind"] == "COVERAGE"]
    samples = [r for r in rows if r["kind"] == "SAMPLE"]
    return {"identity_pass": foreign == 0 and (bool(coverage) if expected else not rows),
            "foreign": foreign, "coverage": coverage, "samples": samples,
            "at_station_samples": sum(str(r.get("at_station")) == "1" for r in samples),
            "in_depot_samples": sum(str(r.get("in_depot")) == "1" for r in samples),
            "time_weighted_wait": None, "congestion_verdict": "not_measured"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--opponent", type=Path, required=True)
    args = parser.parse_args()
    import openttdlab
    import diag_cadence_duel as duel
    folder = args.out.resolve()
    folder.mkdir(parents=True, exist_ok=False)
    years, seeds = 1, [42]
    arms = {}
    for name in ("reference", "trace"):
        target = folder / "copies" / name / "OpexAI"
        shutil.copytree(ROOT / "ai/OpexAI", target)
        if name == "trace":
            instrument(target)
        arms[name] = openttdlab.local_folder(str(target), "OpexAI", ())
    opponent = folder / "copies/AAAHogEx-115"
    shutil.copytree(args.opponent, opponent)
    aaa = openttdlab.local_folder(str(opponent), "AAAHogEx")
    frozen = tree_hashes(folder / "copies")
    cfg = duel.bench_v2.make_cfg(1970)
    plan = {"kind": "technical_probe_on_off_not_adoption", "years": years, "seeds": seeds,
            "git_sha": os.environ.get("DIAG_GIT_SHA"),
            "image": os.environ.get("DIAG_DOCKER_IMAGE_ID"), "configuration": cfg,
            "copies": frozen, "workers": 1, "source_loading": "separate_invocation_per_arm",
            "resolved_settings": duel.bench_v2.resolve_opex_arm_settings("OpexAI")}
    (folder / "plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    experiments = [{"arm": name, "seed": seed, "years": years,
                    "days": (date(1971, 1, 1) - date(1970, 1, 1)).days + 32,
                    "openttd_config": cfg, "ais": (arms[name], aaa),
                    "log_path": str(folder / f"{name}_{seed}.log"),
                    "checkpoint_path": str(folder / f"{name}_{seed}.jsonl")}
                   for name in arms for seed in seeds]
    duel.bench_v2.enable_savegame_cleanup()
    duel.enable_script_debug()
    duel.enable_engine_failure_capture()
    rows = []
    for exp in experiments:
        rows.extend(openttdlab.run_experiments(experiments=[exp], max_workers=1,
                    openttd_version=duel.bench_v2.OPENTTD_VERSION,
                    opengfx_version=duel.bench_v2.OPENGFX_VERSION, result_processor=duel.collect,
                    ai_libraries=(openttdlab.bananas_ai_library("51554648", "Queue.FibonacciHeap"),
                                  openttdlab.bananas_ai_library("5046524c", "Pathfinder.Rail"))))
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["arm"], row["seed"]].append(row)
    games = [duel.finish_game(series, years) for series in grouped.values()]
    probes = {name: inspect_log((folder / f"{name}_42.log").read_text(encoding="utf-8"), name == "trace")
              for name in arms}
    checks = {"games": len(games) == 2 and all(g["valid"] for g in games),
              "probe_identity": all(p["identity_pass"] for p in probes.values()),
              "vehicle_exposure": bool(probes["trace"]["samples"]),
              "copies_unchanged": frozen == tree_hashes(folder / "copies")}
    report = {"checks": checks, "games": games, "probe": probes,
              "perturbation_descriptive": duel.compare(games, list(arms), seeds, years),
              "economic_qualification": False}
    (folder / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(checks), flush=True)
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
