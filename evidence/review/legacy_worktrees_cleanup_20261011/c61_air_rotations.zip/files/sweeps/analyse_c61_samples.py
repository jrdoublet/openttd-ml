"""Coverage of C61 sampled states; no interpolation of airport waiting."""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path


def analyse(probe):
    coverage = probe["coverage"]
    samples = probe["samples"]
    seqs = [int(r["seq"]) for r in coverage]
    if seqs != list(range(1, len(seqs) + 1)):
        raise ValueError("Coverage sequence gap or duplication")
    by_seq = Counter(int(r["seq"]) for r in samples)
    previous = None
    for row in coverage:
        seq, day = int(row["seq"]), int(row["day"])
        if by_seq[seq] != int(row["logged"]):
            raise ValueError("Missing vehicle samples")
        if previous is not None and (day <= previous or int(row["gap"]) != day - previous):
            raise ValueError("Invalid sample timing")
        previous = day
    if any(seq not in seqs for seq in by_seq):
        raise ValueError("Samples without coverage")
    gaps = [int(row["gap"]) for row in coverage if int(row["gap"]) >= 0]
    unknown = sum(gap for gap in gaps if gap > 4)
    return {
        "coverage_records": len(coverage), "vehicle_samples": len(samples),
        "gap_histogram_days": dict(Counter(gaps)),
        "max_gap_days": max(gaps) if gaps else None,
        "intervals_over_4_days": sum(gap > 4 for gap in gaps),
        "days_in_intervals_over_4_days": unknown,
        "total_interval_days": sum(gaps),
        "truncated_samples": sum(int(r["truncated"]) for r in coverage),
        "at_station_samples": sum(int(r["at_station"]) for r in samples),
        "in_depot_samples": sum(int(r["in_depot"]) for r in samples),
        "interpretation": "sample counts only; gaps not interpolated; 4 days is a coverage audit cutoff, not an economic rule",
        "airport_wait_days": None, "flight_days": None, "rotations": None,
        "verdict": "insufficient_temporal_coverage_for_congestion",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = json.loads(args.report.read_text(encoding="utf-8"))
    if not all(report["checks"].values()):
        raise ValueError("Technical smoke did not pass")
    result = analyse(report["probe"]["trace"])
    result["source"] = str(args.report.resolve())
    with args.out.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
