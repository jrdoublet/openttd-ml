"""C61: audit observation coverage, not a congestion classifier.

Reuses C117 enrichment. Streams/repeats remain separated; incompatible copies
of a cumulative observation are rejected instead of silently overwritten.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path

from sweeps.diag_c117_air_throughput import enrich, stats


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def audit(payload):
    observations = {}
    duplicate_count = 0
    for row in payload.get("rows", []):
        for raw in row.get("events", []):
            identity = (row.get("seed"), row.get("repeat"),
                        row.get("bench_arm", payload.get("settings", "unspecified").__repr__()),
                        raw.get("line"), raw.get("build_date"), raw.get("age_bucket"))
            if any(identity[i] is None for i in (0, 3, 4, 5)):
                raise ValueError("Missing seed/line/build_date/age_bucket identity")
            if identity in observations:
                if observations[identity] != raw:
                    raise ValueError(f"Conflicting cumulative observation: {identity}")
                duplicate_count += 1
            else:
                observations[identity] = raw

    reasons = Counter()
    usable = []
    sequences = defaultdict(list)
    for identity, raw in observations.items():
        flags = []
        for field in ("period_days", "sample_days", "trips", "leg_days_n",
                      "invalid_order_samples", "unobserved_transitions",
                      "engine_changes", "mixed_engine_samples", "live_avg", "live_last",
                      "leg_days_sum", "leg_days_min"):
            if not number(raw.get(field)) or raw[field] < 0:
                flags.append("missing_or_invalid:" + field)
        if number(raw.get("period_days")) and raw["period_days"] < 20:
            flags.append("short_window")
        for field in ("invalid_order_samples", "unobserved_transitions",
                      "engine_changes", "mixed_engine_samples"):
            if number(raw.get(field)) and raw[field] > 0:
                flags.append(field)
        if raw.get("trips", 0) == 0 or raw.get("leg_days_n", 0) == 0:
            flags.append("no_observed_timed_leg")
        if (number(raw.get("sample_days")) and number(raw.get("leg_days_min"))
                and 0 <= raw["leg_days_min"] <= raw["sample_days"]):
            flags.append("sampling_alias_risk")
        # A completed leg can have started in an earlier window. Its cargo is
        # credited at completion; that window is not a steady monthly rate.
        if not number(raw.get("leg_days_max")) or raw["leg_days_max"] < 0:
            flags.append("missing_or_invalid:leg_days_max")
        elif number(raw.get("period_days")) and raw["leg_days_max"] > raw["period_days"]:
            flags.append("leg_spans_multiple_windows")
        if (number(raw.get("live_avg")) and number(raw.get("live_last"))
                and abs(raw["live_avg"] - raw["live_last"]) > 1e-6):
            flags.append("fleet_varies_within_window")
        reasons.update(flags)
        if not flags:
            event = enrich(raw)
            event["sampled_leg_days"] = raw["leg_days_sum"] / raw["leg_days_n"]
            usable.append(event)
        sequences[identity[:-1]].append((identity[-1], raw, flags))

    transitions = []
    for identity, sequence in sequences.items():
        sequence.sort(key=lambda item: item[0])
        for before, after in zip(sequence, sequence[1:]):
            a, b = before[1], after[1]
            if not number(a.get("live_last")) or not number(b.get("live_last")):
                continue
            change = b["live_last"] - a["live_last"]
            if change == 0:
                continue
            transitions.append({
                "seed": identity[0], "repeat": identity[1], "arm": identity[2],
                "line": identity[3], "build_date": identity[4],
                "before_bucket": before[0], "after_bucket": after[0],
                "inventory_delta": change, "purchase_attribution": None,
                "adjacent_windows": after[0] == before[0] + 1,
                "coverage_flags": sorted(set(before[2] + after[2])),
            })

    return {
        "schema": "c61_service_coverage_v1", "scope": "descriptive_only",
        "source_health": payload.get("health"),
        "settings": payload.get("settings"),
        "windows": len(observations), "identical_duplicates": duplicate_count,
        "usable_sampled_service_windows": len(usable),
        "exclusion_reasons_nonexclusive": dict(reasons),
        "service": {field: stats([e.get(field) for e in usable
                                  if number(e.get(field)) and
                                  (field == "profit_pm" or e[field] >= 0)]) for field in
                    ("sampled_leg_days", "load_factor", "mail_load_factor",
                     "profit_pm", "live_avg", "waiting_mean")},
        "inventory_transitions": transitions,
        "direct_aircraft_wait_days": None, "airport_occupancy": None,
        "causal_marginal_profit": None, "congestion_verdict": "insufficient_evidence",
        "limitations": [
            "wait_a/wait_b are cargo counts, not aircraft waiting time",
            "loads are sampled maxima while running, not exact departure loads",
            "order transitions estimate simple legs, not full rotations",
            "inventory changes are not identified purchases or sales",
            "usable windows do not certify absence of missed round trips",
            "profit_pm is vehicle operating profit; airport costs are excluded",
            "legacy health is retained, not requalified by game_health",
            "historical sources/settings do not qualify current behavior",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    data = args.input.read_bytes()
    report = audit(json.loads(data))
    report["source"] = str(args.input.resolve())
    report["source_sha256"] = hashlib.sha256(data).hexdigest()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({key: report[key] for key in
                      ("windows", "usable_sampled_service_windows",
                       "exclusion_reasons_nonexclusive", "service")}, indent=2))


if __name__ == "__main__":
    main()
