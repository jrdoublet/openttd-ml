import unittest
from sweeps.analyse_c61_samples import analyse


def fixture():
    return {"coverage": [dict(seq=1, day=100, gap=-1, logged=1, truncated=0),
                         dict(seq=2, day=129, gap=29, logged=1, truncated=0)],
            "samples": [dict(seq=seq, at_station=1, in_depot=0) for seq in (1, 2)]}


class TimingTests(unittest.TestCase):
    def test_gap_not_wait_time(self):
        result = analyse(fixture())
        self.assertEqual(result["max_gap_days"], 29)
        self.assertIsNone(result["airport_wait_days"])

    def test_missing_samples(self):
        probe = fixture()
        probe["samples"].pop()
        with self.assertRaises(ValueError):
            analyse(probe)

    def test_sequence_and_dates(self):
        for field, value in (("seq", 3), ("day", 99), ("gap", 2)):
            probe = fixture()
            probe["coverage"][1][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                analyse(probe)
