import unittest
from sweeps.audit_c61_service import audit


def event(**changes):
    row = dict(line=1, build_date=700000, age_bucket=2, period_days=30,
               sample_days=2, trips=4, leg_days_n=3, leg_days_sum=30,
               leg_days_min=8, leg_days_max=12, invalid_order_samples=0, unobserved_transitions=0,
               engine_changes=0, mixed_engine_samples=0, live_avg=1, live_last=1,
               wait_a=50, wait_b=70, load_factor=0.6, profit_pm=1000)
    row.update(changes)
    return row


def payload(*events):
    return {"rows": [{"seed": 42, "events": list(events)}]}


class CoverageTests(unittest.TestCase):
    def test_cargo_wait_is_not_aircraft_wait(self):
        report = audit(payload(event()))
        self.assertEqual(report["service"]["waiting_mean"]["mean"], 60)
        self.assertIsNone(report["direct_aircraft_wait_days"])
        self.assertEqual(report["congestion_verdict"], "insufficient_evidence")

    def test_missing_quality_not_assumed_zero(self):
        row = event()
        del row["unobserved_transitions"]
        self.assertEqual(audit(payload(row))["usable_sampled_service_windows"], 0)

    def test_invalid_windows(self):
        for change in ({"period_days": 10}, {"unobserved_transitions": 1},
                       {"mixed_engine_samples": 1}, {"leg_days_min": 2},
                       {"live_avg": 1.5}, {"sample_days": float("nan")},
                       {"leg_days_n": 0}, {"leg_days_max": 45}):
            with self.subTest(change=change):
                self.assertEqual(audit(payload(event(**change)))["usable_sampled_service_windows"], 0)

    def test_dedup_and_conflicts(self):
        self.assertEqual(audit(payload(event(), event()))["identical_duplicates"], 1)
        with self.assertRaises(ValueError):
            audit(payload(event(), event(profit_pm=2000)))

    def test_inventory_is_not_purchase(self):
        report = audit(payload(event(), event(age_bucket=3, live_avg=2, live_last=2)))
        self.assertEqual(report["inventory_transitions"][0]["inventory_delta"], 1)
        self.assertIsNone(report["inventory_transitions"][0]["purchase_attribution"])

    def test_seed_streams_separate(self):
        data = {"rows": [{"seed": seed, "events": [event()]} for seed in (42, 100)]}
        self.assertEqual(audit(data)["windows"], 2)


if __name__ == "__main__":
    unittest.main()
