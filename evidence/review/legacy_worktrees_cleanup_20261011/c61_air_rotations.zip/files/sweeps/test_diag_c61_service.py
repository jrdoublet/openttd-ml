import tempfile
from pathlib import Path
import unittest
from sweeps.diag_c61_service import inspect_log, instrument


class ProbeTests(unittest.TestCase):
    def test_owner_and_negative_control(self):
        log = "[script:4] [0] C61_COVERAGE v=1 seq=1 day=1 gap=-1 logged=0 total=0 truncated=0"
        self.assertTrue(inspect_log(log, True)["identity_pass"])
        self.assertFalse(inspect_log(log, False)["identity_pass"])
        self.assertFalse(inspect_log(log.replace("[0]", "[1]"), True)["identity_pass"])
        self.assertTrue(inspect_log("", False)["identity_pass"])

    def test_sampled_state_is_not_wait_time(self):
        log = "[script:4] [0] C61_SAMPLE v=1 seq=1 day=1 at_station=1 in_depot=0"
        result = inspect_log(log, True)
        self.assertEqual(result["at_station_samples"], 1)
        self.assertIsNone(result["time_weighted_wait"])
        self.assertFalse(result["identity_pass"])

    def test_real_main_anchor_copy(self):
        root = Path(__file__).resolve().parents[1]
        original = (root / "ai/OpexAI/main.nut").read_text(encoding="utf-8")
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)
            (target / "main.nut").write_text(original, encoding="utf-8")
            instrument(target)
            changed = (target / "main.nut").read_text(encoding="utf-8")
            self.assertEqual(changed.count("C61Sample(this._lines, this._catalog);"), 1)
            self.assertIn("this._processEvents();\n    C61Sample", changed)
            self.assertTrue((target / "c61_service_probe.nut").exists())
        self.assertEqual((root / "ai/OpexAI/main.nut").read_text(encoding="utf-8"), original)


if __name__ == "__main__":
    unittest.main()
