/* Passive C61 copy-only probe. State is sampled, not an aircraft FTA decoder.
 * First 32 valid aircraft per sample; truncation is explicit. No decisions. */
C61_LAST_DAY <- -1;
C61_SEQUENCE <- 0;
function C61Sample(lines, catalog)
{
  local day = AIDate.GetCurrentDate();
  if (C61_LAST_DAY >= 0 && day - C61_LAST_DAY < 2) return;
  local gap = C61_LAST_DAY >= 0 ? day - C61_LAST_DAY : -1;
  C61_LAST_DAY = day;
  C61_SEQUENCE++;
  local count = 0;
  local total = 0;
  foreach (line in lines) {
    if (line == null || !("mode" in line) || line.mode != "air"
        || !("vehicles" in line) || line.vehicles == null) continue;
    foreach (v in line.vehicles) {
      if (!AIVehicle.IsValidVehicle(v) || AIVehicle.GetVehicleType(v) != AIVehicle.VT_AIR) continue;
      total++;
      if (count >= 32) continue;
      count++;
      local state = AIVehicle.GetState(v);
      local order = AIOrder.IsCurrentOrderPartOfOrderList(v)
          ? AIOrder.ResolveOrderPosition(v, AIOrder.ORDER_CURRENT) : -1;
      local mail = ("mailCargo" in catalog) ? catalog.mailCargo : -1;
      AILog.Info("C61_SAMPLE v=1 seq=" + C61_SEQUENCE + " day=" + day + " gap=" + gap
          + " line=" + line.lineId + " vehicle=" + v + " engine=" + AIVehicle.GetEngineType(v)
          + " station_a=" + OpexAirLineStationId(line, 0)
          + " station_b=" + OpexAirLineStationId(line, 1)
          + " state=" + state + " at_station=" + (state == AIVehicle.VS_AT_STATION ? 1 : 0)
          + " in_depot=" + (state == AIVehicle.VS_IN_DEPOT ? 1 : 0)
          + " order=" + order + " tile=" + AIVehicle.GetLocation(v)
          + " cargo=" + line.cargo + " load=" + AIVehicle.GetCargoLoad(v, line.cargo)
          + " capacity=" + AIVehicle.GetCapacity(v, line.cargo)
          + " mail_load=" + (mail >= 0 ? AIVehicle.GetCargoLoad(v, mail) : -1)
          + " mail_capacity=" + (mail >= 0 ? AIVehicle.GetCapacity(v, mail) : -1)
          + " profit_this=" + AIVehicle.GetProfitThisYear(v)
          + " profit_last=" + AIVehicle.GetProfitLastYear(v));
    }
  }
  AILog.Info("C61_COVERAGE v=1 seq=" + C61_SEQUENCE + " day=" + day + " gap=" + gap
      + " logged=" + count + " total=" + total + " truncated=" + (total > count ? 1 : 0));
}
