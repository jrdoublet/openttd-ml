# AIR : topologie et productivité des avions — 30 septembre 2026

## Conclusion du premier diagnostic

Le souvenir utilisateur est confirmé avec une nuance : AAAHogEx ne partage pas
un aéroport entre plusieurs lignes bidirectionnelles du **même cargo**. Un autre
cargo peut réutiliser cet aéroport. Les relevés ne montrent **aucun hub passagers
AAAHogEx**, contre de nombreux hubs Opex. Cela ne prouve pas que supprimer les
hubs améliorerait Opex : les essais antérieurs de limitation sont perdants.

Le profit par avion est bien inférieur en moyenne chez Opex, mais l'écart varie
avec le moteur et le contexte. Un cas montre aussi une forte disparité entre
deux avions **sur la même ligne, de même moteur et avec les mêmes ordres**.
La piste suivante est donc une observation de l'utilisation réelle de ces avions
et du gain marginal de leur affectation, avant toute règle de réaffectation.

## Périmètre et provenance

- Base : `origin/c121-catalog`, `79497c7498994d25c9f746c826cf2ad36f4e533c`.
- Checkout isolé `.wt_air_productivity`, branche `analysis/c121-air-productivity`.
- Aucun changement Squirrel, aucun changement du défaut C115.
- Campagne `c121_air_topology_3x3_20260930_r1` : graines 42, 100, 999,
  trois ans à partir de 1970 ; les deux premières années sont l'analyse primaire,
  la troisième permet d'observer des avions plus anciens.
- Deux politiques, chacune dans son propre duel contre le même AAAHogEx figé :
  `c115` = défaut ; `c121_catalog` = `c121_air_economics=1`,
  `c121_air_project_realization_adaptive=1`, `c121_air_pressure_probe=1`,
  `c121_catalog_incremental=1`, `c121_catalog_air_first_year=1`.
  Ni `c121_aaa_line`, ni renfort au stock, ni territoire d'abord.
- Runtime : OpenTTD 15.3, OpenGFX 7.1, OpenTTDLab 0.0.75, carte 256²,
  image `sha256:f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659`.
  Docker Desktop local, cache `openttd-lab-home`, CPU 3, RAM/swap 2g, trois workers.
- Bundle `8fd8f4aacddada33285a530efa99ecbe188ef8789cf01d3c4d5a517115a671cd` ;
  manifeste `c9201276778e90b5df601593610221bf332047594c1b554fd408b233ffd55c19`.
- **6/6 parties saines**, horizon décembre 1972 atteint. Verdict `diagnostic_only`.
  Pas de test de traitement « hubs contre absence de hubs » ni d'adoption.

Sources exactes archivées via les helpers de `package_review_evidence.py`,
sans réécrire les entrées antérieures de l'index :

- [Résultat brut](../evidence/review/c121_air_topology_3x3_20260930_r1.json.gz)
- [Manifeste](../evidence/review/c121_air_topology_3x3_20260930_r1.manifest.json.gz)
- [Analyse finale v3](../evidence/review/c121_air_topology_3x3_20260930_r1_analysis_v3.json.gz)
- [Index et hashes](../evidence/review/index.json)

Le résultat brut fait 22,6 Mo, compressé à 1,39 Mo. Les premières analyses v1/v2
dans `results/` sont intermédiaires ; seule **v3** est la référence de cette note.

## Mesure

Le harnais C66 existant reçoit `--line-telemetry-monthly`. Son extracteur conserve
en plus moteur, âge, cargo principal, capacités par cargo, profits individuels
et valeur comptable des seuls véhicules primaires validés par `decode_vehicles`.
Les soutes auxiliaires ne deviennent pas des avions supplémentaires.
L'instrumentation travaille sur les sauvegardes, sans coût NoAI additionnel.

`analyse_air_productivity.py` compte les **destinations distinctes** par StationID.
Deux groupes PASS/MAIL reliant les mêmes aéroports ne créent pas un hub artificiel.
Le graphe passagers utilise le cargo principal, pas la présence d'une soute MAIL.
Le cargo PASS=0 est un paramètre explicite d'analyse de ce runtime vanilla,
pas un identifiant ajouté aux décisions NoAI.

432 relevés compagnie/mois attendus et collectés ; **431 exploitables** pour ce
diagnostic. Sur AAAHogEx, graine 100, témoin, novembre 1971, les ordres de
l'avion 154 sont illisibles : tout ce relevé est exclu de l'analyse de topologie,
ainsi que les intervalles nécessitant ce point. Cela ne rend pas la partie moteur
malsaine, mais empêche de qualifier la couverture télémétrique à 100 %.

6 816 intervalles avion/mois exploitables. Seuls des avions présents aux deux
bornes, sans changement de moteur, cargo, capacité ou aéroports, sont comparés.
561 nouveaux/non observés et 15 changements sont exclus. L'évolution d'âge
est confrontée au nombre de jours calendaires. La somme des profits observés,
divisée par les jours-avions puis multipliée par 365, donne un rendement
annualisé d'exposition ; ce n'est pas une moyenne d'années complètes indépendantes.

**Piège vérifié du 1er janvier :** le checkpoint précède le rollover annuel des
profits véhicules. Les 403 changements observés de `profit_last_year` ont lieu
entre le 1er janvier et le 1er février. Le calcul traite donc décembre→janvier
sans rollover, et janvier→février avec `last_year - previous_this + this`.
Un changement de `last_year` hors de la fenêtre qualifiée est rejeté.

Chargement au départ, rotations, temps en vol/attente et revenu par cargo ne sont
**pas mesurés**. `max_waiting_cargo` n'est pas assimilé à un flux ni à un taux de
remplissage. La valeur comptable dépréciée n'est pas le capital d'achat : aucun
ROI du capital n'est déduit des chiffres ci-dessous.

## Résultats

### Topologie, sommes sur trois graines

| Politique | Fin d'année | Aéroports Opex / AAA | Avions Opex / AAA | Hubs passagers Opex / AAA |
|---|---:|---:|---:|---:|
| C115 | 1970 | 24 / 38 | 28 / 38 | 15 / 0 |
| C115 | 1971 | 44 / 74 | 76 / 66 | 29 / 0 |
| C115 | 1972 | 56 / 94 | 172 / 96 | 52 / 0 |
| C121 catalogue | 1970 | 31 / 38 | 21 / 38 | 9 / 0 |
| C121 catalogue | 1971 | 48 / 68 | 48 / 68 | 21 / 0 |
| C121 catalogue | 1972 | 55 / 102 | 91 / 115 | 34 / 0 |

Lecture de code indépendante : `ai/AAAHogEx-115/air.nut:729`,
`AirStation::CanShareByMultiRoute`, refuse une route bidirectionnelle existante
de même cargo, avec d'autres bornes liées aux terminaux et au débit. Le fichier
local analysé est celui figé dans le manifeste. Aucun code adverse n'est copié
dans OpexAI.

### Premiers 24 mois : avions passagers, mail auxiliaire inclus dans leur profit

La fenêtre va des premiers relevés de 1970 au 1er janvier 1972 inclus.

| Politique du duel | Opex, k£/avion-an | AAA, k£/avion-an | Intervalles Opex / AAA |
|---|---:|---:|---:|
| C115 | 63,6 | 98,6 | 783 / 649 |
| C121 catalogue | 80,7 | 108,0 | 552 / 700 |

AAAHogEx change lui aussi de trajectoire selon son adversaire. Comparer les deux
lignes de ce tableau ne démontre donc pas le gain causal d'une topologie.

Au défaut, le moteur 217 occupe 9 573 jours-avions PASS à **33,3 k£/avion-an**,
tandis que le 223 occupe 8 437 jours-avions à **109,3 k£**. AAA réalise **105,4 k£**
sur le 223 (8 051 jours-avions) dans ces mêmes duels, sans que routes et âges
soient encore appariés. Une part de l'écart global vient donc de populations
différentes ; ce résultat descriptif ne justifie pas de remplacer tous les 217.

Comparaison plus resserrée : même duel, mois, moteur, cargo principal, classe
d'âge (0–6, 6–12, 12+ mois) et tranche de distance euclidienne de 100 tuiles.
Chaque strate reçoit le **même poids** pour les deux IA, égal au minimum de leurs
jours-avions. Pas d'extrapolation aux moteurs absents d'un côté.

| Politique | Graine | Strates communes | Opex / AAA, k£/avion-an |
|---|---:|---:|---:|
| C115 | 42 | 53 | 103,8 / 116,5 |
| C115 | 100 | 18 | 92,4 / 77,2 |
| C115 | 999 | 34 | 118,7 / 116,3 |
| C121 catalogue | 42 | 39 | 89,8 / 134,3 |
| C121 catalogue | 100 | 22 | 61,3 / 77,2 |
| C121 catalogue | 999 | 0 | non comparable |

Les strates restent larges, les villes et la concurrence ne sont pas contrôlées.
Les mois d'un même avion ne sont pas des réplications indépendantes. L'absence
de support commun sur C121/999 interdit une conclusion générale sur trois graines.
**Les hubs ne sont donc pas une cause universelle démontrée de sous-rendement.**

### Cas concrets à instruire

1. **C121, graine 42, aéroport 8**, moteur 223 : sur juin→décembre 1972,
   l'avion 150 (marché 19–31) réalise **2,2 k£/an annualisés**, contre **56,4 k£**
   pour l'avion 18 (marché 19–39). Même moteur, même aéroport commun, destinations
   différentes. Âges finaux 508 et 983 jours : aucune assimilation à un test causal.
2. **C121, graine 999, marché 15–27**, aéroports 8/20, moteur 228, ordres partagés
   `10` : un avion au 1er mars 1972, deux au 1er avril. Entre le 1er juin et le
   1er décembre (183 jours), le profit cumulé de l'avion 44 passe de 20 268 à
   22 573 £ (**+2 305 £**) ; celui du 293 passe de 22 148 à 95 863 £
   (**+73 715 £**). Rendements annualisés ≈**4,6 / 147,0 k£**. Le premier avion
   avait gagné 152 259 £ sur l'année précédente. La baisse ne commence toutefois
   pas nécessairement au renfort : elle est déjà visible en février/mars.

Ces cas justifient une enquête sur l'affectation et l'utilisation. Ils ne prouvent
ni une cannibalisation causée par le renfort, ni un appareil bloqué, ni un gain
disponible par transfert vers l'avion/la ligne actuellement la plus rentable.

## Suite bornée

Priorité : relever, pour les avions ci-dessus et leurs voisins de hub, départs,
PASS/MAIL embarqués, recettes de livraison, temps d'attente/vol/hangar et état des
ordres. Réutiliser le diagnostic physique existant, sans ajouter de scan global.
Il faut expliquer le cas **même ligne / même moteur** avant de supposer qu'une
meilleure destination suffirait.

Si une réaffectation est ensuite testée, juger le **profit total du voisinage des
deux aéroports**, pas seulement celui de l'avion déplacé ; contrôler cash et
ouvertures d'aéroports. Une meilleure moyenne par avion obtenue par contraction
de flotte n'est pas un succès. Pas de restriction globale des hubs, ni de nouveau
classement moteur, ni de 20×10 à ce stade.

Validation : 7 tests du nouvel analyseur/extracteur, 8 tests des compteurs physiques,
selftest C66 ; intégration moteur effectivement exécutée sur les six parties.
Copies gzip vérifiées après décompression. Résultats diagnostiques, pas de défaut
adopté, aucun commit ou push automatique.

Reproduction de l'analyse, depuis la racine du checkout :

```text
rtk proxy python -X utf8 sweeps/analyse_air_productivity.py results/c121_air_topology_3x3_20260930_r1.json --map-width 256 --passenger-cargo 0 --out results/c121_air_topology_reanalyse_unique.json
```
