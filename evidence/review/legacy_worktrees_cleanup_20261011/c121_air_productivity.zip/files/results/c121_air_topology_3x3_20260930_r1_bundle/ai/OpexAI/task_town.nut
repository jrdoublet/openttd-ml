/* C65 : deplace depuis main.nut (passe 1, deplacement pur, aucun corps retouche). */
/* Une seule route v1 ; le scan apres rechargement empeche tout doublon maritime. */
/* La phase routiere : autant de petites lignes courtes que le classement en propose, dans la
 * limite des deux plafonds annuels ci-dessus.
 *
 * Elle tourne APRES _tryBuild, et c'est une decision, pas un detail d'ordonnancement. Les deux
 * modes ne se disputent jamais la meme PAIRE (leurs bandes de distance sont disjointes : le rail
 * commence ou la route s'arrete, a 25 tuiles) mais ils se disputent les memes ORIGINES et la meme
 * tresorerie. Le rail vaut un ordre de grandeur de plus par ligne : il choisit donc en premier, et
 * la route prend ce qui reste -- des villes et des industries qu'aucune ligne rail n'a retenues,
 * avec l'argent qui dort une fois la reserve rail respectee. C'est aussi ce qui garde la baseline
 * rail lisible au banc : a road_mode = 0 il ne se passe litteralement rien de plus.
 *
 * Le classement est recalcule ICI et non dans le cycle annuel : les lignes rail de l'annee
 * viennent d'entrer dans _lines, et leurs origines doivent etre exclues avant que la route ne
 * choisisse. */
/* Compte le nombre de stations actives de notre compagnie dans une ville donnee. */
function OpexCountTownStations(townId)
{
  local stations = AIStationList(AIStation.STATION_ANY);
  stations.Valuate(AIStation.GetNearestTown);
  stations.KeepValue(townId);
  return stations.Count();
}
/* Liste des villes desservies par au moins une liaison rail, air ou route de notre compagnie. */
function OpexGetServedTowns(lines)
{
  local townMap = {};
  local result = [];
  foreach (line in lines) {
    local stA = AIStation.GetStationID(line.stationA);
    local stB = AIStation.GetStationID(line.stationB);
    if (AIStation.IsValidStation(stA)) {
      local tA = AIStation.GetNearestTown(stA);
      if (tA >= 0 && !(tA in townMap)) {
        townMap.rawset(tA, true);
        result.append(tA);
      }
    }
    if (AIStation.IsValidStation(stB)) {
      local tB = AIStation.GetNearestTown(stB);
      if (tB >= 0 && !(tB in townMap)) {
        townMap.rawset(tB, true);
        result.append(tB);
      }
    }
  }
  return result;
}
/* C87 : cle de refus d'une ville dans _abandonedPairs (sauvegardee, purgee par _pruneAbandonedPairs). */
function OpexTownGrowthRejectKey(townId)
{
  return "town_growth|" + townId;
}

/* C87 : passagers mensuels captes par les deux arrets d'une ligne intra-ville.
 * GetCargoProduction compte des tuiles productrices, pas des passagers : on les convertit avec la
 * production moyenne par maison de la ville le mois dernier. Le recouvrement des deux bassins est
 * retire comme pour une ligne ville-ville (OpexRoadPaxUniqueMonthly). */
function OpexTownGrowthStopsMonthly(townId, cargo, tileA, tileB, distance)
{
  local houses = AITown.GetHouseCount(townId);
  if (houses < 1) houses = 1;
  local perHouse = AITown.GetLastMonthProduction(townId, cargo).tofloat() / houses;
  local capA = (AITile.GetCargoProduction(tileA, cargo, 1, 1, ROAD_PAX_CATCHMENT_RADIUS) * perHouse).tointeger();
  local capB = (AITile.GetCargoProduction(tileB, cargo, 1, 1, ROAD_PAX_CATCHMENT_RADIUS) * perHouse).tointeger();
  return OpexRoadPaxUniqueMonthly(capA, capB, distance);
}

/* C87 : memorise un refus sans passer par _markPairAbandoned, qui declencherait une reelection du
 * portefeuille (_hadAbandonsThisPass) et une invalidation C76 sans objet pour la croissance urbaine. */
function OpexAI::_markTownGrowthRejected(townId)
{
  local key = OpexTownGrowthRejectKey(townId);
  local count = (key in this._abandonCounts) ? (this._abandonCounts[key] + 1) : 1;
  this._abandonCounts[key] <- count;
  this._abandonedPairs[key] <- { date = AIDate.GetCurrentDate(), count = count };
}

/* Évalue les gardes d'éligibilité et de trésorerie pour la croissance urbaine.
 * Renvoie le tableau des villes desservies en cas de succès, null sinon. */
function OpexAI::_prepareTownGrowth()
{
  if (!TOWN_GROWTH_ENABLED || this._catalog.roadType < 0 || this._catalog.paxCargo < 0) return null;
  local money = AICompany.GetBankBalance(AICompany.COMPANY_SELF);
  if (money < OpexCashReserve() + 25000) return null;

  local engine = (this._catalog.paxCargo in this._catalog.roadEngineByCargo)
      ? this._catalog.roadEngineByCargo[this._catalog.paxCargo] : null;
  if (engine == null) return null;

  local servedTowns = OpexGetServedTowns(this._lines);
  if (servedTowns.len() == 0) return null;

  return servedTowns;
}

/* Traite une seule ville pour la croissance urbaine.
 * Renvoie true si une ligne a été construite avec succès, false sinon. */
function OpexAI::_tryTownGrowthCity(townId, year, anchor = null)
{
  if (!AITown.IsValidTown(townId)) return false;
  /* Une seule ligne bus de base par commune. Le plafond de croissance n'autorise pas cinq
   * lignes superposees : les quartiers suivants deviennent des bus_pax_extension de la ligne. */
  if (OpexTownBusPaxServed(this._lines, townId)) return false;
  if (TOWN_GROWTH_PLAN_MEMO && this._townPlanFailures != null && (townId in this._townPlanFailures)
      && this._townPlanFailures[townId] == AITown.GetHouseCount(townId)) {
    if (DECISION_LOG) OpexDecide("TOWN_GROWTH_MEMO", "action=skip town=" + townId);
    return false;
  }
  /* C87 : une ville refusee (profit predit <= 0 ou ligne fermee a perte) n'est pas replanifiee
   * avant la fin de son delai d'abandon ; la planification est le poste couteux de cette tache. */
  if (TOWN_GROWTH_ROI_GATE && (OpexTownGrowthRejectKey(townId) in this._abandonedPairs)) return false;
  local currentCount = OpexCountTownStations(townId);
  if (currentCount >= 5) return false;

  local townTile = AITown.GetLocation(townId);
  local townPop = AITown.GetPopulation(townId);
  if (townPop < 100) return false;

  local cx = AIMap.GetTileX(townTile);
  local cy = AIMap.GetTileY(townTile);
  local srcCenter = townTile;
  local offsets = [[6, 0], [-6, 0], [0, 6], [0, -6], [6, 6], [-6, -6], [8, 0], [0, 8]];
  local dstCenter = null;
  foreach (off in offsets) {
    local tx = cx + off[0];
    local ty = cy + off[1];
    if (OpexRoadInMap(tx, ty)) {
      local t = AIMap.GetTileIndex(tx, ty);
      if (AITile.GetClosestTown(t) == townId && AITile.GetCargoProduction(t, this._catalog.paxCargo, 1, 1, 3) > 0) {
        dstCenter = t;
        break;
      }
    }
  }
  if (dstCenter == null) {
    dstCenter = townTile + AIMap.GetTileIndex(5, 5);
    if (!AIMap.IsValidTile(dstCenter) || AITile.GetClosestTown(dstCenter) != townId) dstCenter = townTile;
  }

  local dist = AIMap.DistanceManhattan(srcCenter, dstCenter);
  if (dist < 4) dist = 5;

  local engine = (this._catalog.paxCargo in this._catalog.roadEngineByCargo)
      ? this._catalog.roadEngineByCargo[this._catalog.paxCargo] : null;
  if (engine == null) return false;

  local candidate = {
    src = srcCenter,
    dst = dstCenter,
    srcTown = townId,
    dstTown = townId,
    cargo = this._catalog.paxCargo,
    kind = "pax",
    distance = dist,
    trains = 1,
    engine = engine,
    capital = 2 * this._catalog.costRoadBusStop + 20 * this._catalog.costRoadPerTile + this._catalog.costRoadDepot + engine.price,
    revenueAnnual = 0,
    runningAnnual = 0,
    amortAnnual = 0,
    carried = 0,
    oneWayDays = 1,
    iterations = 0,
    profitAnnual = 0,
    effectiveSpeed = engine.speed,
  };

  this._budget.begin();
  local planning = OpexRoadPlanFor(this._catalog, candidate);
  local planOps = this._budget.end("build_road_plans");
  local plan = planning.plan;
  if (plan == null) {
    if (TOWN_GROWTH_PLAN_MEMO) {
      if (this._townPlanFailures == null) this._townPlanFailures = {};
      this._townPlanFailures.rawset(townId, AITown.GetHouseCount(townId));
      if (DECISION_LOG) OpexDecide("TOWN_GROWTH_MEMO", "action=store town=" + townId + " houses=" + AITown.GetHouseCount(townId));
    }
    if (DECISION_LOG) {
      OpexDecide("TOWN_GROWTH", "action=fail town=" + townId + " stations=" + currentCount
                 + " reason=plan detail=" + planning.reason);
    }
    return false;
  }

  local actualDist = AIMap.DistanceManhattan(plan.stopA.tile, plan.stopB.tile);
  if (actualDist < 1) actualDist = 1;
  candidate.distance = actualDist;
  local routeDist = (plan.routeDistance != null && plan.routeDistance > 0) ? plan.routeDistance : actualDist;
  candidate.capital = 2 * this._catalog.costRoadBusStop + routeDist * this._catalog.costRoadPerTile + this._catalog.costRoadDepot + candidate.engine.price;

  if (TOWN_GROWTH_ROI_GATE) {
    /* C87 : meme modele et meme seuil que les lignes route de profit apres implantation
     * (task_road.nut, unprofitable_after_siting), sur la demande captee par les deux arrets reels. */
    local monthly = OpexTownGrowthStopsMonthly(townId, this._catalog.paxCargo, plan.stopA.tile,
                                               plan.stopB.tile, actualDist);
    local economics = OpexRoadLineEconomics(this._catalog, this._catalog.paxCargo, actualDist,
                                            monthly, engine, "pax", plan.routeDistance);
    local predicted = (economics == null) ? 0 : economics.profitAnnual;
    if (economics == null || predicted <= 0) {
      this._markTownGrowthRejected(townId);
      if (DECISION_LOG) {
        OpexDecide("TOWN_GROWTH", "action=fail town=" + townId + " stations=" + currentCount
                   + " reason=roi monthly=" + monthly + " profit=" + predicted + " dist=" + actualDist);
      }
      return false;
    }
  }

  local need = candidate.capital + OpexCashReserve();
  local money = AICompany.GetBankBalance(AICompany.COMPANY_SELF);
  if (money < need) {
    if (DECISION_LOG) {
      OpexDecide("TOWN_GROWTH", "action=fail town=" + townId + " stations=" + currentCount
                 + " reason=cash need=" + need + " cash=" + money);
    }
    return false;
  }
  if (OPEX_ECONOMY_OPCODE_COMPAT_FALSE && this._projects != null) {}

  local result = OpexBuildRoadRoute(this._catalog, this._budget, plan, candidate);
  if (C63_INVEST_PROBE) OpexC63RecordSpendResult("road", result, candidate.capital);
  if (anchor == null) anchor = AIMap.GetTileIndex(1, 1);
  if (ROAD_COST_PROBE) {
    OpexSign(anchor, "RP|" + townId + "|" + result.plannedCapital + "|" + result.actualCost
                           + "|" + (result.ok ? result.vehicles.len() : 0));
  }
  if (!result.ok) {
    if (DECISION_LOG) {
      OpexDecide("TOWN_GROWTH", "action=fail town=" + townId + " stations=" + currentCount
                 + " reason=build detail=" + result.reason + " error=" + result.error
                 + " dist=" + actualDist);
    }
    return false;
  }

  local newCount = OpexCountTownStations(townId);
  OpexSign(anchor, "TG|" + (year % 100) + "|" + townId + "|" + currentCount + "|" + newCount);
  if (DECISION_LOG) {
    OpexDecide("TOWN_GROWTH", "action=build town=" + townId + " stations_before=" + currentCount + " stations_after=" + newCount + " cost=" + candidate.capital);
  }

  this._lines.append({
    stationA = result.stopA, stationB = result.stopB,
    originA = candidate.src, originB = candidate.dst,
    cargo = candidate.cargo,
    predicted = 0, iterations = 0, trains = result.vehicles.len(), distance = dist, year = year,
    predRevenue = 0, predRunning = 0, predAmort = 0, predCarried = 0, predTrains = 1, predOneWayDays = 1,
    /* Batie pour la CROISSANCE de la ville, pas pour son profit : son candidat porte
     * revenueAnnual = 0 EXPLICITE. A exclure nommement d'une comparaison predit/reel, et non
     * devinee par pred_rev == 0 -- 21 a 23 % des enregistrements du diagnostic. */
    purpose = "town_growth",
    effectiveSpeed = engine.speed, catalogSpeed = engine.speed,
    mode = "road", kind = "pax", depot = result.depot,
    srcTown = townId, dstTown = townId, extraStops = [],
    nStopsA = result.nStopsA, nStopsB = result.nStopsB,
    srcIndustry = -1, dstIndustry = -1,
    deadStreak = 0, scrapping = false, scrapVehicles = [],
    isLowRatio = ("isLowRatio" in candidate) ? candidate.isLowRatio : false,
    opcodeRatio = ("opcodeRatio" in candidate) ? candidate.opcodeRatio : -1,
    lineId = this._nextLineId,
  });
  this._nextLineId++;
  if (C76_REGEN_TARGETED) {
    if (C76_LEAN_INVALIDATION) {
      this._c76PurgeInvalidCandidates("road");
    } else {
      this._c76BumpLayer("lines", false);
    }
  }
  return true;
}

/* Tache basse priorite de croissance urbaine : construit au plus une ligne bus de base dans une
 * ville deja desservie. Les quartiers suivants sont proposes au portefeuille comme extensions
 * espacees de cette meme ligne, jusqu'au plafond de croissance maximale OpenTTD. */
function OpexAI::_tryTownGrowth(year)
{
  local servedTowns = this._prepareTownGrowth();
  if (servedTowns == null) return false;

  local anchor = AIMap.GetTileIndex(1, 1);
  foreach (townId in servedTowns) {
    if (this._tryTownGrowthCity(townId, year, anchor)) return true;
    if (V89_RAIL_SEARCH_THROUGHPUT) this._advanceRailSearchThroughput();
  }
  return false;
}
