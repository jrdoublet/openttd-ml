"""Passive AIR topology and profit diagnostic from the frozen C66 harness.

No inferred departure loads, no summing unlike cargo capacities, no claim of
causality from a hub/profit association. Monthly profits concern surviving,
unchanged aircraft observed at both ends of consecutive monthly checkpoints.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import date
import hashlib
import json
import math
from pathlib import Path
import statistics


def stats(values):
    values = [v for v in values if isinstance(v, (int, float))]
    return {"n": len(values), "mean": statistics.mean(values) if values else None,
            "median": statistics.median(values) if values else None}


def ratio(a, b):
    return a / b if a is not None and b else None


def adjacency(lines):
    result = defaultdict(set)
    for line in lines:
        ids = line.get("station_ids", [])
        if len(ids) != 2 or ids[0] == ids[1]:
            continue
        a, b = ids
        result[a].add(b)
        result[b].add(a)
    return result


def distance(line, width):
    tiles = line.get("ordered_station_tiles", [])
    if len(tiles) != 2 or not all(isinstance(t, int) for t in tiles):
        return None
    a, b = tiles
    return math.hypot(a % width - b % width, a // width - b // width)


def interval_profit(previous, current, date0, date1):
    """OpenTTDLab's Jan 1 save precedes the vehicle annual rollover.

    Qualified on this OpenTTD 15.3 run: all 403 changes of profit_last_year
    occur from Jan 1 to Feb 1. Reject inconsistent same-accounting-year pairs.
    Currency-fract conversion already done by the canonical extractor.
    """
    p0, p1 = previous.get("profit_this_year_gbp"), current.get("profit_this_year_gbp")
    if p0 is None or p1 is None:
        return None
    year0 = date0.year - int((date0.month, date0.day) == (1, 1))
    year1 = date1.year - int((date1.month, date1.day) == (1, 1))
    if year1 == year0:
        if previous.get("profit_last_year_gbp") != current.get("profit_last_year_gbp"):
            return None
        return p1 - p0
    last = current.get("profit_last_year_gbp")
    if year1 == year0 + 1 and last is not None:
        return last - p0 + p1
    return None


def summarise_intervals(rows):
    days = sum(r["days"] for r in rows)
    profit = sum(r["profit_gbp"] for r in rows)
    return {"intervals": len(rows), "aircraft_days": days, "profit_gbp": profit,
            "profit_per_aircraft_year_gbp": ratio(profit * 365, days),
            "negative_intervals": sum(r["profit_gbp"] < 0 for r in rows)}


def analyse(payload, width, passenger_cargo):
    snapshots = (payload.get("line_telemetry") or {}).get("snapshots", [])
    seen = set()
    previous = {}
    snapshots_out, intervals = [], []
    quality = Counter()
    health = {(g["policy_id"], g["seed"], g.get("repeat", 0)): g.get("game_ok")
              for g in payload.get("games", [])}
    for snap in sorted(snapshots, key=lambda s: str(s.get("date"))):
        group = (snap.get("duel_policy_id"), snap.get("seed"), snap.get("repeat", 0))
        company = group + (snap.get("arm"),)
        key = company + (snap.get("date"),)
        if key in seen:
            raise ValueError(f"Duplicate snapshot: {key}")
        seen.add(key)
        if health.get(group) is not True or snap.get("ok") is not True:
            quality["unhealthy_or_unqualified_snapshots"] += 1
            continue
        unresolved = [v for v in snap.get("unresolved_vehicles", []) if v.get("mode") == "air"]
        if unresolved:
            quality["snapshots_with_unresolved_aircraft"] += 1
            continue
        when = date.fromisoformat(snap["date"])
        air = [l for l in snap.get("lines", []) if l.get("mode") == "air"]
        graph = adjacency(air)
        pax = [l for l in air if any(v.get("primary_cargo") == passenger_cargo
                                   for v in l.get("aircraft_detail", []))]
        pax_graph = adjacency(pax)
        details_complete = all(len(l.get("aircraft_detail", [])) == l.get("vehicles") for l in air)
        if not details_complete:
            quality["snapshots_without_complete_aircraft_detail"] += 1
        vehicles = {}
        line_rows = []
        for line in air:
            ids = line.get("station_ids", [])
            if len(ids) != 2 or ids[0] == ids[1]:
                quality["unsupported_line_topology"] += 1
                continue
            deg = max(len(graph[s]) for s in ids)
            pax_deg = max(len(pax_graph[s]) for s in ids)
            dist = distance(line, width)
            line_rows.append({"line": line["line_key_local"], "stations": ids,
                              "market_key": line.get("market_key"), "distance_tiles": dist,
                              "degree_max": deg, "passenger_degree_max": pax_deg if details_complete else None,
                              "vehicles": line.get("vehicles"),
                              "profit_this_year_gbp": line.get("profit_this_year_gbp"),
                              "profit_last_year_gbp": line.get("profit_last_year_gbp")})
            for v in line.get("aircraft_detail", []):
                vid = v["vehicle_id"]
                if vid in vehicles:
                    raise ValueError(f"Aircraft in multiple lines: {key}, {vid}")
                vehicles[vid] = dict(v, stations=ids, market_key=line.get("market_key"),
                                     distance_tiles=dist, degree_max=deg, passenger_degree_max=pax_deg)
        n = sum(l.get("vehicles", 0) for l in air)
        this_profit = sum(l.get("profit_this_year_gbp", 0) for l in air)
        last_profit = sum(l.get("profit_last_year_gbp", 0) for l in air)
        base = dict(policy=group[0], seed=group[1], repeat=group[2], arm=company[3], date=when.isoformat())
        snapshots_out.append(dict(base, airports=len(graph), lines=len(air), aircraft=n,
            hubs=sum(len(v) > 1 for v in graph.values()),
            max_degree=max(map(len, graph.values()), default=0),
            passenger_hubs=sum(len(v) > 1 for v in pax_graph.values()) if details_complete else None,
            passenger_airports=len(pax_graph) if details_complete else None,
            max_passenger_degree=max(map(len, pax_graph.values()), default=0) if details_complete else None,
            aircraft_per_airport=ratio(n, len(graph)),
            profit_this_year_gbp=this_profit, profit_last_year_gbp=last_profit,
            profit_this_year_per_aircraft_gbp=ratio(this_profit, n),
            profit_this_year_per_airport_gbp=ratio(this_profit, len(graph)),
            distance_tiles=stats(l["distance_tiles"] for l in line_rows),
            engines=dict(Counter(str(v.get("engine_type")) for v in vehicles.values())),
            line_details=line_rows))
        if company in previous:
            date0, old = previous[company]
            days = (when - date0).days
            if 27 <= days <= 32:
                for vid, v in vehicles.items():
                    before = old.get(vid)
                    if before is None:
                        quality["new_or_unobserved_aircraft_intervals"] += 1
                        continue
                    # Exclude replacement/refit/reassignment and ambiguous reused vehicle IDs.
                    identity = ("engine_type", "build_year", "primary_cargo", "capacity_by_cargo", "stations")
                    if any(v.get(k) != before.get(k) for k in identity):
                        quality["changed_aircraft_intervals"] += 1
                        continue
                    age0, age1 = before.get("age_days"), v.get("age_days")
                    if not isinstance(age0, int) or not isinstance(age1, int) or abs(age1 - age0 - days) > 2:
                        quality["unqualified_age_intervals"] += 1
                        continue
                    profit = interval_profit(before, v, date0, when)
                    if profit is None or not v.get("consist_valid") or not before.get("consist_valid"):
                        quality["missing_profit_or_invalid_consist_intervals"] += 1
                        continue
                    intervals.append(dict(base, vehicle_id=vid, engine=v.get("engine_type"),
                        primary_cargo=v.get("primary_cargo"), age_band="0-6m" if age0 < 183 else "6-12m" if age0 < 365 else "12m+",
                        distance_band=int(v["distance_tiles"] // 100) if v["distance_tiles"] is not None else None,
                        market_key=v.get("market_key"), days=days, profit_gbp=profit,
                        passenger_hub=before["passenger_degree_max"] > 1,
                        topology_stable=before["passenger_degree_max"] == v["passenger_degree_max"],
                        book_value_gbp=before.get("book_value_gbp")))
            else:
                quality["non_monthly_gaps"] += 1
        previous[company] = (when, vehicles)

    grouped = defaultdict(list)
    for row in intervals:
        grouped[(row["policy"], row["seed"], row["arm"], row["date"][:4], row["passenger_hub"])].append(row)
    interval_summary = [dict(policy=k[0], seed=k[1], arm=k[2], year=int(k[3]), passenger_hub=k[4],
                             **summarise_intervals(v)) for k, v in sorted(grouped.items())]
    # Exact same duel/date/engine/age-band/distance-band/cargo strata. Each
    # aircraft-month stays descriptive; independent replication is by seed.
    matched = defaultdict(lambda: defaultdict(list))
    for row in intervals:
        if row["engine"] is None or row["distance_band"] is None:
            continue
        k = tuple(row[f] for f in ("policy", "seed", "repeat", "date", "engine", "age_band", "distance_band", "primary_cargo"))
        matched[k][row["arm"]].append(row)
    matches = []
    for k, arms in sorted(matched.items()):
        if not all(arm in arms for arm in ("OpexAI", "AAAHogEx")):
            continue
        matches.append(dict(zip(("policy", "seed", "repeat", "date", "engine", "age_band", "distance_band", "primary_cargo"), k),
                            opex=summarise_intervals(arms["OpexAI"]), aaa=summarise_intervals(arms["AAAHogEx"])))
    first_year = min((int(s["date"][:4]) for s in snapshots_out), default=None)
    early_end = f"{first_year + 2}-01-01" if first_year is not None else ""
    early_groups = defaultdict(list)
    early_engines = defaultdict(list)
    early_matches = defaultdict(list)
    for row in intervals:
        if row["date"] <= early_end and row["primary_cargo"] == passenger_cargo:
            early_groups[(row["policy"], row["arm"])].append(row)
            early_engines[(row["policy"], row["arm"], row["engine"])].append(row)
    for row in matches:
        if row["date"] <= early_end and row["primary_cargo"] == passenger_cargo:
            early_matches[(row["policy"], row["seed"])].append(row)
    standardised = []
    for (policy, seed), rows in sorted(early_matches.items()):
        weights = [min(r["opex"]["aircraft_days"], r["aaa"]["aircraft_days"]) for r in rows]
        rates = {arm: sum(r[arm]["profit_per_aircraft_year_gbp"] * w for r, w in zip(rows, weights)) / sum(weights)
                 for arm in ("opex", "aaa")}
        standardised.append(dict(policy=policy, seed=seed, strata=len(rows), matched_weight_days=sum(weights),
                                 opex= rates["opex"], aaa=rates["aaa"], delta_opex_minus_aaa=rates["opex"]-rates["aaa"]))
    return {"schema_version": 1, "campaign_id": payload.get("campaign_id"),
            "source_bundle_sha256": payload.get("source_bundle_sha256"),
            "map_width": width, "passenger_cargo_id": passenger_cargo,
            "games": [{k: g.get(k) for k in ("policy_id", "seed", "game_ok", "game_status")} for g in payload.get("games", [])],
            "quality": dict(quality), "snapshots": snapshots_out,
            "intervals": intervals, "interval_summary": interval_summary, "matched_strata": matches,
            "first_24_months": {"through": early_end,
                "passenger_profit": [dict(policy=k[0], arm=k[1], **summarise_intervals(v)) for k, v in sorted(early_groups.items())],
                "by_engine": [dict(policy=k[0], arm=k[1], engine=k[2], **summarise_intervals(v)) for k, v in sorted(early_engines.items())],
                "standardised_by_seed": standardised,
                "standardisation": "Same duel/month/engine/age band/100-tile distance band/primary cargo. Both arms weighted by min aircraft-days in each shared stratum; no extrapolation outside common support."},
            "limits": ["Descriptive, not a hub treatment or an adoption test.",
                       "Monthly intervals exclude aircraft not present at both ends; survivorship bias remains.",
                       "Profit per aircraft-year is annualised exposure, not an independent annual observation.",
                       "Book value is depreciated value, not purchase capital or ROI.",
                       "No departure loads, rotations, or cargo-specific revenue observed.",
                       "Jan 1 checkpoints precede vehicle annual profit rollover (qualified on OpenTTD 15.3).",
                       "Distance is Euclidean station-anchor distance; matching bands are 100 tiles.",
                       "Primary cargo distinguishes passenger service from mail-only; auxiliary mail is not a separate route."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--map-width", required=True, type=int)
    parser.add_argument("--passenger-cargo", required=True, type=int)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.map_width <= 0:
        parser.error("map width must be positive")
    raw = args.input.read_bytes()
    report = analyse(json.loads(raw), args.map_width, args.passenger_cargo)
    report["input_sha256"] = hashlib.sha256(raw).hexdigest()
    report["input_path"] = str(args.input)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps({"snapshots": len(report["snapshots"]), "intervals": len(report["intervals"]),
                      "matched_strata": len(report["matched_strata"]), "quality": report["quality"]}))


if __name__ == "__main__":
    main()
