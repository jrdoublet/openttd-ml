import copy
from datetime import date
import unittest

from analyse_air_productivity import adjacency, analyse, interval_profit
from bench_1v1_5y_20seeds import extract_line_telemetry


def aircraft(vid=1, cargo=0, profit=0, age=100):
    return dict(vehicle_id=vid, engine_type=223, build_year=1970,
                age_days=age, primary_cargo=cargo, capacity_by_cargo={str(cargo): 100},
                consist_valid=True, profit_this_year_gbp=profit,
                profit_last_year_gbp=0, book_value_gbp=10000)


def line(a, b, vehicle):
    return dict(mode="air", line_key_local=f"air|{a},{b}", station_ids=[a, b],
                ordered_station_tiles=[a, b], vehicles=1, aircraft_detail=[vehicle],
                profit_this_year_gbp=vehicle["profit_this_year_gbp"], profit_last_year_gbp=0)


def payload(lines):
    return dict(games=[dict(policy_id="reference", seed=42, game_ok=True)],
                line_telemetry=dict(snapshots=[dict(duel_policy_id="reference", seed=42,
                    arm="OpexAI", date="1970-05-01", ok=True, lines=lines)]))


class ProductivityTests(unittest.TestCase):
    def test_parallel_services_not_extra_destination(self):
        graph = adjacency([line(1, 2, aircraft()), line(1, 2, aircraft(2, 2))])
        self.assertEqual({k: len(v) for k, v in graph.items()}, {1: 1, 2: 1})

    def test_mail_route_not_passenger_hub(self):
        result = analyse(payload([line(1, 2, aircraft()), line(1, 3, aircraft(2, 2))]), 256, 0)
        snap = result["snapshots"][0]
        self.assertEqual(snap["hubs"], 1)
        self.assertEqual(snap["passenger_hubs"], 0)

    def test_year_boundary_includes_december(self):
        before = aircraft(profit=100)
        after = aircraft(profit=150)
        self.assertEqual(interval_profit(before, after, date(1970, 12, 1), date(1971, 1, 1)), 50)
        before = after
        after = aircraft(profit=20)
        after["profit_last_year_gbp"] = 150
        self.assertEqual(interval_profit(before, after, date(1971, 1, 1), date(1971, 2, 1)), 20)
        after["profit_last_year_gbp"] = None
        self.assertIsNone(interval_profit(before, after, date(1971, 1, 1), date(1971, 2, 1)))

    def test_missing_detail_not_inferred_passenger_topology(self):
        p = payload([line(1, 2, aircraft())])
        p["line_telemetry"]["snapshots"][0]["lines"][0].pop("aircraft_detail")
        self.assertIsNone(analyse(p, 256, 0)["snapshots"][0]["passenger_hubs"])

    def test_monthly_profit_and_reassignment_exclusion(self):
        p = payload([line(1, 2, aircraft(profit=100, age=100))])
        new = copy.deepcopy(p["line_telemetry"]["snapshots"][0])
        new["date"] = "1970-06-01"
        new["lines"] = [line(1, 2, aircraft(profit=410, age=131))]
        p["line_telemetry"]["snapshots"].append(new)
        result = analyse(p, 256, 0)
        self.assertEqual(result["interval_summary"][0]["profit_per_aircraft_year_gbp"], 3650)
        new["lines"][0]["station_ids"] = [1, 3]
        self.assertEqual(analyse(p, 256, 0)["intervals"], [])

    def test_unhealthy_and_duplicate_snapshots(self):
        p = payload([line(1, 2, aircraft())])
        p["games"][0]["game_ok"] = False
        self.assertEqual(analyse(p, 256, 0)["snapshots"], [])
        p["line_telemetry"]["snapshots"] *= 2
        with self.assertRaises(ValueError):
            analyse(p, 256, 0)

    def test_extractor_missing_profit_stays_unknown_and_shadow_not_aircraft(self):
        common = dict(owner=1, unitnumber=1, subtype=0, group_id=7, orders=1,
                      next=2, cargo_type=0, cargo_cap=100, age=123,
                      engine_type=223, build_year=1970, profit_this_year=2560, value=5000)
        shadow = dict(owner=1, unitnumber=0, subtype=2, next=0, cargo_type=2,
                      cargo_cap=20, value=0)
        chunks = dict(
            STNN={i: {"normal": {"base": {"owner": 1, "town": i, "xy": i, "facilities": 8}}} for i in (0, 1)},
            ORDL={"0": {"orders": [{"type": 1, "flags": 0, "dest": i} for i in (0, 1)]}},
            VEHS={0: {"type": 3, "aircraft": {"common": common}},
                  1: {"type": 3, "aircraft": {"common": shadow}}})
        result = extract_line_telemetry(chunks, 1)
        detail = result["lines"][0]["aircraft_detail"]
        self.assertEqual(len(detail), 1)
        self.assertEqual(detail[0]["profit_this_year_gbp"], 10)
        self.assertIsNone(detail[0]["profit_last_year_gbp"])
        self.assertEqual(detail[0]["capacity_by_cargo"], {"0": 100, "2": 20})


if __name__ == "__main__":
    unittest.main()
