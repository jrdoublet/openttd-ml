# C83 — réparation locale d'emplacement (02/10/2026)

Demande utilisateur : après l'ablation défavorable de la réaction C83, conserver
la réponse au dernier créneau, éviter la recherche d'emplacements dans les autres
villes et réparer uniquement l'aéroport de la ville menacée.

## Intervention pré-enregistrée

Catégorie **comportement**, pas optimisation qualifiée par neutralité. Le vivier
de partenaires connus peut différer du recalcul : aucun gain économique présumé.
`c83_local_repair=0` reste le défaut aux quatre difficultés ; candidat `=1`.
`c83_slot_reaction=1`, C115=1, C121=0, C83 fixes/P4/préemption ouverte OFF.

Le worker ne passe par le nouveau chemin que pour une intention `c83_slot_race`
ciblée sur une ville. Une photographie transitoire reprend les ancres non-reuse
du portefeuille et les ancres positives du cache, sans modifier leurs tables.
Les données de ville/équipement sont rafraîchies par C77 comme au témoin.

Par combinaison aéroport/avion : revalider les partenaires connus dans le même
vivier urbain ; revalider l'ancre cible, y compris son identité physique de ville
de créneau. Si nécessaire, appeler le chercheur existant seulement pour cette
ville. Revalider le résultat après recherche. Aucun partenaire valide connu
entraîne un repli sur le parcours ciblé ancien pour cette combinaison. Sinon,
la découverte des hubs conserve les hubs existants sans resondage des autres
villes. Les fonctions usuelles évaluent uniquement les paires touchant la cible
et la fusion ciblée conserve les autres projets et modes. Les alternatives ne
sont pas réduites à la seule tête du portefeuille.

La passe reste interrompue pendant le travail réactif comme au témoin : ce lot
réduit son travail, sans changer simultanément l'ordre d'exécution. La recherche
globale normale, C83.1 proactif, le watcher et les autres intentions C77 gardent
leur parcours. Save/Load conserve le contrat de reprise existant : abandon de
la tranche AIR non publiée, redémarrage du mode et reconstruction de la photo.

## Protocole décidé avant les résultats

- Worktree isolé `results/c83_local_worktree_20261002` sous le dépôt partagé Docker,
  HEAD `b2334d7156f12519b1f27a0078bc267f7d40dce8` ; sources C83 et préfiltre de
  cooldown AIR adopté repris du bundle précédent `c83_reaction_off_diag_20261002_r1`.
  Les modifications concurrentes AIR efficiency du checkout principal sont exclues.
- Référence `OpexAI[c83_local_repair=0]`, variante `OpexAI[c83_local_repair=1]`,
  autres réglages aux défauts de cette copie, même AAAHogEx-115 figée.
- Contrats Python, huit cas dirigés en VM NoAI, smoke causal 42 × 1 an,
  puis 5 graines (42,100,999,1234,5678) × 6 ans, une répétition, deux workers.
- Primaire `profit_year`, effet utile +50 000 £/an, garde valeur −5 %, `signs20`.
  Diagnostic : complet/sain, moyenne ≥50 000, garde tenue ; exposition locale
  sur au moins trois des cinq graines pour envisager le 20×10 officiel.
- Trace rare de chaque travail C83 terminé dans les deux bras : branche locale,
  replis, cible conservée/recherchée, partenaires, opcodes et ticks du worker AIR.
  Ces durées excluent le délai d'attente en file et la construction ultérieure.
  Des travaux non appariés ne constituent pas une preuve de gain d'opcodes.
- Docker desktop-linux, image `openttd-lab:latest`
  `sha256:f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659`,
  3 CPU / 2 Go / swap 2 Go, volume `openttd-lab-home`, montage du worktree.
  Aucun commit/push ; aucun défaut changé avant qualification.

Statut : implémenté expérimentalement ; validation en cours.
