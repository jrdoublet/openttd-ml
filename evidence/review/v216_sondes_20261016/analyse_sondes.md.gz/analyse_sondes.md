# V216 — analyses de la sonde

## Politique `v216_sonde_aaacomplet_20x3_20261016_engine:ref` : 20 parties sondées

### A. Premier rail voyageurs construit et dernière sélection avant lui

| partie | date | rôle | mode | rang | palier | score | profit calibré | financement | revenu | transporté |
|---|---|---|---|---|---|---|---|---|---|---|
| ref_seed100_r0.log | 1971-10-23 | construit | rail/pax | 0 | 0 | 0 | 4914 | 40835 | 8832 | 32 |
| ref_seed100_r0.log | 1971-10-9 | ce rail dans la sélection | rail/pax | 0 | 0 | 91 | 4914 | 39887 | 8832 | 32 |
| ref_seed100_r0.log | 1971-10-9 | rang 0 | rail/pax | 0 | 0 | 91 | 4914 | 39887 | 8832 | 32 |
| ref_seed100_r0.log | 1971-10-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed100_r0.log | 1971-10-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed1024_r0.log | aucun | | | | | | | | | |
| ref_seed123456_r0.log | 1972-11-15 | construit | rail/pax | 0 | 0 | 0 | 34920 | 69618 | 43008 | 64 |
| ref_seed123456_r0.log | 1972-11-6 | ce rail dans la sélection | rail/pax | 2 | 0 | 324 | 34152 | 88240 | 42240 | 64 |
| ref_seed123456_r0.log | 1972-11-6 | rang 0 | rail/freight | 0 | 0 | 495 | 52081 | 52239 | 56160 | 52 |
| ref_seed123456_r0.log | 1972-11-6 | meilleur AIR classé | air/pax | 5 | 0 | 296 | 31187.877 | 40964 | 72216 | 45 |
| ref_seed123456_r0.log | 1972-11-6 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed12345_r0.log | 1972-12-25 | construit | rail/pax | 0 | 0 | 0 | 9366 | 44358 | 13284 | 41 |
| ref_seed12345_r0.log | 1972-11-22 | ce rail dans la sélection | rail/pax | 2 | 0 | 100 | 9366 | 41231 | 13284 | 41 |
| ref_seed12345_r0.log | 1972-11-22 | rang 0 | rail/freight | 0 | 0 | 583 | 54436 | 52160 | 58560 | 61 |
| ref_seed12345_r0.log | 1972-11-22 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed12345_r0.log | 1972-11-22 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed1337_r0.log | aucun | | | | | | | | | |
| ref_seed17_r0.log | 1971-11-24 | construit | rail/pax | 0 | 0 | 0 | 6162 | 40269 | 10080 | 70 |
| ref_seed17_r0.log | 1971-11-20 | ce rail dans la sélection | rail/pax | 32 | 0 | 97 | 6162 | 36639 | 10080 | 70 |
| ref_seed17_r0.log | 1971-11-20 | rang 0 | air/pax | 0 | 0 | 1293 | 82489 | 63523 | 92064 | 44 |
| ref_seed17_r0.log | 1971-11-20 | meilleur AIR classé | air/pax | 0 | 0 | 1293 | 82489 | 63523 | 92064 | 44 |
| ref_seed17_r0.log | 1971-11-20 | meilleur AIR non finançable | air/pax | 0 | 0 | 1540 | 138181 | 89723 | 147756 | 71 |
| ref_seed1_r0.log | 1971-1-28 | construit | rail/pax | 0 | 0 | 0 | 14958 | 38400 | 18876 | 121 |
| ref_seed1_r0.log | 1971-1-20 | ce rail dans la sélection | rail/pax | 1 | 0 | 228 | 14958 | 35407 | 18876 | 121 |
| ref_seed1_r0.log | 1971-1-20 | rang 0 | rail/freight | 0 | 0 | 426 | 28021 | 40346 | 31968 | 72 |
| ref_seed1_r0.log | 1971-1-20 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed1_r0.log | 1971-1-20 | meilleur AIR non finançable | air/pax | 0 | 0 | 1380 | 139916 | 101364 | 147264 | 97 |
| ref_seed2026_r0.log | 1971-1-14 | construit | rail/pax | 0 | 0 | 0 | 18258 | 36217 | 22176 | 154 |
| ref_seed2026_r0.log | 1971-1-3 | ce rail dans la sélection | rail/pax | 1 | 0 | 339 | 18258 | 35967 | 22176 | 154 |
| ref_seed2026_r0.log | 1971-1-3 | rang 0 | rail/freight | 0 | 0 | 666 | 35859 | 38384 | 39804 | 107 |
| ref_seed2026_r0.log | 1971-1-3 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed2026_r0.log | 1971-1-3 | meilleur AIR non finançable | air/pax | 0 | 0 | 1809 | 183404 | 101364 | 190752 | 102 |
| ref_seed314_r0.log | aucun | | | | | | | | | |
| ref_seed4096_r0.log | 1972-12-12 | construit | rail/pax | 0 | 0 | 0 | 22227 | 59028 | 26208 | 39 |
| ref_seed4096_r0.log | 1972-12-3 | ce rail dans la sélection | rail/pax | 1 | 0 | 342 | 30216 | 88352 | 38304 | 57 |
| ref_seed4096_r0.log | 1972-12-3 | rang 0 | rail/freight | 0 | 0 | 373 | 27915 | 43536 | 31860 | 45 |
| ref_seed4096_r0.log | 1972-12-3 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed4096_r0.log | 1972-12-3 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed424242_r0.log | 1971-1-31 | construit | rail/pax | 0 | 0 | 0 | 11778 | 36935 | 15696 | 109 |
| ref_seed424242_r0.log | 1971-1-28 | ce rail dans la sélection | rail/pax | 0 | 0 | 225 | 11778 | 35295 | 15696 | 109 |
| ref_seed424242_r0.log | 1971-1-28 | rang 0 | rail/pax | 0 | 0 | 225 | 11778 | 35295 | 15696 | 109 |
| ref_seed424242_r0.log | 1971-1-28 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed424242_r0.log | 1971-1-28 | meilleur AIR non finançable | air/pax | 0 | 0 | 1509 | 153008 | 101364 | 160356 | 110 |
| ref_seed42_r0.log | 1972-5-30 | construit | rail/pax | 0 | 0 | 0 | 11271 | 52743 | 15252 | 31 |
| ref_seed42_r0.log | 1972-5-24 | ce rail dans la sélection | rail/pax | 1 | 0 | 184 | 10899 | 47280 | 14880 | 31 |
| ref_seed42_r0.log | 1972-5-24 | rang 0 | rail/freight | 0 | 0 | 459 | 27210 | 51063 | 31200 | 26 |
| ref_seed42_r0.log | 1972-5-24 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed42_r0.log | 1972-5-24 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed512_r0.log | 1971-8-22 | construit | rail/pax | 0 | 0 | 0 | 9054 | 40835 | 12972 | 47 |
| ref_seed512_r0.log | 1971-8-16 | ce rail dans la sélection | rail/pax | 0 | 0 | 136 | 9054 | 39887 | 12972 | 47 |
| ref_seed512_r0.log | 1971-8-16 | rang 0 | rail/pax | 0 | 0 | 136 | 9054 | 39887 | 12972 | 47 |
| ref_seed512_r0.log | 1971-8-16 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed512_r0.log | 1971-8-16 | meilleur AIR non finançable | air/pax | 0 | 0 | 0 | 148933 | 89723 | 158508 | 78 |
| ref_seed54321_r0.log | 1972-5-3 | construit | rail/pax | 0 | 0 | 0 | 18195 | 52196 | 22176 | 42 |
| ref_seed54321_r0.log | 1972-4-20 | ce rail dans la sélection | rail/pax | 1 | 0 | 255 | 18195 | 48400 | 22176 | 42 |
| ref_seed54321_r0.log | 1972-4-20 | rang 0 | rail/freight | 0 | 0 | 255 | 18255 | 38160 | 22200 | 74 |
| ref_seed54321_r0.log | 1972-4-20 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed54321_r0.log | 1972-4-20 | meilleur AIR non finançable | air/pax | 0 | 0 | 682 | 84518.01 | 123923 | 188892 | 87 |
| ref_seed65537_r0.log | 1972-8-20 | construit | rail/pax | 0 | 0 | 0 | 18516 | 84733 | 22560 | 47 |
| ref_seed65537_r0.log | 1972-8-12 | ce rail dans la sélection | rail/pax | 1 | 0 | 347 | 18579 | 47280 | 22560 | 47 |
| ref_seed65537_r0.log | 1972-8-12 | rang 0 | rail/pax | 0 | 0 | 424 | 37452 | 88240 | 45540 | 69 |
| ref_seed65537_r0.log | 1972-8-12 | meilleur AIR classé | air/pax | 10 | 0 | 208 | 21131.918 | 101364 | 54672 | 34 |
| ref_seed65537_r0.log | 1972-8-12 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed73_r0.log | aucun | | | | | | | | | |
| ref_seed7_r0.log | 1971-1-20 | construit | rail/pax | 0 | 0 | 0 | 16938 | 36030 | 20856 | 158 |
| ref_seed7_r0.log | 1971-1-4 | ce rail dans la sélection | rail/pax | 2 | 0 | 256 | 16938 | 34735 | 20856 | 158 |
| ref_seed7_r0.log | 1971-1-4 | rang 0 | road/pax | 0 | 0 | 427 | 28268 | 20007 | 30233 | 59 |
| ref_seed7_r0.log | 1971-1-4 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed7_r0.log | 1971-1-4 | meilleur AIR non finançable | air/pax | 0 | 0 | 0 | 199825 | 106128 | 214521 | 149 |
| ref_seed8191_r0.log | 1972-12-26 | construit | rail/pax | 0 | 0 | 0 | 17667 | 57989 | 21648 | 41 |
| ref_seed8191_r0.log | 1972-12-19 | ce rail dans la sélection | rail/pax | 1 | 0 | 85 | 17667 | 48400 | 21648 | 41 |
| ref_seed8191_r0.log | 1972-12-19 | rang 0 | rail/freight | 0 | 0 | 175 | 36285 | 50088 | 40320 | 40 |
| ref_seed8191_r0.log | 1972-12-19 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed8191_r0.log | 1972-12-19 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed8675309_r0.log | 1971-3-19 | construit | rail/pax | 0 | 0 | 0 | 8886 | 47056 | 12804 | 97 |
| ref_seed8675309_r0.log | 1971-3-16 | ce rail dans la sélection | rail/pax | 0 | 0 | 184 | 8886 | 48181 | 12804 | 97 |
| ref_seed8675309_r0.log | 1971-3-16 | rang 0 | rail/pax | 0 | 0 | 184 | 8886 | 48181 | 12804 | 97 |
| ref_seed8675309_r0.log | 1971-3-16 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed8675309_r0.log | 1971-3-16 | meilleur AIR non finançable | air/pax | 0 | 0 | 0 | 185996 | 67164 | 193344 | 92 |
| ref_seed999_r0.log | 1971-2-18 | construit | rail/pax | 0 | 0 | 0 | 10674 | 39521 | 14592 | 152 |
| ref_seed999_r0.log | 1971-2-16 | ce rail dans la sélection | — | — | — | — | — | — | — | — |
| ref_seed999_r0.log | 1971-2-16 | rang 0 | rail/freight | 0 | 0 | 235 | 13992 | 35551 | 17892 | 71 |
| ref_seed999_r0.log | 1971-2-16 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed999_r0.log | 1971-2-16 | meilleur AIR non finançable | air/pax | 0 | 0 | 1366 | 169285 | 123923 | 178860 | 76 |

### B. Attribution des erreurs : lignes rail 1971 (>= 180 j)

| groupe | n | revenu médian | ratio sommes revenu | profit médian | ratio sommes profit | offre moy. | capacité moy. | cap. séjour | liaison modèle | liaison séjour |
|---|---|---|---|---|---|---|---|---|---|---|
| PASS | 7 | 0.16 | 0.20 | 0.03 | 0.07 | 134.2 | 244.0 | 128.2 | 7 off / 0 cap | 2 off / 5 cap |
| freight | 42 | 0.79 | 0.81 | 0.82 | 0.83 | 79.0 | 93.5 | 66.6 | 38 off / 4 cap | 5 off / 37 cap |

### E. K_dec plus grand que le financement

| mode | K_dec gagne | lignes | part |
|---|---|---|---|
| air | 2008 | 15286 | 13% |
| fleet | 681 | 849 | 80% |
| rail | 28503 | 28880 | 99% |
| road | 198 | 198 | 100% |
| water | 0 | 14 | 0% |

### V216a. Fantôme : couverture et facteurs (médianes par extrémité, %)

| mode | extrémités | couvert par nous | couvert par adversaire seul | part ligne | gain compagnie | opcodes médians |
|---|---|---|---|---|---|---|
| air/pax | 12844 | 0 | 0 | 100 | 100 | 394 |
| rail/pax | 52656 | 83 | 11 | 62 | 11 | 355 |

### Rejeu des décisions (§6)

- sélections rejouées : 2424
- sélections avec changement du rang 0 : 112 (dont 112 en 1971-72)

| choix initial | remplaçant | occurrences |
|---|---|---|
| rail/pax | rail/pax | 69 |
| rail/pax | air/pax | 23 |
| rail/pax | fleet/fleet | 11 |
| rail/pax | rail/freight | 8 |
| rail/pax | road/freight | 1 |

### G. Arrivée de la concurrence (industries fret rail)

- industries sources fret observées : 62
- arrivée d'un concurrent sous 12 mois : 12 (19.4%)
*(src tile non requis : proxy basé sur les lignes V216_IND_FLOW dont stations_around augmente après le mois de RAIL_BUILD)*

| partie | industrie | cargo | ligne | date construction | première obs. | gares initiales | arrivée 12 mois | date arrivée | mois écoulés |
|---|---|---|---|---|---|---|---|---|---|
| ref_seed100_r0.log | 10 | COAL | 10 | 1971-01-20 | 1971-02-01 | 1 | NON | — | — |
| ref_seed100_r0.log | 11 | IORE | 20 | 1971-07-18 | 1971-08-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 46 | WOOD | 9 | 1971-01-16 | 1971-02-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 36 | COAL | 10 | 1971-02-25 | 1971-04-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 7 | LVST | 11 | 1971-03-18 | 1971-04-01 | 1 | NON | — | — |
| ref_seed123456_r0.log | 41 | COAL | 8 | 1971-01-16 | 1971-02-05 | 1 | NON | — | — |
| ref_seed123456_r0.log | 26 | GRAI | 9 | 1971-02-02 | 1971-03-27 | 1 | OUI | 1971-08-01 | 5.9 |
| ref_seed123456_r0.log | 37 | COAL | 33 | 1972-07-06 | 1972-08-02 | 2 | NON | — | — |
| ref_seed12345_r0.log | 32 | COAL | 9 | 1971-01-20 | 1971-02-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 28 | COAL | 9 | 1971-01-20 | 1971-03-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 16 | WOOD | 11 | 1971-02-08 | 1971-03-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 17 | COAL | 43 | 1972-07-03 | 1972-08-01 | 2 | NON | — | — |
| ref_seed12345_r0.log | 49 | COAL | 46 | 1972-08-28 | 1972-10-09 | 1 | NON | — | — |
| ref_seed1337_r0.log | 38 | WOOD | 13 | 1971-01-26 | 1971-02-10 | 2 | NON | — | — |
| ref_seed1337_r0.log | 0 | COAL | 12 | 1971-01-18 | 1971-02-10 | 1 | OUI | 1971-05-01 | 3.4 |
| ref_seed1337_r0.log | 29 | OIL_ | 14 | 1971-02-01 | 1971-03-01 | 1 | NON | — | — |
| ref_seed17_r0.log | 29 | COAL | 8 | 1971-01-11 | 1971-02-01 | 1 | NON | — | — |
| ref_seed17_r0.log | 26 | WOOD | 9 | 1971-01-26 | 1971-02-01 | 3 | OUI | 1971-07-03 | 5.2 |
| ref_seed17_r0.log | 28 | COAL | 22 | 1971-11-05 | 1971-12-06 | 1 | NON | — | — |
| ref_seed17_r0.log | 3 | WOOD | 25 | 1971-12-15 | 1972-01-10 | 1 | NON | — | — |
| ref_seed17_r0.log | 40 | WOOD | 28 | 1972-03-11 | 1972-04-02 | 1 | NON | — | — |
| ref_seed1_r0.log | 14 | WOOD | 12 | 1971-01-24 | 1971-02-01 | 2 | OUI | 1971-12-01 | 10.2 |
| ref_seed1_r0.log | 3 | WOOD | 12 | 1971-01-24 | 1971-03-02 | 1 | NON | — | — |
| ref_seed2026_r0.log | 17 | COAL | 8 | 1971-01-11 | 1971-02-01 | 1 | NON | — | — |
| ref_seed2026_r0.log | 0 | COAL | 34 | 1972-05-01 | 1972-06-04 | 1 | NON | — | — |
| ref_seed314_r0.log | 0 | COAL | 9 | 1971-01-23 | 1971-02-03 | 1 | NON | — | — |
| ref_seed4096_r0.log | 35 | COAL | 8 | 1971-01-18 | 1971-02-02 | 1 | OUI | 1971-07-03 | 5.5 |
| ref_seed4096_r0.log | 25 | COAL | 8 | 1971-01-18 | 1971-02-02 | 1 | NON | — | — |
| ref_seed4096_r0.log | 15 | COAL | 57 | 1972-11-20 | 1972-12-03 | 2 | NON | — | — |
| ref_seed424242_r0.log | 38 | GRAI | 11 | 1971-01-25 | 1971-02-02 | 2 | OUI | 1971-05-02 | 3.2 |
| ref_seed424242_r0.log | 17 | WOOD | 9 | 1971-01-11 | 1971-02-02 | 1 | NON | — | — |
| ref_seed424242_r0.log | 0 | COAL | 43 | 1972-03-13 | 1972-04-10 | 1 | NON | — | — |
| ref_seed424242_r0.log | 12 | COAL | 46 | 1972-05-14 | 1972-06-03 | 2 | NON | — | — |
| ref_seed424242_r0.log | 43 | COAL | 50 | 1972-08-03 | 1972-09-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 13 | COAL | 13 | 1971-01-11 | 1971-02-01 | 1 | OUI | 1971-09-02 | 7.7 |
| ref_seed42_r0.log | 0 | COAL | 13 | 1971-01-11 | 1971-02-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 11 | COAL | 49 | 1972-03-05 | 1972-05-01 | 1 | NON | — | — |
| ref_seed512_r0.log | 38 | WOOD | 4 | 1971-01-09 | 1971-02-01 | 1 | OUI | 1972-01-05 | 11.9 |
| ref_seed512_r0.log | 46 | WOOD | 4 | 1971-01-09 | 1971-03-01 | 1 | NON | — | — |
| ref_seed512_r0.log | 35 | WOOD | 4 | 1971-01-09 | 1971-03-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 37 | COAL | 5 | 1971-01-13 | 1971-02-01 | 1 | OUI | 1971-12-01 | 10.6 |
| ref_seed54321_r0.log | 30 | OIL_ | 6 | 1971-01-16 | 1971-02-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 33 | IORE | 7 | 1971-02-14 | 1971-03-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 0 | COAL | 22 | 1972-03-26 | 1972-04-01 | 1 | NON | — | — |
| ref_seed65537_r0.log | 31 | COAL | 6 | 1971-01-05 | 1971-02-07 | 1 | NON | — | — |
| ref_seed65537_r0.log | 39 | COAL | 6 | 1971-01-05 | 1971-03-01 | 1 | OUI | 1972-01-01 | 11.9 |
| ref_seed65537_r0.log | 0 | COAL | 6 | 1971-01-05 | 1971-03-01 | 1 | NON | — | — |
| ref_seed73_r0.log | 9 | IORE | 9 | 1971-01-05 | 1971-02-01 | 2 | NON | — | — |
| ref_seed73_r0.log | 25 | WOOD | 10 | 1971-01-27 | 1971-03-06 | 1 | NON | — | — |
| ref_seed7_r0.log | 13 | WOOD | 14 | 1971-01-23 | 1971-02-01 | 1 | NON | — | — |
| ref_seed8191_r0.log | 37 | COAL | 9 | 1971-01-13 | 1971-02-01 | 1 | NON | — | — |
| ref_seed8191_r0.log | 12 | COAL | 9 | 1971-01-13 | 1971-02-01 | 2 | NON | — | — |
| ref_seed8191_r0.log | 0 | COAL | 48 | 1972-10-05 | 1972-11-03 | 1 | NON | — | — |
| ref_seed8675309_r0.log | 16 | LVST | 8 | 1971-02-02 | 1971-03-01 | 1 | OUI | 1971-12-01 | 9.9 |
| ref_seed8675309_r0.log | 12 | WOOD | 9 | 1971-03-11 | 1971-04-01 | 1 | OUI | 1971-11-06 | 7.9 |
| ref_seed8675309_r0.log | 37 | COAL | 30 | 1972-04-13 | 1972-05-02 | 1 | NON | — | — |
| ref_seed999_r0.log | 26 | COAL | 5 | 1971-01-12 | 1971-02-10 | 1 | NON | — | — |
| ref_seed999_r0.log | 11 | GOOD | 19 | 1972-04-05 | 1972-05-01 | 2 | NON | — | — |
| ref_seed999_r0.log | 3 | WOOD | 25 | 1972-07-22 | 1972-08-03 | 1 | NON | — | — |
| ref_seed999_r0.log | 44 | WOOD | 27 | 1972-08-19 | 1972-10-17 | 1 | NON | — | — |
| ref_seed999_r0.log | 19 | WOOD | 27 | 1972-08-19 | 1972-10-17 | 1 | NON | — | — |
| ref_seed999_r0.log | 20 | WOOD | 30 | 1972-09-14 | 1972-11-01 | 1 | NON | — | — |

### Coût de la sonde

- sélections journalisées : 2424, opcodes total 285540530, médiane 50427, max 3603611
- relevés mensuels : 715, opcodes total 9535090

## Politique `v216_sonde_aaacomplet_20x3_20261016_engine:railseul` : 20 parties sondées

### A. Premier rail voyageurs construit et dernière sélection avant lui

| partie | date | rôle | mode | rang | palier | score | profit calibré | financement | revenu | transporté |
|---|---|---|---|---|---|---|---|---|---|---|
| railseul_seed100_r0.log | 1970-1-27 | construit | rail/pax | 0 | 0 | 0 | 4086 | 54432 | 8004 | 23 |
| railseul_seed100_r0.log | 1970-1-19 | ce rail dans la sélection | rail/pax | 3 | 0 | 98 | 4086 | 41791 | 8004 | 23 |
| railseul_seed100_r0.log | 1970-1-19 | rang 0 | rail/freight | 0 | 0 | 632 | 27375 | 43312 | 31320 | 45 |
| railseul_seed100_r0.log | 1970-1-19 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed100_r0.log | 1970-1-19 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed1024_r0.log | 1970-8-22 | construit | rail/pax | 0 | 0 | 0 | 8610 | 43638 | 12528 | 36 |
| railseul_seed1024_r0.log | 1970-8-15 | ce rail dans la sélection | rail/pax | 26 | 0 | 198 | 8262 | 41791 | 12180 | 35 |
| railseul_seed1024_r0.log | 1970-8-15 | rang 0 | rail/freight | 0 | 0 | 643 | 30110 | 46800 | 34104 | 49 |
| railseul_seed1024_r0.log | 1970-8-15 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed1024_r0.log | 1970-8-15 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed123456_r0.log | 1970-5-4 | construit | rail/pax | 0 | 0 | 0 | 7746 | 42957 | 11664 | 36 |
| railseul_seed123456_r0.log | 1970-4-28 | ce rail dans la sélection | rail/pax | 5 | 0 | 188 | 7746 | 41119 | 11664 | 36 |
| railseul_seed123456_r0.log | 1970-4-28 | rang 0 | rail/freight | 0 | 0 | 1069 | 61144 | 57200 | 65268 | 49 |
| railseul_seed123456_r0.log | 1970-4-28 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed123456_r0.log | 1970-4-28 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed12345_r0.log | 1970-9-2 | construit | rail/pax | 0 | 0 | 0 | 9102 | 68416 | 13020 | 31 |
| railseul_seed12345_r0.log | 1970-8-12 | ce rail dans la sélection | rail/pax | 8 | 0 | 236 | 10719 | 45488 | 14700 | 35 |
| railseul_seed12345_r0.log | 1970-8-12 | rang 0 | rail/freight | 0 | 0 | 340 | 17173 | 50538 | 21120 | 20 |
| railseul_seed12345_r0.log | 1970-8-12 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed12345_r0.log | 1970-8-12 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed1337_r0.log | 1970-3-28 | construit | rail/pax | 0 | 0 | 0 | 6834 | 45867 | 10752 | 32 |
| railseul_seed1337_r0.log | 1970-3-13 | ce rail dans la sélection | rail/pax | 2 | 0 | 165 | 6834 | 41455 | 10752 | 32 |
| railseul_seed1337_r0.log | 1970-3-13 | rang 0 | rail/freight | 0 | 0 | 889 | 43633 | 49103 | 47712 | 56 |
| railseul_seed1337_r0.log | 1970-3-13 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed1337_r0.log | 1970-3-13 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed17_r0.log | 1970-4-24 | construit | rail/pax | 0 | 0 | 0 | 8514 | 45135 | 12432 | 37 |
| railseul_seed17_r0.log | 1970-4-5 | ce rail dans la sélection | rail/pax | 8 | 0 | 206 | 8514 | 41343 | 12432 | 37 |
| railseul_seed17_r0.log | 1970-4-5 | rang 0 | rail/freight | 0 | 0 | 708 | 28431 | 40176 | 32376 | 71 |
| railseul_seed17_r0.log | 1970-4-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed17_r0.log | 1970-4-5 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed1_r0.log | 1970-4-15 | construit | rail/pax | 0 | 0 | 0 | 11682 | 45688 | 15600 | 50 |
| railseul_seed1_r0.log | 1970-4-8 | ce rail dans la sélection | rail/pax | 0 | 0 | 286 | 11682 | 40783 | 15600 | 50 |
| railseul_seed1_r0.log | 1970-4-8 | rang 0 | rail/pax | 0 | 0 | 286 | 11682 | 40783 | 15600 | 50 |
| railseul_seed1_r0.log | 1970-4-8 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed1_r0.log | 1970-4-8 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed2026_r0.log | 1970-12-30 | construit | rail/pax | 0 | 0 | 0 | 13659 | 54998 | 17640 | 35 |
| railseul_seed2026_r0.log | 1970-12-9 | ce rail dans la sélection | rail/pax | 5 | 0 | 286 | 13659 | 47840 | 17640 | 35 |
| railseul_seed2026_r0.log | 1970-12-9 | rang 0 | rail/freight | 0 | 0 | 792 | 39210 | 49495 | 43200 | 40 |
| railseul_seed2026_r0.log | 1970-12-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed2026_r0.log | 1970-12-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed314_r0.log | 1970-6-18 | construit | rail/pax | 0 | 0 | 0 | 6522 | 47136 | 10440 | 30 |
| railseul_seed314_r0.log | 1970-6-6 | ce rail dans la sélection | rail/pax | 5 | 0 | 264 | 11046 | 41903 | 14964 | 43 |
| railseul_seed314_r0.log | 1970-6-6 | rang 0 | rail/freight | 0 | 0 | 1208 | 56445 | 46728 | 60480 | 80 |
| railseul_seed314_r0.log | 1970-6-6 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed314_r0.log | 1970-6-6 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed4096_r0.log | 1970-4-17 | construit | rail/pax | 0 | 0 | 0 | 10770 | 49749 | 14688 | 51 |
| railseul_seed4096_r0.log | 1970-4-9 | ce rail dans la sélection | rail/pax | 11 | 0 | 267 | 10770 | 40335 | 14688 | 51 |
| railseul_seed4096_r0.log | 1970-4-9 | rang 0 | rail/freight | 0 | 0 | 1129 | 62404 | 55296 | 66528 | 56 |
| railseul_seed4096_r0.log | 1970-4-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed4096_r0.log | 1970-4-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed424242_r0.log | 1970-4-24 | construit | rail/pax | 0 | 0 | 0 | 8262 | 64330 | 12180 | 29 |
| railseul_seed424242_r0.log | 1970-4-9 | ce rail dans la sélection | rail/pax | 12 | 0 | 190 | 8262 | 43583 | 12180 | 29 |
| railseul_seed424242_r0.log | 1970-4-9 | rang 0 | rail/freight | 0 | 0 | 793 | 35946 | 45351 | 39936 | 52 |
| railseul_seed424242_r0.log | 1970-4-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed424242_r0.log | 1970-4-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed42_r0.log | 1970-6-14 | construit | rail/pax | 0 | 0 | 0 | 10350 | 52478 | 14268 | 29 |
| railseul_seed42_r0.log | 1970-6-5 | ce rail dans la sélection | rail/pax | 2 | 0 | 210 | 9939 | 47280 | 13920 | 29 |
| railseul_seed42_r0.log | 1970-6-5 | rang 0 | rail/freight | 0 | 0 | 582 | 26295 | 45216 | 30240 | 36 |
| railseul_seed42_r0.log | 1970-6-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed42_r0.log | 1970-6-5 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed512_r0.log | 1970-1-31 | construit | rail/pax | 0 | 0 | 0 | 7950 | 40746 | 11868 | 43 |
| railseul_seed512_r0.log | 1970-1-25 | ce rail dans la sélection | rail/pax | 3 | 0 | 199 | 7950 | 39887 | 11868 | 43 |
| railseul_seed512_r0.log | 1970-1-25 | rang 0 | rail/freight | 0 | 0 | 823 | 38634 | 46919 | 42624 | 48 |
| railseul_seed512_r0.log | 1970-1-25 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed512_r0.log | 1970-1-25 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed54321_r0.log | 1970-2-19 | construit | rail/pax | 0 | 0 | 0 | 15555 | 52069 | 19536 | 37 |
| railseul_seed54321_r0.log | 1970-2-9 | ce rail dans la sélection | rail/pax | 2 | 0 | 321 | 15555 | 48400 | 19536 | 37 |
| railseul_seed54321_r0.log | 1970-2-9 | rang 0 | rail/freight | 0 | 0 | 718 | 27567 | 38384 | 31512 | 101 |
| railseul_seed54321_r0.log | 1970-2-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed54321_r0.log | 1970-2-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed65537_r0.log | 1970-4-18 | construit | rail/pax | 0 | 0 | 0 | 16611 | 71288 | 20592 | 39 |
| railseul_seed65537_r0.log | 1970-4-2 | ce rail dans la sélection | rail/pax | 11 | 0 | 344 | 16611 | 48288 | 20592 | 39 |
| railseul_seed65537_r0.log | 1970-4-2 | rang 0 | rail/freight | 0 | 0 | 784 | 34170 | 43559 | 38160 | 60 |
| railseul_seed65537_r0.log | 1970-4-2 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed65537_r0.log | 1970-4-2 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed73_r0.log | 1970-6-13 | construit | rail/pax | 0 | 0 | 0 | 3282 | 35022 | 7200 | 75 |
| railseul_seed73_r0.log | 1970-6-11 | ce rail dans la sélection | rail/pax | 0 | 0 | 49 | 1746 | 35519 | 5664 | 59 |
| railseul_seed73_r0.log | 1970-6-11 | rang 0 | rail/pax | 0 | 0 | 49 | 1746 | 35519 | 5664 | 59 |
| railseul_seed73_r0.log | 1970-6-11 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed73_r0.log | 1970-6-11 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed7_r0.log | 1971-1-31 | construit | rail/pax | 0 | 0 | 0 | 7962 | 39985 | 11880 | 99 |
| railseul_seed7_r0.log | 1971-1-15 | ce rail dans la sélection | rail/pax | 0 | 0 | 220 | 7962 | 36191 | 11880 | 99 |
| railseul_seed7_r0.log | 1971-1-15 | rang 0 | rail/pax | 0 | 0 | 220 | 7962 | 36191 | 11880 | 99 |
| railseul_seed7_r0.log | 1971-1-15 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed7_r0.log | 1971-1-15 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed8191_r0.log | 1970-7-18 | construit | rail/pax | 0 | 0 | 0 | 13971 | 52112 | 17952 | 34 |
| railseul_seed8191_r0.log | 1970-7-10 | ce rail dans la sélection | rail/pax | 7 | 0 | 409 | 19779 | 48400 | 23760 | 45 |
| railseul_seed8191_r0.log | 1970-7-10 | rang 0 | rail/freight | 0 | 0 | 1028 | 59158 | 57538 | 63336 | 58 |
| railseul_seed8191_r0.log | 1970-7-10 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed8191_r0.log | 1970-7-10 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed8675309_r0.log | 1970-5-11 | construit | rail/pax | 0 | 0 | 0 | 10671 | 51136 | 14652 | 37 |
| railseul_seed8675309_r0.log | 1970-5-5 | ce rail dans la sélection | rail/pax | 1 | 0 | 238 | 10671 | 44928 | 14652 | 37 |
| railseul_seed8675309_r0.log | 1970-5-5 | rang 0 | rail/freight | 0 | 0 | 641 | 33189 | 51768 | 37224 | 33 |
| railseul_seed8675309_r0.log | 1970-5-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed8675309_r0.log | 1970-5-5 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| railseul_seed999_r0.log | 1970-8-1 | construit | rail/pax | 0 | 0 | 0 | 11814 | 48057 | 15732 | 57 |
| railseul_seed999_r0.log | 1970-7-25 | ce rail dans la sélection | rail/pax | 12 | 0 | 312 | 12498 | 40111 | 16416 | 57 |
| railseul_seed999_r0.log | 1970-7-25 | rang 0 | rail/freight | 0 | 0 | 979 | 40782 | 41655 | 44772 | 91 |
| railseul_seed999_r0.log | 1970-7-25 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| railseul_seed999_r0.log | 1970-7-25 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |

### B. Attribution des erreurs : lignes rail 1971 (>= 180 j)

| groupe | n | revenu médian | ratio sommes revenu | profit médian | ratio sommes profit | offre moy. | capacité moy. | cap. séjour | liaison modèle | liaison séjour |
|---|---|---|---|---|---|---|---|---|---|---|
| PASS | 7 | 0.44 | 0.54 | 0.16 | 0.46 | 40.2 | 118.4 | 81.6 | 7 off / 0 cap | 7 off / 0 cap |
| freight | 34 | 0.96 | 0.99 | 1.02 | 1.05 | 55.5 | 73.6 | 58.5 | 30 off / 4 cap | 19 off / 15 cap |

### E. K_dec plus grand que le financement

| mode | K_dec gagne | lignes | part |
|---|---|---|---|
| rail | 12045 | 31566 | 38% |

### V216a. Fantôme : couverture et facteurs (médianes par extrémité, %)

| mode | extrémités | couvert par nous | couvert par adversaire seul | part ligne | gain compagnie | opcodes médians |
|---|---|---|---|---|---|---|
| rail/pax | 46370 | 0 | 27 | 85 | 78 | 356 |

### Rejeu des décisions (§6)

- sélections rejouées : 1117
- sélections avec changement du rang 0 : 16 (dont 15 en 1971-72)

| choix initial | remplaçant | occurrences |
|---|---|---|
| rail/pax | rail/pax | 14 |
| rail/pax | rail/freight | 2 |

### G. Arrivée de la concurrence (industries fret rail)

- industries sources fret observées : 203
- arrivée d'un concurrent sous 12 mois : 12 (5.9%)
*(src tile non requis : proxy basé sur les lignes V216_IND_FLOW dont stations_around augmente après le mois de RAIL_BUILD)*

| partie | industrie | cargo | ligne | date construction | première obs. | gares initiales | arrivée 12 mois | date arrivée | mois écoulés |
|---|---|---|---|---|---|---|---|---|---|
| railseul_seed100_r0.log | 10 | COAL | 0 | 1970-01-18 | 1970-02-01 | 1 | NON | — | — |
| railseul_seed100_r0.log | 18 | WOOD | 3 | 1971-01-19 | 1971-03-01 | 1 | NON | — | — |
| railseul_seed100_r0.log | 11 | IORE | 7 | 1972-09-17 | 1972-10-01 | 1 | NON | — | — |
| railseul_seed1024_r0.log | 46 | WOOD | 0 | 1970-05-25 | 1970-06-08 | 1 | NON | — | — |
| railseul_seed1024_r0.log | 34 | IORE | 1 | 1970-06-05 | 1970-07-01 | 2 | NON | — | — |
| railseul_seed1024_r0.log | 42 | GRAI | 3 | 1970-09-05 | 1970-10-01 | 1 | NON | — | — |
| railseul_seed1024_r0.log | 22 | GRAI | 3 | 1970-09-05 | 1970-10-01 | 1 | OUI | 1971-09-01 | 11.9 |
| railseul_seed1024_r0.log | 39 | LVST | 7 | 1971-08-25 | 1971-09-01 | 1 | NON | — | — |
| railseul_seed1024_r0.log | 36 | COAL | 8 | 1972-01-28 | 1972-03-01 | 1 | NON | — | — |
| railseul_seed1024_r0.log | 17 | COAL | 9 | 1972-05-01 | 1972-06-05 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 44 | COAL | 0 | 1970-01-31 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 50 | COAL | 1 | 1970-02-23 | 1970-04-06 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 41 | COAL | 1 | 1970-02-23 | 1970-04-06 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 0 | COAL | 2 | 1970-03-18 | 1970-05-05 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 3 | WOOD | 6 | 1971-02-07 | 1971-03-05 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 12 | IORE | 7 | 1971-07-28 | 1971-09-03 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 34 | OIL_ | 8 | 1971-12-06 | 1972-01-07 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 30 | LVST | 9 | 1971-12-25 | 1972-01-07 | 1 | OUI | 1972-04-01 | 3.2 |
| railseul_seed123456_r0.log | 26 | LVST | 10 | 1972-02-01 | 1972-03-01 | 1 | NON | — | — |
| railseul_seed123456_r0.log | 42 | IORE | 12 | 1972-09-11 | 1972-10-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 49 | COAL | 0 | 1970-02-02 | 1970-03-09 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 17 | COAL | 0 | 1970-02-02 | 1970-03-09 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 32 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 28 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 0 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 33 | IORE | 7 | 1970-12-15 | 1971-01-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 21 | IORE | 7 | 1970-12-15 | 1971-01-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 16 | WOOD | 6 | 1970-11-29 | 1971-01-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 7 | GRAI | 9 | 1971-05-11 | 1971-06-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 23 | GRAI | 10 | 1971-09-10 | 1971-10-06 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 40 | GRAI | 10 | 1971-09-10 | 1971-11-03 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 36 | LVST | 11 | 1972-02-04 | 1972-03-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 43 | WOOD | 13 | 1972-07-03 | 1972-08-01 | 1 | NON | — | — |
| railseul_seed12345_r0.log | 9 | IORE | 14 | 1972-08-11 | 1972-09-01 | 3 | NON | — | — |
| railseul_seed12345_r0.log | 18 | IORE | 14 | 1972-08-11 | 1972-10-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 22 | COAL | 0 | 1970-02-24 | 1970-04-07 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 0 | COAL | 0 | 1970-02-24 | 1970-04-07 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 38 | WOOD | 4 | 1970-06-12 | 1970-07-01 | 1 | OUI | 1971-02-01 | 7.7 |
| railseul_seed1337_r0.log | 33 | WOOD | 4 | 1970-06-12 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 46 | IORE | 8 | 1971-01-19 | 1971-02-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 9 | IORE | 9 | 1971-07-04 | 1971-08-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 29 | OIL_ | 11 | 1972-02-22 | 1972-03-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 32 | OIL_ | 12 | 1972-08-08 | 1972-09-01 | 1 | NON | — | — |
| railseul_seed1337_r0.log | 18 | OIL_ | 13 | 1972-11-16 | 1972-12-04 | 2 | NON | — | — |
| railseul_seed17_r0.log | 10 | COAL | 0 | 1970-01-28 | 1970-02-01 | 1 | NON | — | — |
| railseul_seed17_r0.log | 20 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed17_r0.log | 0 | COAL | 1 | 1970-02-14 | 1970-04-05 | 1 | NON | — | — |
| railseul_seed17_r0.log | 35 | COAL | 2 | 1970-03-17 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed17_r0.log | 3 | WOOD | 7 | 1971-01-20 | 1971-02-01 | 2 | NON | — | — |
| railseul_seed17_r0.log | 24 | WOOD | 8 | 1971-05-16 | 1971-06-01 | 1 | OUI | 1972-01-03 | 7.6 |
| railseul_seed17_r0.log | 38 | IORE | 9 | 1971-08-21 | 1971-09-01 | 1 | OUI | 1972-02-03 | 5.5 |
| railseul_seed17_r0.log | 7 | LVST | 11 | 1972-02-24 | 1972-03-14 | 1 | NON | — | — |
| railseul_seed17_r0.log | 17 | GOOD | 12 | 1972-03-27 | 1972-05-01 | 2 | NON | — | — |
| railseul_seed17_r0.log | 26 | WOOD | 14 | 1972-10-14 | 1972-11-01 | 3 | NON | — | — |
| railseul_seed1_r0.log | 25 | COAL | 0 | 1970-01-25 | 1970-02-02 | 1 | NON | — | — |
| railseul_seed1_r0.log | 16 | COAL | 0 | 1970-01-25 | 1970-03-03 | 1 | NON | — | — |
| railseul_seed1_r0.log | 0 | COAL | 1 | 1970-02-17 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed1_r0.log | 3 | WOOD | 6 | 1971-02-19 | 1971-03-01 | 2 | NON | — | — |
| railseul_seed1_r0.log | 14 | WOOD | 6 | 1971-02-19 | 1971-04-01 | 2 | NON | — | — |
| railseul_seed1_r0.log | 30 | WOOD | 8 | 1971-06-26 | 1971-08-03 | 1 | NON | — | — |
| railseul_seed1_r0.log | 36 | IORE | 10 | 1971-12-05 | 1972-01-04 | 1 | NON | — | — |
| railseul_seed1_r0.log | 11 | GRAI | 12 | 1972-06-09 | 1972-07-01 | 2 | NON | — | — |
| railseul_seed1_r0.log | 15 | GRAI | 13 | 1972-08-13 | 1972-09-04 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 46 | COAL | 0 | 1970-03-19 | 1970-04-11 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 17 | COAL | 0 | 1970-03-19 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 28 | COAL | 2 | 1970-05-23 | 1970-06-06 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 42 | COAL | 2 | 1970-05-23 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 13 | COAL | 2 | 1970-05-23 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 0 | COAL | 2 | 1970-05-23 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 51 | COAL | 6 | 1970-09-30 | 1970-11-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 3 | WOOD | 8 | 1971-02-15 | 1971-03-01 | 2 | NON | — | — |
| railseul_seed2026_r0.log | 32 | WOOD | 9 | 1971-06-11 | 1971-07-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 24 | WOOD | 10 | 1971-08-20 | 1971-10-03 | 1 | OUI | 1972-03-01 | 6.4 |
| railseul_seed2026_r0.log | 30 | IORE | 11 | 1971-11-23 | 1971-12-01 | 1 | NON | — | — |
| railseul_seed2026_r0.log | 48 | GRAI | 12 | 1972-05-15 | 1972-06-02 | 2 | NON | — | — |
| railseul_seed2026_r0.log | 45 | GRAI | 13 | 1972-08-28 | 1972-10-09 | 1 | NON | — | — |
| railseul_seed314_r0.log | 46 | COAL | 0 | 1970-01-26 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 0 | COAL | 0 | 1970-01-26 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 27 | COAL | 2 | 1970-04-19 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 11 | COAL | 2 | 1970-04-19 | 1970-06-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 15 | IORE | 7 | 1971-02-09 | 1971-03-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 13 | IORE | 8 | 1971-04-11 | 1971-05-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 44 | GRAI | 9 | 1971-09-21 | 1971-10-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 7 | GRAI | 10 | 1971-12-14 | 1972-01-01 | 1 | NON | — | — |
| railseul_seed314_r0.log | 3 | WOOD | 12 | 1972-06-21 | 1972-07-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 35 | COAL | 0 | 1970-01-25 | 1970-02-10 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 15 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 0 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 25 | COAL | 1 | 1970-02-07 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 18 | WOOD | 8 | 1971-03-04 | 1971-04-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 3 | WOOD | 9 | 1971-05-13 | 1971-07-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 40 | WOOD | 10 | 1971-09-24 | 1971-10-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 7 | GRAI | 11 | 1972-01-23 | 1972-02-01 | 1 | NON | — | — |
| railseul_seed4096_r0.log | 16 | GRAI | 12 | 1972-07-10 | 1972-08-01 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 0 | COAL | 0 | 1970-01-23 | 1970-02-10 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 12 | COAL | 0 | 1970-01-23 | 1970-03-03 | 1 | OUI | 1970-07-08 | 5.5 |
| railseul_seed424242_r0.log | 43 | COAL | 1 | 1970-02-08 | 1970-04-05 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 39 | COAL | 1 | 1970-02-08 | 1970-04-05 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 17 | WOOD | 6 | 1970-08-11 | 1970-09-01 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 38 | GRAI | 9 | 1971-04-05 | 1971-04-06 | 2 | NON | — | — |
| railseul_seed424242_r0.log | 25 | IORE | 8 | 1971-03-24 | 1971-04-06 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 26 | GRAI | 9 | 1971-04-05 | 1971-05-01 | 1 | OUI | 1971-08-01 | 3.9 |
| railseul_seed424242_r0.log | 44 | GRAI | 9 | 1971-04-05 | 1971-06-01 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 24 | OIL_ | 10 | 1971-09-30 | 1971-11-06 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 33 | IORE | 12 | 1972-02-26 | 1972-04-01 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 28 | GOOD | 11 | 1972-02-13 | 1972-04-01 | 2 | NON | — | — |
| railseul_seed424242_r0.log | 30 | IORE | 14 | 1972-06-08 | 1972-07-01 | 2 | NON | — | — |
| railseul_seed424242_r0.log | 36 | LVST | 16 | 1972-10-13 | 1972-11-05 | 1 | NON | — | — |
| railseul_seed424242_r0.log | 48 | LVST | 16 | 1972-10-13 | 1972-12-01 | 2 | NON | — | — |
| railseul_seed42_r0.log | 34 | COAL | 0 | 1970-01-27 | 1970-02-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 13 | COAL | 0 | 1970-01-27 | 1970-03-02 | 1 | NON | — | — |
| railseul_seed42_r0.log | 45 | COAL | 1 | 1970-02-13 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 11 | COAL | 1 | 1970-02-13 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 0 | COAL | 1 | 1970-02-13 | 1970-04-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 38 | IORE | 9 | 1971-04-26 | 1971-05-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 19 | WOOD | 8 | 1971-04-02 | 1971-05-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 41 | IORE | 9 | 1971-04-26 | 1971-06-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 21 | IORE | 10 | 1971-05-09 | 1971-07-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 7 | GRAI | 12 | 1972-01-03 | 1972-02-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 8 | OIL_ | 13 | 1972-02-11 | 1972-03-01 | 1 | NON | — | — |
| railseul_seed42_r0.log | 14 | OIL_ | 14 | 1972-05-21 | 1972-06-04 | 1 | NON | — | — |
| railseul_seed42_r0.log | 24 | OIL_ | 15 | 1972-08-30 | 1972-10-06 | 1 | NON | — | — |
| railseul_seed512_r0.log | 0 | COAL | 0 | 1970-01-24 | 1970-02-02 | 1 | NON | — | — |
| railseul_seed512_r0.log | 36 | WOOD | 6 | 1971-01-19 | 1971-02-01 | 2 | NON | — | — |
| railseul_seed512_r0.log | 27 | IORE | 7 | 1972-01-01 | 1972-02-01 | 1 | NON | — | — |
| railseul_seed512_r0.log | 11 | OIL_ | 8 | 1972-06-09 | 1972-07-01 | 1 | NON | — | — |
| railseul_seed512_r0.log | 22 | LVST | 9 | 1972-07-20 | 1972-08-01 | 1 | NON | — | — |
| railseul_seed512_r0.log | 26 | LVST | 10 | 1972-10-29 | 1972-12-01 | 2 | NON | — | — |
| railseul_seed54321_r0.log | 37 | COAL | 0 | 1970-01-21 | 1970-02-06 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 0 | COAL | 0 | 1970-01-21 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 14 | WOOD | 5 | 1971-01-24 | 1971-02-02 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 33 | IORE | 7 | 1971-07-15 | 1971-08-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 18 | WOOD | 6 | 1971-06-27 | 1971-08-01 | 1 | OUI | 1971-09-01 | 2.2 |
| railseul_seed54321_r0.log | 9 | IORE | 8 | 1971-09-12 | 1971-10-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 13 | GRAI | 9 | 1972-01-26 | 1972-02-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 27 | GRAI | 10 | 1972-04-22 | 1972-05-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 7 | GRAI | 11 | 1972-06-01 | 1972-07-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 42 | LVST | 13 | 1972-11-17 | 1972-12-01 | 1 | NON | — | — |
| railseul_seed54321_r0.log | 15 | OIL_ | 12 | 1972-10-28 | 1972-12-01 | 3 | NON | — | — |
| railseul_seed65537_r0.log | 39 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 30 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 0 | COAL | 1 | 1970-02-13 | 1970-04-02 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 31 | COAL | 2 | 1970-03-17 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 44 | COAL | 5 | 1970-07-24 | 1970-08-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 9 | IORE | 8 | 1971-05-26 | 1971-06-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 19 | GRAI | 11 | 1972-02-28 | 1972-04-01 | 1 | NON | — | — |
| railseul_seed65537_r0.log | 10 | OIL_ | 13 | 1972-08-14 | 1972-09-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 50 | COAL | 0 | 1970-03-28 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 49 | WOOD | 1 | 1970-04-21 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 25 | WOOD | 1 | 1970-04-21 | 1970-06-09 | 1 | NON | — | — |
| railseul_seed73_r0.log | 43 | WOOD | 2 | 1970-05-12 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 3 | WOOD | 2 | 1970-05-12 | 1970-07-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 9 | IORE | 8 | 1971-09-08 | 1971-10-01 | 2 | NON | — | — |
| railseul_seed73_r0.log | 8 | OIL_ | 9 | 1972-03-27 | 1972-05-01 | 1 | NON | — | — |
| railseul_seed73_r0.log | 48 | LVST | 11 | 1972-11-17 | 1972-12-01 | 1 | NON | — | — |
| railseul_seed7_r0.log | 33 | COAL | 0 | 1970-01-30 | 1970-03-03 | 1 | NON | — | — |
| railseul_seed7_r0.log | 29 | COAL | 0 | 1970-01-30 | 1970-03-03 | 1 | NON | — | — |
| railseul_seed7_r0.log | 47 | COAL | 2 | 1970-05-25 | 1970-06-04 | 1 | NON | — | — |
| railseul_seed7_r0.log | 23 | WOOD | 3 | 1970-06-13 | 1970-07-10 | 1 | NON | — | — |
| railseul_seed7_r0.log | 26 | IORE | 5 | 1970-10-24 | 1970-11-10 | 1 | NON | — | — |
| railseul_seed7_r0.log | 16 | WOOD | 4 | 1970-09-30 | 1970-11-10 | 1 | NON | — | — |
| railseul_seed7_r0.log | 49 | IORE | 5 | 1970-10-24 | 1970-12-02 | 1 | NON | — | — |
| railseul_seed7_r0.log | 9 | IORE | 6 | 1970-11-06 | 1971-01-01 | 1 | NON | — | — |
| railseul_seed7_r0.log | 8 | OIL_ | 9 | 1971-07-04 | 1971-08-01 | 1 | NON | — | — |
| railseul_seed7_r0.log | 31 | LVST | 10 | 1971-08-29 | 1971-10-09 | 1 | NON | — | — |
| railseul_seed7_r0.log | 7 | LVST | 11 | 1971-10-08 | 1971-11-01 | 2 | NON | — | — |
| railseul_seed7_r0.log | 40 | WOOD | 12 | 1972-04-07 | 1972-05-01 | 2 | NON | — | — |
| railseul_seed7_r0.log | 44 | IORE | 13 | 1972-06-15 | 1972-07-07 | 1 | NON | — | — |
| railseul_seed7_r0.log | 15 | GRAI | 14 | 1972-11-16 | 1972-12-10 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 12 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 37 | COAL | 1 | 1970-04-01 | 1970-05-04 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 35 | COAL | 1 | 1970-04-01 | 1970-05-04 | 1 | OUI | 1971-02-02 | 10.1 |
| railseul_seed8191_r0.log | 0 | COAL | 1 | 1970-04-01 | 1970-06-02 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 3 | WOOD | 5 | 1970-08-06 | 1970-09-01 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 45 | WOOD | 5 | 1970-08-06 | 1970-10-01 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 14 | IORE | 10 | 1971-04-06 | 1971-05-02 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 11 | OIL_ | 11 | 1971-06-30 | 1971-08-01 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 47 | LVST | 12 | 1971-08-19 | 1971-10-10 | 1 | OUI | 1971-12-03 | 3.5 |
| railseul_seed8191_r0.log | 27 | COAL | 14 | 1971-11-13 | 1971-12-03 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 25 | LVST | 15 | 1972-04-01 | 1972-05-01 | 1 | NON | — | — |
| railseul_seed8191_r0.log | 20 | GRAI | 16 | 1972-10-15 | 1972-11-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 37 | COAL | 0 | 1970-01-25 | 1970-02-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 35 | WOOD | 4 | 1971-01-23 | 1971-03-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 31 | WOOD | 4 | 1971-01-23 | 1971-03-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 3 | WOOD | 6 | 1971-04-19 | 1971-05-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 39 | IORE | 8 | 1971-09-12 | 1971-10-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 33 | IORE | 9 | 1972-01-21 | 1972-02-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 8 | OIL_ | 10 | 1972-07-28 | 1972-09-01 | 1 | NON | — | — |
| railseul_seed8675309_r0.log | 26 | OIL_ | 11 | 1972-09-10 | 1972-10-01 | 5 | NON | — | — |
| railseul_seed999_r0.log | 10 | COAL | 0 | 1970-01-25 | 1970-02-11 | 1 | NON | — | — |
| railseul_seed999_r0.log | 23 | COAL | 0 | 1970-01-25 | 1970-03-03 | 1 | NON | — | — |
| railseul_seed999_r0.log | 0 | COAL | 0 | 1970-01-25 | 1970-03-03 | 1 | NON | — | — |
| railseul_seed999_r0.log | 31 | COAL | 1 | 1970-02-08 | 1970-04-08 | 1 | NON | — | — |
| railseul_seed999_r0.log | 22 | COAL | 3 | 1970-03-25 | 1970-05-01 | 1 | NON | — | — |
| railseul_seed999_r0.log | 32 | COAL | 5 | 1970-06-11 | 1970-07-04 | 1 | NON | — | — |
| railseul_seed999_r0.log | 37 | COAL | 8 | 1970-11-05 | 1970-12-01 | 1 | NON | — | — |
| railseul_seed999_r0.log | 28 | WOOD | 9 | 1971-01-27 | 1971-03-01 | 1 | NON | — | — |
| railseul_seed999_r0.log | 44 | WOOD | 10 | 1971-05-13 | 1971-06-01 | 1 | NON | — | — |
| railseul_seed999_r0.log | 3 | WOOD | 11 | 1971-10-17 | 1971-11-04 | 1 | OUI | 1972-07-08 | 8.7 |
| railseul_seed999_r0.log | 30 | IORE | 12 | 1971-11-12 | 1971-12-01 | 1 | NON | — | — |
| railseul_seed999_r0.log | 15 | IORE | 12 | 1971-11-12 | 1972-01-10 | 1 | NON | — | — |
| railseul_seed999_r0.log | 8 | OIL_ | 14 | 1972-05-18 | 1972-06-03 | 1 | NON | — | — |
| railseul_seed999_r0.log | 16 | LVST | 17 | 1972-09-08 | 1972-11-01 | 1 | NON | — | — |

### Coût de la sonde

- sélections journalisées : 1117, opcodes total 199882064, médiane 63745, max 1584206
- relevés mensuels : 720, opcodes total 7833089

## Politique `v216_sonde_aaarail_20x3_20261016_engine:ref` : 20 parties sondées

### A. Premier rail voyageurs construit et dernière sélection avant lui

| partie | date | rôle | mode | rang | palier | score | profit calibré | financement | revenu | transporté |
|---|---|---|---|---|---|---|---|---|---|---|
| ref_seed100_r0.log | 1970-1-27 | construit | rail/pax | 0 | 0 | 0 | 4086 | 54432 | 8004 | 23 |
| ref_seed100_r0.log | 1970-1-19 | ce rail dans la sélection | rail/pax | 3 | 0 | 98 | 4086 | 41791 | 8004 | 23 |
| ref_seed100_r0.log | 1970-1-19 | rang 0 | rail/freight | 0 | 0 | 632 | 27375 | 43312 | 31320 | 45 |
| ref_seed100_r0.log | 1970-1-19 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed100_r0.log | 1970-1-19 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed1024_r0.log | 1971-11-1 | construit | rail/pax | 0 | 0 | 0 | 1626 | 41187 | 5544 | 33 |
| ref_seed1024_r0.log | 1971-10-6 | ce rail dans la sélection | rail/pax | 0 | 0 | 126 | 4818 | 37199 | 8736 | 52 |
| ref_seed1024_r0.log | 1971-10-6 | rang 0 | rail/pax | 0 | 0 | 126 | 4818 | 37199 | 8736 | 52 |
| ref_seed1024_r0.log | 1971-10-6 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed1024_r0.log | 1971-10-6 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed123456_r0.log | 1970-6-2 | construit | rail/pax | 0 | 0 | 0 | 7746 | 44385 | 11664 | 36 |
| ref_seed123456_r0.log | 1970-5-3 | ce rail dans la sélection | rail/pax | 5 | 0 | 188 | 7746 | 41119 | 11664 | 36 |
| ref_seed123456_r0.log | 1970-5-3 | rang 0 | rail/freight | 0 | 0 | 1069 | 61144 | 57200 | 65268 | 49 |
| ref_seed123456_r0.log | 1970-5-3 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed123456_r0.log | 1970-5-3 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed12345_r0.log | 1971-12-5 | construit | rail/pax | 0 | 0 | 0 | 15999 | 57268 | 19980 | 37 |
| ref_seed12345_r0.log | 1971-11-5 | ce rail dans la sélection | rail/pax | 3 | 0 | 329 | 15999 | 48624 | 19980 | 37 |
| ref_seed12345_r0.log | 1971-11-5 | rang 0 | rail/freight | 0 | 0 | 443 | 23849 | 53824 | 27900 | 31 |
| ref_seed12345_r0.log | 1971-11-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed12345_r0.log | 1971-11-5 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed1337_r0.log | 1970-3-20 | construit | rail/pax | 0 | 0 | 0 | 6834 | 49457 | 10752 | 32 |
| ref_seed1337_r0.log | 1970-3-12 | ce rail dans la sélection | rail/pax | 2 | 0 | 165 | 6834 | 41455 | 10752 | 32 |
| ref_seed1337_r0.log | 1970-3-12 | rang 0 | rail/freight | 0 | 0 | 889 | 43633 | 49103 | 47712 | 56 |
| ref_seed1337_r0.log | 1970-3-12 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed1337_r0.log | 1970-3-12 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed17_r0.log | 1970-5-4 | construit | rail/pax | 0 | 0 | 0 | 8514 | 44542 | 12432 | 37 |
| ref_seed17_r0.log | 1970-4-11 | ce rail dans la sélection | rail/pax | 8 | 0 | 206 | 8514 | 41343 | 12432 | 37 |
| ref_seed17_r0.log | 1970-4-11 | rang 0 | rail/freight | 0 | 0 | 708 | 28431 | 40176 | 32376 | 71 |
| ref_seed17_r0.log | 1970-4-11 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed17_r0.log | 1970-4-11 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed1_r0.log | 1970-3-21 | construit | rail/pax | 0 | 0 | 0 | 11682 | 46944 | 15600 | 50 |
| ref_seed1_r0.log | 1970-3-4 | ce rail dans la sélection | rail/pax | 0 | 0 | 286 | 11682 | 40783 | 15600 | 50 |
| ref_seed1_r0.log | 1970-3-4 | rang 0 | rail/pax | 0 | 0 | 286 | 11682 | 40783 | 15600 | 50 |
| ref_seed1_r0.log | 1970-3-4 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed1_r0.log | 1970-3-4 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed2026_r0.log | 1971-2-2 | construit | rail/pax | 0 | 0 | 0 | 13659 | 56482 | 17640 | 35 |
| ref_seed2026_r0.log | 1971-1-20 | ce rail dans la sélection | rail/pax | 15 | 0 | 307 | 14667 | 47840 | 18648 | 37 |
| ref_seed2026_r0.log | 1971-1-20 | rang 0 | rail/freight | 0 | 0 | 2158 | 113357 | 52529 | 117648 | 172 |
| ref_seed2026_r0.log | 1971-1-20 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed2026_r0.log | 1971-1-20 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed314_r0.log | 1971-11-5 | construit | rail/pax | 0 | 0 | 0 | 19635 | 63920 | 23616 | 41 |
| ref_seed314_r0.log | 1971-10-13 | ce rail dans la sélection | rail/pax | 0 | 0 | 164 | 19059 | 49632 | 23040 | 40 |
| ref_seed314_r0.log | 1971-10-13 | rang 0 | rail/pax | 0 | 0 | 164 | 19059 | 49632 | 23040 | 40 |
| ref_seed314_r0.log | 1971-10-13 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed314_r0.log | 1971-10-13 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed4096_r0.log | 1970-4-12 | construit | rail/pax | 0 | 0 | 0 | 10770 | 53655 | 14688 | 51 |
| ref_seed4096_r0.log | 1970-4-8 | ce rail dans la sélection | rail/pax | 11 | 0 | 267 | 10770 | 40335 | 14688 | 51 |
| ref_seed4096_r0.log | 1970-4-8 | rang 0 | rail/freight | 0 | 0 | 1129 | 62404 | 55296 | 66528 | 56 |
| ref_seed4096_r0.log | 1970-4-8 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed4096_r0.log | 1970-4-8 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed424242_r0.log | 1970-3-24 | construit | rail/pax | 0 | 0 | 0 | 10419 | 62667 | 14400 | 30 |
| ref_seed424242_r0.log | 1970-3-14 | ce rail dans la sélection | rail/pax | 12 | 0 | 221 | 10419 | 47056 | 14400 | 30 |
| ref_seed424242_r0.log | 1970-3-14 | rang 0 | rail/freight | 0 | 0 | 793 | 35946 | 45351 | 39936 | 52 |
| ref_seed424242_r0.log | 1970-3-14 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed424242_r0.log | 1970-3-14 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed42_r0.log | 1970-6-14 | construit | rail/pax | 0 | 0 | 0 | 10350 | 52702 | 14268 | 29 |
| ref_seed42_r0.log | 1970-6-5 | ce rail dans la sélection | rail/pax | 2 | 0 | 210 | 9939 | 47280 | 13920 | 29 |
| ref_seed42_r0.log | 1970-6-5 | rang 0 | rail/freight | 0 | 0 | 582 | 26295 | 45216 | 30240 | 36 |
| ref_seed42_r0.log | 1970-6-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed42_r0.log | 1970-6-5 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed512_r0.log | 1970-1-31 | construit | rail/pax | 0 | 0 | 0 | 7950 | 40746 | 11868 | 43 |
| ref_seed512_r0.log | 1970-1-25 | ce rail dans la sélection | rail/pax | 3 | 0 | 199 | 7950 | 39887 | 11868 | 43 |
| ref_seed512_r0.log | 1970-1-25 | rang 0 | rail/freight | 0 | 0 | 823 | 38634 | 46919 | 42624 | 48 |
| ref_seed512_r0.log | 1970-1-25 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed512_r0.log | 1970-1-25 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed54321_r0.log | 1970-2-19 | construit | rail/pax | 0 | 0 | 0 | 15555 | 52084 | 19536 | 37 |
| ref_seed54321_r0.log | 1970-2-9 | ce rail dans la sélection | rail/pax | 2 | 0 | 321 | 15555 | 48400 | 19536 | 37 |
| ref_seed54321_r0.log | 1970-2-9 | rang 0 | rail/freight | 0 | 0 | 718 | 27567 | 38384 | 31512 | 101 |
| ref_seed54321_r0.log | 1970-2-9 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed54321_r0.log | 1970-2-9 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed65537_r0.log | 1970-4-15 | construit | rail/pax | 0 | 0 | 0 | 16611 | 65383 | 20592 | 39 |
| ref_seed65537_r0.log | 1970-4-8 | ce rail dans la sélection | rail/pax | 10 | 0 | 344 | 16611 | 48288 | 20592 | 39 |
| ref_seed65537_r0.log | 1970-4-8 | rang 0 | rail/freight | 0 | 0 | 784 | 34170 | 43559 | 38160 | 60 |
| ref_seed65537_r0.log | 1970-4-8 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed65537_r0.log | 1970-4-8 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed73_r0.log | 1970-7-4 | construit | rail/pax | 0 | 0 | 0 | 21219 | 56903 | 25200 | 42 |
| ref_seed73_r0.log | 1970-6-12 | ce rail dans la sélection | rail/pax | 3 | 0 | 423 | 21219 | 50192 | 25200 | 42 |
| ref_seed73_r0.log | 1970-6-12 | rang 0 | rail/freight | 0 | 0 | 622 | 27002 | 43440 | 30996 | 63 |
| ref_seed73_r0.log | 1970-6-12 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed73_r0.log | 1970-6-12 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed7_r0.log | 1971-7-22 | construit | rail/pax | 0 | 0 | 0 | 23376 | 69618 | 31464 | 46 |
| ref_seed7_r0.log | 1971-7-11 | ce rail dans la sélection | rail/pax | 0 | 0 | 214 | 36372 | 88800 | 44460 | 65 |
| ref_seed7_r0.log | 1971-7-11 | rang 0 | rail/pax | 0 | 0 | 214 | 36372 | 88800 | 44460 | 65 |
| ref_seed7_r0.log | 1971-7-11 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed7_r0.log | 1971-7-11 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed8191_r0.log | 1970-8-15 | construit | rail/pax | 0 | 0 | 0 | 13971 | 53032 | 17952 | 34 |
| ref_seed8191_r0.log | 1970-8-8 | ce rail dans la sélection | rail/pax | 7 | 0 | 387 | 18723 | 48400 | 22704 | 43 |
| ref_seed8191_r0.log | 1970-8-8 | rang 0 | rail/freight | 0 | 0 | 841 | 46146 | 54848 | 50232 | 46 |
| ref_seed8191_r0.log | 1970-8-8 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed8191_r0.log | 1970-8-8 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed8675309_r0.log | 1970-4-21 | construit | rail/pax | 0 | 0 | 0 | 10899 | 65476 | 14880 | 31 |
| ref_seed8675309_r0.log | 1970-4-11 | ce rail dans la sélection | rail/pax | 11 | 0 | 252 | 11859 | 47056 | 15840 | 33 |
| ref_seed8675309_r0.log | 1970-4-11 | rang 0 | rail/freight | 0 | 0 | 786 | 35175 | 44766 | 39168 | 64 |
| ref_seed8675309_r0.log | 1970-4-11 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed8675309_r0.log | 1970-4-11 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| ref_seed999_r0.log | 1970-9-11 | construit | rail/pax | 0 | 0 | 0 | 5874 | 35814 | 9792 | 102 |
| ref_seed999_r0.log | 1970-9-3 | ce rail dans la sélection | rail/pax | 3 | 0 | 106 | 3762 | 35407 | 7680 | 80 |
| ref_seed999_r0.log | 1970-9-3 | rang 0 | rail/freight | 0 | 0 | 300 | 10740 | 35775 | 14640 | 61 |
| ref_seed999_r0.log | 1970-9-3 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| ref_seed999_r0.log | 1970-9-3 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |

### B. Attribution des erreurs : lignes rail 1971 (>= 180 j)

| groupe | n | revenu médian | ratio sommes revenu | profit médian | ratio sommes profit | offre moy. | capacité moy. | cap. séjour | liaison modèle | liaison séjour |
|---|---|---|---|---|---|---|---|---|---|---|
| PASS | 14 | 0.93 | 1.00 | 1.50 | 1.25 | 35.4 | 155.7 | 97.9 | 14 off / 0 cap | 14 off / 0 cap |
| freight | 22 | 0.89 | 0.81 | 0.95 | 0.83 | 48.7 | 73.7 | 61.7 | 21 off / 1 cap | 17 off / 5 cap |

### E. K_dec plus grand que le financement

| mode | K_dec gagne | lignes | part |
|---|---|---|---|
| rail | 15652 | 34738 | 45% |

### V216a. Fantôme : couverture et facteurs (médianes par extrémité, %)

| mode | extrémités | couvert par nous | couvert par adversaire seul | part ligne | gain compagnie | opcodes médians |
|---|---|---|---|---|---|---|
| rail/pax | 53268 | 0 | 0 | 100 | 100 | 356 |

### Rejeu des décisions (§6)

- sélections rejouées : 1038
- sélections avec changement du rang 0 : 24 (dont 23 en 1971-72)

| choix initial | remplaçant | occurrences |
|---|---|---|
| rail/pax | rail/freight | 16 |
| rail/pax | rail/pax | 8 |

### G. Arrivée de la concurrence (industries fret rail)

- industries sources fret observées : 147
- arrivée d'un concurrent sous 12 mois : 53 (36.1%)
*(src tile non requis : proxy basé sur les lignes V216_IND_FLOW dont stations_around augmente après le mois de RAIL_BUILD)*

| partie | industrie | cargo | ligne | date construction | première obs. | gares initiales | arrivée 12 mois | date arrivée | mois écoulés |
|---|---|---|---|---|---|---|---|---|---|
| ref_seed100_r0.log | 10 | COAL | 0 | 1970-01-18 | 1970-02-01 | 1 | OUI | 1970-11-01 | 9.4 |
| ref_seed100_r0.log | 30 | WOOD | 5 | 1971-05-25 | 1971-06-01 | 1 | NON | — | — |
| ref_seed100_r0.log | 3 | WOOD | 5 | 1971-05-25 | 1971-07-01 | 1 | NON | — | — |
| ref_seed100_r0.log | 11 | IORE | 7 | 1972-02-19 | 1972-03-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 46 | WOOD | 0 | 1970-05-15 | 1970-06-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 34 | IORE | 1 | 1970-07-21 | 1970-08-06 | 1 | OUI | 1971-02-05 | 6.5 |
| ref_seed1024_r0.log | 42 | GRAI | 2 | 1970-08-03 | 1970-09-02 | 1 | OUI | 1970-12-09 | 4.2 |
| ref_seed1024_r0.log | 8 | OIL_ | 3 | 1970-12-04 | 1971-01-01 | 1 | NON | — | — |
| ref_seed1024_r0.log | 45 | COAL | 4 | 1971-04-27 | 1971-06-05 | 2 | NON | — | — |
| ref_seed1024_r0.log | 27 | COAL | 4 | 1971-04-27 | 1971-06-05 | 1 | NON | — | — |
| ref_seed1024_r0.log | 3 | WOOD | 5 | 1971-05-15 | 1971-06-05 | 1 | NON | — | — |
| ref_seed1024_r0.log | 35 | LVST | 9 | 1972-03-13 | 1972-04-01 | 1 | OUI | 1972-06-01 | 2.6 |
| ref_seed123456_r0.log | 44 | COAL | 0 | 1970-01-31 | 1970-03-01 | 1 | OUI | 1971-01-01 | 11.0 |
| ref_seed123456_r0.log | 50 | COAL | 0 | 1970-01-31 | 1970-04-01 | 1 | OUI | 1970-05-03 | 3.0 |
| ref_seed123456_r0.log | 41 | COAL | 0 | 1970-01-31 | 1970-04-01 | 1 | NON | — | — |
| ref_seed123456_r0.log | 0 | COAL | 3 | 1970-05-01 | 1970-06-04 | 1 | NON | — | — |
| ref_seed123456_r0.log | 3 | WOOD | 7 | 1971-04-23 | 1971-06-01 | 1 | OUI | 1972-02-09 | 9.6 |
| ref_seed123456_r0.log | 45 | IORE | 8 | 1971-06-19 | 1971-07-01 | 1 | NON | — | — |
| ref_seed123456_r0.log | 34 | OIL_ | 9 | 1972-01-07 | 1972-02-09 | 1 | NON | — | — |
| ref_seed123456_r0.log | 30 | LVST | 10 | 1972-02-08 | 1972-03-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 49 | COAL | 0 | 1970-02-02 | 1970-03-03 | 1 | OUI | 1970-05-01 | 2.9 |
| ref_seed12345_r0.log | 17 | COAL | 0 | 1970-02-02 | 1970-03-03 | 1 | OUI | 1970-05-01 | 2.9 |
| ref_seed12345_r0.log | 32 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 28 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 0 | COAL | 0 | 1970-02-02 | 1970-04-01 | 1 | OUI | 1970-08-07 | 6.1 |
| ref_seed12345_r0.log | 3 | WOOD | 5 | 1970-11-15 | 1970-12-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 13 | IORE | 6 | 1970-12-21 | 1971-01-07 | 1 | NON | — | — |
| ref_seed12345_r0.log | 33 | IORE | 6 | 1970-12-21 | 1971-02-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 36 | GRAI | 8 | 1971-03-10 | 1971-04-01 | 1 | NON | — | — |
| ref_seed12345_r0.log | 23 | LVST | 9 | 1971-06-03 | 1971-07-03 | 1 | OUI | 1971-12-07 | 6.2 |
| ref_seed12345_r0.log | 45 | LVST | 9 | 1971-06-03 | 1971-08-01 | 1 | OUI | 1971-09-06 | 3.1 |
| ref_seed12345_r0.log | 47 | GOOD | 12 | 1972-02-10 | 1972-03-01 | 3 | NON | — | — |
| ref_seed12345_r0.log | 43 | WOOD | 13 | 1972-10-24 | 1972-12-01 | 1 | NON | — | — |
| ref_seed1337_r0.log | 22 | COAL | 0 | 1970-02-24 | 1970-04-01 | 1 | OUI | 1970-09-01 | 6.2 |
| ref_seed1337_r0.log | 0 | COAL | 0 | 1970-02-24 | 1970-04-01 | 2 | NON | — | — |
| ref_seed1337_r0.log | 38 | WOOD | 4 | 1970-06-16 | 1970-07-01 | 1 | OUI | 1971-02-02 | 7.6 |
| ref_seed1337_r0.log | 33 | WOOD | 4 | 1970-06-16 | 1970-08-01 | 1 | NON | — | — |
| ref_seed1337_r0.log | 30 | IORE | 7 | 1971-03-05 | 1971-04-01 | 1 | NON | — | — |
| ref_seed17_r0.log | 10 | COAL | 0 | 1970-01-28 | 1970-02-01 | 1 | OUI | 1970-04-11 | 2.4 |
| ref_seed17_r0.log | 20 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | OUI | 1970-04-11 | 2.4 |
| ref_seed17_r0.log | 0 | COAL | 1 | 1970-02-14 | 1970-04-11 | 2 | NON | — | — |
| ref_seed17_r0.log | 35 | COAL | 2 | 1970-03-21 | 1970-05-06 | 1 | OUI | 1970-08-01 | 4.4 |
| ref_seed17_r0.log | 22 | WOOD | 7 | 1971-06-09 | 1971-06-10 | 1 | NON | — | — |
| ref_seed17_r0.log | 24 | WOOD | 7 | 1971-06-09 | 1971-08-01 | 2 | NON | — | — |
| ref_seed17_r0.log | 38 | IORE | 9 | 1971-12-06 | 1972-01-01 | 1 | NON | — | — |
| ref_seed1_r0.log | 25 | COAL | 0 | 1970-01-25 | 1970-02-01 | 1 | OUI | 1971-01-01 | 11.2 |
| ref_seed1_r0.log | 16 | COAL | 0 | 1970-01-25 | 1970-03-02 | 1 | NON | — | — |
| ref_seed1_r0.log | 0 | COAL | 1 | 1970-02-16 | 1970-04-06 | 1 | NON | — | — |
| ref_seed1_r0.log | 14 | WOOD | 5 | 1970-08-16 | 1970-09-01 | 1 | OUI | 1971-01-01 | 4.5 |
| ref_seed1_r0.log | 28 | WOOD | 7 | 1970-12-09 | 1971-01-01 | 1 | NON | — | — |
| ref_seed1_r0.log | 45 | IORE | 8 | 1971-04-19 | 1971-05-01 | 1 | NON | — | — |
| ref_seed1_r0.log | 27 | GRAI | 10 | 1971-11-17 | 1971-12-01 | 1 | NON | — | — |
| ref_seed1_r0.log | 8 | OIL_ | 12 | 1972-07-02 | 1972-08-01 | 1 | NON | — | — |
| ref_seed2026_r0.log | 46 | COAL | 0 | 1970-02-07 | 1970-03-01 | 2 | NON | — | — |
| ref_seed2026_r0.log | 17 | COAL | 0 | 1970-02-07 | 1970-04-01 | 1 | NON | — | — |
| ref_seed2026_r0.log | 13 | COAL | 0 | 1970-02-07 | 1970-04-01 | 1 | OUI | 1970-07-01 | 4.7 |
| ref_seed2026_r0.log | 28 | COAL | 2 | 1970-04-14 | 1970-05-01 | 1 | OUI | 1971-04-01 | 11.6 |
| ref_seed2026_r0.log | 42 | COAL | 3 | 1970-06-13 | 1970-07-01 | 1 | NON | — | — |
| ref_seed2026_r0.log | 0 | COAL | 3 | 1970-06-13 | 1970-08-01 | 1 | OUI | 1971-01-06 | 6.8 |
| ref_seed2026_r0.log | 51 | COAL | 6 | 1970-10-25 | 1970-11-01 | 1 | NON | — | — |
| ref_seed2026_r0.log | 29 | GRAI | 11 | 1972-05-27 | 1972-07-01 | 1 | NON | — | — |
| ref_seed314_r0.log | 46 | COAL | 0 | 1970-01-26 | 1970-03-02 | 1 | OUI | 1970-04-06 | 2.3 |
| ref_seed314_r0.log | 0 | COAL | 0 | 1970-01-26 | 1970-03-02 | 1 | OUI | 1971-01-01 | 11.2 |
| ref_seed314_r0.log | 27 | COAL | 1 | 1970-02-14 | 1970-04-06 | 1 | OUI | 1970-06-02 | 3.6 |
| ref_seed314_r0.log | 3 | WOOD | 3 | 1970-06-21 | 1970-07-10 | 1 | NON | — | — |
| ref_seed314_r0.log | 14 | WOOD | 3 | 1970-06-21 | 1970-08-01 | 1 | NON | — | — |
| ref_seed314_r0.log | 12 | WOOD | 5 | 1970-10-05 | 1970-11-01 | 1 | OUI | 1971-01-01 | 2.9 |
| ref_seed314_r0.log | 22 | IORE | 6 | 1970-12-04 | 1971-01-01 | 1 | NON | — | — |
| ref_seed314_r0.log | 7 | GRAI | 7 | 1971-03-30 | 1971-05-01 | 1 | NON | — | — |
| ref_seed314_r0.log | 8 | OIL_ | 8 | 1971-08-01 | 1971-09-02 | 1 | OUI | 1971-10-08 | 2.2 |
| ref_seed314_r0.log | 15 | IORE | 10 | 1972-03-24 | 1972-04-01 | 1 | NON | — | — |
| ref_seed314_r0.log | 17 | GRAI | 11 | 1972-05-20 | 1972-06-08 | 1 | NON | — | — |
| ref_seed314_r0.log | 41 | GRAI | 11 | 1972-05-20 | 1972-07-08 | 1 | NON | — | — |
| ref_seed4096_r0.log | 35 | COAL | 0 | 1970-01-25 | 1970-02-10 | 1 | OUI | 1970-03-01 | 1.2 |
| ref_seed4096_r0.log | 15 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | NON | — | — |
| ref_seed4096_r0.log | 0 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | NON | — | — |
| ref_seed4096_r0.log | 25 | COAL | 1 | 1970-02-07 | 1970-04-01 | 1 | NON | — | — |
| ref_seed4096_r0.log | 48 | COAL | 3 | 1970-03-11 | 1970-05-01 | 1 | NON | — | — |
| ref_seed4096_r0.log | 40 | WOOD | 7 | 1971-02-18 | 1971-04-01 | 1 | NON | — | — |
| ref_seed424242_r0.log | 0 | COAL | 0 | 1970-01-23 | 1970-02-10 | 1 | OUI | 1971-01-04 | 11.4 |
| ref_seed424242_r0.log | 12 | COAL | 0 | 1970-01-23 | 1970-03-01 | 1 | NON | — | — |
| ref_seed424242_r0.log | 43 | COAL | 1 | 1970-02-08 | 1970-04-01 | 1 | OUI | 1971-02-01 | 11.8 |
| ref_seed424242_r0.log | 39 | COAL | 1 | 1970-02-08 | 1970-04-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 34 | COAL | 0 | 1970-01-27 | 1970-02-01 | 1 | OUI | 1970-03-02 | 1.1 |
| ref_seed42_r0.log | 13 | COAL | 0 | 1970-01-27 | 1970-03-02 | 1 | OUI | 1970-04-01 | 2.1 |
| ref_seed42_r0.log | 45 | COAL | 1 | 1970-02-16 | 1970-04-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 11 | COAL | 1 | 1970-02-16 | 1970-04-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 0 | COAL | 1 | 1970-02-16 | 1970-04-01 | 1 | NON | — | — |
| ref_seed42_r0.log | 16 | GOOD | 8 | 1971-02-06 | 1971-04-01 | 2 | NON | — | — |
| ref_seed42_r0.log | 29 | WOOD | 11 | 1971-08-17 | 1971-09-01 | 1 | OUI | 1972-02-04 | 5.6 |
| ref_seed512_r0.log | 0 | COAL | 0 | 1970-01-24 | 1970-02-02 | 1 | OUI | 1970-09-01 | 7.2 |
| ref_seed512_r0.log | 9 | IORE | 7 | 1971-06-01 | 1971-07-01 | 1 | NON | — | — |
| ref_seed512_r0.log | 32 | OIL_ | 9 | 1972-05-03 | 1972-06-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 37 | COAL | 0 | 1970-01-21 | 1970-02-06 | 1 | OUI | 1970-07-06 | 5.5 |
| ref_seed54321_r0.log | 0 | COAL | 0 | 1970-01-21 | 1970-03-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 14 | WOOD | 3 | 1970-06-19 | 1970-07-06 | 1 | OUI | 1970-10-01 | 3.4 |
| ref_seed54321_r0.log | 33 | IORE | 4 | 1970-07-24 | 1970-08-01 | 1 | NON | — | — |
| ref_seed54321_r0.log | 9 | IORE | 5 | 1970-11-26 | 1970-12-03 | 1 | NON | — | — |
| ref_seed54321_r0.log | 19 | WOOD | 11 | 1972-07-28 | 1972-08-03 | 2 | NON | — | — |
| ref_seed54321_r0.log | 18 | WOOD | 11 | 1972-07-28 | 1972-08-03 | 4 | NON | — | — |
| ref_seed65537_r0.log | 39 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | OUI | 1970-09-01 | 7.1 |
| ref_seed65537_r0.log | 30 | COAL | 0 | 1970-01-28 | 1970-03-01 | 1 | NON | — | — |
| ref_seed65537_r0.log | 31 | COAL | 1 | 1970-02-12 | 1970-04-01 | 1 | NON | — | — |
| ref_seed65537_r0.log | 0 | COAL | 1 | 1970-02-12 | 1970-04-01 | 1 | OUI | 1970-12-01 | 9.6 |
| ref_seed65537_r0.log | 44 | COAL | 5 | 1970-07-23 | 1970-08-01 | 1 | NON | — | — |
| ref_seed65537_r0.log | 14 | GRAI | 9 | 1971-12-06 | 1972-01-01 | 2 | NON | — | — |
| ref_seed65537_r0.log | 8 | OIL_ | 10 | 1971-12-21 | 1972-01-01 | 1 | NON | — | — |
| ref_seed73_r0.log | 49 | WOOD | 0 | 1970-04-02 | 1970-05-03 | 1 | NON | — | — |
| ref_seed73_r0.log | 14 | IORE | 1 | 1970-05-22 | 1970-06-13 | 1 | NON | — | — |
| ref_seed73_r0.log | 7 | GRAI | 2 | 1970-06-09 | 1970-07-13 | 2 | OUI | 1971-03-03 | 8.8 |
| ref_seed73_r0.log | 29 | GRAI | 2 | 1970-06-09 | 1970-08-01 | 1 | OUI | 1971-06-01 | 11.7 |
| ref_seed73_r0.log | 48 | LVST | 9 | 1972-03-11 | 1972-04-01 | 1 | NON | — | — |
| ref_seed7_r0.log | 33 | COAL | 0 | 1970-01-30 | 1970-03-01 | 1 | OUI | 1970-05-07 | 3.2 |
| ref_seed7_r0.log | 29 | COAL | 0 | 1970-01-30 | 1970-03-01 | 1 | OUI | 1970-09-01 | 7.0 |
| ref_seed7_r0.log | 38 | COAL | 0 | 1970-01-30 | 1970-04-01 | 1 | OUI | 1970-05-07 | 3.2 |
| ref_seed7_r0.log | 47 | COAL | 2 | 1970-04-23 | 1970-06-01 | 1 | NON | — | — |
| ref_seed7_r0.log | 0 | COAL | 2 | 1970-04-23 | 1970-06-01 | 1 | NON | — | — |
| ref_seed7_r0.log | 23 | WOOD | 5 | 1970-08-22 | 1970-09-01 | 1 | OUI | 1971-06-01 | 9.3 |
| ref_seed7_r0.log | 26 | IORE | 6 | 1971-02-07 | 1971-03-07 | 1 | NON | — | — |
| ref_seed7_r0.log | 8 | OIL_ | 10 | 1972-07-24 | 1972-08-02 | 1 | NON | — | — |
| ref_seed7_r0.log | 36 | OIL_ | 11 | 1972-11-19 | 1972-12-01 | 1 | NON | — | — |
| ref_seed8191_r0.log | 35 | COAL | 0 | 1970-01-28 | 1970-03-03 | 1 | OUI | 1970-06-02 | 4.1 |
| ref_seed8191_r0.log | 12 | COAL | 0 | 1970-01-28 | 1970-03-03 | 1 | NON | — | — |
| ref_seed8191_r0.log | 37 | COAL | 1 | 1970-03-29 | 1970-05-01 | 1 | NON | — | — |
| ref_seed8191_r0.log | 0 | COAL | 2 | 1970-05-16 | 1970-07-01 | 1 | OUI | 1971-03-01 | 9.5 |
| ref_seed8191_r0.log | 3 | WOOD | 5 | 1970-09-04 | 1970-10-01 | 1 | OUI | 1971-08-06 | 11.1 |
| ref_seed8191_r0.log | 45 | WOOD | 6 | 1970-12-31 | 1971-02-01 | 1 | NON | — | — |
| ref_seed8191_r0.log | 44 | IORE | 7 | 1971-02-10 | 1971-03-01 | 1 | OUI | 1971-07-01 | 4.6 |
| ref_seed8675309_r0.log | 37 | COAL | 0 | 1970-01-25 | 1970-02-01 | 1 | NON | — | — |
| ref_seed8675309_r0.log | 35 | WOOD | 2 | 1970-05-06 | 1970-06-01 | 1 | OUI | 1971-05-01 | 11.8 |
| ref_seed8675309_r0.log | 31 | WOOD | 2 | 1970-05-06 | 1970-06-01 | 1 | OUI | 1971-04-01 | 10.9 |
| ref_seed8675309_r0.log | 39 | IORE | 5 | 1970-08-19 | 1970-09-01 | 1 | NON | — | — |
| ref_seed8675309_r0.log | 33 | IORE | 6 | 1970-12-13 | 1971-01-01 | 1 | NON | — | — |
| ref_seed8675309_r0.log | 26 | OIL_ | 7 | 1971-12-05 | 1972-01-01 | 1 | NON | — | — |
| ref_seed8675309_r0.log | 46 | LVST | 11 | 1972-11-03 | 1972-12-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 10 | COAL | 0 | 1970-01-25 | 1970-02-11 | 1 | NON | — | — |
| ref_seed999_r0.log | 23 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 0 | COAL | 0 | 1970-01-25 | 1970-03-01 | 1 | OUI | 1970-12-03 | 10.3 |
| ref_seed999_r0.log | 31 | COAL | 1 | 1970-02-08 | 1970-04-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 22 | COAL | 3 | 1970-03-18 | 1970-05-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 26 | COAL | 5 | 1970-07-06 | 1970-08-01 | 1 | OUI | 1971-07-01 | 11.8 |
| ref_seed999_r0.log | 37 | COAL | 5 | 1970-07-06 | 1970-09-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 44 | WOOD | 10 | 1971-05-19 | 1971-06-02 | 1 | OUI | 1971-09-02 | 3.5 |
| ref_seed999_r0.log | 3 | WOOD | 11 | 1971-07-24 | 1971-09-02 | 1 | NON | — | — |
| ref_seed999_r0.log | 30 | IORE | 13 | 1971-11-22 | 1971-12-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 8 | OIL_ | 14 | 1972-05-16 | 1972-06-01 | 1 | NON | — | — |
| ref_seed999_r0.log | 16 | LVST | 15 | 1972-06-13 | 1972-07-11 | 1 | NON | — | — |

### Coût de la sonde

- sélections journalisées : 1038, opcodes total 196387170, médiane 90285, max 1252570
- relevés mensuels : 716, opcodes total 7377501

## Politique `v216_sonde_aaarail_20x3_20261016_engine:complet` : 20 parties sondées

### A. Premier rail voyageurs construit et dernière sélection avant lui

| partie | date | rôle | mode | rang | palier | score | profit calibré | financement | revenu | transporté |
|---|---|---|---|---|---|---|---|---|---|---|
| complet_seed100_r0.log | aucun | | | | | | | | | |
| complet_seed1024_r0.log | 1972-12-20 | construit | rail/pax | 0 | 0 | 0 | 9591 | 67849 | 13572 | 29 |
| complet_seed1024_r0.log | 1972-11-27 | ce rail dans la sélection | rail/pax | 0 | 0 | 92 | 9591 | 46832 | 13572 | 29 |
| complet_seed1024_r0.log | 1972-11-27 | rang 0 | rail/pax | 0 | 0 | 92 | 9591 | 46832 | 13572 | 29 |
| complet_seed1024_r0.log | 1972-11-27 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed1024_r0.log | 1972-11-27 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed123456_r0.log | aucun | | | | | | | | | |
| complet_seed12345_r0.log | 1972-11-2 | construit | rail/pax | 0 | 0 | 0 | 8394 | 46938 | 12312 | 38 |
| complet_seed12345_r0.log | 1972-10-18 | ce rail dans la sélection | rail/pax | 3 | 0 | 107 | 8394 | 41231 | 12312 | 38 |
| complet_seed12345_r0.log | 1972-10-18 | rang 0 | rail/freight | 0 | 0 | 948 | 74155 | 57559 | 78324 | 61 |
| complet_seed12345_r0.log | 1972-10-18 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed12345_r0.log | 1972-10-18 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed1337_r0.log | aucun | | | | | | | | | |
| complet_seed17_r0.log | 1972-10-2 | construit | rail/pax | 0 | 0 | 0 | 12210 | 45307 | 16128 | 48 |
| complet_seed17_r0.log | 1972-9-27 | ce rail dans la sélection | rail/pax | 0 | 0 | 119 | 12210 | 41343 | 16128 | 48 |
| complet_seed17_r0.log | 1972-9-27 | rang 0 | rail/pax | 0 | 0 | 119 | 12210 | 41343 | 16128 | 48 |
| complet_seed17_r0.log | 1972-9-27 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed17_r0.log | 1972-9-27 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed1_r0.log | 1971-1-14 | construit | rail/pax | 0 | 0 | 0 | 15270 | 37989 | 19188 | 123 |
| complet_seed1_r0.log | 1971-1-3 | ce rail dans la sélection | rail/pax | 1 | 0 | 252 | 15270 | 35407 | 19188 | 123 |
| complet_seed1_r0.log | 1971-1-3 | rang 0 | rail/freight | 0 | 0 | 463 | 28021 | 40346 | 31968 | 72 |
| complet_seed1_r0.log | 1971-1-3 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed1_r0.log | 1971-1-3 | meilleur AIR non finançable | air/pax | 0 | 0 | 1755 | 177884 | 101364 | 185232 | 100 |
| complet_seed2026_r0.log | 1971-1-20 | construit | rail/pax | 0 | 0 | 0 | 17250 | 37562 | 21168 | 147 |
| complet_seed2026_r0.log | 1971-1-16 | ce rail dans la sélection | — | — | — | — | — | — | — | — |
| complet_seed2026_r0.log | 1971-1-16 | rang 0 | air/pax | 0 | 0 | 1926 | 129356 | 67164 | 136704 | 124 |
| complet_seed2026_r0.log | 1971-1-16 | meilleur AIR classé | air/pax | 0 | 0 | 1926 | 129356 | 67164 | 136704 | 124 |
| complet_seed2026_r0.log | 1971-1-16 | meilleur AIR non finançable | air/pax | 0 | 0 | 1701 | 172436 | 101364 | 179784 | 138 |
| complet_seed314_r0.log | aucun | | | | | | | | | |
| complet_seed4096_r0.log | aucun | | | | | | | | | |
| complet_seed424242_r0.log | 1972-8-4 | construit | rail/pax | 0 | 0 | 0 | 12399 | 93042 | 16380 | 35 |
| complet_seed424242_r0.log | 1972-7-13 | ce rail dans la sélection | rail/pax | 0 | 0 | 94 | 12819 | 47056 | 16800 | 35 |
| complet_seed424242_r0.log | 1972-7-13 | rang 0 | rail/pax | 0 | 0 | 94 | 12819 | 47056 | 16800 | 35 |
| complet_seed424242_r0.log | 1972-7-13 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed424242_r0.log | 1972-7-13 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed42_r0.log | 1972-8-31 | construit | rail/pax | 0 | 0 | 0 | 25884 | 69257 | 29928 | 43 |
| complet_seed42_r0.log | 1972-8-23 | ce rail dans la sélection | rail/pax | 1 | 0 | 267 | 35064 | 89024 | 43152 | 43 |
| complet_seed42_r0.log | 1972-8-23 | rang 0 | rail/freight | 0 | 0 | 295 | 38793 | 49976 | 42828 | 43 |
| complet_seed42_r0.log | 1972-8-23 | meilleur AIR classé | air/pax | 3 | 0 | 165 | 21736.998 | 40964 | 56772 | 47 |
| complet_seed42_r0.log | 1972-8-23 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed512_r0.log | 1972-10-20 | construit | rail/pax | 0 | 0 | 0 | 9699 | 84111 | 13680 | 30 |
| complet_seed512_r0.log | 1972-10-5 | ce rail dans la sélection | rail/pax | 0 | 0 | 133 | 10059 | 46720 | 14040 | 30 |
| complet_seed512_r0.log | 1972-10-5 | rang 0 | rail/pax | 0 | 0 | 64 | 4974 | 37087 | 8892 | 57 |
| complet_seed512_r0.log | 1972-10-5 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed512_r0.log | 1972-10-5 | meilleur AIR non finançable | air/pax | 0 | 0 | 311 | 38502.133 | 123923 | 86652 | 75 |
| complet_seed54321_r0.log | aucun | | | | | | | | | |
| complet_seed65537_r0.log | 1972-12-21 | construit | rail/pax | 0 | 0 | 0 | 44586 | 90809 | 52800 | 80 |
| complet_seed65537_r0.log | 1972-12-13 | ce rail dans la sélection | rail/pax | 1 | 0 | 422 | 44712 | 88240 | 52800 | 80 |
| complet_seed65537_r0.log | 1972-12-13 | rang 0 | rail/freight | 0 | 0 | 434 | 45906 | 45575 | 49896 | 63 |
| complet_seed65537_r0.log | 1972-12-13 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed65537_r0.log | 1972-12-13 | meilleur AIR non finançable | — | — | — | — | — | — | — | — |
| complet_seed73_r0.log | aucun | | | | | | | | | |
| complet_seed7_r0.log | 1971-1-12 | construit | rail/pax | 0 | 0 | 0 | 18522 | 37012 | 22440 | 187 |
| complet_seed7_r0.log | 1971-1-10 | ce rail dans la sélection | rail/pax | 0 | 0 | 319 | 18522 | 34511 | 22440 | 187 |
| complet_seed7_r0.log | 1971-1-10 | rang 0 | rail/pax | 0 | 0 | 319 | 18522 | 34511 | 22440 | 187 |
| complet_seed7_r0.log | 1971-1-10 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed7_r0.log | 1971-1-10 | meilleur AIR non finançable | air/pax | 0 | 0 | 0 | 401728 | 140328 | 416424 | 233 |
| complet_seed8191_r0.log | aucun | | | | | | | | | |
| complet_seed8675309_r0.log | 1971-2-6 | construit | rail/pax | 0 | 0 | 0 | 8754 | 46696 | 12672 | 96 |
| complet_seed8675309_r0.log | 1971-2-4 | ce rail dans la sélection | rail/pax | 0 | 0 | 183 | 8754 | 47821 | 12672 | 96 |
| complet_seed8675309_r0.log | 1971-2-4 | rang 0 | rail/pax | 0 | 0 | 183 | 8754 | 47821 | 12672 | 96 |
| complet_seed8675309_r0.log | 1971-2-4 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed8675309_r0.log | 1971-2-4 | meilleur AIR non finançable | air/pax | 0 | 0 | 0 | 157844 | 67164 | 165192 | 86 |
| complet_seed999_r0.log | 1971-1-27 | construit | rail/pax | 0 | 0 | 0 | 14418 | 35799 | 18336 | 191 |
| complet_seed999_r0.log | 1971-1-21 | ce rail dans la sélection | rail/pax | 1 | 0 | 183 | 14418 | 34175 | 18336 | 191 |
| complet_seed999_r0.log | 1971-1-21 | rang 0 | rail/freight | 0 | 0 | 513 | 40335 | 39504 | 44280 | 90 |
| complet_seed999_r0.log | 1971-1-21 | meilleur AIR classé | — | — | — | — | — | — | — | — |
| complet_seed999_r0.log | 1971-1-21 | meilleur AIR non finançable | air/pax | 0 | 0 | 1660 | 205669 | 123923 | 215244 | 101 |

### B. Attribution des erreurs : lignes rail 1971 (>= 180 j)

| groupe | n | revenu médian | ratio sommes revenu | profit médian | ratio sommes profit | offre moy. | capacité moy. | cap. séjour | liaison modèle | liaison séjour |
|---|---|---|---|---|---|---|---|---|---|---|
| PASS | 6 | 0.27 | 0.26 | 0.19 | 0.16 | 150.7 | 298.9 | 141.2 | 6 off / 0 cap | 2 off / 4 cap |
| freight | 29 | 0.65 | 0.68 | 0.65 | 0.69 | 78.5 | 90.7 | 63.8 | 24 off / 5 cap | 2 off / 27 cap |

### E. K_dec plus grand que le financement

| mode | K_dec gagne | lignes | part |
|---|---|---|---|
| air | 2182 | 14402 | 15% |
| fleet | 459 | 589 | 78% |
| rail | 23516 | 23801 | 99% |
| road | 33 | 33 | 100% |
| water | 4 | 7 | 57% |

### V216a. Fantôme : couverture et facteurs (médianes par extrémité, %)

| mode | extrémités | couvert par nous | couvert par adversaire seul | part ligne | gain compagnie | opcodes médians |
|---|---|---|---|---|---|---|
| air/pax | 11966 | 0 | 0 | 100 | 100 | 394 |
| rail/pax | 41738 | 92 | 0 | 66 | 8 | 354 |

### Rejeu des décisions (§6)

- sélections rejouées : 2346
- sélections avec changement du rang 0 : 98 (dont 98 en 1971-72)

| choix initial | remplaçant | occurrences |
|---|---|---|
| rail/pax | rail/pax | 91 |
| rail/pax | fleet/fleet | 7 |

### G. Arrivée de la concurrence (industries fret rail)

- industries sources fret observées : 30
- arrivée d'un concurrent sous 12 mois : 16 (53.3%)
*(src tile non requis : proxy basé sur les lignes V216_IND_FLOW dont stations_around augmente après le mois de RAIL_BUILD)*

| partie | industrie | cargo | ligne | date construction | première obs. | gares initiales | arrivée 12 mois | date arrivée | mois écoulés |
|---|---|---|---|---|---|---|---|---|---|
| complet_seed1024_r0.log | 46 | WOOD | 11 | 1971-02-16 | 1971-03-01 | 1 | OUI | 1971-09-01 | 6.5 |
| complet_seed123456_r0.log | 44 | COAL | 12 | 1971-01-22 | 1971-02-01 | 1 | NON | — | — |
| complet_seed12345_r0.log | 16 | WOOD | 11 | 1971-01-16 | 1971-02-01 | 1 | NON | — | — |
| complet_seed12345_r0.log | 32 | COAL | 12 | 1971-01-27 | 1971-03-01 | 1 | OUI | 1971-08-02 | 6.2 |
| complet_seed1337_r0.log | 29 | OIL_ | 18 | 1971-02-01 | 1971-03-01 | 1 | OUI | 1971-04-01 | 1.9 |
| complet_seed17_r0.log | 26 | WOOD | 10 | 1971-01-19 | 1971-02-01 | 3 | OUI | 1971-05-01 | 3.4 |
| complet_seed17_r0.log | 43 | WOOD | 10 | 1971-01-19 | 1971-03-09 | 1 | NON | — | — |
| complet_seed17_r0.log | 3 | WOOD | 10 | 1971-01-19 | 1971-03-09 | 1 | NON | — | — |
| complet_seed1_r0.log | 14 | WOOD | 10 | 1971-01-16 | 1971-02-06 | 3 | NON | — | — |
| complet_seed1_r0.log | 3 | WOOD | 10 | 1971-01-16 | 1971-02-06 | 1 | OUI | 1971-04-02 | 2.5 |
| complet_seed2026_r0.log | 17 | COAL | 9 | 1971-01-12 | 1971-02-01 | 1 | OUI | 1971-08-01 | 6.6 |
| complet_seed4096_r0.log | 25 | COAL | 13 | 1971-02-11 | 1971-03-02 | 2 | NON | — | — |
| complet_seed424242_r0.log | 15 | COAL | 47 | 1972-03-16 | 1972-04-01 | 1 | NON | — | — |
| complet_seed42_r0.log | 40 | COAL | 17 | 1971-02-10 | 1971-03-01 | 1 | NON | — | — |
| complet_seed42_r0.log | 0 | COAL | 17 | 1971-02-10 | 1971-03-01 | 1 | OUI | 1971-05-01 | 2.6 |
| complet_seed42_r0.log | 11 | COAL | 17 | 1971-02-10 | 1971-04-01 | 1 | NON | — | — |
| complet_seed512_r0.log | 35 | WOOD | 5 | 1971-01-16 | 1971-02-01 | 1 | OUI | 1971-05-02 | 3.5 |
| complet_seed512_r0.log | 36 | WOOD | 26 | 1972-06-18 | 1972-07-10 | 2 | OUI | 1972-11-07 | 4.7 |
| complet_seed65537_r0.log | 31 | COAL | 10 | 1971-04-07 | 1971-05-09 | 1 | NON | — | — |
| complet_seed65537_r0.log | 30 | COAL | 10 | 1971-04-07 | 1971-05-09 | 1 | OUI | 1971-07-01 | 2.8 |
| complet_seed73_r0.log | 25 | WOOD | 10 | 1971-01-25 | 1971-03-01 | 1 | OUI | 1971-11-01 | 9.2 |
| complet_seed73_r0.log | 9 | IORE | 11 | 1971-02-03 | 1971-03-01 | 2 | OUI | 1972-01-05 | 11.1 |
| complet_seed7_r0.log | 13 | WOOD | 12 | 1971-01-21 | 1971-02-01 | 2 | NON | — | — |
| complet_seed8191_r0.log | 37 | COAL | 8 | 1971-01-10 | 1971-02-01 | 1 | OUI | 1971-06-01 | 4.7 |
| complet_seed8191_r0.log | 0 | COAL | 8 | 1971-01-10 | 1971-03-01 | 1 | NON | — | — |
| complet_seed8675309_r0.log | 16 | LVST | 8 | 1971-01-23 | 1971-02-02 | 2 | OUI | 1971-11-01 | 9.3 |
| complet_seed8675309_r0.log | 31 | WOOD | 9 | 1971-01-30 | 1971-03-08 | 1 | NON | — | — |
| complet_seed8675309_r0.log | 12 | WOOD | 9 | 1971-01-30 | 1971-03-08 | 2 | OUI | 1971-10-01 | 8.0 |
| complet_seed8675309_r0.log | 37 | COAL | 43 | 1972-05-27 | 1972-07-07 | 1 | NON | — | — |
| complet_seed999_r0.log | 26 | COAL | 6 | 1971-01-25 | 1971-02-02 | 1 | OUI | 1971-07-01 | 5.2 |

### Coût de la sonde

- sélections journalisées : 2346, opcodes total 233855773, médiane 49941, max 1773777
- relevés mensuels : 714, opcodes total 10019393

## D. Test d'invariance (critère principal gelé)

| cellule / politique | lignes PASS 1971 | somme réalisé | somme prévu actuel | ratio actuel | somme prévu fantôme (gain) | ratio fantôme (gain) | somme prévu fantôme (ligne) | ratio fantôme (ligne) |
|---|---|---|---|---|---|---|---|---|
| v216_sonde_aaacomplet_20x3_20261016_engine:railseul | 7 | 34659 | 64260 | 0.54 | 44720 | 0.78 | 44720 | 0.78 |
| v216_sonde_aaacomplet_20x3_20261016_engine:ref | 7 | 24277 | 122520 | 0.20 | 27062 | 0.90 | 69564 | 0.35 |
| v216_sonde_aaarail_20x3_20261016_engine:complet | 6 | 29858 | 114660 | 0.26 | 60297 | 0.50 | 83788 | 0.36 |
| v216_sonde_aaarail_20x3_20261016_engine:ref | 14 | 129411 | 129864 | 1.00 | 97036 | 1.33 | 97036 | 1.33 |

- ratios fantôme gain : min = 0.50, max = 1.33, max/min = 2.69 (seuil <= 1.5, borne [0.7, 1.4])
**Verdict test d'invariance : FAIL**

