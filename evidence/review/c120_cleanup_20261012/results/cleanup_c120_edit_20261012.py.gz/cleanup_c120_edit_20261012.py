from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent / 'c118_c119_merge_stage_20261012'
BACKUP = ROOT / 'results/cleanup_c120_sources_backup_20261012'
assert not BACKUP.exists(), 'Backup must be new'
FILES = [
    'ai/OpexAI/info.nut', 'ai/OpexAI/settings.nut', 'ai/OpexAI/globals_pre.nut',
    'ai/OpexAI/projects_finance.nut', 'ai/OpexAI/projects_selection.nut',
    'ai/OpexAI/projects_generation.nut', 'ai/OpexAI/selection_diagnostics.nut',
    'ai/OpexAI/task_air.nut', 'ai/OpexAI/task_projects.nut',
    'ai/OpexAI/air_coverage.nut', 'ai/OpexAI/builder_air.nut',
    'ai/OpexAI/persist.nut', 'ai/OpexAI/air_economics_c121.nut',
    'ai/OpexAI/air_catalog_c121.nut', 'ai/OpexAI/air_planning.nut',
    'sweeps/test_c118_air_territorial_expansion.py',
    'sweeps/test_c120_air_territorial_ranking.py',
    'sweeps/run_c120_territorial_smoke.py', 'sweeps/run_c120_territorial_5x6.py',
    'sweeps/test_air0310_6_site_validity_cache.py',
    'sweeps/test_c121_air_economics.py', 'sweeps/test_c122_air_regime_priority.py',
    'sweeps/test_r1_partial_fleet.py', 'sweeps/test_r3_air_bypass.py',
    'sweeps/test_three_lots_integration.py', 'sweeps/run_mechanism_fixtures.py',
    'sweeps/bench_1v1_5y_20seeds.py',
]
manifest = []
for name in FILES:
    src = ROOT / name
    dst = BACKUP / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    raw = src.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert hashlib.sha256(dst.read_bytes()).hexdigest() == digest
    manifest.append({'path': name, 'bytes': len(raw), 'sha256': digest})
(BACKUP / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')

def read(name):
    return (ROOT / name).read_text(encoding='utf-8')

def write(name, text):
    (ROOT / name).write_text(text, encoding='utf-8', newline='\n')

def sub(text, old, new='', count=1):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)

def cut(text, start, end):
    a = text.index(start)
    b = text.index(end, a)
    return text[:a] + text[b:]

name = 'ai/OpexAI/info.nut'
t = read(name)
a = t.index('    AddSetting({\n      name = "c120_air_territorial_ranking"')
b = t.index('    });', a) + len('    });\n\n')
write(name, t[:a] + t[b:])

name = 'ai/OpexAI/globals_pre.nut'
t = cut(read(name), '/* C120 : experience isolee', 'C121_AIR_ECONOMICS_SHADOW')
t = sub(t, 'C120_AIR_LAST_TRACE_KEY <- "";\n')
write(name, t)

name = 'ai/OpexAI/settings.nut'
t = read(name)
t = re.sub(r'^  C120_AIR_.*\n', '', t, flags=re.M)
write(name, t)

name = 'ai/OpexAI/projects_finance.nut'
t = read(name)
t = t[:t.index('function OpexC118SetProjectField')].rstrip() + '\n'
t = sub(t, 'Contraintes financieres : capital financable, C120 preparation de selection.', 'Contraintes financieres : capital financable.')
write(name, t)

name = 'ai/OpexAI/projects_selection.nut'
t = read(name)
t = sub(t, '  /* Avant plancher, preparation territoriale et filtre. */\n  OpexC120PrepareSelection(alternatives, capitalBudget);\n', '  /* Avant plancher et filtre. */\n')
t = sub(t, '  OpexC120ReorderAffordableAir(affordable);\n')
t = sub(t, '  OpexC120FinalizeSelection(affordable, capitalBudget);\n')
t = cut(t, '  /* C120 a deja classe', '  local earlyState = null;')
write(name, t)

name = 'ai/OpexAI/projects_generation.nut'
t = read(name)
snapshot = '''  if (C120_AIR_TERRITORIAL_RANKING) {
    C120_AIR_FILTER_SNAPSHOT = {
      date = AIDate.GetCurrentDate(), inputAir = c120InputAir,
      filteredAir = c120FilteredAir, liveAir = c120InputAir - c120FilteredAir,
    };
  }
'''
t = sub(t, snapshot, count=2)
t = re.sub(r'^\s*local c120(?:Input|Filtered)Air = 0;\n', '', t, flags=re.M)
t = re.sub(r'^\s*if \(C120_AIR_TERRITORIAL_RANKING\) c120(?:Input|Filtered)Air\+\+;\n', '', t, flags=re.M)
write(name, t)

name = 'ai/OpexAI/selection_diagnostics.nut'
write(name, sub(read(name), '      && !C120_AIR_TERRITORIAL_RANKING\n'))

for name in ('ai/OpexAI/task_air.nut', 'ai/OpexAI/task_projects.nut'):
    t = read(name)
    t = t.replace(' || C120_AIR_TERRITORIAL_RANKING', '')
    if name.endswith('task_projects.nut'):
        t = cut(t, '/* C120 : motif', '/* C75 : resout')
        t = re.sub(r'^  local c120Air.*\n', '', t, flags=re.M)
        t = sub(t, '      local c120DiscardStart = C120_AIR_TERRITORIAL_RANKING ? passDiscards.len() : 0;\n')
        t = sub(t, '      if (C120_AIR_TERRITORIAL_RANKING) c120AirAttempts++;\n')
        t = cut(t, '      if (C120_AIR_TERRITORIAL_RANKING) {', '      if (C69_BOTTLENECK_PROBE) OpexC78LogBuild')
        t = sub(t, '''  if (C120_AIR_TERRITORIAL_RANKING) {
    OpexC120FinalizeProjectsPass(c120AirBuilt, c120AirAttempts, c120AirLastReason,
        c120AirLastReject, c75StopReason, builtCount);
  }

''')
    write(name, t)

name = 'ai/OpexAI/air_coverage.nut'
t = read(name)
t = cut(t, 'function OpexC118EndpointCoverageTowns', 'function OpexC118EngineFitsPlan')
t = cut(t, 'function OpexAirResetTerritorialCoverageCache', 'function OpexAirResetStationCoverageTownCache')
for line in ('  AIR_TERRITORIAL_COVERAGE_CACHE.clear();\n', '  AIR_TERRITORIAL_COVERAGE_HITS = 0;\n', '  AIR_TERRITORIAL_COVERAGE_MISSES = 0;\n', '    OpexAirResetTerritorialCoverageCache();\n'):
    t = sub(t, line)
t = sub(t, '''  if ((!C118_AIR_COVERAGE_PROBE
      && !C120_AIR_TERRITORIAL_RANKING) || cargo < 0) return covered;''', '  if (!C118_AIR_COVERAGE_PROBE || cargo < 0) return covered;')
write(name, t)

name = 'ai/OpexAI/builder_air.nut'
write(name, cut(read(name), '/* C118/C120 : cache exact', '/* Cache court pour les hubs existants'))

for name in ('sweeps/run_c120_territorial_smoke.py', 'sweeps/run_c120_territorial_5x6.py'):
    (ROOT / name).unlink()

name = 'sweeps/test_c118_air_territorial_expansion.py'
t = read(name)
t = sub(t, '"function OpexC118EndpointCoverageTowns")', '"function OpexC118EngineFitsPlan")')
t = sub(t, '        endpoint = body(AIR, "function OpexC118EndpointCoverageTowns", "function OpexC118PlanCoverageTowns")\n')
t = sub(t, '        coverage = station + endpoint\n', '        coverage = station\n')
t = sub(t, '        self.assertIn("OpexC118StationCoverageTowns", endpoint)\n')
t = cut(t, '    def test_new_site_coverage_cache_depends_on_airport_type', '    def test_durable_sign_probe')
write(name, t)

name = 'sweeps/test_air0310_6_site_validity_cache.py'
t = read(name)
t = sub(t, 'historique du filtre est le seul execute. C120_AIR_FILTER_SNAPSHOT et ses\ncompteurs ne changent pas. Aucune partie n\'est lancee.', 'historique du filtre est le seul execute. Aucune partie n\'est lancee.')
t = cut(t, 'SNAPSHOT = ', 'def _read')
t = sub(t, '        self.assertEqual(self.hist.count(SNAPSHOT), 1)\n')
t = sub(t, '        self.assertEqual(self.cached.count(SNAPSHOT), 1)\n')
for s in ('        self.assertIn("c120InputAir++", self.hist)\n', '        self.assertIn("c120FilteredAir++", self.hist)\n', '        self.assertIn("c120InputAir++", self.cached)\n', '        self.assertIn("c120FilteredAir++", self.cached)\n'):
    t = sub(t, s)
write(name, t)

name = 'sweeps/test_c121_air_economics.py'
t = sub(read(name), '        c120 = selection.index("OpexC120ReorderAffordableAir")\n', '        c122 = selection.index("OpexC122ProbeExposure")\n')
write(name, sub(t, '        self.assertLess(finish, c120)', '        self.assertLess(finish, c122)'))

name = 'sweeps/test_c122_air_regime_priority.py'
t = sub(read(name), '        reorder_at = select.index("OpexC120ReorderAffordableAir(affordable);")\n', '        compact_at = select.index("OpexAirBatchTownReserveCompact(affordable);")\n')
write(name, sub(t, '        self.assertLess(probe_at, reorder_at)', '        self.assertLess(probe_at, compact_at)'))

name = 'sweeps/test_r1_partial_fleet.py'
write(name, sub(read(name), '"OpexC120PrepareSelection", ', ''))
name = 'sweeps/test_r3_air_bypass.py'
write(name, sub(read(name), '"C120_AIR_TERRITORIAL_RANKING", ', ''))
name = 'sweeps/test_three_lots_integration.py'
write(name, sub(read(name), 's.index("OpexC120ReorderAffordableAir(affordable)")', 's.index("OpexAirBatchTownReserveCompact(affordable)")'))
name = 'sweeps/run_mechanism_fixtures.py'
write(name, sub(read(name), ' || C120_AIR_TERRITORIAL_RANKING', '', count=2))
print(json.dumps({'backup': str(BACKUP), 'files': len(manifest)}, indent=2))
