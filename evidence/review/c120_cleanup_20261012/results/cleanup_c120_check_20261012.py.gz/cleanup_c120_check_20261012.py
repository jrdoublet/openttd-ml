from pathlib import Path
import hashlib
import io
import json
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parent / 'c118_c119_merge_stage_20261012'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'sweeps'))
BACKUP = ROOT / 'results/cleanup_c120_sources_backup_20261012'

def read(base, name):
    return (base / name).read_text(encoding='utf-8')

def function(text, name):
    start = text.index('function ' + name + '(')
    end = text.find('\nfunction ', start + 1)
    # Compare function through closing brace, excluding next helper's comments.
    section = text[start:end if end >= 0 else len(text)]
    return section[:section.rfind('}') + 1]

audit = {'backup_hashes_verified': 0, 'unchanged_files': {}, 'unchanged_functions': []}
for entry in json.loads((BACKUP / 'manifest.json').read_text(encoding='utf-8')):
    assert hashlib.sha256((BACKUP / entry['path']).read_bytes()).hexdigest() == entry['sha256']
    audit['backup_hashes_verified'] += 1
for name in ('persist.nut', 'air_economics_c121.nut', 'air_catalog_c121.nut', 'air_planning.nut'):
    rel = 'ai/OpexAI/' + name
    assert (ROOT / rel).read_bytes() == (BACKUP / rel).read_bytes(), name
    audit['unchanged_files'][name] = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
for filename, names in (
    ('air_coverage.nut', ('OpexC118StationCoverageTowns', 'OpexC118EngineFitsPlan', 'OpexAirResetStationCoverageTownCache', 'OpexC121InvalidateEndpointGeometry')),
    ('projects_finance.nut', ('OpexProjectFinanceCapital',)),
):
    old, new = [read(b, 'ai/OpexAI/' + filename) for b in (BACKUP, ROOT)]
    for name in names:
        assert function(old, name) == function(new, name), name
        audit['unchanged_functions'].append(name)
old, new = [read(b, 'ai/OpexAI/air_coverage.nut') for b in (BACKUP, ROOT)]
old_own = function(old, 'OpexC118OwnCoveredTownSet').replace(
    'if ((!C118_AIR_COVERAGE_PROBE\n      && !C120_AIR_TERRITORIAL_RANKING) || cargo < 0)',
    'if (!C118_AIR_COVERAGE_PROBE || cargo < 0)')
assert old_own == function(new, 'OpexC118OwnCoveredTownSet')
audit['own_coverage_only_guard_simplified'] = True
old, new = [read(b, 'ai/OpexAI/task_air.nut') for b in (BACKUP, ROOT)]
assert old.replace(' || C120_AIR_TERRITORIAL_RANKING', '') == new
audit['task_air_only_C120_discard_gate_removed'] = True
old, new = [read(b, 'ai/OpexAI/projects_generation.nut') for b in (BACKUP, ROOT)]
for name in ('OpexFilterAirAlternativesStillValid', 'OpexAir0310FilterAirAlternativesStillValid'):
    before = function(old, name)
    before = re.sub(r'^  local c120(?:Input|Filtered)Air = 0;\n', '', before, flags=re.M)
    before = re.sub(r'^\s*if \(C120_AIR_TERRITORIAL_RANKING\) c120(?:Input|Filtered)Air\+\+;\n', '', before, flags=re.M)
    before = re.sub(r'  if \(C120_AIR_TERRITORIAL_RANKING\) \{\n    C120_AIR_FILTER_SNAPSHOT = \{.*?\n    \};\n  \}\n', '', before, flags=re.S)
    assert before == function(new, name), name
audit['both_filter_bodies_only_C120_counters_removed'] = True
assert (ROOT / 'sweeps/bench_1v1_5y_20seeds.py').read_bytes() == (BACKUP / 'sweeps/bench_1v1_5y_20seeds.py').read_bytes()
audit['historical_decoders_unchanged'] = True
for f in (ROOT / 'ai/OpexAI').glob('*.nut'):
    for pattern in ('C120_', 'c120', 'AIR_TERRITORIAL_COVERAGE', 'OpexC118SetProjectField', 'OpexC118PlanCoverageTowns', 'OpexC118EndpointCoverageTowns', 'OpexAirResetTerritorialCoverageCache'):
        assert pattern not in f.read_text(encoding='utf-8'), (f, pattern)
audit['exclusive_symbols_absent'] = True
from sweeps.campaign_freeze import parse_ai_setting_specs
old_specs = parse_ai_setting_specs(BACKUP / 'ai/OpexAI/info.nut')
new_specs = parse_ai_setting_specs(ROOT / 'ai/OpexAI/info.nut')
assert 'c120_air_territorial_ranking' in old_specs
assert 'c120_air_territorial_ranking' not in new_specs
old_specs.pop('c120_air_territorial_ranking')
assert old_specs == new_specs
audit['other_setting_specs_unchanged'] = True
(ROOT / 'results/cleanup_c120_audit_20261012.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
print(json.dumps(audit, indent=2))

modules = json.loads((ROOT / 'results/c118_c119_merge_contracts_20261012.json').read_text(encoding='utf-8'))['modules']
modules.remove('test_c120_air_territorial_ranking')
modules += ['test_air0310_6_site_validity_cache', 'test_r3_air_bypass', 'test_three_lots_integration']
stream = io.StringIO()
suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('sweeps.' + m) for m in modules)
result = unittest.TextTestRunner(stream=stream, verbosity=1).run(suite)
record = {'modules': modules, 'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'pass': result.wasSuccessful(), 'output': stream.getvalue()}
(ROOT / 'results/cleanup_c120_contracts_20261012.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(stream.getvalue())
sys.exit(0 if result.wasSuccessful() else 1)
