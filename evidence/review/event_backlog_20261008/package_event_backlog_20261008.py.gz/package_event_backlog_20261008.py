import gzip
import hashlib
import json
import re
from pathlib import Path

campaign = 'event_backlog_exposure_3x3_20261008'
root = Path('results')
out = Path('evidence/review/event_backlog_20261008')
out.mkdir(parents=True, exist_ok=True)
report_path = root / (campaign + '.json')
report = json.loads(report_path.read_text(encoding='utf-8'))
pattern = r'EVENT_BACKLOG date=(\d{4}-\d{2}-\d{2}) calls=(\d+) events=(\d+) max_burst=(\d+) ops_total=(\d+) ops_max=(\d+)'
rows = []
logs = []
for seed in [42, 100, 999]:
    log = root / (campaign + '_engine') / f'reference_seed{seed}_r0.log'
    logs.append(log)
    for line_no, line in enumerate(log.read_text(encoding='utf-8').splitlines(), 1):
        match = re.search(pattern, line)
        if match:
            assert re.search(r'\[0\]\s*\[I\]', line), line
            date, *values = match.groups()
            rows.append(dict(seed=seed, line=line_no, date=date, **dict(zip(
                ['calls', 'events', 'max_burst', 'ops_total', 'ops_max'], map(int, values)))))
assert len(rows) == 105
assert len({(r['seed'], r['date'][:7]) for r in rows}) == 105
assert all(g['game_ok'] and all(c['horizon_complete'] for c in g['companies'].values()) for g in report['games'])
assert sum(r['events'] for r in rows) == 185
assert sum(r['calls'] for r in rows) == 7906
assert sum(r['ops_max'] >= 10000 for r in rows) == 16
manifest = root / (campaign + '.manifest.json')
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == report['manifest_sha256']
exposure = root / (campaign + '.exposure.json')
exposure.write_text(json.dumps(dict(campaign_id=campaign, pattern=pattern,
    company_slot=0, signal_ops_max=10000, rows=rows,
    limits=['Final December interval not flushed', 'Counts are drained events, not queue latency',
            'Opcode clock includes command waiting ticks', 'No event type attribution',
            'No uninstrumented control or economic conclusion']), indent=2) + '\n', encoding='utf-8')
artifacts = []
for source in [report_path, manifest, exposure, *logs, Path(__file__)]:
    raw = source.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    target = out / (source.name + '.gz')
    assert not target.exists(), target
    target.write_bytes(compressed)
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts.append(dict(source=str(source).replace('\\', '/'), archive=target.name,
        raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(),
        gzip_bytes=len(compressed), gzip_sha256=hashlib.sha256(compressed).hexdigest()))
(out / 'index.json').write_text(json.dumps(dict(campaign_id=campaign,
    source_bundle_sha256=report['source_bundle_sha256'], artifacts=artifacts), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(windows=len(rows), events=185, calls=7906, signal_windows=16,
    archived_bytes=sum(a['gzip_bytes'] for a in artifacts))))
