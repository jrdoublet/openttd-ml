import tempfile
from pathlib import Path
import unittest

from analyse_p0_topk_check import analyse


class TopKCheckAnalyzerTest(unittest.TestCase):
    def test_parses_and_rejects_missing_or_duplicate_years(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            path = folder/'p0_topk_check_seed42_r0.log'
            source = '[script:4] [0] [I] P0_TOPK_BINARY year=1970 calls=2 old_ops=100 new_ops=20 mismatches=0'
            path.write_text(source+'\n',encoding='utf8')
            data = analyse(folder,[42])
            self.assertEqual(data['calls'],2)
            self.assertEqual(data['all_mismatches'],0)
            self.assertEqual(data['by_seed']['42']['1970']['reduction_pct'],80)
            path.write_text(source+'\n'+source+'\n',encoding='utf8')
            with self.assertRaises(ValueError):
                analyse(folder,[42])
            with self.assertRaises(FileNotFoundError):
                analyse(folder,[100])


if __name__ == '__main__':
    unittest.main()
