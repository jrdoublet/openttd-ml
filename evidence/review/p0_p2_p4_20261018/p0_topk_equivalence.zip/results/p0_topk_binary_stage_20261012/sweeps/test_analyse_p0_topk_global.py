import tempfile
from pathlib import Path
import unittest

from analyse_p0_topk_global import parse, analyze


class GlobalBudgetTests(unittest.TestCase):
    def test_exclusive_posts_and_missing_year(self):
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder)
            line='[script:4] [0] [I] LOOP_OPS y=1970 post='
            original='\n'.join([line+'_year n=1 ops=0 tk=10',
                                line+'orchestrator n=3 ops=30000 tk=3',
                                line+'catalog_continuation n=1 ops=10000 tk=1',
                                line+'sleep_left n=3 ops=4000 tk=0',
                                line+'tg_rail_scan n=1 ops=900000 tk=0'])
            other=original.replace('orchestrator n=3 ops=30000',
                                   'orchestrator n=3 ops=20000')
            (folder/'reference_seed42_r0.log').write_text(original,encoding='utf8')
            (folder/'p0_topk_binary_seed42_r0.log').write_text(other,encoding='utf8')
            rec=parse(folder/'reference_seed42_r0.log')
            self.assertEqual(rec[1970]['occupied_top'],40000)
            self.assertEqual(rec[1970]['remaining_gap'],56000)
            data=analyze(folder,[42],[1970])
            self.assertEqual(data['paired_delta_occupied_by_seed']['42'],-10000)
            with self.assertRaises(ValueError):
                analyze(folder,[42],[1970,1971])


if __name__=='__main__':
    unittest.main()
