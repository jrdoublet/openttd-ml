"""Contrats hote P0 AIR : garde OFF inchangee et sonde sur rejets seulement.

Ces tests ne compilent pas Squirrel ; aucun runtime Docker n'est execute.
"""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
AI = ROOT / "ai" / "OpexAI"
CAUSAL = ROOT.parent / "p0_projects_causal_stage_20261012" / "ai" / "OpexAI"


def source(name):
    return (AI / name).read_text(encoding="utf-8")


def function_block(text, name, next_marker):
    start = text.index(name)
    end = text.index(next_marker, start)
    return text[start:end]


class P0AirVetoShadowContracts(unittest.TestCase):
    def test_causal_overlays_copied_byte_for_byte(self):
        for name in ("air_planning.nut", "projects_builders.nut", "probes.nut"):
            with self.subTest(name=name):
                self.assertEqual((AI / name).read_bytes(), (CAUSAL / name).read_bytes())

    def test_default_off_for_all_difficulties_and_one_setting_read(self):
        info = source("info.nut")
        entry = re.search(
            r'AddSetting\(\{\s*name\s*=\s*"p0_air_live_veto_reason_shadow"'
            r'(?P<body>.*?)\}\);',
            info,
            re.S,
        )
        self.assertIsNotNone(entry)
        for level in ("easy", "medium", "hard", "custom"):
            self.assertRegex(entry["body"], rf"\b{level}_value\s*=\s*0\b")
        self.assertIn("P0_AIR_LIVE_VETO_REASON_SHADOW <- false", source("globals_pre.nut"))
        self.assertEqual(
            source("settings.nut").count(
                'P0_AIR_LIVE_VETO_REASON_SHADOW = AIController.GetSetting("p0_air_live_veto_reason_shadow") != 0;'
            ),
            1,
        )

    def test_live_gate_is_verbatim_unchanged_from_frozen_base(self):
        current = source("task_air.nut")
        base = (CAUSAL / "task_air.nut").read_text(encoding="utf-8")
        marker = "function OpexAirBatchPlanStillLive(plan, lines)"
        end = "/* C38 etape 2"
        old = function_block(base, marker, end)
        new = function_block(current, marker, "/* P0 AIR, sonde intrusive")
        self.assertEqual(old, new)

    def test_both_real_rejection_paths_run_shadow_after_gate(self):
        task = source("task_projects.nut")
        air = source("task_air.nut")
        portfolio = function_block(
            task,
            '    if (project.mode == "air"\n        && !OpexAirBatchPlanStillLive(',
            "      if (V133_AIR_BUILD_RETRY) OpexV133SalvageDeadPlan",
        )
        self.assertIn("if (P0_AIR_LIVE_VETO_REASON_SHADOW && p0AirVetoLogged < 12)", portfolio)
        self.assertIn('OpexP0AirLiveVetoShadow(project.payload, this._lines, "projects"', portfolio)
        self.assertIn("p0AirVetoLogged++;", portfolio)
        builder = function_block(
            air,
            "      if (!OpexAirBatchPlanStillLive(plan, this._lines)) {",
            "          if (AIR_BATCH_TOWN_RESERVE)",
        )
        self.assertIn("if (P0_AIR_LIVE_VETO_REASON_SHADOW && i < 12)", builder)
        self.assertIn('OpexP0AirLiveVetoShadow(plan, this._lines, "builder"', builder)
        self.assertEqual(air.count("function OpexP0AirLiveVetoShadow("), 1)

    def test_shadow_is_stateless_and_covers_original_rejection_order(self):
        air = source("task_air.nut")
        shadow = function_block(
            air,
            "function OpexP0AirLiveVetoShadow(",
            "/* C38 etape 2",
        )
        markers = [
            'reasons.append("recovery")',
            'reasons.append("secondA_unserved")',
            'reasons.append("secondA_closed")',
            'reasons.append("servedA")',
            'reasons.append("secondB_unserved")',
            'reasons.append("secondB_closed")',
            'reasons.append("servedB")',
            'reasons.append("capA")',
            'reasons.append("capB")',
            'reasons.append("linkedOD")',
        ]
        positions = [shadow.index(marker) for marker in markers]
        self.assertEqual(positions, sorted(positions))
        self.assertIn("local first = reasons.len() > 0 ? reasons[0]", shadow)
        self.assertIn('local first', shadow)
        self.assertNotRegex(shadow, r"\b(Sleep|BuildAirport|RemoveAirport|rawset|save|Save|Load)\s*\(")
        self.assertNotIn("OpexAirBatchPlanStillLive(", shadow)
        self.assertIn('first=" + first + " reasons="', shadow)
        self.assertIn('P0_AIR_VETO mode=air stage=', shadow)
        self.assertIn('anchorA=', shadow)


if __name__ == "__main__":
    unittest.main()
