# P0 AIR — sonde de veto vivant (stage isolé, 12 octobre 2026)

**Statut : instrumentation expérimentale, non qualifiée en moteur.** Stage
`results/p0_air_veto_shadow_stage_20261012`, base `f6139d8`; les trois
overlays du stage causal (`air_planning.nut`, `projects_builders.nut`,
`probes.nut`) ont été copiés exactement pour servir de base commune aux
deux bras. Aucun changement sur `master` ou les autres stages.

Le seul nouveau réglage `p0_air_live_veto_reason_shadow` vaut **0 sur les
quatre difficultés**, avec lecture unique lors du chargement des settings.
Les bras d'un éventuel diagnostic comparatif devront utiliser le **même
bundle** : `OpexAI[p0_air_live_veto_reason_shadow=0]` et
`OpexAI[p0_air_live_veto_reason_shadow=1]`. Les autres réglages doivent
être les mêmes et leur provenance figée.

Sous ON, lorsqu'un des deux callsites du constructeur ou du portefeuille
vient de recevoir `false` de `OpexAirBatchPlanStillLive`, la sonde
`OpexP0AirLiveVetoShadow` relit les préconditions à titre diagnostic.
Elle affiche `P0_AIR_VETO` avec `stage=projects|builder`, date, tick,
rang, `built_before`, taille de `best`, mode AIR, arm, OD, ancres de site,
reuse, flags seconde place,
résultat des tests served/slot/capacity, premier motif et liste de motifs
simultanés. Valeurs `-1` = contrôle inapplicable/non exécuté.
Les motifs sont `recovery`, `servedA|servedB`,
`secondA_unserved|secondB_unserved`,
`secondA_closed|secondB_closed`, `capA|capB`, `linkedOD`.
`first=none` signifie qu'un monde vivant différent peut avoir été observé
pendant la reprise VM ; il n'autorise aucune correction.

Le code OFF n'évalue jamais ce helper ni ses appels NoAI. En ON, le
portefeuille émet **au maximum 12** diagnostics par passage; le second
callsite est borné aux rangs 0–11. Ce sont des **échantillons de vetos**,
pas un décompte exhaustif de projets distincts, de routes constructibles
ou de pertes de profit. Aucun candidat n'est supprimé ou réordonné,
aucun score, quota, cache, paire abandonnée, queue ni Save/Load n'est
modifié. La fonction garde `OpexAirBatchPlanStillLive` est identique
octet par octet à la base isolée.

**Attention : sonde intrusive de trajectoire.** Les appels API répétés
consomment des opcodes et peuvent suspendre la VM entre les contrôles ;
`first` décrit le replay diagnostique, pas nécessairement l'instant exact
du veto réel. Une partie ON ne doit pas être appariée événementiellement
à l'ancienne campagne C66 ou à un témoin sans sonde. Il faut un smoke
compilation/exécution 1×1 moteur puis une campagne diagnostique dédiée
avec freeze, provenance, santé et logs source conservés, pilotée par le prime.
Une classification ne prouve jamais une alternative finançable et
constructible : cette preuve nécessite une analyse contrefactuelle séparée.

## Qualification moteur de la sonde — prime, 12 octobre

Après 149/149 contrats hôte verts (dont 52/52 C121 adaptés sans skip),
smoke C66 `p0_air_live_veto_shadow_smoke42_1y_20261012` **2/2 sain** et
diagnostic C66 `p0_air_live_veto_shadow_diag3x5_20261012` **6/6 sains**, trois
graines 42/100/999 ×5 ans, zéro erreur Squirrel/script, télémétrie annuelle
60 snapshots. Les deux campagnes proviennent du même bundle gelé
`c80f601f86e0836a0e435fcd4934c04776e2f8dd95f2eb345b1f93d2af0b3161`.
Manifest 3×5 `3320df8bd8ea4e6a8bb5f0b99a96f1cf607665410de9709c1f3d98b2f6e643fb`.

**Échantillon 1973 dans le SEUL bras sonde ON** : graine42 zéro veto capturé,
graine100 **26 visites /14 OD+arm distincts** (24 `capA`, 2 `capB` ; 12 avec
`linkedOD` simultané), graine999 **20 visites /20 OD+arm** (18 `capA`, 2
`capB`). Tous au point d'appel `projects`; aucune seconde lecture `first=none`
sur ces observations. Les gardes physiques de capacité aéroport atteinte
constituent les motifs vérifiables dans cet échantillon, **pas** preuve d'un
projet alternatif finançable ou physiquement constructible perdu. Après une
construction réussie, il est normal que d'autres OD sur ce hub soient refusées.
Les logs sont bornés (12 par passe / rangs 0–11), pas exhaustifs : graine42
zéro observation ne signifie pas zéro veto total.

**La sonde ON perturbe les trajectoires** : ON−OFF profit terminal 1974
**−148 490 £/an en moyenne sur trois graines**, IC95 bootstrap
[−220 317 ;−101 747] (n=3, **non qualifiant**), valeur −0,938 %.
Verdict `diagnostic_only`, aucune acceptation économique ni nouveau seuil.
Ne pas apparier les événements aux données FUNNEL antérieures bundle `04af961`.
Analyseur `sweeps/analyse_p0_air_veto_shadow_20261012.py` (4 tests verts),
résumé dans `evidence/review/p0_projects_conversion_20261012/p0_air_live_veto_shadow_diag3x5_analysis.json`
SHA256 `ce4656e5bda09b3617c03d6caa0e8ecd8712a697830a0725e7740ef4ffb690cf`.
Preuves intégrales (JSON brut, manifeste, logs, bundle) conservées dans
`results/` de ce stage. Flag OFF, aucun commit/push.
