# P0 AIR — concurrence visible C121, qualification économique distincte

**Pré-enregistrement du 12 octobre 2026 :** candidat économique
`c121_air_visible_competition=0` (référence) → `1` (variante), **aucun
changement de défaut, de seuil, de score arbitraire ou de code de production**.
Ce candidat existe déjà, mais n'a pas de qualification économique C66 A40×3
documentée : les résultats historiques `c121_visible_flux_porteA_40x6` portent
un **autre flag, `c121_visible_flux`**, déjà NON DÉMONTRÉ/OFF, et ne seront
pas retestés. Si un test économique `visible_competition` identique existe
ailleurs, arrêter le banc et réutiliser la décision plutôt que le répéter.

## Hypothèse et exposition préalable

La télémétrie active C66 OFF de 20 graines donne, sur **19 paires entièrement
résolues** fin 1973, 77,684 avions Opex vs 37,368 AAA par graine,
21 690 vs 51 278 £ de profit véhicule YTD moyen par appareil ; les mêmes
avions Opex restant sur les mêmes gares/OD perdent −252 998 £/graine
1972→1973, contre +350 178 £ AAA. Sur lignes AIR à flotte active **nette
augmentée** et même avion ancien sur même StationID, le profit des anciens
avions Opex recule dans **19/19 graines**, −11 762 £/avion survivant,
contre +751 £/avion sur les lignes à flotte inchangée.

Le code courant `task_air.nut:1176–1222,1271–1309` utilise la cible C121
et son marginal pour les renforts sous cible, sans exiger un avion plein de
cargo en attente ; retour sur marge réelle seulement à `year+2`
(`task_projects.nut:249–307`). Le devis de demande visible des concurrents
pour les lignes et renforts **existe déjà** mais `c121_air_visible_competition`
vaut zéro : `OpexC121RefreshVisibleFleet` retourne immédiatement.

Une étude indépendante le 8 octobre avec `visible_competition=1` a montré
une meilleure exactitude prédictive mensuelle des flux sur graines réservées
73/314/512 (WAPE 44,04 %→26,41 %, biais 36,62 %→11,75 %), mais ne prouve
ni une baisse de surflotte ni un gain de profit comptable : sa modification
économique est donc une **hypothèse à tester**, pas un correctif accepté.
Elle réestime également certains projets AIR neufs/hubs : les effets du test
ne pourront pas être attribués uniquement aux renforts AIR sans instrumentation
complémentaire. Aucune OD alternative constructible n'est prouvée par ce devis.

## Isolement et garde-fous

- Worktree **détaché** `results/p0_visible_competition_stage_20261012`
  au HEAD `f6139d89f299bcd3d2d24bc32bf22fef6df21d8f`.
- Trois overlays communs `air_planning.nut`, `projects_builders.nut`,
  `probes.nut` copiés byte-identiques depuis `p0_projects_causal_stage_20261012`,
  copie ignorée AAAHogEx-115, communs aux deux politiques. Aucun autre `.nut`
  changé et aucune édition master pour ce candidat.
- Tous les autres réglages par défaut communs, dont
  `c121_air_visible_fused=0`, `c121_air_visible_flux=0` s'ils existent,
  `ac04_hub_usage_gate=1` lorsque retenu par le dépôt, `probe_loop_ops=1`
  commun aux deux bras pour mesurer global opcodes. `--script-debug`
  et `--line-telemetry` annuelle identiques.
- `--years 1 --seeds 42 --max-workers 2` smoke moteur pour compiler les deux
  branches. Puis **si sain**, `gain_short`, **40 graines canoniques ×3 ans,
  80 duels**, `--cpus 10 --max-workers 10 --memory 8g`, une campagne à la fois.
- Selon `AGENTS.md` §4, ne poursuivre en B20×10 que si Wilcoxon bilatéral exact
  p0 probant, gain moyen final **≥4 %** du profit de référence et garde valeur
  **−5 %**. Une absence de défaite significative ou une bonne précision flux
  n'autorisent pas une adoption. Exiger croissance physique AIR/RAIL, année
  1972→1973, profit comptable, valeur, budget global et écart AAA ; les
  services de `--line-telemetry` ne sont **pas** des constructions brutes.
- Si A échoue : verdict **NON DÉMONTRÉ ou REJETER**, flag 0, pas de B,
  aucune réactivation/répétition opportuniste. Ne pas confondre avec
  `c121_visible_flux` retiré. Pas de commit/push sans permission.

## État

**Porte A terminée et ÉCHOUÉE ; décision `fail_primary`, NON DÉMONTRÉ, flag
OFF. Pas de porte B20×10 et pas d'adoption.**

- Contrats hôte ciblés avant moteur : `test_c121_visible_target.py` **2/2**,
  `test_c121_visible_flux.py` **3/3**, `test_c121_visible_fused_port.py`
  **2/2**, V141 **6/6**, `git diff --check` sain. L'ancienne validation
  NoAI/Save-Load du modèle visible documentée dans `docs/taches.md` ne prouve
  pas une quelconque amélioration économique.
- Smoke `p0_visible_competition_smoke42_1y_20261012` **2/2 sain**,
  `diagnostic_only`, ON−OFF +67 746 £/an sur **1 graine ×1 an**, non
  qualifiant. Source gelée SHA256
  `04af9610318c9214da9664b17d9c6326ba17e332c8f3a4bc8d3cec1342e0a59f`.
- Porte A `p0_visible_competition_a40x3_20261012` : même bundle
  `04af961...`, manifest SHA256
  `d82eb214d80bcb05bf90a674296e979b6be40eb4c4cc38153cd51dd9a9dee620`,
  **80/80 parties, 40/40 paires complètes**, profits de l'année terminale
  1972 tous couverts, `--script-debug --line-telemetry` annuels identiques,
  `probe_loop_ops=1` commun, machine 10 CPU/10workers/8 Go, sans autre
  campagne moteur en parallèle. L'année1973 est **hors horizon de A**.

| Critère 1972, ON moins OFF | Résultat |
|---|---:|
| Profit annuel Opex moyen référence | 1 921 392 £/an |
| Profit annuel variante | 1 872 907 £/an |
| Moyenne delta profit | **−48 485,3 £/an**, **−2,5234 %** |
| Intervalle bootstrap95 | [−107 413,2 ; +11 065,5] £/an |
| Wilcoxon bilatéral exact | **p=0,1213988**, V/D/E=15/25/0 |
| Minimum utile pré-enregistré | **+76 856 £/an** (=4 % de référence) |
| Company value ON−OFF | **−118 402 £**, **−3,5227 %** (garde−5 % tenue) |
| Verdict C66 | **`fail_primary`** : p0, CI et seuil de gain non validés |

Trajectoire de `profit_year` moyen Opex ON−OFF : 1970 +120 £ (année
de démarrage partielle), 1971 +55 701 £, **1972 −48 485 £** ; l'effet
n'est ni monotone ni un gain reproductible. Sur 40 paires, écart Opex−AAA
fin1972 sous référence **−107 672 £/an**, sous ON **−225 080 £/an** ; cette
différence ne s'attribue pas à la seule flotte. La comparaison des services
**actifs** reconstitués, uniquement sur **38 graines Opex avec les deux
snapshots complets** : ON−OFF fin1972 **−5,921 AIR**, **−0,395 RAIL**,
**−0,158 ROAD** par graine. Nombre de créations brutes inconnu.

Occupation LOOP_OPS top-level (sans ajouter les sous-budgets C39) : ON−OFF
1970 **+157 486 fenêtres-opcodes**/graine, 1971 **+2 112 045**/graine,
34/40 graines plus coûteuses en 1971. Mesure d'occupation, y compris
commandes/attentes, pas un relevé VM pur. Pas de gain opcode global local
à adopter. Les diagnostics de services sont couverts pour 38 Opex/38 AAA
en bras OFF 1972, 40 Opex/39 AAA en ON ; **ne pas comparer sans appariement
des snapshots**. Source script audit
`sweeps/analyse_p0_visible_competition_porteA_20261012.py`, trois tests hôte
verts, archive
`evidence/review/p0_projects_conversion_20261012/p0_visible_competition_a40x3_analysis_v2_20261012.json`.

Le modèle de flux NoAI peut prédire plus précisément sans augmenter le
nombre de lignes ni les profits ; cet échec de porte ne prouve pas que le
modèle est inutile sur toutes les circonstances ou que les avions déjà
installés ne souffrent pas de surcapacité. Mais **il interdit l'adoption et
la porte B** de cette activation globale dans ce cycle. Aucune relance pour
chercher un meilleur tirage, aucun changement de défaut/code prod, aucun
commit/push.
