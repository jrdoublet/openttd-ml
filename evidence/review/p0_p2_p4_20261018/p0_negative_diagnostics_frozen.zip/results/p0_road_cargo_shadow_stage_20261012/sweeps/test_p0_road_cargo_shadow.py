"""Static/functional assertions on the isolated diagnostic-only ROAD cargo probe.

Python does not compile Squirrel; the motor smoke is separate.
"""
from pathlib import Path
import re
import unittest


AI = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


class RoadCargoShadowContracts(unittest.TestCase):
    def test_off_four_difficulties(self):
        src = (AI / "info.nut").read_text(encoding="utf8")
        m = re.search(r'name = "p0_road_cargo_shadow".*?flags = AICONFIG_BOOLEAN', src, re.S)
        self.assertIsNotNone(m)
        for difficulty in ("easy", "medium", "hard", "custom"):
            self.assertRegex(m.group(), rf'\b{difficulty}_value = 0')

    def test_global_nonpersistent_and_setting_loaded(self):
        glob = (AI / "globals_pre.nut").read_text(encoding="utf8")
        load = (AI / "settings.nut").read_text(encoding="utf8")
        self.assertIn("P0_ROAD_CARGO_SHADOW <- false;", glob)
        self.assertIn("P0_ROAD_CARGO_SHADOW_LAST_MONTH <- -1;", glob)
        self.assertIn('AIController.GetSetting("p0_road_cargo_shadow")', load)
        persist = (AI / "persist.nut").read_text(encoding="utf8")
        self.assertNotIn("P0_ROAD_CARGO_SHADOW", persist)

    def test_counterfactual_does_not_publish_or_build(self):
        source = (AI / "projects_generation.nut").read_text(encoding="utf8")
        segment = source.split("function OpexP0RoadCargoShadow(",1)[1].split("function OpexGenerateModeProjects(",1)[0]
        self.assertIn("if (!P0_ROAD_CARGO_SHADOW || !ROAD_BUILD_ENABLED) return;", segment)
        self.assertIn("P0_ROAD_CARGO_SHADOW_LAST_MONTH == ym", segment)
        self.assertIn("OpexBuildRoadCandidates(catalog, budget, lines, abandonedPairs,", segment)
        self.assertIn("null, null, null, -1);", segment)
        self.assertIn('OpexDecide("P0_ROAD_CARGO_SHADOW"', segment)
        for operation in ("generated.projects.append", "generated.road =", "OpexBuildRoadRoute(", "OpexRoadPlanFor(", "candidateGroups", "OpexProjectInsert"):
            self.assertNotIn(operation, segment)
        selection = source.split('} else if (mode == "road") {',1)[1].split('} else if (mode == "air") {',1)[0]
        self.assertIn("generated.road = road;", selection)
        self.assertIn("foreach (candidate in road.candidates)", selection)
        self.assertIn("OpexP0RoadCargoShadow(catalog, budget, lines, abandonedPairs, road, freightCargo);", selection)
        full = (AI / "projects.nut").read_text(encoding="utf8")
        self.assertIn("road = OpexBuildRoadCandidates(catalog, budget, lines, abandonedPairs, roadProfile, freightCargo);", full)
        self.assertIn("OpexP0RoadCargoShadow(catalog, budget, lines, abandonedPairs, road, freightCargo);", full)

    def test_counterfactual_cargo_counts_are_not_constructed_lines(self):
        # Confirms diagnostic classification only; no candidate can be claimed
        # buildable from this Python oracle.
        candidates = [dict(cargo=1, capital=50, profit=20),
                      dict(cargo=2, capital=75, profit=30),
                      dict(cargo=2, capital=150, profit=90),
                      dict(cargo=1, capital=20, profit=10)]
        chosen = 1
        alternative = [c for c in candidates if c["cargo"] != chosen]
        self.assertEqual(2, len(alternative))
        self.assertEqual(1, sum(c["capital"] <= 100 for c in alternative))
        self.assertEqual(90, max(c["profit"] for c in alternative))
        # Their unknown road plans make certified construction count unavailable.
        self.assertIsNone(None)


if __name__ == "__main__":
    unittest.main()
