"""Contrats hote P0 RAIL : exposition A* seule, pas de compilation Squirrel."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
AI = ROOT / "ai" / "OpexAI"
CAUSAL = ROOT.parent / "p0_projects_causal_stage_20261012"


def source(name):
    return (AI / name).read_text(encoding="utf-8")


def body(text, start, end):
    i = text.index(start)
    return text[i:text.index(end, i)]


class P0RailBlockExposureContracts(unittest.TestCase):
    def test_shared_causal_overlays_byte_identical(self):
        for name in ("air_planning.nut", "projects_builders.nut", "probes.nut"):
            with self.subTest(name=name):
                self.assertEqual((AI / name).read_bytes(),
                                 (CAUSAL / "ai" / "OpexAI" / name).read_bytes())

    def test_ignored_opponent_tree_identical(self):
        ours = ROOT / "ai" / "AAAHogEx-115"
        theirs = CAUSAL / "ai" / "AAAHogEx-115"
        files = sorted(p.relative_to(ours) for p in ours.rglob("*") if p.is_file())
        self.assertGreater(len(files), 0)
        self.assertEqual(files, sorted(p.relative_to(theirs) for p in theirs.rglob("*") if p.is_file()))
        for rel in files:
            with self.subTest(path=str(rel)):
                self.assertEqual((ours / rel).read_bytes(), (theirs / rel).read_bytes())

    def test_flag_off_all_four_and_loaded_once(self):
        settings = source("info.nut")
        definition = re.search(
            r'AddSetting\(\{\s*name\s*=\s*"p0_rail_block_exposure_shadow"'
            r'(?P<body>.*?)\}\);', settings, re.S)
        self.assertIsNotNone(definition)
        for level in ("easy", "medium", "hard", "custom"):
            self.assertRegex(definition["body"], rf"\b{level}_value\s*=\s*0\b")
        self.assertIn("P0_RAIL_BLOCK_EXPOSURE_SHADOW <- false;", source("globals_pre.nut"))
        self.assertEqual(source("settings.nut").count(
            'P0_RAIL_BLOCK_EXPOSURE_SHADOW = AIController.GetSetting("p0_rail_block_exposure_shadow") != 0;'), 1)

    def test_exact_original_code_paths_after_stripping_only_shadow(self):
        stage = source("task_rail.nut")
        base = (CAUSAL / "ai" / "OpexAI" / "task_rail.nut").read_text(encoding="utf-8")
        start = "/* P0 RAIL : appeler seulement apres un rejet search_in_progress"
        end = "/* C38 etape 2 : une tentative rail est une transaction explicite."
        self.assertEqual(stage.count(start), 1)
        stage = stage[:stage.index(start)] + stage[stage.index(end, stage.index(start)):]
        new_call = (
            '          if (P0_RAIL_BLOCK_EXPOSURE_SHADOW)\n'
            '            OpexP0RailBlockExposureShadow(this._railSearch, candidate, project, i, "stock_gate");\n'
        )
        new_call2 = (
            '          if (P0_RAIL_BLOCK_EXPOSURE_SHADOW)\n'
            '            OpexP0RailBlockExposureShadow(this._railSearch, candidate, project, i, "normal");\n'
        )
        self.assertEqual(stage.count(new_call), 1)
        self.assertEqual(stage.count(new_call2), 1)
        stage = stage.replace(new_call, "").replace(new_call2, "")
        self.assertEqual(stage, base, "le reste de task_rail doit etre STRICTEMENT inchange")

    def test_call_sites_are_after_supersede_and_before_legacy_audit(self):
        code = source("task_rail.nut")
        fn = code[code.index("function OpexAI::_tryBuildRailProject"):]
        supersede = fn.index("this._maybeSupersedeRailSearchForOriginReuse(candidate, i);")
        stock = fn.index('OpexP0RailBlockExposureShadow(this._railSearch, candidate, project, i, "stock_gate");')
        normal = fn.index('OpexP0RailBlockExposureShadow(this._railSearch, candidate, project, i, "normal");')
        self.assertLess(supersede, stock)
        self.assertLess(stock, normal)
        for branch in ("stock_gate", "normal"):
            idx = fn.index(f'OpexP0RailBlockExposureShadow(this._railSearch, candidate, project, i, "{branch}");')
            self.assertIn('if (P0_RAIL_BLOCK_EXPOSURE_SHADOW)', fn[idx-75:idx])
            self.assertIn('if (RAIL_FAILURE_AUDIT) OpexRailFailureAudit("early"', fn[idx:idx+350])

    def test_transient_dedup_and_single_post_dedup_cash_read(self):
        src = source("task_rail.nut")
        helper = body(src, "function OpexP0RailBlockExposureShadow(", "/* C38 etape 2")
        required = (
            "if (!P0_RAIL_BLOCK_EXPOSURE_SHADOW || state == null || candidate == null) return;",
            "OpexProjectPairKey(candidate.kind, candidate.cargo,",
            'if (!("p0Seen" in state)) state.rawset("p0Seen", {});',
            "if (requestedKey in state.p0Seen) return;",
            "state.p0Seen.rawset(requestedKey, true);",
            "OpexProjectPairKey(blocker.kind, blocker.cargo, blocker.src, blocker.dst)",
            "self_revisit=",
            "physical=unknown",
            "blocker_start_date=",
            "blocker_spent=",
            "blocker_budget=",
            "pred_profit=",
            "pred_budget_capital=",
            "requested_cargo=",
            "requested_kind=",
        )
        for needle in required:
            with self.subTest(needle=needle):
                self.assertIn(needle, helper)
        self.assertEqual(helper.count("OpexAvailableCapital()"), 1)
        self.assertLess(helper.index("if (requestedKey in state.p0Seen) return;"),
                        helper.index("OpexAvailableCapital()"))
        self.assertNotIn("OpexRailSearchBlockerAudit(", helper)
        self.assertNotIn("OpexRailFailureAudit(", helper)
        for unsafe in ("AITestMode(", "OpexBuildLine(", "OpexCreateRailPathfinder(",
                       "OpexCreateSegmentedSearch(", "AIController.Sleep(",
                       "this._railSearch =", "OpexDecide(", "OpexSign("):
            self.assertNotIn(unsafe, helper)
        persist = source("persist.nut")
        self.assertNotIn("p0Seen", persist)
        self.assertIn("railSearchPending = this._railSearch != null", persist)
        self.assertIn("this._railSearch = null;", persist)


if __name__ == "__main__":
    unittest.main()
