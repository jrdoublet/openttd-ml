# P0 RAIL — exposition au verrou A* (12 octobre 2026)

**Statut : instrumentation seulement, NON validée en moteur.** Nouveau stage
`results/p0_rail_block_exposure_stage_20261012` au commit `f6139d8`.
Les trois overlays `air_planning.nut`, `projects_builders.nut`,
`probes.nut` sont copiés byte-identiques du stage causal ; le répertoire
ignoré `ai/AAAHogEx-115` également. Aucun changement dans master ni les
stages AIR veto, abandon ou causal.

Le flag `p0_rail_block_exposure_shadow` est à **0 sur les quatre difficultés**.
ON n'est évalué qu'aux DEUX sorties `search_in_progress` de
`_tryBuildRailProject` : branche stock `C80_RAIL_STOCK_GATE` et branche
normale, après l'éventuel `_maybeSupersedeRailSearchForOriginReuse`.
La troisième sortie `prep_dropped` n'est pas incluse dans ce protocole.

À chaque refus réel, le helper vérifie `_railSearch.p0Seen` pour journaliser
une seule fois une **clé OD/cargo/kind** par **objet-épisode de recherche A***
(même helper sur les deux branches). La clé canonise les extrémités pour
`pax` comme `OpexProjectPairKey`, et respecte le sens du fret. La
classification `self_revisit=1` signifie que le candidat demandé est la même
clé OD/cargo/kind que le candidat occupant ; elle ne constitue pas une
opportunité perdue supplémentaire. Une recherche d'upgrade sans candidat
attaché expose des origines de ligne si connues, mais jamais un
`self_revisit` certain.

Une clé non vue entraîne **une seule lecture de `OpexAvailableCapital()`**
après dédup, puis un `AILog.Info` `P0_RAIL_BLOCK` comportant la branche,
date, rang, kind/cargo/src/dst, profit et capital prévus dans le projet,
cash disponible, phase/kind/startDate/âge/tick/spent/budget de l'occupant,
OD de l'occupant si accessible. `physical=unknown` est fixe : **aucune
revalidation géométrique, devis nouveau, A* additionnel ni construction**.
Un capital prévu n'est pas une preuve de financement réellement suffisant.
`p0Seen` est une table transitoire créée à la première exposition ON et
libérée avec `_railSearch`, déjà non sérialisé. Aucune modification Save/Load.

L'ancienne sonde `RAIL_FAILURE_AUDIT` existait déjà et journalisait le
blocage sans cash vivant ni déduplication : elle reste indépendante,
désactivée sauf son propre réglage, et n'est pas appelée par notre helper.

**Sonde intrusive de trajectoire** : ON consomme du temps/opcodes et peut
modifier les dates ou choix ultérieurs ; les éléments du log ne démontrent
pas qu'un autre tracé profitable était physiquement constructible.
Le chemin OFF ne calcule aucune clé, aucun cash, aucun log et ne touche
aucun état A*. Restent nécessaires le smoke Squirrel 1×1 et la collecte
C66 diagnostique sur bundle figé identique sous pilotage du prime, sans
comparer la séquence ON événement par événement à un ancien témoin.

**Qualification recommandée au prime :** figer ce worktree complet, y
compris les overlays et AAAHogEx-115, puis un smoke C66 apparié 1 graine ×
1 an avec les deux bras
`OpexAI[p0_rail_block_exposure_shadow=0]` et
`OpexAI[p0_rail_block_exposure_shadow=1]`, tous autres réglages identiques.
Activer `--script-debug` lors de l'exécution moteur pour capturer
`AILog.Info` dans les journaux ; `RAIL_FAILURE_AUDIT` reste indépendant et
n'est pas nécessaire pour ce protocole. Vérifier la santé, les journaux ON,
l'absence de `P0_RAIL_BLOCK` côté OFF, puis seulement un diagnostic 3×5 si
le smoke est sain. Les événements doivent être interprétés dans chaque
trajectoire séparément ; on ne déduit jamais la constructibilité de
`physical=unknown` ni de `cash_available`.
