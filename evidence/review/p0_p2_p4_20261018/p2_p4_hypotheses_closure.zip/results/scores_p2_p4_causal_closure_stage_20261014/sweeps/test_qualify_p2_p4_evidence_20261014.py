"""Independent host tests of the economic evidence reconciliation."""
import unittest

from qualify_p2_p4_evidence_20261014 import setting_is_off, report


class EvidenceContracts(unittest.TestCase):
    def test_four_defaults(self):
        good = ('AddSetting({ name = "demo", easy_value=0, medium_value=0, '
                'hard_value=0, custom_value=0 });')
        self.assertTrue(setting_is_off(good, 'demo'))
        self.assertFalse(setting_is_off(good.replace('hard_value=0', 'hard_value=1'), 'demo'))
        self.assertFalse(setting_is_off(good + good, 'demo'))

    def test_no_claim_of_global_impossibility(self):
        result = report()
        self.assertTrue(result['does_not_imply_universal_impossibility'])
        self.assertEqual(len(result['evidence']), 3)

    def test_none_qualifies_for_adoption(self):
        for entry in report()['evidence'].values():
            self.assertFalse(entry['ci_entirely_positive'])
            self.assertEqual(entry['qualification'], 'reject_for_adoption')

    def test_validity_gates(self):
        result = report()['evidence']
        self.assertEqual(result['fleet_vs_new_air']['actual_defer_marks_variant'], 0)
        self.assertTrue(all(result['net_revenue_air']['same_bundle_precheck_aa_logs_identical_2y'].values()))
        self.assertGreater(result['hub_positive_externality']['reference_positive_evaluations'], 0)
        self.assertLessEqual(result['hub_positive_externality']['reference_positive_evaluations'],
                             result['hub_positive_externality']['reference_quoted_evaluations'])


if __name__ == '__main__':
    unittest.main()
