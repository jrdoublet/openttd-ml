"""Independent, read-only reconciliation of the three new P2/P4 policy gates.

No OpenTTD, no Docker, and no mutation of any original campaign. Output is
written only into the exclusive causal-closure worktree.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re


STAGE = Path(__file__).resolve().parents[1]
RESULTS = STAGE.parent
SPECS = {
    "fleet_vs_new_air": (
        "scores_p2_p4_fleet_opportunity_stage_20261014",
        "p2_p4_fleet_displace_exposure3x5_20261014",
        "p2_fleet_air_displacement",
    ),
    "net_revenue_air": (
        "scores_p2_p4_net_revenue_stage_20261014",
        "p2_p4_net_revenue_parity5x5_20261014",
        "p2_air_net_revenue",
    ),
    "hub_positive_externality": (
        "scores_p2_p4_signed_hub_stage_20261014",
        "p2_p4_signed_hub_dev5x5_20261014",
        "c121_hub_signed_externality",
    ),
}
EXPOSURE = re.compile(
    r"C121_HUB_SIGNED exposure_year=(\d+) quote_evaluations=(\d+)"
    r" positive_quotes=(\d+) max_gain_annual=(\d+) applied=(\d+)"
)
TIME = re.compile(r"^\[[^]]+\]\s*")


def setting_is_off(info_text: str, setting: str) -> bool:
    needle = 'name = "' + setting + '"'
    if info_text.count(needle) != 1:
        return False
    fragment = info_text.split(needle, 1)[1].split("});", 1)[0]
    return all(re.search(rf"\b{difficulty}_value\s*=\s*0\b", fragment)
               for difficulty in ("easy", "medium", "hard", "custom"))


def normalized_log(path: Path) -> list[str]:
    return [TIME.sub("", line.rstrip("\r\n"))
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()]


def analyze_gate(tag: str, stage_name: str, campaign: str, setting: str) -> dict:
    stage = RESULTS / stage_name
    path = stage / "results" / (campaign + ".json")
    result = json.loads(path.read_text(encoding="utf-8"))
    comp = result["policy_comparison"]
    profit = comp["aggregates"]["profit_year"]["policy_delta"]
    value = comp["aggregates"]["company_value"]["policy_ratio"]
    assert comp["complete_pairs"] == comp["planned_pairs"], tag
    assert comp["comparison_complete"], tag
    assert result["years"] == 5, tag
    assert comp["verdict"] == "diagnostic_only", tag
    info = (stage / "ai" / "OpexAI" / "info.nut").read_text(encoding="utf-8")
    assert setting_is_off(info, setting), tag
    assert len(comp["per_pair"]) == comp["complete_pairs"], tag
    pair_deltas = {str(p["seed"]): p["metrics"]["profit_year"]["policy_delta"]
                   for p in comp["per_pair"]}
    ci = profit["mean_bootstrap_95pct_ci"]
    return {
        "campaign": campaign,
        "stage": stage_name,
        "flags_off_four_difficulties": True,
        "bundle_sha256": result["source_bundle_sha256"],
        "years": result["years"],
        "complete_pairs": comp["complete_pairs"],
        "profit_year_deltas": pair_deltas,
        "profit_year_mean": profit["mean"],
        "profit_year_median": profit["median"],
        "wins": profit["wins"], "losses": profit["losses"],
        "ties": profit["ties"],
        "profit_year_bootstrap_ci95": ci,
        "company_value_ratio_change_pct": value["ratio_of_means_percent_change"],
        "ci_entirely_positive": bool(ci[0] > 0),
        "qualification": "reject_for_adoption",
    }


def report() -> dict:
    results = {key: analyze_gate(key, *spec) for key, spec in SPECS.items()}
    h1 = RESULTS / SPECS["fleet_vs_new_air"][0] / "results"
    h1logs = h1 / (SPECS["fleet_vs_new_air"][1] + "_engine")
    on = sorted(h1logs.glob("fleet_air_dominance_seed*_r0.log"))
    assert len(on) == 3, on
    marks = sum(log.read_text(encoding="utf-8", errors="replace").count("P2_FLEET_AIR_DEFER")
                for log in on)
    results["fleet_vs_new_air"]["actual_defer_marks_variant"] = marks
    results["fleet_vs_new_air"]["no_attributable_intervention"] = (marks == 0)

    h2 = RESULTS / SPECS["net_revenue_air"][0] / "results"
    pre = json.loads((h2 / "p2_p4_net_revenue_precheck2x2_20261014.json").read_text(encoding="utf-8"))
    assert pre["source_bundle_sha256"] == results["net_revenue_air"]["bundle_sha256"]
    prelogs = h2 / "p2_p4_net_revenue_precheck2x2_20261014_engine"
    identical = {}
    for seed in (42, 100):
        reference = prelogs / f"c70_net_shadow_seed{seed}_r0.log"
        variant = prelogs / f"measured_net_execute_seed{seed}_r0.log"
        identical[str(seed)] = normalized_log(reference) == normalized_log(variant)
    results["net_revenue_air"]["same_bundle_precheck_aa_logs_identical_2y"] = identical
    assert all(identical.values()), identical

    h3 = RESULTS / SPECS["hub_positive_externality"][0] / "results"
    logs = h3 / (SPECS["hub_positive_externality"][1] + "_engine")
    control = sorted(logs.glob("hub_shadow_historical_seed*_r0.log"))
    assert len(control) == 5, control
    count, positive, max_gain = 0, 0, 0
    for path in control:
        events = EXPOSURE.findall(path.read_text(encoding="utf-8", errors="replace"))
        assert len(events) == 5, (path, len(events))
        assert all(int(event[4]) == 0 for event in events)
        count += sum(int(e[1]) for e in events)
        positive += sum(int(e[2]) for e in events)
        max_gain = max(max_gain, *(int(e[3]) for e in events))
    results["hub_positive_externality"]["reference_quoted_evaluations"] = count
    results["hub_positive_externality"]["reference_positive_evaluations"] = positive
    results["hub_positive_externality"]["maximum_quote_gain_annual_model"] = max_gain
    results["hub_positive_externality"]["evaluation_is_not_distinct_build"] = True

    assert not any(x["ci_entirely_positive"] for x in results.values())
    return {
        "scope": "new_P2_P4_mechanisms_since_C77_rejection",
        "decision": "no_robust_terminal_profit_year_gain_on_tested_mechanisms",
        "does_not_imply_universal_impossibility": True,
        "evidence": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=STAGE / "results" /
                        "p2_p4_causal_closure_20261014.json")
    args = parser.parse_args()
    destination = args.out.resolve()
    allowed = (STAGE / "results").resolve()
    if destination.parent != allowed:
        raise ValueError("output must be a file directly in exclusive stage results")
    if destination.exists():
        raise FileExistsError(destination)
    payload = report()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
