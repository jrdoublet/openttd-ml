# OpexAI V166 — P2/P4 : décision économique consolidée et mécanismes ouverts

Date de reprise : 14 octobre 2026. Cette fiche examine le programme **au-delà
de C77 RAIL→RAIL** sans recycler ses campagnes ni ses audits. Base de code
V166 conservée : `7ecbabe8ff4154dfd62184a5d6d1e33db3bbccbf`.

## Contrat de provenance

Worktree exclusif **nouveau** :
`results/scores_p2_p4_causal_closure_stage_20261014/`. Le checkout principal
sale, les stages P1/V165, V166, C121/R2/V161, C77 et finances ainsi que
master/origin sont intacts. Aucune opération commit, merge, reset ou push.
Docker contrôlé libre ; **aucune campagne moteur relancée** au cours de
cette réconciliation. Le vérificateur hôte réutilise uniquement les JSON,
bundles et traces moteur déjà figés :

```powershell
python -X utf8 sweeps/qualify_p2_p4_evidence_20261014.py
python -X utf8 -m unittest discover -s sweeps -p test_qualify_p2_p4_evidence_20261014.py -v
git diff --check
```

Sortie : `results/p2_p4_causal_closure_20261014.json`, **4/4 tests**.
L'outil vérifie les flags OFF dans les quatre difficultés, le nombre de
paires, le bundle identique du precheck H2, l'absence d'intervention H1,
les vraies evaluations H3 et les IC95 bootstrap. Refus d'ecraser sa propre
sortie, jamais d'ecriture dans les anciennes campagnes.

## Pistes économiquement justifiées et EFFECTIVEMENT essayées

| Hypothèse | Exposition / effet prévu | Mesure appariée à 5 ans | Décision |
|---|---|---|---|
| H1 — renfort flotte évinçant une nouvelle AIR immédiatement suivante plus rentable à tier égal | Malgré la compétition potentielle, **0** marque `P2_FLEET_AIR_DEFER` en 3 graines x5 ans | +49 418 £/an apparent, 2V/1D ; bootstrap [−72 204 ; +124 295] | Condition non exposée ; delta NON imputable ; STOP |
| H2 — recettes AIR observées, coûts prédits non réduits artificiellement avec le profit | Ratio mature non neutre ; A/A 2x2 byte-identique après retrait timestamps, bundle commun final | **−16 913 £/an**, 2V/3D ; bootstrap [−94 875 ; +63 109], valeur +1,382 % | Rejet/no gate : bruit/dispersion ; seed999 écart d'opcodes avant intervention |
| H3 — externalité POSITIVE de fréquence des hubs C121 | **9 475/18 148 cotations** de référence avec gain positif selon modèle, pas autant de projets ; max 230 353 £/an modélisé | **−109 433 £/an**, 3V/2D ; bootstrap [−405 956 ; +177 481], valeur −4,09 % | Rejet/no gate : pertes seed1234 −563 915 et seed5678 −476 259 |

Chaque politique a son **propre nouveau worktree V166**, flags OFF en
easy/medium/hard/custom, tests hôte et moteur, smoke, campagne appariée
et rapport complet :

- H1 `results/scores_p2_p4_fleet_opportunity_stage_20261014/docs/p2_p4_fleet_air_displacement_20261014.md`
- H2 `results/scores_p2_p4_net_revenue_stage_20261014/docs/p2_p4_net_revenue_experiment_20261014.md`
- H3 `results/scores_p2_p4_signed_hub_stage_20261014/docs/p2_p4_signed_hub_externality_20261014.md`

Les trois portes sont **non qualifiées**. Ne pas faire 40x5 ou holdout
avec un IC95 traversant zéro / sans action physique exposée. Aucune
« amélioration » déduite d'un gain apparent sans changement de choix.

## Autopsie des autres mécanismes : tri par occasion de gain net réel

### Priorité 1 — coûts physiques, marges et dépenses concurrentes

**Chaîne possible** : `devis finance` → classement du projet AIR →
un chantier RAIL ou flotte consomme du cash sous réserve de 25 k£ /
marge AIR 30 k£ → AIR différé. Le code V166 (`capital.nut:35–43`,
`projects_finance.nut:8–41`, `projects_selection.nut:1077–1205`,
`task_air.nut:684–778`) vérifie bien budget, devis et cash réel.

Exposition mesurée dans V165 et revue : en 1971 master dépense **2,13 M£**
hors AIR, dont **0,55 M£** quand meilleur AIR échoue uniquement sur marge
et **0,97 M£** marge+réserve. Mais **837/984** décisions ont le meilleur
AIR hors budget et les nouveaux AIR différés arrivent typiquement après
**14–20 jours**, rattrapés en 1972, quand le blocage disparaît. Ordre
de grandeur du gain limité à ~**10–50 k£/an** ; les essais sur réserve,
marge, quote physique et reselect ont déjà échoué à une porte :
`capital_quote_learning` A40x3 −106,8 k£/an IC95 entièrement négatif,
`air_site_cost_quote=1, margin=15 %` A40x3 −92,7 k£/an,
`air_efficiency_reselect` 5x6 −94,8 k£/an.

Autre exposition : 111/313 devis AIR devenus obsolètes mais **un seul
flip de décision finançable** identifié, sur les données précédentes ;
les devis RAIL sont réconciliés après A*. La baisse du devis ne démontre
pas l'amélioration de la ligne effectivement bâtie. **Pas de nouveau
réglage arbitraire du capital, pas de gate.**

**Dépenses hors portefeuille vérifiées séparément** : sur les deux
graines V166 du témoin physique de 60 mois
(`results/scores_p2_p4_save_baseline_stage_20261013/results/
scores_p2_p4_v166_physical_base2x5_r2_20261013.jsonl`), les relevés
retracent **95 services AIR, 18 RAIL, 5 ROAD**, dont changements de
taille de flotte observés dans **50 AIR, 3 RAIL, 0 ROAD**.
Les trois renforts RAIL peuvent être déclenchés hors portefeuille par
`scheduler_tasks.nut:1093-1104`, `task_rail.nut:729-735,811-920`.
Sur 161803 (juin–juillet 1972), la caisse passe de 117 467 à 49 848 £ ;
sur 314159, juillet–août de 287 150 à 186 762 £, puis octobre–novembre
de 82 532 à 76 059 £. Ce sont des **variations mensuelles de caisse**,
pas les factures exactes de ces trois renforts : plusieurs événements
peuvent affecter le solde entre checkpoints. Les YTD terminaux des
services concernés (23 606, 67 644, 14 310 £) ne donnent **pas** le
profit marginal du nouveau train. Aucun challenger viable et supérieur
au même tick n'est connu. Une interdiction globale du refleet serait
une nouvelle pénalité arbitraire, non une correction causale étayée.

### Priorité 2 — constructibilité effective et alternatives après veto

Chaîne possible : la tête de portefeuille échoue physiquement
(`BFAIL`, `TRKFAIL` ou A* pending), bloque la prochaine opportunité
finançable. L'audit V166 des 103 paires C77 identifiées dans une A/A
indique 75 dispatch, 57 constructeurs, 44 constructions,
10 RAIL différées. Parmi huit alternatives effectivement construites,
**quatre** arrivent déjà après échec de la tête AIR (une erreur
`siteB_unbuildable`, trois `BFAIL`) en 1–6 jours. La boucle V166
fait déjà ce fallback ; `task_projects.nut:1660–1674,1820–1883` ne
s'arrête pas simplement au premier refus AIR.

RAIL-only V166 : 285 tentatives, **216 bâties**, 69 échecs dont
42 `TRKFAIL` et 21 `ABND`. C'est un coût important, mais pas encore
une preuve que le projet alternatif était finançable, constructible
et plus rentable à ce tick. Anciennes variantes de sites, cap A* et
rail-origin ont déjà été étudiées : **pas de nouvel override prouvé**.

### Priorité 3 — marge nette et externalités du réseau

Les diagnostics P2 retiennent 43 nouvelles AIR strictes ayant une
comparaison exploitable, avec seulement **trois changements de tête**
sur environ 202 sélections et sans construction alternative prouvée
pour ces flips. Dans le réseau P4 apparié, 132/140 routes de même OD,
date de construction et nombre de véhicules ont des profits différents
au rapport 1974, dont AIR 121/122. Ce rapport décrit essentiellement
l'exercice 1973 et **ne contient PAS le profit marginal causal d'un
hub** ou d'une ligne fictive. H3 a précisément testé la contrepartie
positive des externalités déjà soustraites par C121 : elle est exposée
mais **pas rentable en moyenne** au cinq ans.

La boucle de flotte reste économiquement importante : en 1973–1979,
88–95 % des nouveaux chantiers ne créent plus de gare et ressemblent
à des achats de véhicules. Toutefois C69, C121, C80 et V161 gèrent
déjà l'arbitrage et le marginal de flotte ; les filtres C80/V105
et H1 ne prouvent aucun investissement substitut suffisamment meilleur.
Des prix ou pénalités inventés ne résoudraient pas cette absence de preuve.

L'ancien panel P4 5x5 avait 332/354 choix et 313/324 constructions,
mais **0/5 nouveaux couples origine-destination construits avant la
première divergence de trésorerie**. Une tête qui change après que les
mondes divergent ne constitue pas un contrefactuel au même cash : ne pas
attribuer a la variante de classement les écarts ultérieurs du réseau.
Dans le 5x5 H3, les premières differences textuelles, en écartant
le simple champ `applied=0/1` du log, concernent aussi des compteurs
`AIR_PLAN_PERF` de quelques opcodes selon la graine. Le signe terminal
ne suffit donc pas a démontrer la cause précise de chaque perte ; le
NO-GO est celui de la qualification, pas la preuve de l'effet marginal
d'une cotation unique.

**Autopsie quantitative des deux plus grosses pertes H3** (mêmes dix
journaux et JSONL du développement 5x5, aucun nouveau replay) :
seed1234 construit 55 AIR sous H3 contre 61 témoin, 35 renforts flotte
contre 45, 84 avions finaux contre 105, 37 aéroports contre 42,
et seulement 13 projets en 1974 contre 31 ; `profit_year` −563 915 £/an.
Seed5678 compte 61 vs62 constructions AIR, 46 vs66 renforts flotte,
106 vs126 avions, 8 vs16 trains, 10 vs48 projets en 1973,
`profit_year` −476 259 £/an. **Malgré cela le cash de H3 est PLUS
élevé** : seed5678 fin1973 3,303 M£ vs1,924 M£, fin1974 4,561 M£
vs3,711 M£. La perte ne se réduit donc pas à un blocage de caisse ;
un changement de selection, cadence ou constructibilité peut réduire
fortement les investissements effectifs malgré un score local majoré.
Ce n'est toujours pas la preuve causale du rendement de chaque projet
écarté.

L'autre limitation ne suffit pas à créer un nouveau levier chiffré :
`runway_scale < 1` n'apparait que dans 4/278 événements `C121_BUILD`
du témoin et 6/286 variante ; 95/278 présentent un hub delay de plus
d'un jour, sans exposition décisionnelle démontrée. Dans les dix logs
du 5x5 H3, zéro `[FLEET_PROJECT] replaced>0` : un filtre spécial de
renouvellement ne serait pas exercé ici. Aucun calibrage supplémentaire
de saturation/piste ou du remplacement ne peut être justifié par
ces seules statistiques.

## Limite de preuve actuelle — à NE PAS appeler épuisement universel

Ces trois changements comportementaux récents **ont été implémentés et
expérimentalement épuisés pour leur profil annoncé** ; les leviers
immédiats encore justifiés par les données (dévis, veto, cash, hub) ont
été audités contre les essais physiques conservés, avec classement
NO-GO lorsque l'exposition au choix rentable manque.

RESTENT OUVERTS : rendement marginal net d'un réseau comportant des hubs,
et gain d'une alternative choisie depuis le **même tick OpenTTD** avec
flotte/rivale/RNG/VM strictement contrôlés. Les sauvegardes mensuelles
P2/P4 d'anciennes campagnes n'encodent pas la pile de décision au
tick historique ; un fork mensuel dédié ghost-free reste une preuve
conditionnelle **depuis l'état rechargé**, pas le tick initial.

Un nouvel investissement comportemental est légitime seulement si une
occasion CONCRETE (capital, rang, head/challenger tous deux constructibles,
evenement physique) est identifiée dans les logs d'un monde dont les
A/A ne divergent pas avant l'intervention, puis si les mêmes sources
permettent un A/B de `profit_year` global terminal à cinq ans. Sans ce
contrôle, une variation de scheduling avant construction (déjà observée
sur C77 seed5678 et H2 seed999) peut être faussement imputée à une
ligne. **L'absence de candidat dans ces traces ne prouve pas
qu'OpexAI soit définitivement optimal.**
