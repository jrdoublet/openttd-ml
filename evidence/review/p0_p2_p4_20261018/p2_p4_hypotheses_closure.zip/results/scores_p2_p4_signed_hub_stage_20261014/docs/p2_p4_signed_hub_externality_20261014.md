# P2/P4 V166 — externalite positive des hubs AIR (14 octobre 2026)

## Piste economique distincte, OFF et rejetee

Troisieme nouvelle hypothese du cycle P2/P4 global, apres rejet du C77
RAIL→RAIL, de l'eviction de capital fleet→AIR non exposee et du recalage
net des recettes AIR. Prototype dans **un nouveau worktree detache**
`results/scores_p2_p4_signed_hub_stage_20261014` depuis V166
`7ecbabe8ff4154dfd62184a5d6d1e33db3bbccbf` ; aucun changement du
checkout principal, des autres stages ou de leurs modifications sales,
aucun commit, merge, reset ou push.

**Verdict : politique non qualifiee ; ne pas activer ni porter.**
Le score moyen terminal sur 5 graines x5 ans recule de
**109 432,8 GBP/an** ; 3 victoires / 2 defaites, mediane +98 613,
IC95 bootstrap **[-405 956 ; +177 481,4] GBP/an** et `company_value`
**-4,0901 %**. L'intervalle recouvre largement zero et deux enormes
pertes annulent les gains. Aucun 40x5 ni holdout justifie.

## Defaut de modele precis, intervention sans coefficients

`ai/OpexAI/air_economics_c121.nut` calcule deja le profit net d'une
nouvelle AIR en soustrayant sa cannibalisation sur les routes du hub.
Deux chemins `OpexC121AirEconomics` et `OpexC121OneOrTwoDepth`,
vers les lignes 785-825 et 1374-1409, imposent individuellement
`lostCargo=max(0, before-after)`. Lorsque plus de vols relevent la
note de gare et le fret conserve sur une route deja presente,
**le benefice externe positif** `after-before` est ecrase.

Sous le flag `c121_hub_signed_externality=1`, sans toucher aux pertes
historiques ni aux prix/couts physiques, la correction deduit une fois
du `cannibalLossAnnual` la somme des seuls gains positifs des routes
existantes, au meme tarif et avec le meme `realizationFactor` C121.
Ceci equivaut a une externalite signee mais garde les champs de
diagnostic `lostPax/ lostMail` non negatifs. Deux chemins modifies
symetriquement ; score et constructeur utilisent la meme economie.
Tous les coefficients C70/P2/P4 et les priorites/financements restent
inchanges. Flags `c121_hub_signed_externality=0` et
`c121_hub_signed_shadow=0` pour easy/medium/hard/custom. Pas de nouvel
etat persiste ; OFF ne penetre jamais le chemin du calcul alternatif.

## Qualite et exposition reelles

Ancienne exposition **structurelle** : `docs/air_marge_sonde_5x3_20261012.md`
rapportait 208 constructions AIR dont 77 hubsite et 84 hubhub, soit
**161/208 = 77,4 %** avec une gare reutilisee. Cela ne mesure pas
directement l'externalite positive et n'est pas un gain attribuable.

Nouvelle mesure sur **le meme bundle et avec shadow active dans les
deux bras** : logs moteur `C121_HUB_SIGNED exposure_year`. Pour les 5
graines x5 ans, la reference contient **18 148 evaluations economiques**
dont **9 475 cotations positives** ; la variante contient **17 487
evaluations**, dont **8 405 positives**. Par graine de la reference :

| Graine | Evaluations C121 | Cotations avec gain externe positif | Maximum annuel modele |
|---:|---:|---:|---:|
| 42 | 2 628 | 1 275 | 211 649 GBP |
| 100 | 2 614 | 1 324 | 185 412 GBP |
| 999 | 4 968 | 2 555 | 230 353 GBP |
| 1234 | 4 555 | 2 490 | 155 527 GBP |
| 5678 | 3 383 | 1 831 | 208 762 GBP |

Ces compteurs representent des **evaluations de candidats**, incluant
plusieurs profondeurs/moteurs d'un meme plan : **ne pas les appeler
9 475 lignes ou projets distincts**, ni transferer les maxima de modele
aux revenus reellement verses. Les changements physiques peuvent
alors expliquer que les comptes de la variante different des temoins ;
ils ne certifient pas la causalite d'un profit d'un projet individuel.

## Validation et resultats A/B

`sweeps/test_c121_hub_signed_20261014.py` **4/4**, tests C121 historiques
`test_c121_air_economics.py` **52/52**, `git diff --check` vert ;
smoke 2 graines x3 ans **4/4 parties moteur** sans erreur Squirrel.
Le smoke variant−reference **−125 939,5 GBP/an**, 0V/2D,
company_value −3,4772 % ; ne pas annoncer IC95 robuste avec deux graines.

Le developpement 5x5 a utilise EXACTEMENT le meme bundle moteur et code
que le smoke, SHA256
`de9a48fbb1255cc930dac545cb64914f88a69f31b73b5237240415cc617e9ca5`,
image `openttd-lab:latest` ID `f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659` ;
10CPU/10workers maximum, **10/10 parties, 5/5 paires** saines.

| Graine | Delta `profit_year` terminal | Delta `company_value` |
|---:|---:|---:|
| 42 | +138 224 GBP/an | -171 193 GBP |
| 100 | +98 613 GBP/an | -241 994 GBP |
| 999 | +256 173 GBP/an | +667 320 GBP |
| 1234 | **-563 915 GBP/an** | **-1 173 562 GBP** |
| 5678 | **-476 259 GBP/an** | -445 893 GBP |

Mean **−109 432,8 GBP/an**, bootstrap95
**[−405 956 ; +177 481,4]**, Student95
**[−581 999,76 ; +363 134,16]**, signe p=1,0, Wilcoxon p=0,8125,
valeur -4,0901 %. `diagnostic_only`, pas de signal economique robuste.

Ce candidat n'est ni une recalibration numerique P4, ni une resurrection
des filtres de flotte, ni une inversion C77. Son exposition est bien plus
frequente que H1, mais sa **profitabilite marginale globale n'est pas
etablie**. Ne pas extraire apres coup le sous-ensemble des 3 graines
positives pour en faire une politique.

Fichiers exacts :
`ai/OpexAI/{globals_pre,info,settings,air_economics_c121,task_report}.nut`,
`sweeps/test_c121_hub_signed_20261014.py`, recu
`results/p2_p4_signed_hub_dev5x5_20261014.json`, manifest, 10 logs `_engine`.
Ne pas relancer des campagnes anciennes/rejetees ni ouvrir 40x5 pour cela.
