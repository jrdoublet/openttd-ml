"""Contracts for C121 positive hub externality, experimental and OFF by default."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'ai' / 'OpexAI'


def read(name):
    return (ROOT / name).read_text(encoding='utf-8')


class SignedHubContracts(unittest.TestCase):
    def test_flags_off_four_difficulties(self):
        info = read('info.nut')
        for name in ('c121_hub_signed_externality', 'c121_hub_signed_shadow'):
            key = f'name = "{name}"'
            self.assertEqual(info.count(key), 1)
            entry = info[info.index(key):info.index(key) + 310]
            for difficulty in ('easy', 'medium', 'hard', 'custom'):
                self.assertRegex(entry, rf'{difficulty}_value\s*=\s*0')
        settings = read('settings.nut')
        self.assertIn('C121_HUB_SIGNED_PROFILE = C121_HUB_SIGNED_SHADOW || C121_HUB_SIGNED_EXTERNALITY;', settings)
        globals_ = read('globals_pre.nut')
        for name in ('C121_HUB_SIGNED_EXTERNALITY', 'C121_HUB_SIGNED_SHADOW'):
            self.assertIn(name + ' <- false;', globals_)

    def test_both_route_paths_count_and_gate_positive_only(self):
        src = read('air_economics_c121.nut')
        for statement in (
            'if (C121_HUB_SIGNED_PROFILE) {',
            'C121_HUB_SIGNED_EVALS++;',
            'if (signedGainAnnual > 0) {',
            'if (C121_HUB_SIGNED_EXTERNALITY) cannibalLossAnnual -= signedGainAnnual;',
            'existingPaxAfterA > existingPaxBeforeA',
            'existingPaxAfterB > existingPaxBeforeB',
            'existingMailAfterA > existingMailBeforeA',
            'existingMailAfterB > existingMailBeforeB',
        ):
            self.assertEqual(src.count(statement), 2, statement)
        self.assertEqual(src.count('local cannibalLossAnnual = rawCannibalLossAnnual > 0'), 2)

    def test_no_second_cost_penalty_and_report(self):
        src = read('air_economics_c121.nut')
        self.assertEqual(src.count('local revenueAnnual = revenuePaxAnnual + revenueMailAnnual - cannibalLossAnnual;'), 2)
        report = read('task_report.nut')
        self.assertIn('C121_HUB_SIGNED exposure_year=', report)
        self.assertIn('quote_evaluations=', report)
        self.assertIn('positive_quotes=', report)
        self.assertIn('C121_HUB_SIGNED_POSITIVE = 0;', report)

    def test_source_delimiters(self):
        for f in ('air_economics_c121.nut','globals_pre.nut','settings.nut','info.nut','task_report.nut'):
            s = read(f)
            s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
            s = re.sub(r'/\*.*?\*/|//[^\n]*', '', s, flags=re.S)
            for op,cl in (('{','}'),('(',')')):
                self.assertEqual(s.count(op), s.count(cl), f)


if __name__ == '__main__':
    unittest.main()
