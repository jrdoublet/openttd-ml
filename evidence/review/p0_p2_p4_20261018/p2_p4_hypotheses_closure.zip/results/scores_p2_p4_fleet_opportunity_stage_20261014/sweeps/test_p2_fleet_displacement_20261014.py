"""Host contracts for the strictly optional P2/P4 fleet-to-new-AIR substitution.

These contracts do not claim economic benefit; real OpenTTD A/B is required.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


class FleetAirDisplacementContracts(unittest.TestCase):
    def test_off_on_all_difficulties(self):
        info = source("info.nut")
        marker = 'name = "p2_fleet_air_displacement"'
        self.assertEqual(info.count(marker), 1)
        setting = info[info.index(marker):info.index(marker) + 350]
        for difficulty in ("easy", "medium", "hard", "custom"):
            self.assertRegex(setting, rf"{difficulty}_value\s*=\s*0")
        self.assertIn('P2_FLEET_AIR_DISPLACEMENT <- false;', source("globals_pre.nut"))
        self.assertIn('P2_FLEET_AIR_DISPLACEMENT = AIController.GetSetting("p2_fleet_air_displacement") != 0;', source("settings.nut"))

    def test_nonintrusive_off_and_no_coefficient(self):
        task = source("task_projects.nut")
        self.assertEqual(task.count("if (P2_FLEET_AIR_DISPLACEMENT && project.mode == \"fleet\")"), 1)
        block = task.split('if (P2_FLEET_AIR_DISPLACEMENT && project.mode == "fleet")', 1)[1]
        block = block.split("local r1r3BypassBefore", 1)[0]
        self.assertIn("OpexP2FleetAirDisplacement(", block)
        self.assertIn("continue;", block)
        self.assertIn("P2_FLEET_AIR_DEFER", block)
        self.assertLess(task.index("if (C75_MULTI_BUILD && (OpexC69AttemptKey(project) in c75BuiltKeys))"),
                        task.index("if (P2_FLEET_AIR_DISPLACEMENT && project.mode"))

    def test_strict_immediately_next_dominates_and_displaces(self):
        task = source("task_projects.nut")
        func = task.split("function OpexP2FleetAirDisplacement(", 1)[1].split("/* rail_origin_reuse", 1)[0]
        for check in (
            "builtCount != 0", "rank + 1 >= projects.best.len()",
            'next.mode != "air"', "!OpexAirBatchPlanStillLive(next.payload, lines)",
            "!opportunity.displaced", "opportunity.nextRank != rank + 1",
            "OpexProjectDefensiveAirPriority(project) != OpexProjectDefensiveAirPriority(next)",
            "next.profitAnnual <= project.profitAnnual", "next.roi <= project.roi",
        ):
            self.assertIn(check, func)
        self.assertNotRegex(func, r"\b(?:0\.\d+|1\.\d+)\b")

    def test_parentheses_braces_are_balanced(self):
        for name in ("info.nut", "settings.nut", "task_projects.nut", "globals_pre.nut"):
            text = source(name)
            text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
            text = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
            for opening, closing in (("{", "}"), ("(", ")")):
                self.assertEqual(text.count(opening), text.count(closing), name)


if __name__ == "__main__":
    unittest.main()
