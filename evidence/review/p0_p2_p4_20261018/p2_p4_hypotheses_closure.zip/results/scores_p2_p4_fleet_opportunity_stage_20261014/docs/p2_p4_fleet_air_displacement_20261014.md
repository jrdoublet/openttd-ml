# P2/P4 V166 — eviction de capital entre renfort AIR et nouvelle ligne

**14 octobre 2026, essai nouveau, PAS de qualification economique.** Worktree
detache sur V166 `7ecbabe8ff4154dfd62184a5d6d1e33db3bbccbf`.
Ne pas adopter, merger, committer ou pousser ce code avant un resultat A/B
reproductible. Aucun calibrateur C70, P2, P4 n'est modifie.

## Raison economique et preuve anterieure

`docs/air_p0_opportunity_20261009.md` du cycle precedent recoupe
117 renforts AIR dont 17 fenetres ou un profit de ligne diminue :
16 ont une nouvelle AIR derriere le renfort, 14 ont un profit brut predit
superieur et 12 un ratio profit/financement brut superieur. Cette observation
**n'identifie pas** une nouvelle route effectivement constructible ou une
eviction de caisse. Les resultats negatifs V105 (plancher de flotte) et
C77 rank2 interdisent de generaliser une suppression arbitraire de flotte.

## Hypothese et politique falsifiable

La variante ne differera une depense de renfort que si :

1. elle concerne la premiere opportunite de renfort C121 `c121FirstLive`,
   aucune ligne construite dans la passe ;
2. le projet immediatement suivant au portefeuille est une **nouvelle AIR**
   dont le plan est encore live ; les deux projets ont le meme tier defensif ;
3. la nouvelle AIR est individuellement financable aujourd'hui mais la
   somme des devis de la flotte et de cette AIR depasse le cash disponible ;
4. profit annuel **et** ROI predit AIR dominent strictement ceux du renfort.

Cette condition est un ordre partiel sans seuil magique ni correction des
coefficients C70/P2/P4. Elle ne garantit pas la faisabilite physique ou un
gain net des hubs. `P2_FLEET_AIR_DEFER` trace le rang, `lineId` de flotte,
les deux devis, cash, profits et ROI avant de continuer vers AIR.

Le flag `p2_fleet_air_displacement=0` pour easy/medium/hard/custom garde le
chemin V166 historique au defaut ; aucun sidecar n'est requis.

## Validation obtenue

- `python -X utf8 -m unittest discover -s sweeps -p
  test_p2_fleet_displacement_20261014.py -v` : **4/4 OK**.
- `python -X utf8 -m unittest discover -s sweeps -p
  test_c121_air_economics.py -q` : **52/52 OK**.
- `git diff --check` : OK.
- Image Docker de qualification deja connue : `openttd-lab:latest`, SHA
  `f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659`.

## Smoke moteur reel et extension d'exposition cinq ans

Commande depuis ce worktree :

```powershell
docker ps --format '{{.Names}} {{.Status}}'
python -X utf8 sweeps/run_c66_reference.py `
  --campaign p2_p4_fleet_displace_smoke2x3_20261014 `
  --container-name opex-p2p4-fleet-displace-smoke-r2 `
  --mount-root ../.. --years 3 --seeds 42 100 --repeats 1 `
  --policy-id fleet_historical `
  --reference 'OpexAI[p2_fleet_air_displacement=0]' `
  --variant 'OpexAI[p2_fleet_air_displacement=1]' `
  --variant-policy-id fleet_air_dominance `
  --primary-metric profit_year --decision-rule signs20 `
  --min-useful-primary-delta 0 --value-guard-max-loss-pct 5 `
  --max-workers 4 --cpus 4 --memory 6g --script-debug `
  --out results/p2_p4_fleet_displace_smoke2x3_20261014.json
```

Le 14 octobre vers 11 h 16, `docker run` est reste sans conteneur actif
visible, dans une phase Docker Desktop `stopping` ; `docker info` a egalement
mis plusieurs minutes a repondre. Le lanceur propre a cet essai a ete
interrompu, sans resultat moteur exploitable. Le redemarrage ordinaire
`docker desktop restart` a echoue en timeout, puis `docker desktop stop
--force --timeout 120` et `docker desktop start` ont retabli le moteur,
sans suppression des volumes ni des archives.

Le smoke relance a reussi **4/4 parties** : seeds 42/100, trois ans,
bundle `a01921034d6aacadee242cc131a3bc3894617ec67ac831fec0d50644168aef5e`.
OFF vs ON : `profit_year` moyen et `company_value` **identiques**, 0/2
occurrences de `P2_FLEET_AIR_DEFER` dans les logs ON.

Une extension distincte jusqu'a cinq ans sur les graines **42,100,999**
(`results/p2_p4_fleet_displace_exposure3x5_20261014.json`, meme bundle)
a donne **6/6 parties completes**, delta variant−reference `profit_year`
**+49 418,33 GBP/an**, mediane +96 164, 2V/1D,
IC95 Student [−70 827 ; +169 664], `company_value` +0,3275 %.
Mais les trois logs ON contiennent **zero `P2_FLEET_AIR_DEFER`**, donc
zero intervention physique correspondant a l'hypothese. La divergence
des trajectoires n'est **pas** attribuable a la garde. Ce gain apparent
ne qualifie ni sa causalite ni son adoption.

## Verdict local : condition non exposee, pas de gate

Hypothese stricte non exposee sur le panel teste. Pas de gate 40x5 ;
aucune adoption. Le faible nombre de graines ne prouve pas absence de
condition dans tous les mondes possibles, mais une variante non exercee
ne merite pas une nouvelle campagne de profit dans cette tranche.

Le programme P2/P4 GLOBAL n'est pas clos. La calibration des RECETTES vs
COUTS de nouveaux AIR demeure une seconde hypothese ouverte, differente du
facteur C70 applique actuellement au profit net ; les externalites de hubs
ne sont pas attribuables a partir des seuls profits YTD des lignes.
