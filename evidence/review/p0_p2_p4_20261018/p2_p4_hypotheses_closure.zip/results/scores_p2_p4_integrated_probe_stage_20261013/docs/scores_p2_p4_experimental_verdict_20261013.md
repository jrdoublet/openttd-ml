# OpexAI P2/P4 — qualification expérimentale complémentaire V166

**13 octobre 2026 — étude sur des bundles V166 gelés.** Le chantier a été
rouvert à la demande de l'utilisateur après la qualification indépendante P4
garde AIR négative. Le but est un gain robuste du `profit_year` terminal à cinq
ans, ou l'épuisement **expérimental** des mécanismes identifiables ; cette
étude n'est pas un simple inventaire des impossibilités.

## Propriété, isolation, méthodes

- `HEAD` V166 source `7ecbabe8ff4154dfd62184a5d6d1e33db3bbccbf`.
- Sonde sorties indépendante :
  `results/scores_p4_exits_probe_stage_20261013`.
- Sonde C77 indépendante :
  `results/scores_p2_p4_c77_probe_stage_20261013`.
- Intégration **contrôlée** de leurs seuls hunks puis correction ciblée AIR
  après crash : `results/scores_p2_p4_integrated_probe_stage_20261013`.
- Variante **politique** crash AIR seule (sans sondes) :
  `results/scores_p4_air_crash_only_stage_20261013`.
- Témoin physique avec archives mensuelles :
  `results/scores_p2_p4_save_baseline_stage_20261013`.

Toutes ces propriétés sont séparées du checkout principal, de `master`,
`origin/master`, de P1/V165, C77/V88, C121/R2/V161, du financement et des
stages antérieurs. Aucun commit, merge, reset ou push ; aucune modification de
valeur par défaut acceptée sans qualification.

### Codes et invariants

Trois réglages distincts, tous OFF easy/medium/hard/custom :

1. `score_p4_exits_probe` : collecte les profits des ventes **avant**
   `SellVehicle` seulement si vente effective, événement crash avec dernier
   C117 valable et son âge, remappage d'autoreplace, changement d'identités de
   flotte aux rapports, tombstone avant retrait de ligne. Ne prête aucune
   recette inventée à un avion déjà détruit ; inventaire borné.
2. `score_c77_chain_probe` : paire de candidats de même classe et
   simultanément finançables **après** sélection C77 définitive, sans score
   contrefactuel fabriqué ; trace choix, veto, dispatch, constructeur AIR/RAIL,
   A* RAIL différé, et `lineId` réel lorsqu'observé.
3. `score_p4_air_crash_only` : politique nouvelle et isolée qui réagit
   uniquement au crash confirmé d'une ligne AIR, via le refleet V166 existant
   respectant `AICompany.GetBankBalance >= price + OpexCashReserve()` ; aucun
   changement des retraites non rentables, scoring C70, prior, C77, taux ou
   financement.

Les fonctions `Save()/Load()` et leur schéma restent inchangés ; caches
de sondes transitoires réinitialisés après Load, donc la première comparaison
d'IDs post-Load est déclarée inconnue. **Un Save→Load réel ciblé a aussi été
effectué** : graine 314159, deux ans en phase A (25 sauvegardes), rechargement
de la sauvegarde du 1er janvier 1971 (12 gares, 25 véhicules), un an en phase B
(13 sauvegardes), présence positive de `LOAD_RECONCILE`, 64 gares et 92 véhicules
à l'issue de la reprise. Les 38 `.sav` ont été conservés dans
`results/scores_p2_p4_probe_save_load_artifacts_20261013/` et le rapport dans
`results/scores_p2_p4_probe_save_load_1x2_20261013.json`. Limite : ce
roundtrip OpexAI seule signale une compagnie humaine fantôme après chargement,
déjà connue du harness ; cela ne valide pas l'équivalence exacte des mondes
contre AAAHogEx. Les chemins
OFF conservent les appels de construction et de vente historiques ; des
gardes supplémentaires changent néanmoins le coût VM et ne doivent jamais
être présentées comme une équivalence d'opcodes bit à bit.

### Tests et smoke Squirrel

- Worktree intégré : **50 tests hôte verts** après composition des deux
  sondes et du crash-only ; `git diff --check` passé.
- Smoke réel `scores_p2_p4_probe_combo_smoke1x2_20261013` : un jeu V166
  de deux ans, complet ; aucune erreur Squirrel fatale. Le décodeur a observé
  **12 paires C77**, 12 dispatch, 12 retours, 9 constructeurs réussis,
  9 vetos explicitement relevés. Le smoke seul ne mesure aucun gain.

## Données physiques nouvelles — pas d'imputation des crashs

Le témoin `scores_p2_p4_v166_physical_base2x5_r2_20261013` a terminé
deux graines × cinq ans, **120 sauvegardes `.sav`** conservées et télémétrie
mensuelle par `VEHS/ORDL/ORDR/STNN`, **sans sonde dans l'IA**.
Bundle `0830cc935d72dd553a671e8a8d4d1c6eb5fec99fe864056a2713baa9f9c8c9c0`.

| Graine | Terminal `profit_year` | Terminal `company_value` | Avions disparus entre deux relevés |
|---|---:|---:|---:|
| 314159 | 2 040 094 £/an | 5 795 964 £ | 1 (VehicleID 67, juin→juillet 1973) |
| 161803 | 1 072 946 £/an | 3 369 219 £ | 1 (VehicleID 448, juillet→août 1973) |

Le dernier profit YTD connu des IDs est **19 810,402344 £** et
**2 805,765625 £**, respectivement, sans anomalie `unresolved_vehicles` aux
snapshots concernés. Ces deux ID ne sont pas la preuve suffisante de deux
crashes ; aucune archive mensuelle ne révèle à elle seule la cause ou le
profit final de sortie.

Le pilote A/A instrumenté ci-dessous a, en revanche, capté **un crash AIR
confirmé** : 22 mars 1971, line 1, vehicle 45, code de raison 3 ; dernier
échantillon C117 daté du 18 mars, profit YTD **20 502 £**, retard quatre
jours ; `final_profit_known=0`. Un `P4_EXITS_MISSING` ultérieur identifie
la même disparition au rapport annuel. Cela valide le lien sonde→événement
pour une exposition réelle, pas la récupération d'un profit inexistant.

## A/A et mesure de la perturbation des sondes

Bundle intégré des sondes `92d65a00ae2896713d200fa75ec5c545784f293c694e5794d842c3855bcb6a20`.

**A/A ON/ON**, `scores_p2_p4_probes_aa1x5_r2_20261013` : même
seed 314159, deux répétitions, cinq ans, 120 sauvegardes. Les **60/60
checkpoints** ont exactement les mêmes `profit_year`, `company_value`,
trésorerie, flotte, gares et `observed_opcodes_total`. Les **872 séquences
d'événements P4/C77** sont identiques entre répétitions (timestamps muraux
retirés). Par répétition, 103 `C77_CHAIN_PAIR`, 75 dispatch et retours,
57 constructeurs, 44 construits, **10 retours différés RAIL**, 34 vetos
explicites, 28 paires sans dispatch. Le résultat est **un A/A positif sur
une graine**, pas une preuve de déterminisme universel.

**Sondes OFF/ON**, `scores_p2_p4_probes_onoff2x5_20261013` : même bundle,
deux graines, cinq ans, quatre jeux complets, 240 saves physiques. Premier
écart de trésorerie dès **mai 1970 (314159)** et **septembre 1970 (161803)**.
Δ `profit_year` ON−OFF moyen **−108 623 £/an**, 1 victoire/1 défaite ;
ratio des moyennes de `company_value` **−11,045 %**. Ces écarts sont
des **perturbations de mesure/ordonnancement**, pas des bénéfices ou pertes
causales d'une politique P2/P4. L'égalité A/A ON/ON dans un même panel ne
contredit pas cette non-neutralité ON/OFF. Toute politique future doit donc
être comparée avec **sondes identiques dans les deux bras**, sur le même
bundle, tout en signalant que ce monde instrumenté peut différer du jeu OFF.

Deux journaux OFF/ON `probes_on` contiennent 123 et 96 épisodes C77 finançables,
avec respectivement 44 et 34 constructions attestées et 11 et 12 retours
différés. Une tête réellement admise **n'est jamais un rendement marginal
de l'alternative non construite**.

## Politique testée : réparation AIR sur crash uniquement

L'implémentation `score_p4_air_crash_only=1` réutilise uniquement le
constructeur de refleet déjà présent. Cela isole la **survivance** de la
politique C52 complète, qui mélange crash, retraites, etc. Les contrôles
fonctionnels ciblés et de cash passent (4 tests hôte).

Deux lots de développement **disjoints et de même bundle**
`ac2e49507fd88aef06a4f7268702d9fc4e5fcf520ef8dfecbc1a058c70b1eeec`
ont comparé OFF et ON sur 5 ans :

| Lot | Δ profit terminal moyen | Victoires / défaites |
|---|---:|---:|
| `scores_p4_air_crash_only_smoke2x5_20261013` | −14 503 £/an | 0/2 |
| `scores_p4_air_crash_only_new3x5_20261013` | +849 £/an | 1/2 |
| **Panel combiné 5 graines** | **−5 291,8 £/an** | **1/4** |

Médiane du panel **−28 393 £/an**, IC95 bootstrap de la moyenne
**[−81 137,8 ; +91 073,6] £/an** ; Δ moyen de `company_value`
**+61 687,8 £** et distribution très dispersée. La seule graine gagnante
est 987653 (**+170 718 £/an**) ; elle a sa première divergence de cash
en **septembre 1970**, avant que les effets tardifs sur flottes puissent
être identifiés. Quatre pertes (−28 393 ; −613 ; −42 610 ; −125 561)
neutralisent ce gain. **Aucune porte à 40×5 n'est justifiée.**

### Contrôle causal de l'exposition : sondes activées dans les deux bras

Le lot `scores_p2_p4_probe_crash_policy2x5_20261013`, bundle **unique**
`d34cd312a223682a2316c41aa919775f180dd8876da75ee5197e4cf06784f7c3`,
fait varier **uniquement** `score_p4_air_crash_only=0/1`, avec
`score_p4_exits_probe=1` et `score_c77_chain_probe=1` des deux côtés.
Quatre jeux 5 ans complets, 240 saves mensuels, source identique :

| Graine | Δ `profit_year` | Δ `company_value` | Première divergence monétaire |
|---|---:|---:|---|
| 314159 | −1 051 £/an | −135 638 £ | mai 1971 |
| 161803 | −108 568 £/an | −335 924 £ | décembre 1970 |
| **Moyenne** | **−54 809,5 £/an** | **−235 781 £** | — |

**0 victoire / 2 défaites**, `company_value` ratio des moyennes
**−5,6559 %** ; IC95 bootstrap du gain moyen rapporté par harness
[−160 174,2 ; +50 555,2] £/an. À ces faibles effectifs, l'IC n'est
ni une preuve d'impossibilité ni un critère suffisant de rejet à lui seul ;
le bilan défavorable, répété sur les cinq graines du pilote non instrumenté,
ne déclenche pas de 40×5.

Cette fois, les **deux premiers crashs sont exactement identiques dans
les deux politiques AVANT divergence** :

- Graine 314159 : **22 mars 1971**, ligne AIR 1, VehicleID 45,
  raison 3, dernier YTD 20 502 £ mesuré quatre jours avant.
  Le rapport suivant mesure **2 avions dans la variante**, avec un ID
  nouveau après disparition du 45, contre **1** dans la référence.
- Graine 161803 : **13 novembre 1970**, ligne AIR 0, VehicleID 12,
  raison 3, dernier YTD 77 980 £ mesuré deux jours avant.
  Le premier rapport après crash a un avion dans les deux bras, puis
  le rapport 1972 **2 dans la variante** contre **1 dans la référence**.

Le décodeur
`sweeps/analyse_p2_p4_crash_paired_trace_20261013.py` vérifie dans
chaque graine **5 paires C77 pré-crash strictement identiques** des
deux côtés. Après le crash, la première paire C77 a encore la même
tête/alternative mais est publiée **plus tard** :
314159, jour OpenTTD 720011 contre 720083 (+72 jours dans variante) ;
161803, 719901 contre 719933 (+32 jours). Les constructeurs physiques
réussis ou tentés avec un `C77_CHAIN_STEP` de type `constructor built`
divergent ensuite : **46 contre 38** sur 314159 et **34 contre 28**
sur 161803 (référence puis variante). Ce sont des chemins réellement
exposés par la correction, pas un effet de score P4 hypothétique ;
leur lien précis au `profit_year` marginal ne doit pas être surestimé.

Les relevés prouvent donc la **réparation effective** au moins pour
l'avion 45 et une divergence économique **postérieure à un même crash**,
mais pas un gain. Le refleet utilise du cash et modifie les trajectoires
d'achat et les choix ultérieurs du réseau ; le simple gain de véhicule
sur sa ligne ne peut être substitué au profit terminal du portefeuille.
L'intervention est classée **testée / non gagnante**, et non « non exposée ».

## Hypothèses restantes effectivement confrontées aux données

- **Sortants et vehicle-year** : vente explicite mesurable avant succès,
  crash exact non mesurable après invalidation ; dernier C117 borné par
  lag, cohortes de survivants sélectionnées. Après refleet ciblé négatif
  sur cinq graines, aucun facteur « correction des morts » sans imputation
  n'a de base économique testable sur les archives disponibles.
- **Transfert anciennes flottes→projets neufs** : AIR P4-vyear 311/546
  ligne-années acceptées, RAIL 35/81 ; facteurs historiques sur 76 lignes
  neuves moins erronés (0,194 contre 0,249), mais interventions voisines
  `fresh_equal`, `partial`, garde AIR et `stable-cohort` ont échoué ; pas
  de nouveau prior sûr ni d'intervention à exposer à un 40×5.
- **AIR/RAIL** : 10/15 publications RAIL couvertes, 1–7 lignes, six
  ratios plafonnés ; on n'a pas échantillonné un rendement différentiel
  de construction rail capable de soutenir un score RAIL distinct.
- **Hubs/net marginal** : l'audit descriptif matched historique trouvait
  110/150 profits différents au rapport 1973 et 132/140 au rapport 1974
  malgré même OD/date de construction/flotte au rapport. La nouvelle
  télémétrie mensuelle montre davantage de trajectoires mais reste
  dans **des mondes différents** entre politiques ; on ne peut attribuer
  aux hubs ni calculer le profit net de l'autre projet sans relecture
  contrefactuelle du même save **avant** la décision.
- **P2 froid** : sur 102 constructions précoces, 43 strictes (6 newpair,
  28 hubsite, 9 hubhub), 55 descriptives ; trois flips P2 dans 202
  décisions finançables mais **0/3 alternatives construites**. La
  censure MNAR et l'absence de saves du bundle P2 rendent une priorité
  économique calibrée froide non vérifiable au même état.

## Critère de réouverture et décision économique

Le seul protocole restant qui change la **qualité d'identification** :
save exactement **avant** un C77 final avec deux services de même classe
finançables, deux replays A/A du même monde, puis fork témoin / alternative
avec **instrumentation et opcodes identiques**. Relier `event → veto →
constructeur immédiat ou A* différé → lineId → flottes et autres lignes →
profits annuels complets → profit_year terminal`. Le harness mensuel
archive des `.sav` au premier jour du mois, **pas** le checkpoint
intra-tick juste avant un choix ; on ne doit pas vendre ces saves comme
équivalents à un fork exact. Il faudrait modifier le contrôle de la
simulation/sauvegarde pour permettre le point d'arrêt. Aucun coefficient
arbitraire n'est ajouté dans l'attente.

**Verdict limité aux hypothèses effectivement éprouvées :** la politique
crash-only (survivance) ne présente pas de gain terminal robuste ; les
sondes C77/sortants sont exécutables et exposées, mais perturbent la
trajectoire et ne reconstituent pas l'alternative non réalisée. Les
variantes historiques P3, stable, P4-vyear, fresh_equal, partial et garde
AIR **restent rejetées ou non qualifiées** selon leurs propres portes,
sans être relancées. Aucune intégration à V166 ni qualification 40×5
de cette correction négative. Cela **ne démontre pas** l'impossibilité
générale d'une amélioration économique ultérieure.
