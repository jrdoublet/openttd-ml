"""Reconcile two disjoint matched development batches for crash-only P4.

Both batches must have byte-identical source bundles and intervention settings.
This is a development report, not an independent holdout qualification.
"""
import argparse
import json
import random
import statistics
from pathlib import Path


def consolidate(paths):
    manifests = [json.loads(Path(path).read_text(encoding="utf8")) for path in paths]
    bundles = {item["source_bundle_sha256"] for item in manifests}
    if len(bundles) != 1:
        raise ValueError(f"mixed source bundle hashes: {bundles}")
    settings = [tuple(sorted((p["id"], tuple(sorted(p.get("settings", {}).items())))
                             for p in item["policies"])) for item in manifests]
    if settings[0] != settings[1]:
        raise ValueError("policy settings differ between batches")
    per_seed = {}
    for src, item in zip(paths, manifests):
        paired = Path(src).with_suffix(".jsonl")
        rows = {}
        for raw in paired.open(encoding="utf8"):
            d = json.loads(raw)
            r = d.get("run") or []
            if not r or r[0] != "OpexAI" or d.get("date") != "1974-12-01":
                continue
            rows.setdefault(int(r[1]), {})[d["duel_policy_id"]] = d
        for seed, arms in rows.items():
            if seed in per_seed:
                raise ValueError(f"seed repeated: {seed}")
            if set(arms) != {"crash_off", "crash_on"}:
                raise ValueError(f"missing arm for seed {seed}: {set(arms)}")
            per_seed[seed] = {key: arms["crash_on"][key] - arms["crash_off"][key]
                              for key in ("profit_year", "company_value", "money",
                                          "n_vehicles", "n_stations")}
    if len(per_seed) != 5:
        raise ValueError(f"expected five distinct seeds, got {len(per_seed)}")
    rng = random.Random(20261013)
    deltas = [v["profit_year"] for _, v in sorted(per_seed.items())]
    draws = sorted(statistics.mean(rng.choices(deltas, k=len(deltas))) for _ in range(20000))
    report = {
        "scope": "development only; not a causal crash event attribution or independent validation",
        "source_bundle_sha256": next(iter(bundles)),
        "seeds": sorted(per_seed),
        "per_seed_deltas": per_seed,
        "mean_profit_year_delta": statistics.mean(deltas),
        "median_profit_year_delta": statistics.median(deltas),
        "win_loss_tie": [sum(d > 0 for d in deltas), sum(d < 0 for d in deltas),
                         sum(d == 0 for d in deltas)],
        "bootstrap_mean_95": [draws[499], draws[19499]],
        "mean_company_value_delta": statistics.mean(v["company_value"] for v in per_seed.values()),
    }
    return report


def main():
    p = argparse.ArgumentParser()
    p.add_argument("batches", nargs=2, type=Path)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    data = consolidate(args.batches)
    args.out.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
    print(json.dumps(data, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
