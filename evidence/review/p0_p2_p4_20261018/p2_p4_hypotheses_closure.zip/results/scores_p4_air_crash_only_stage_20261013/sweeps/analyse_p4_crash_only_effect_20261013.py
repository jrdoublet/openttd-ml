"""Analyze new crash-only paired campaign, without attributing correlation.

Monthly first-divergence time is a falsification check: a divergence before
any documented crash does not support a crash-repair mechanism.
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path


FIELDS = ('money', 'profit_year', 'company_value', 'n_vehicles', 'n_stations')


def analyze(path):
    grouped = defaultdict(lambda: defaultdict(dict))
    for line in path.open(encoding='utf-8'):
        row = json.loads(line)
        run = row.get('run') or []
        if len(run) < 2 or run[0] != 'OpexAI':
            continue
        grouped[run[1]][row['duel_policy_id']][row['date']] = row
    result = {}
    for seed, arms in sorted(grouped.items()):
        if len(arms) != 2:
            continue
        labels = sorted(arms)
        off = arms['crash_off'] if 'crash_off' in arms else arms[labels[0]]
        on = arms['crash_on'] if 'crash_on' in arms else arms[labels[1]]
        dates = sorted(set(off) & set(on))
        first = {}
        for field in FIELDS:
            changed = [d for d in dates if off[d].get(field) != on[d].get(field)]
            first[field] = changed[0] if changed else None
        if not dates:
            raise ValueError(f'no shared dates for seed {seed}')
        end = dates[-1]
        result[str(seed)] = {
            'months_common': len(dates), 'last_date': end,
            'first_divergence': first,
            'terminal': {k: {'off': off[end].get(k), 'on': on[end].get(k),
                             'delta': (on[end][k] - off[end][k])
                             if isinstance(off[end].get(k), (int, float))
                             and isinstance(on[end].get(k), (int, float)) else None}
                         for k in FIELDS},
        }
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('jsonl', type=Path)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    result = analyze(args.jsonl)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf8')
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
