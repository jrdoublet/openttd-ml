"""P2/P4 revenue-minus-cost experimental contracts; engine economics need A/B."""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'ai' / 'OpexAI'


def read(name):
    return (ROOT / name).read_text(encoding='utf-8')


class RevenueNetCalibrationContracts(unittest.TestCase):
    def test_four_off_settings(self):
        info = read('info.nut')
        for key in ('name = "p2_air_net_revenue"', 'name = "p2_air_revenue_shadow"'):
            self.assertEqual(info.count(key), 1)
            desc = info[info.index(key):info.index(key) + 330]
            for difficulty in ('easy', 'medium', 'hard', 'custom'):
                self.assertRegex(desc, rf'{difficulty}_value\s*=\s*0')
        self.assertIn('P2_AIR_NET_REVENUE <- false;', read('globals_pre.nut'))
        self.assertIn('P2_AIR_REVENUE_PROFILE <- false;', read('globals_pre.nut'))
        self.assertIn('P2_AIR_REVENUE_SOURCE_EXECUTE <- false;', read('globals_pre.nut'))
        self.assertIn('P2_AIR_REVENUE_SOURCE_SHADOW <- false;', read('globals_pre.nut'))

    def test_revenue_observations_are_real_and_mature(self):
        report = read('task_report.nut')
        self.assertIn('year - line.year >= 2', report)
        self.assertIn('line.trains0 > 0 && vehCount > 0', report)
        self.assertIn('line.p2RevenueReal += currentRevenue.tofloat() * line.trains0 / vehCount;', report)
        self.assertIn('line.p2RevenuePred += line.predRevenue.tofloat();', report)
        self.assertIn('if (p2AirRevenueReport)', report)

    def test_profit_and_revenue_factors_are_distinct(self):
        models = read('projects_models.nut')
        start = models.index('function OpexP2RecomputeAirRevenueFactor')
        end = models.index('/* C121 :', start)
        factor = models[start:end]
        self.assertIn('line.p2RevenueReal.tofloat() / line.p2RevenuePred.tofloat()', factor)
        self.assertNotIn('c70Real', factor)
        self.assertIn('(ratioSum + 1.0) / (count + 1).tofloat()', factor)
        scoring = models[models.index('function OpexC70Profit'):models.index('function OpexC82Profit')]
        self.assertIn('P2_AIR_REVENUE_FACTOR * project.revenueAnnual', scoring)
        self.assertIn('project.revenueAnnual - project.profitAnnual', scoring)
        self.assertIn('local historical = project.profitAnnual * OpexC70Factor(project);', scoring)
        self.assertIn('if (P2_AIR_REVENUE_FACTOR == 1.0) return historical;', scoring)
        self.assertIn('return P2_AIR_NET_REVENUE ? alternative : historical;', scoring)
        self.assertIn('return project.profitAnnual * OpexC70Factor(project);', scoring)
        for guard in ('profitIsObserved', 'AIR_P0_DIRECT_REALIZATION_ACTIVE', 'project.mode == "fleet"'):
            self.assertIn(guard, scoring)

    def test_save_load_and_baseline_unchanged(self):
        persist = read('persist.nut')
        self.assertIn('if (P2_AIR_REVENUE_PROFILE) OpexP2RecomputeAirRevenueFactor(this._lines);', persist)
        self.assertIn('local serializableLine = clone line;', persist)
        setting = read('settings.nut')
        self.assertIn('AIController.GetSetting("p2_air_net_revenue") != 0 || P2_AIR_REVENUE_SOURCE_EXECUTE', setting)
        self.assertIn('AIController.GetSetting("p2_air_revenue_shadow") != 0 || P2_AIR_REVENUE_SOURCE_SHADOW', setting)
        self.assertLess(setting.index('C82_ENGINE_CALIBRATION = AIController.GetSetting'),
                        setting.index('P2_AIR_NET_REVENUE ='))
        self.assertIn('P2_AIR_REVENUE_FACTOR = 1.0;', setting)
        self.assertIn('P2_AIR_REVENUE_PROFILE = P2_AIR_REVENUE_SHADOW || P2_AIR_NET_REVENUE;', setting)

    def test_parenthesis_sanity(self):
        for name in ('settings.nut', 'info.nut', 'task_report.nut', 'persist.nut',
                     'projects_models.nut', 'globals_pre.nut'):
            s = read(name)
            s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
            s = re.sub(r'/\*.*?\*/|//[^\n]*', '', s, flags=re.S)
            for l, r in (('{', '}'), ('(', ')')):
                self.assertEqual(s.count(l), s.count(r), name)


if __name__ == '__main__':
    unittest.main()
