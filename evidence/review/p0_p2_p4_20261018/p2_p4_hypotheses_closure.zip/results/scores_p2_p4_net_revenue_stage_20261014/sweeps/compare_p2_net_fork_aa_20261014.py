"""Strict A/A offline comparison of raw monthly same-save fork outputs.

Reparse the SAV payloads; game-file hashes can differ for metadata even when
economic state is identical. First economic divergence blocks causal claims.
"""
import argparse
import json
from pathlib import Path


def snapshot(save):
    import openttdlab
    from bench_1v1_5y_20seeds import extract_company_record
    with save.open('rb') as handle:
        obj = openttdlab.parse_savegame(iter(lambda: handle.read(65536), b''))
    chunks = {k: v['records'] for k, v in obj['chunks'].items()}
    return {**{key: extract_company_record(chunks, owner, ['C77',owner], '1974-12-01')
               for owner, key in [(0,'opex'),(1,'aaa')]},
            'DATE': chunks['DATE']['0']}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--aa0', type=Path, required=True)
    p.add_argument('--aa1', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a=p.parse_args()
    files0={p.name:p for p in a.aa0.glob('*.sav')}
    files1={p.name:p for p in a.aa1.glob('*.sav')}
    if files0.keys()!=files1.keys():
        raise ValueError('A/A checkpoints differ')
    fields=('company_value','profit_year','money','current_loan',
            'n_vehicles','n_stations','performance_history')
    mismatches=[]
    first=[]
    for name in sorted(files0):
        one,two=snapshot(files0[name]),snapshot(files1[name])
        delta={}
        for owner in ('opex','aaa'):
            changes={key:[one[owner].get(key),two[owner].get(key)]
                     for key in fields if one[owner].get(key)!=two[owner].get(key)}
            if changes:delta[owner]=changes
        if one['DATE']!=two['DATE']:
            delta['DATE']='different date or tick data'
        if delta:
            mismatches.append({'file':name,'delta':delta})
            if len(first)<5:first.append(mismatches[-1])
    report={'checkpoint_count':len(files0),
            'economically_identical_AA':not bool(mismatches),
            'mismatched_checkpoints':len(mismatches),'first_mismatches':first}
    a.out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps(report,indent=2,ensure_ascii=False))


if __name__=='__main__':main()
