# OpexAI P2/P4 — calibration des recettes AIR et cout net (14 octobre 2026)

## Perimetre et decision

Travail exclusivement dans le worktree detache
`results/scores_p2_p4_net_revenue_stage_20261014`, base V166
`7ecbabe8ff4154dfd62184a5d6d1e33db3bbccbf`. Aucun commit, merge,
push ou transfert vers master. Les fichiers et worktrees precedents sont intacts.

**Verdict local : REJET / pas de promotion A40x5.** Le vrai A/B final a cinq
ans, avec parity d'opcodes avant effet sur deux graines, donne un delta
`profit_year` moyen **-16 912,6 GBP/an** (2 victoires, 3 defaites),
IC95 bootstrap **[-94 875 ; +63 108,6] GBP/an**, Student
**[-145 336,29 ; +111 511,09] GBP/an**. Pas de gain economique robuste ;
la non-divergence pre-traitement n'est pas garantie sur toutes les graines
(premier ecart mineur de compteur AAA en octobre 1971 sur seed999).
**Aucune adoption** et aucune justification de holdout.

## Hypothese nouvelle distincte de P4-vyear, C77 et C121

`ai/OpexAI/projects_models.nut:218-240` appliquait le facteur C70 de profit
observe/predit a la marge **nette** `project.profitAnnual`. Il est dangereux
d'en deduire le ratio des recettes : multiplier un benefice net par 0,4
revient a reduire de 60 % recettes **et** couts. Le projet C121 fournit deja
separement `revenueAnnual` R et `profitAnnual` P, donc les couts prevus
C = R - P.

La variante observe un ratio recettes reelles/predites pour les lignes AIR
matures (age >=2), ramene le realise a la flotte initiale comme C70,
cumule les ratios par ligne et reprend la seule pseudo-observation 1,0 deja
utilisee par C70 (pas de coefficient arbitraire). Sur projets AIR neufs,
`P_alt = k_revenue * R - (R - P)` ; le score historique reste intact
hors projet AIR neuf. Les exemptions `profitIsObserved`, correction C121
non neutre, et flotte C121/V161 sont conservees. Financement physique,
devis, couts de construction et tier C77 restent historiques.

Le flag `p2_air_net_revenue` est OFF sur easy/medium/hard/custom ;
`p2_air_revenue_shadow` egalement. Le second flag assure une meme collecte
sur OFF/ON lors du controle experimental. Les cumuls sur les lignes sont
reconstruits au Load via `OpexP2RecomputeAirRevenueFactor(this._lines)` ;
ceci est un **contrat code et tests hote**, pas un nouveau Save/Load moteur
avec 80 lignes (campagne interdite a relancer).

## Traces et progression des portes

Image `openttd-lab:latest` SHA256
`f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659` ;
une seule campagne Docker a la fois, jamais plus de 10 CPU/10 workers.
Tests hote : `test_p2_net_revenue_20261014.py` **5/5**,
`test_c121_air_economics.py` **52/52**,
`test_r2_fleet_profit_calibration.py` **6/6**,
`test_c69_reload_contract.py` **2/2**,
`test_air_p0_direct_realization_default.py` **4/4** ; `git diff --check` sain.

1. Smoke `p2_p4_net_revenue_smoke2x3_20261014` : 4/4 parties saines ;
   facteurs 1972 pour seed42/100 : **0,43306 / 0,44005**. Profit ON-OFF
   seed42 **-310 668**, seed100 **+343 640** : signal instable.
2. Premier dev5x5 `p2_p4_net_revenue_dev5x5_20261014`, bundle
   `eec136b6...` : **+86 069,2** GBP/an, 3V/2D, IC95 Student
   [-192 325 ; +364 464], valeur -0,3347 %. NON CAUSAL propre : collecte
   du facteur et opcodes differents entre bras des 1970.
3. Symmetric5x5 `p2_p4_net_revenue_symmetric5x5_20261014`, bundle
   `3feeccec...` : **+61 502,6**, 3V/2D, IC95 normal
   [-130 382 ; +253 387], valeur +0,6271 %. Mais le shadow collectait
   symetriquement sans evaluer le **meme scoring** entre bras : divergences
   avant premiere valeur du facteur.
4. Correctif purement experimental dans le meme stage : les bras calculent
   tous deux `historical` et `alternative`, **rendent obligatoirement
   historical si k_revenue==1**, ON seul choisit alternative ensuite.
   `p2_p4_net_revenue_precheck2x2_20261014` : **4/4 parties**, sorties
   moteur OFF/ON **byte-identiques apres retrait des timestamps du logger**
   pour graines42 et100 (4 850 / 3 362 lignes), meme profit et valeur.
5. Finale dev **`p2_p4_net_revenue_parity5x5_20261014`** avec le MEME
   bundle que le precheck, SHA256
   `aa11fd16691fd3b05ed1d1c89f87f562b9a631abc6f8a2e8fabc63d4eb275d86` :
   **10/10 parties saines**, 5/5 paires, reception `diagnostic_only`.

| Seed | Δ `profit_year` final ON-OFF | Δ `company_value` |
|---:|---:|---:|
| 42 | -136 613 | -432 747 |
| 100 | -60 743 | -11 335 |
| 999 | +81 621 | +730 744 |
| 1234 | -70 203 | +154 285 |
| 5678 | +101 375 | +46 720 |

Les premieres differences textuelles apres retrait du timestamp apparaissent
aux dates 1972-02-01 (seed42, adresses de pointeurs AAA, non significatives),
1972 pour 100/1234/5678, mais **1971-10-21 pour seed999**, une mesure
d'opcodes du rival `CheckBuildVehicle` 953 283 vs 953 319, avant rapport
non neutre. Cette difference peut relever des frontieres opcodes et interdit
d'imputer mecaniquement l'integralite du delta au score.

## Interdits et suivi du programme global

Cette variante **ne prouve ni une externalite de hub, ni une eviction de
nouvelle ligne effectivement plus rentable**, car les echantillons A/B
observent des mondes deja divergents (flottes, trains, reseau et concurrence).
Le resultat 5x5 ne satisfait pas le seuil de la porte 40x5. Ne pas
recalibrer le k C70/P2/P4 ni tester des coefficients arbitraires.

L'ancien C77 RAIL→RAIL et les politiques P3/P4 stable, P4 fresh_equal,
partial, vehicle-year et crash-only sont clos/rejetes ; ce verdict **ne
clot pas le programme economique P2/P4**. Les nouveaux leviers possibles
doivent d'abord prouver leur exposition, la constructibilite de l'alternative
et une causalite du gain terminal dans un monde sans compagnie fantome.
