# C77 same-save — Save/Load, override strict et rendement marginal

**Verdict au 14 octobre 2026** : mécanisme C77 opérationnel, substitution
strictement ciblée avec preuve physique et A/A court terme sans compagnie
parasite. **Aucun gain robuste terminal à cinq ans qualifié pour adoption.**
Résultats conservés dans ce worktree V166 `7ecbabe`, aucun commit/merge/push.

## Checkpoints, intégrité et épisode historique

Sources des saves : le bundle figé
`scores_p2_p4_probes_aa1x5_r2_20261013_bundle` du stage intégré P2/P4.
Vérification locale contre le manifeste : **73/73 fichiers OpexAI** et
**17/17 AAAHogEx** identiques. Sur la graine 314159, le checkpoint
`save/000000011.sav` du 1er janvier 1971 a SHA256
`6102c3df89a0631f984b5a2083c6d3808faea041d75c71b71c3af912aa3823e3`,
`DATE.tick_counter=28289`, OpexAI v7 slot0 et AAAHogEx-115 slot1.
La graine 161803 utilise son autre save Jan1971 SHA256
`e60cf0dcbb6418217f184d56d71baf4b0038ffa0c8895ed5d9e3cee0352b707d`.

`sweeps/c77_savefork_host_20261013.py` vérifie SHA du SAV,
sources/versions et quatre bibliothèques figées, copie les mêmes
octets trois fois (aa0/aa1/variant), reconstitue l'exécution depuis
`-g` sans nouveau `start_ai` et conserve les journaux, les saves et les
comptes physiques/financiers mensuels. Le contrat de fork est
**« même checkpoint mensuel puis replay »**, non un snapshot de pile
Squirrel juste avant C77.

**Contre-épreuve historique** : même les sources exactes du bundle
historique ne reproduisent pas le choix C77 du **2 janvier 1971**
(`event=719894:6788:4`) après Load ; la première paire de la reprise
apparaît vers le 16 janvier. La trace originelle ne doit donc jamais être
présentée comme un tick retrouvé. Preuves :
`results/c77_historical_exact_source_aa2m_20261014` et
`results/c77_historical_exact_source_dedicated2m_20261014`.

## Défaut de rechargement découvert puis contourné

Le mode `-vnull:ticks` crée à l'AfterLoad un **slot2 humain fantôme**
absent du save, avec cash initial 100 000 £, prêt 100 000 £,
aucun véhicule ni gare mais charges financières. OpenTTD15.3
`src/saveload/afterload.cpp` crée une compagnie humaine lorsqu'il n'y a
pas de réseau/joueur humain. Cette création change notamment RNG et le
monde. Les replays en null sont étiquetés `slots_valid=false` et
`diagnostic_only`, même lorsqu'ils reproduisent un même traitement.

**Remède testé en véritable OpenTTD** : `replay --dedicated`
remplace la vidéo null par `-D`, conserve les scripts mensuels,
ajoute `quit` après le dernier save et supprime la compagnie fantôme :
`valid_replay=true`, deux slots IA attendus et `LOAD_RECONCILE`
positif. Avec sources historiques exactes : **A/A 2/2 checkpoints
économiquement identiques** (`results/c77_historical_exact_source_dedicated2m_AA_20261014.json`).

## Causalité locale : fork sans fantôme, ligne différée construite

`results/c77_seed314159_dedicated4m_20261014` : même save hashé,
les mêmes deux sources IA dans les trois bras (deux compagnies après Load),
code C77 identique sauf **un bool source** `C77_REPLAY_SOURCE_EXECUTE`.
Les trois replays sont valides ; A/A **4/4 identiques**, même événement
et même cash/tier dans aa0,aa1,B :

- DATE 719937, HEAD RAIL pax `42818→48653`, ALT RAIL pax
  `13484→10210`; tier0, budget44 401, HEAD finance41 567,
  ALT finance40 559, cash62 670 £ au passage d'exécution.
- B : `force` unique puis recherche A* asynchrone, retours pending/rejected,
  **constructeur RAIL OK lineId8**, `deferred_return built`
  sur DATE719952. A/A : `eligible_shadow`, sans mutation de classement.
- Au checkpoint du 1er avril 1971, B−A : **cash −81 247 £,
  +4 véhicules, +3 gares**, `profit_year` publié inchangé (aucun
  exercice annuel mûr). La construction et son financement sont réels.
- `results/c77_seed314159_dedicated4m_analysis_20261014.json` :
  `qualification=conditional_same_save_causal`, A/A identique,
  aucune compagnie supplémentaire, aucune erreur moteur.

Il s'agit du résultat local le plus défendable : il démontre la chaîne
choix→constructeur→flotte/gares/cash. Il **ne démontre pas** encore un
surcroît de rentabilité à cinq ans.

## Deux fourches longues : gains conditionnels, non généralisables

Le harnais null a poursuivi trois bras identiques sauf le bool
d'exécution jusqu'au **1er janvier 1975** (49 checkpoints), ce qui
publie le `profit_year` 1974 complet plutôt que d'utiliser l'état
de décembre 1974 insuffisamment clos.

| Graine et reçus | A/A de cette réalisation | Substitution et ligne | Δ profit_year 1974 | Δ valeur |
|---|---|---|---:|---:|
| 314159, `results/c77_live_eligible_seed314159_terminal49m_analysis_20261014.json` | 49/49 | RAIL, ligne6 | **+181 618 £/an** | +417 815 £ |
| 161803, `results/c77_live_rail_rail_seed161803_terminal49m_analysis_20261014.json` | 49/49 | RAIL différé, ligne8 | **+173 456 £/an** | +535 703 £ |

**Caveats irréductibles de ces deux reçus** : slot2 fantôme dans tous
les bras ; condition de réutilisation d'une seule sauvegarde mensuelle,
pas tick C77 ; deux graines sélectionnées et non échantillon aléatoire
indépendant ; instabilité à long terme observée dans une répétition
précédente du *même* scenario 314159, où A/A était identique 24 mois
puis divergeait à janvier 1973 (24/48 checkpoints différents).
La variante de ce run 48m semblait +262 378 £/an vs aa0, mais son
témoin aa1 différait déjà de +80 760 £/an sans aucune intervention.
Ni les deux gains 49m ni leur moyenne ne constituent un IC95,
et ils ne peuvent pas être extrapolés à une règle générale.

## Externalités de hubs : décomposition, non attribution individuelle

`sweeps/analyse_c77_same_save_marginal_20261013.py` joint les
stations physiques et flottes des lignes de deux mondes ; il conserve
les profits YTD des véhicules et sépare lignes communes, perdues et
créées. Sur 314159 au terme de 49 checkpoints :
**81 lignes physiques de référence**, **72 variante**, seulement
**12 communes**, dont huit partageant une gare/hub du réseau observé.
Le total des écarts YTD des 12 lignes communes est d'environ
−84 705 £ (environ −78 214 £ pour huit lignes à hub).
Ce total **n'est pas** un rendement marginal causal d'un hub ; les
69 lignes exclusivement référence et 60 lignes exclusivement variante,
ainsi que les autres compagnies, les investissements reportés et le
cash, modifient toute la trajectoire. Seul le delta du profit global
dans un fork A/A stable permet une attribution au traitement one-shot.

## Généralisation réellement tentée et rejetée

Voir `results/scores_c77_rank2_policy_stage_20261014/docs/c77_rank2_policy_experiment_20261014.md`
(chemin relatif à la racine du dépôt).
Un nouveau stage détaché V166 avec flags OFF quatre difficultés et la
seule inversion de la première alternative de même tier a fait :
smoke AIR/RAIL 1×2 négatif, puis **RAIL→RAIL 5×5**
(bundle figé unique) : **Δ profit_year moyen −4 229,4 £/an,
2V/2D/1E, IC95 [−131 479 ; +123 020]**, Δ valeur −2,039 %.
Trois alternatives RAIL physiquement construites ; deux graines
n'ont pas exécuté l'override. Sur la graine 5678, −135 264 £/an
malgré `head_mismatch` sans force ni constructeur : effet de
scheduling/chemin non attribuable à une ligne forcée. Une campagne
témoin à deux répétitions chacune des cinq graines a donné les mêmes
résultats économiques sur les cinq paires A/A, sans toutefois
garantir l'identité entre deux bras de réglage différent.
**La porte 40×5 et le holdout indépendant ne sont pas déclenchés.**

## Décision

**Conserver les outils/sauvegardes pour preuve, ne pas adopter la
priorisation alternative C77**. Pas d'altération C70/P2/P4/C121/R2,
aucun coefficient arbitraire. Les hypothèses économiquement exposées
de substitution tête C77 AIR ou RAIL ont été **réellement testées** ;
elles n'ont produit aucun signal de politique général robuste.
De nouveaux tests ne seraient fondés qu'après identification
indépendante d'un mécanisme de rendement marginal net réseau,
et d'un contrôle d'ordonnancement/Save→Load à cinq ans sans fantôme.
Un échantillon petit ou une absence de significativité ne signifient
pas impossibilité générale d'améliorer OpexAI.

### Commandes reproductibles et garde-fous

`python -X utf8 -m unittest discover -s sweeps -p test_c77_savefork_host_20261013.py -v`
(runtime, tests hôte) ;
`python -X utf8 -m unittest discover -s sweeps -p test_c77_replay_20261013.py -v`
(stage source replay), `git diff --check`.
`sweeps/extend_c77_same_save_fork_20261014.py` n'écrit
qu'une **nouvelle destination** et re-vérifie tous les SHA ; les résultats
existants ne sont jamais écrasés. Aucune intégration automatique.

**Revalidation hôte du 14 octobre après reprise** : 9 tests Save→Load
réussissent, 1 échoue par `FileNotFoundError` d'une **archive externe** au
stage : `results/scores_p2_p4_integrated_probe_stage_20261013/results/
scores_p2_p4_probes_aa1x5_r2_20261013_engine/
both_probes_on_aa_seed314159_r0.log` (répertoire `_engine` absent).
Ce test d'attestation de l'épisode historique avait réussi avant la
disparition de l'archive. Le résultat ancien n'est pas invalidé par un
échec moteur, mais la suite ne peut plus être déclarée 10/10 verte
dans l'état présent. Aucun fichier externe n'a été recréé ou modifié.
Compilation du script d'extension, `git diff --check` et contrôle de
whitespace documentaire : OK.
