/* P4 exits — journal PASSIF, OFF par defaut. Aucun estimateur ou facteur C70.
 * L'etat de dedup est transient ; il n'entre jamais dans Save/Load.
 * Seules les ventes reussies donnent un profit exact AVANT disparition.
 * Un crash ne livre JAMAIS un profit final interrogable a l'evenement. */

function OpexP4ExitsDate()
{
  local d = AIDate.GetCurrentDate();
  return "year=" + AIDate.GetYear(d) + " date=" + d
      + " month=" + AIDate.GetMonth(d) + " day=" + AIDate.GetDayOfMonth(d);
}

/* Dedup d'evenements crash/autoreplace sur la meme date, plafonnee a 256
 * identifiants par an. Pas de scan du registre, pas de bruit quotidien. */
function OpexP4ExitsEventOnce(kind, vehicle, lineId, detail)
{
  if (!SCORE_P4_EXITS_PROBE) return;
  local d = AIDate.GetCurrentDate();
  local y = AIDate.GetYear(d);
  if (P4_EXITS_EVENT_YEAR != y) {
    P4_EXITS_EVENT_YEAR = y;
    P4_EXITS_EVENT_SEEN = {};
    P4_EXITS_EVENT_COUNT = 0;
  }
  local key = kind + "|" + vehicle + "|" + lineId + "|" + d;
  if (key in P4_EXITS_EVENT_SEEN) return;
  if (P4_EXITS_EVENT_COUNT >= 256) {
    if (P4_EXITS_EVENT_COUNT == 256) {
      AILog.Info("P4_EXITS_LIMIT " + OpexP4ExitsDate() + " kind=event max=256");
      P4_EXITS_EVENT_COUNT++;
    }
    return;
  }
  P4_EXITS_EVENT_SEEN.rawset(key, true);
  P4_EXITS_EVENT_COUNT++;
  AILog.Info("P4_EXITS_" + kind + " " + OpexP4ExitsDate()
      + " line=" + lineId + " vehicle=" + vehicle + " " + detail);
}

/* Une seule vente reelle. Capturer AVANT l'appel destructif, emettre APRES
 * succes seulement. Les echecs restent dans le jeu et ne sont pas des sorties.
 * Les ventes rollback en phase de construction sont etiquetees distinctement. */
function OpexP4ExitsSellVehicle(vehicle, line, reason)
{
  if (!SCORE_P4_EXITS_PROBE) return AIVehicle.SellVehicle(vehicle);
  local valid = AIVehicle.IsValidVehicle(vehicle);
  /* Les wagons seuls ne sont pas des vehicules primaires comptables. */
  local primary = valid && AIVehicle.IsPrimaryVehicle(vehicle);
  local thisProfit = primary ? AIVehicle.GetProfitThisYear(vehicle) : -1;
  local lastProfit = primary ? AIVehicle.GetProfitLastYear(vehicle) : -1;
  local ageDays = valid ? AIVehicle.GetAge(vehicle) : -1;
  local engine = valid ? AIVehicle.GetEngineType(vehicle) : -1;
  local success = AIVehicle.SellVehicle(vehicle);
  if (success) {
    local lineId = line != null && ("lineId" in line) ? line.lineId : -1;
    local mode = line != null && ("mode" in line) ? line.mode : "unknown";
    AILog.Info("P4_EXITS_SALE " + OpexP4ExitsDate()
        + " line=" + lineId + " mode=" + mode + " vehicle=" + vehicle
        + " reason=" + reason + " age_days=" + ageDays + " engine=" + engine
        + " primary=" + (primary ? 1 : 0)
        + " profit_this_ytd=" + thisProfit + " profit_last_full=" + lastProfit
        + " captured=pre_sell success=1");
  }
  return success;
}

function OpexP4ExitsCrash(vehicle, reason, line)
{
  if (!SCORE_P4_EXITS_PROBE) return;
  local sampleYear = -1, sampleDate = -1, sampleProfit = -1;
  local sampleAvailable = 0;
  /* C117 AIR uniquement, dernier YTD note AVANT l'evenement, eventuellement
   * plusieurs jours trop ancien. Ni GetProfitThisYear sur un ID deja detruit
   * ni imputation du restant d'exercice. */
  if (line != null && ("mode" in line) && line.mode == "air"
      && (vehicle in C117_AIR_VEHICLE_STATE)) {
    local sample = C117_AIR_VEHICLE_STATE[vehicle];
    if (sample != null && ("lineId" in sample) && sample.lineId == line.lineId) {
      sampleYear = ("profitYear" in sample) ? sample.profitYear : -1;
      sampleDate = ("lastDate" in sample) ? sample.lastDate : -1;
      sampleProfit = ("profitThisYear" in sample) ? sample.profitThisYear : -1;
      if (sampleYear >= 0 && sampleDate >= 0 && ("profitThisYear" in sample))
        sampleAvailable = 1;
    }
  }
  local lag = sampleAvailable ? AIDate.GetCurrentDate() - sampleDate : -1;
  OpexP4ExitsEventOnce("CRASH", vehicle, line != null ? line.lineId : -1,
      "reason=" + reason + " last_sample_year=" + sampleYear
      + " last_sample_date=" + sampleDate + " last_profit_this_ytd=" + sampleProfit
      + " last_sample_available=" + sampleAvailable + " last_sample_lag_days=" + lag
      + " last_sample_source=c117_air"
      + " final_profit_known=0");
}

function OpexP4ExitsAutoReplace(oldVehicle, newVehicle, line)
{
  if (!SCORE_P4_EXITS_PROBE) return;
  OpexP4ExitsEventOnce("AUTOREPLACE", oldVehicle,
      line != null ? line.lineId : -1,
      "replacement=" + newVehicle + " old_final_profit_known=0");
}

/* Plafond independant de la liste des crashes : les identifiants manquants
 * ne doivent pas monopoliser le VM pendant le rapport annuel. Le compteur
 * missing_ids sur P4_EXITS_FLEET reste complet, meme apres saturation. */
function OpexP4ExitsMissing(id, mode, year, vehicle, lastYear)
{
  if (P4_EXITS_MISSING_YEAR != year) {
    P4_EXITS_MISSING_YEAR = year;
    P4_EXITS_MISSING_COUNT = 0;
  }
  if (P4_EXITS_MISSING_COUNT >= 256) {
    if (P4_EXITS_MISSING_COUNT == 256) {
      AILog.Info("P4_EXITS_LIMIT " + OpexP4ExitsDate() + " kind=missing max=256");
      P4_EXITS_MISSING_COUNT++;
    }
    return;
  }
  P4_EXITS_MISSING_COUNT++;
  AILog.Info("P4_EXITS_MISSING " + OpexP4ExitsDate()
      + " exercise=" + (year - 1) + " line=" + id + " mode=" + mode
      + " vehicle=" + vehicle + " last_seen_report=" + lastYear
      + " cause=unknown final_profit_known=0");
}

/* Une ligne = au plus un log par exercice, jusqu'a 512 lignes. Comparaison
 * exacte des IDs uniquement sur flotte explicitement attribuee, au plus
 * 32 IDs ; hors de ces limites les variations restent UNKNOWN, jamais zero.
 * Etat perdu au Load, signale par previous_year=-1 (pas de faux match). */
function OpexP4ExitsReportLine(line, year, vehicles, vehicleType, currentCount)
{
  if (!SCORE_P4_EXITS_PROBE || line == null
      || !("lineId" in line) || !("mode" in line)) return;
  local id = line.lineId;
  local hasOld = id in P4_EXITS_FLEET_STATE;
  if (!hasOld && P4_EXITS_FLEET_STATE.len() >= 512) {
    if (P4_EXITS_FLEET_LIMIT_YEAR != year) {
      P4_EXITS_FLEET_LIMIT_YEAR = year;
      AILog.Info("P4_EXITS_LIMIT " + OpexP4ExitsDate() + " kind=fleet max=512");
    }
    return;
  }
  local prior = hasOld ? P4_EXITS_FLEET_STATE[id] : null;
  if (prior != null && prior.year == year) return;
  local owned = ("mode" in line) && line.mode != "road"
      && ("vehicles" in line) && line.vehicles != null;
  local ids = [];
  local full = owned;
  if (owned) {
    foreach (v in vehicles) {
      if (ids.len() >= 32) { full = false; break; }
      if (AIVehicle.IsValidVehicle(v) && AIVehicle.GetVehicleType(v) == vehicleType)
        ids.append(v);
    }
  }
  local added = -1, missing = -1;
  if (prior != null && prior.year == year - 1 && prior.full && full) {
    added = 0; missing = 0;
    /* Ensemble d'IDs : comparaison lineaire, pas N² en appels Squirrel. */
    local priorSet = {}, currentSet = {};
    foreach (v in prior.ids) priorSet.rawset(v, true);
    foreach (v in ids) currentSet.rawset(v, true);
    foreach (v in ids) if (!(v in priorSet)) added++;
    foreach (v in prior.ids) {
      if (!(v in currentSet)) {
        missing++;
        OpexP4ExitsMissing(id, line.mode, year, v, prior.year);
      }
    }
  }
  local metaCount = ("vehCount" in line) ? line.vehCount : -1;
  AILog.Info("P4_EXITS_FLEET " + OpexP4ExitsDate()
      + " exercise=" + (year - 1) + " line=" + id + " mode=" + line.mode
      + " built_year=" + (("year" in line) ? line.year : -1)
      + " n0=" + (("trains0" in line) ? line.trains0 : -1)
      + " last_report_count=" + (prior != null && prior.year == year - 1 ? prior.count : -1)
      + " metadata_count=" + metaCount + " current=" + currentCount
      + " added_ids=" + added + " missing_ids=" + missing
      + " ownership_complete=" + (full ? 1 : 0)
      + " previous_year=" + (prior != null ? prior.year : -1));
  if (hasOld || P4_EXITS_FLEET_STATE.len() < 512)
    P4_EXITS_FLEET_STATE.rawset(id,
        { year = year, count = currentCount, ids = ids, full = full });
}

function OpexP4ExitsRemovedLine(line, year, remaining, stuck)
{
  if (!SCORE_P4_EXITS_PROBE || line == null) return;
  local mode = ("mode" in line) ? line.mode : "unknown";
  AILog.Info("P4_EXITS_TOMBSTONE " + OpexP4ExitsDate()
      + " report_year=" + year + " line=" + line.lineId
      + " mode=" + mode + " built_year=" + (("year" in line) ? line.year : -1)
      + " remaining=" + remaining + " timeout=" + (stuck ? 1 : 0)
      + " last_report_profit=" + (("lastProfit" in line) ? line.lastProfit : -1)
      + " last_report_count=" + (("vehCount" in line) ? line.vehCount : -1)
      + " final_profit_known=0");
  if (line.lineId in P4_EXITS_FLEET_STATE) delete P4_EXITS_FLEET_STATE[line.lineId];
}
