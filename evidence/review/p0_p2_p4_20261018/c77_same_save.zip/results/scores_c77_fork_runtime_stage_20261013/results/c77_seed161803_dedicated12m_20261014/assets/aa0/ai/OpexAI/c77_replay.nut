/* Replay contrefactuel sur UN SEUL choix : deplace une alternative du TOP_K
 * deja selectionnee par C77. Aucun projet nouveau, aucun score change.
 * La source et le monde doivent etre geles par le banc, PAS par ce code.
 * Seed : le harness lance UNE seed et le fork de cette sauvegarde; NoAI
 * n'expose pas ici de seed runtime sure a faire passer pour une preuve. */

function OpexC77ReplayEnsureState()
{
  if (C77_REPLAY_STATE == null || C77_REPLAY_STATE.profile != C77_REPLAY_PROFILE) {
    C77_REPLAY_STATE = {
      profile = C77_REPLAY_PROFILE, month = -1, seen = {},
      episodes = 0, fired = false, status = "idle",
      event = "", head = "", alt = "", line = -1, lastSkip = "",
      armed = null
    };
  }
  return C77_REPLAY_STATE;
}

function OpexC77ReplayConfigurationValid()
{
  if (!C77_REPLAY_ENABLED || C77_REPLAY_CONFIG == null) return false;
  local c = C77_REPLAY_CONFIG;
  if (c.nth > 0 || c.nth == -1) return true;
  /* Exact mode: no accidental automatic replay on enable=1 only. */
  return c.year > 0 && c.month > 0 && c.day > 0
      && c.headMode > 0 && c.headKind > 0 && c.headCargo >= 0
      && c.headSrc > 0 && c.headDst > 0
      && c.altMode > 0 && c.altKind > 0 && c.altCargo >= 0
      && c.altSrc > 0 && c.altDst > 0;
}

function OpexC77ReplayKey(project)
{
  return OpexProjectAttemptKey(project);
}

function OpexC77ReplayTier(project)
{
  return OpexProjectDefensiveAirPriority(project)
      + (OpexProjectIsForcedChain(project) ? 1000 : 0);
}

function OpexC77ReplayMatches(project, head)
{
  local c = C77_REPLAY_CONFIG;
  local wantMode = head ? c.headMode : c.altMode;
  local wantKind = head ? c.headKind : c.altKind;
  local wantCargo = head ? c.headCargo : c.altCargo;
  local wantSrc = head ? c.headSrc : c.altSrc;
  local wantDst = head ? c.headDst : c.altDst;
  if (project == null || !("mode" in project)
      || (project.mode != "air" && project.mode != "rail")) return false;
  if (wantMode == 1 && project.mode != "air") return false;
  if (wantMode == 2 && project.mode != "rail") return false;
  if (wantKind == 1 && project.kind != "pax") return false;
  if (wantKind == 2 && project.kind != "freight") return false;
  if (wantCargo >= 0 && project.cargo != wantCargo) return false;
  if (wantSrc > 0 && project.src != wantSrc) return false;
  if (wantDst > 0 && project.dst != wantDst) return false;
  /* Not a replay of chain step1 / a forced project that builds two lines. */
  if (("isChain" in project) && project.isChain) return false;
  if (("payload" in project) && project.payload != null
      && ("isChain" in project.payload) && project.payload.isChain) return false;
  return true;
}

function OpexC77ReplayDateMatches(date)
{
  local c = C77_REPLAY_CONFIG;
  if (c.year > 0 && AIDate.GetYear(date) != c.year) return false;
  if (c.month > 0 && AIDate.GetMonth(date) != c.month) return false;
  if (c.day > 0 && AIDate.GetDayOfMonth(date) != c.day) return false;
  return true;
}

/* Devis du constructeur vivant : le budget C77 seul n'est pas un permis de
 * construire. Ce preflight est plus restrictif que le constructeur, jamais
 * moins. Tous ses appels sont sous le seul flag comportemental ON. */
function OpexC77ReplayLiveGate(ai, project, bank, available)
{
  if (!OpexCandidateStillValid(project, ai._lines, ai._abandonedPairs))
    return "stale_candidate";
  local finance = OpexProjectFinanceCapital(project);
  if (finance <= 0 || finance > available) return "finance";
  local candidate = project.payload;
  if (candidate == null) return "missing_payload";
  if (project.mode == "air") {
    if (OpexAirV92PairBlocked(ai._lines, candidate)) return "v92_pair";
    if (V133_AIR_BUILD_RETRY && OpexV133AirPlanBlocked(candidate)) return "air_quarantine";
    local freshA = !(("reuseA" in candidate) && candidate.reuseA);
    local freshB = !(("reuseB" in candidate) && candidate.reuseB);
    local nAirports = (freshA ? 1 : 0) + (freshB ? 1 : 0);
    local margin = OpexAirRequiredMargin(nAirports, candidate);
    local cost = ("capital" in candidate) ? candidate.capital
        : nAirports * candidate.airport.price + candidate.plane.price;
    if (bank < cost + OpexCashReserve() + margin) return "air_cash_margin";
    return null;
  }
  if (project.mode == "rail") {
    if (C121_AIR_FIRST_YEAR_RAIL_PREP && C121_CATALOG_FIRST_YEAR_ACTIVE)
      return "rail_prep_first_year";
    if (C80_RAIL_STOCK_GATE) {
      if (ai._railReadyStock == null) return "no_rail_stock";
      local pair = OpexProjectPairKey(candidate.kind, candidate.cargo,
                                     candidate.src, candidate.dst);
      if (!(pair in ai._railReadyStock)) return "no_rail_stock";
    }
    if (!OpexRailVehicleSlotAvailable()) return "rail_vehicle_limit";
    local close = ai._tooClose(candidate);
    if (close.hard >= 0 || close.blocking >= 0) return "rail_proximity";
    if (bank < candidate.capital + OpexCashReserve()) return "rail_cash";
    return null;
  }
  return "unsupported_mode";
}

function OpexC77ReplayLog(action, state, extra = "")
{
  if (!C77_REPLAY_ENABLED) return;
  AILog.Info("C77_REPLAY action=" + action + " event=" + state.event
      + " episode=" + state.episodes + " status=" + state.status
      + " head=" + state.head + " alt=" + state.alt
      + " line=" + state.line + " date=" + AIDate.GetCurrentDate()
      + " cash=" + AICompany.GetBankBalance(AICompany.COMPANY_SELF) + extra);
}

function OpexC77ReplaySkipOnce(state, reason, extra = "")
{
  local signature = "" + AIDate.GetCurrentDate() + ":" + reason;
  if (state.lastSkip == signature) return;
  state.lastSkip = signature;
  OpexC77ReplayLog("skip", state, " reason=" + reason + extra);
}

function OpexC77ReplayVeto(project, reason)
{
  if (!C77_REPLAY_ENABLED || C77_REPLAY_STATE == null || project == null
      || !("c77ReplayEvent" in project)
      || project.c77ReplayEvent != C77_REPLAY_STATE.event) return;
  C77_REPLAY_STATE.status = "rejected";
  OpexC77ReplayLog("veto", C77_REPLAY_STATE, " reason=" + reason);
}

/* Capturer LA DATE DU CLASSEMENT C77, car la tache projects peut n'executer
 * sa tete que le lendemain : exemple prouve le 23->24 mars 1971. Ce hook ne
 * change pas le classement et ne revalide pas des sites avant l'execution. */
function OpexC77ReplayObserveSelection(affordable, budget)
{
  if (!C77_REPLAY_ENABLED || !OpexC77ReplayConfigurationValid()) return;
  if (C77_REPLAY_CONFIG.nth == -1) return; // Live-executor fork, not a stale selection.
  local s = OpexC77ReplayEnsureState();
  if (s.fired || s.armed != null || affordable.len() < 2) return;
  local today = AIDate.GetCurrentDate();
  if (!OpexC77ReplayDateMatches(today)) return;
  local head = affordable[0];
  if (!OpexC77ReplayMatches(head, true)) return;
  local key = OpexC77ReplayKey(head);
  local tier = OpexC77ReplayTier(head);
  local headCap = OpexProjectFinanceCapital(head);
  if (headCap <= 0 || headCap > budget) return;
  for (local i = 1; i < affordable.len(); i++) {
    local alt = affordable[i];
    if (!OpexC77ReplayMatches(alt, false)) continue;
    if (OpexC77ReplayTier(alt) != tier) continue;
    local altKey = OpexC77ReplayKey(alt);
    if (altKey == key) continue;
    local altCap = OpexProjectFinanceCapital(alt);
    if (altCap <= 0 || altCap > budget) continue;
    local month = AIDate.GetYear(today) * 12 + AIDate.GetMonth(today);
    if (s.month != month) { s.month = month; s.seen = {}; }
    local sig = key + ">>" + altKey + "|" + tier;
    if (sig in s.seen) continue;
    s.seen.rawset(sig, true);
    s.episodes++;
    if (C77_REPLAY_CONFIG.nth > 0 && s.episodes != C77_REPLAY_CONFIG.nth)
      continue;
    s.armed = { head = key, alt = altKey, tier = tier, date = today,
                budget = budget, fromRank = i };
    s.status = "armed";
    s.head = key;
    s.alt = altKey;
    s.event = "" + today + ":" + AIController.GetTick() + ":" + s.episodes;
    OpexC77ReplayLog("armed", s, " tier=" + tier + " budget=" + budget
        + " head_finance=" + headCap + " alt_finance=" + altCap
        + " alternative_rank=" + i);
    return;
  }
}

/* Live executor fork: never force the historic selection when its HEAD has
 * already changed. Pick the first two simultaneously valid and funded
 * alternatives in the actual final C77 portfolio immediately before spending.
 * The same full live gates run in shadow and execute; only promotion differs. */
function OpexC77ReplayArmLive(ai)
{
  local s = OpexC77ReplayEnsureState();
  if (s.fired || s.armed != null || C77_REPLAY_CONFIG.nth != -1) return;
  local today = AIDate.GetCurrentDate();
  if (!OpexC77ReplayDateMatches(today)) return;
  if (ai._projects == null || ai._projects.best == null) return;
  local best = ai._projects.best;
  if (best.len() < 2) return;
  local head = best[0];
  if (!OpexC77ReplayMatches(head, true)) return;
  local cash = AICompany.GetBankBalance(AICompany.COMPANY_SELF);
  local available = OpexAvailableCapital();
  if (OpexC77ReplayLiveGate(ai, head, cash, available) != null) return;
  local tier = OpexC77ReplayTier(head);
  local headKey = OpexC77ReplayKey(head);
  for (local i = 1; i < best.len(); i++) {
    local alt = best[i];
    if (!OpexC77ReplayMatches(alt, false)) continue;
    if (OpexC77ReplayTier(alt) != tier) continue;
    local altKey = OpexC77ReplayKey(alt);
    if (altKey == headKey) continue;
    if (OpexC77ReplayLiveGate(ai, alt, cash, available) != null) continue;
    s.episodes++;
    s.armed = { head = headKey, alt = altKey, tier = tier,
                date = today, budget = available, fromRank = i };
    s.status = "armed";
    s.head = headKey;
    s.alt = altKey;
    s.event = "" + today + ":" + AIController.GetTick() + ":" + s.episodes;
    OpexC77ReplayLog("armed_live", s, " from_rank=" + i
        + " tier=" + tier + " available=" + available
        + " head_finance=" + OpexProjectFinanceCapital(head)
        + " alt_finance=" + OpexProjectFinanceCapital(alt));
    return;
  }
}

function OpexC77ReplayTryPriority(ai)
{
  if (!C77_REPLAY_ENABLED || !OpexC77ReplayConfigurationValid()) return false;
  local s = OpexC77ReplayEnsureState();
  if (s.fired || PORTFOLIO_MAX_BATCH != 1) return false;
  /* No early A* build, rail-stock worker or goods-chain second step may
   * consume capital before the promoted alternative. Refuse rather than
   * skip or cancel an existing construction. */
  if (ai._railSearch != null || ai._activeGoodsChain != null
      || (ai._activeWorker != null
          && (ai._activeWorker.kind == "rail_search"
              || ai._activeWorker.kind == "rail_stock"))) return false;
  if (s.armed == null && C77_REPLAY_CONFIG.nth == -1)
    OpexC77ReplayArmLive(ai);
  if (s.armed == null) return false;
  if (ai._projects == null || ai._projects.best == null
      || ai._projects.best.len() < 2) return false;
  local best = ai._projects.best;
  local head = best[0];
  if (!OpexC77ReplayMatches(head, true)
      || OpexC77ReplayKey(head) != s.armed.head) {
    OpexC77ReplaySkipOnce(s, "head_mismatch",
        " actual_head=" + OpexC77ReplayKey(head));
    s.fired = true;
    s.status = "skipped_head_mismatch";
    s.armed = null;
    return false;
  }
  local headKey = OpexC77ReplayKey(head);
  local tier = OpexC77ReplayTier(head);
  if (tier != s.armed.tier) {
    s.fired = true;
    s.status = "skipped_tier_changed";
    s.armed = null;
    OpexC77ReplayLog("skip", s, " reason=tier_changed");
    return false;
  }
  local available = OpexAvailableCapital();
  local bank = AICompany.GetBankBalance(AICompany.COMPANY_SELF);
  local headGate = OpexC77ReplayLiveGate(ai, head, bank, available);
  if (headGate != null) {
    OpexC77ReplaySkipOnce(s, "head_" + headGate);
    s.fired = true;
    s.status = "skipped_head_" + headGate;
    s.armed = null;
    return false;
  }
  local target = -1;
  local lastGate = "alternative_not_in_top";
  for (local i = 1; i < best.len(); i++) {
    local alt = best[i];
    if (!OpexC77ReplayMatches(alt, false)) continue;
    if (OpexC77ReplayTier(alt) != tier) {
      lastGate = "tier_mismatch";
      continue;
    }
    if (OpexC77ReplayKey(alt) != s.armed.alt) {
      lastGate = "alternative_changed";
      continue;
    }
    local altGate = OpexC77ReplayLiveGate(ai, alt, bank, available);
    if (altGate != null) {
      lastGate = "alt_" + altGate;
      continue;
    }
    target = i;
    break;
  }
  if (target < 0) {
    OpexC77ReplaySkipOnce(s, lastGate);
    s.fired = true;
    s.status = "skipped_" + lastGate;
    s.armed = null;
    return false;
  }
  local altProject = best[target];
  local altKey = OpexC77ReplayKey(altProject);
  /* Les DEUX bras de fork passent par les memes APIs, verifications et prix.
   * Seul execute=1 deplace physiquement ce projet APRES avoir constate
   * exactement le meme etat eligible. Zero coefficient modifie. */
  s.fired = true;
  s.status = C77_REPLAY_EXECUTE ? "promoted" : "eligible_shadow";
  s.head = headKey;
  s.alt = altKey;
  s.line = -1;
  s.armed = null;
  if (!C77_REPLAY_EXECUTE) {
    OpexC77ReplayLog("eligible_shadow", s, " from_rank=" + target
        + " tier=" + tier + " budget=" + available
        + " head_finance=" + OpexProjectFinanceCapital(head)
        + " alt_finance=" + OpexProjectFinanceCapital(altProject)
        + " head_score=" + head.fundScore + " alt_score=" + altProject.fundScore);
    return false;
  }
  /* Unique difference de politique du fork (le reste est natif). */
  altProject.rawset("c77ReplayEvent", s.event);
  altProject.payload.rawset("c77ReplayEvent", s.event);
  best.remove(target);
  best.insert(0, altProject);
  OpexC77ReplayLog("force", s, " from_rank=" + target
      + " tier=" + tier + " budget=" + available
      + " head_finance=" + OpexProjectFinanceCapital(head)
      + " alt_finance=" + OpexProjectFinanceCapital(altProject)
      + " head_score=" + head.fundScore + " alt_score=" + altProject.fundScore);
  return true;
}

function OpexC77ReplayResult(ai, project, result, rank, phase, discards = null, before = -1)
{
  if (!C77_REPLAY_ENABLED || C77_REPLAY_STATE == null || project == null
      || !("c77ReplayEvent" in project)
      || project.c77ReplayEvent != C77_REPLAY_STATE.event) return;
  local s = C77_REPLAY_STATE;
  local reason = ("reason" in result) ? result.reason : result.outcome;
  if (result.outcome == "built") {
    s.line = ai._nextLineId - 1;
    s.status = "built";
  } else if (result.outcome == "pending") {
    s.status = "rail_pending";
  } else if (result.outcome == "cash") {
    s.status = "rail_cash_wait";
  } else {
    s.status = "rejected";
    if (discards != null && before >= 0) {
      for (local j = before; j < discards.len(); j++) {
        local d = discards[j];
        if (d != null && d.rank == rank && d.mode == project.mode) {
          reason = d.reason;
          if (("detail" in d) && d.detail != "") reason += ":" + d.detail;
        }
      }
    }
  }
  OpexC77ReplayLog(phase, s, " outcome=" + result.outcome + " reason=" + reason
      + " rank=" + rank);
}

function OpexC77ReplayConstructor(ai, candidate, result, mode)
{
  if (!C77_REPLAY_ENABLED || C77_REPLAY_STATE == null || candidate == null
      || !("c77ReplayEvent" in candidate)
      || candidate.c77ReplayEvent != C77_REPLAY_STATE.event) return;
  local s = C77_REPLAY_STATE;
  local ok = result.ok;
  OpexC77ReplayLog("constructor", s, " mode=" + mode
      + " ok=" + (ok ? 1 : 0) + " reason=" + (("reason" in result) ? result.reason : "-")
      + " line=" + (ok ? ai._nextLineId : -1));
}

function OpexC77ReplayDeferred(ai, candidate, result)
{
  if (!C77_REPLAY_ENABLED || C77_REPLAY_STATE == null || candidate == null
      || !("c77ReplayEvent" in candidate)
      || candidate.c77ReplayEvent != C77_REPLAY_STATE.event) return;
  /* Rail payloads do not have mode; provide the minimal event shape. */
  local s = C77_REPLAY_STATE;
  if (result.outcome == "built") {
    s.line = ai._nextLineId - 1;
    s.status = "built";
  } else if (result.outcome == "cash") s.status = "rail_cash_wait";
  else s.status = "rail_failed";
  OpexC77ReplayLog("deferred_return", s,
      " outcome=" + result.outcome
      + " reason=" + (("reason" in result) ? result.reason : "-"));
}
