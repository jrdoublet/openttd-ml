# P2 — réconciliation de la population AIR réellement mature

**Audit complémentaire du 13 octobre 2026, sans nouveau Docker ni politique.**
L'analyse initiale de 57 lignes-années/43 lignes sous-entendait une
sélection fortement censurée. Les journaux du même bundle
`e9f750665f438d28f82a6e7cd93659a04472eedd4899ae6b6688289e2b708227`
permettent de préciser la nature de cette sélection sans supposer que les
projets exclus n'ont jamais réalisé de bénéfice.

## Couverture et comparabilité, strictement séparées

Sur cinq graines de développement, 281 `AIR_BUILD` : **32** en 1970,
**70** en 1971, **91** en 1972, **67** en 1973 et **21** en 1974.
Sur toutes les constructions, 193 lignes atteignent un exercice mature,
pour 327 lignes-années matures. Parmi les **102 lignes construites en
1970–1971**, **102/102** ont un `LINE_REVENUE` à âge >= 2 et un
`C121_BUILD.actual_amort` correspondant. La disparition de 59 objets du
calibrateur strict n'est donc **pas** une absence de résultat annuel.

| Famille | Construites en 1970–71 | Première cohorte stricte | Taux strict |
|---|---:|---:|---:|
| AIR newpair | 38 | 6 | 15,8 % |
| AIR hubsite | 54 | 28 | 51,9 % |
| AIR hubhub | 10 | 9 | 90,0 % |
| **Total** | **102** | **43** | **42,2 %** |

Parmi les 59 refus de comparabilité : **19** n'avaient pas de tête P2
enregistrée et **40** présentaient une mutation de flotte connue selon
la hiérarchie exclusive des motifs. Les journaux retrouvent néanmoins
pour **19/19** un `SCORE_COLD_P2_CAND` de même famille/OD/moteur/profit
brut, de **1 à 5 jours avant `AIR_BUILD`** : 12/19 gardent la flotte
initiale et n'ont pas de mutation connue. En les ajoutant à titre
**descriptif**, on obtient **55 lignes** : 8 newpair (4 graines),
38 hubsite (5 graines), 9 hubhub (2 graines). Il serait faux de
présenter leurs candidats comme une **tête C77 élue** ; le statut de
HEAD antérieur reste non vérifié pour ces 12 lignes.

Une estimation brute de rapport
`(profit_reel - actual_amort) / profit_prédit` sur ces 55 premières
années par ligne, médiane au sein des graines puis médiane entre
graines, donne **0,488422 newpair**, **0,409934 hubsite**, soit un
rapport relatif **1,19147**. Le bootstrap sur **20 000 tirages de
graines entières**, et non de lignes indépendantes, donne un intervalle
95 % **[0,581475 ; 1,635479]** pour ce rapport. La valeur 1 reste
à l'intérieur ; le signe de l'avantage relatif n'est pas établi.

Si l'on utilise les **102** constructions et un proxy
`N_initial/N_rapport` de correction des flottes de première année,
les médianes sont **0,370608 newpair** et **0,375652 hubsite**,
rapport **0,9866**, intervalle bootstrap par graine
**[0,729367 ; 1,327589]**. Ce proxy est **non causal** : il suppose
des revenus proportionnels au nombre final de véhicules et ignore la
date de chaque achat ou vente, les gains marginaux, la congestion et
la concurrence. Le changement de signe possible par rapport aux 55
montre précisément l'instabilité de cette calibration froide.

## Trajectoires physiques et limites du contrefactuel

La télémétrie existante fournit **100 snapshots** de duel
(1er décembre, 5 graines × 5 ans × 2 bras × 2 entreprises), dont 25
snapshots Opex du bras sonde. Les `station_ids` de `C121_BUILD` permettent
de relier **sans collision 102/102 lignes** au premier exercice mature.
**90/102** ont un snapshot en décembre de l'année précédente ; seuls
**28/102** gardent exactement tous les incumbents jusqu'au décembre
suivant avec profit individuel `GetProfitLastYear` vérifiable. Parmi
ces 28, le total rejoint `LINE_REVENUE` à **±2 £**, mais **25/28**
ont déjà deux appareils au lieu de N_initial=1 avant le début de
l'exercice : la linéarité du profit d'une ligne initiale n'est pas
identifiée. Répartition des 28 : 19 newpair, 9 hubsite, 0 hubhub.

Les trois flips LOSO P2 entre projets simultanément finançables restent
des **inversions de tête**, pas des achats alternatifs : aucune des trois
alternatives n'a été construite dans le témoin. Les manifests P2 indiquent
`retain_savegames=null` et JSON `retained_savegames=null` : **aucune
sauvegarde exploitable** de ces trois états de décision n'est disponible
pour un replay constructeur dans le même monde. Les archives P4 matched
(`01f22c...`) et P4 flip (`a21a67...`) sont de **bundles différents**
de P2 ; les cinq graines communes ne suffisent pas à construire un
P2×P4 causal apparié.

## Verdict

Le calibrateur P2 initial manque des observations comparables à cause des
renforts et de la preuve d'élection, **non** faute de données de profits.
L'élargissement de 43 à 55 puis aux 102 révèle une **sensibilité au
choix du dénominateur**, pas une convergence vers un coefficient froid.
Il n'y a donc pas de multiplicateur à estimer légitimement pour les
trois familles, ni d'interaction P2/P4 à qualifier en 40×5.

**Sources conservées, non modifiées :**
`results/scores_p2_stage_20261013/results/scores_p2_dev5x5_20261013_execution_analysis.json`,
`scores_p2_dev5x5_20261013.json`, manifest et cinq fichiers
`scores_p2_shadow_seed*_r0.log` dans `_engine` ; analyseurs existants
`sweeps/analyse_score_cold_execution_p2.py`,
`sweeps/analyse_p2_recal_oos_20261013.py`, et
`docs/p2_recal_oos_resultats_20261013.json`. Les recomptages
complémentaires ont été effectués en lecture seule sur ces fichiers ;
ils ne constituent pas un nouvel essai moteur ni une qualification
statistique indépendante.
