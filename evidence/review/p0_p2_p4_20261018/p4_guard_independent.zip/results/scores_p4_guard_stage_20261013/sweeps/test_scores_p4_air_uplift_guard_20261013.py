"""Small P4-vyear AIR guard behavioral invariants; no engine dependency."""

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


class P4AirUpliftGuard(unittest.TestCase):
    def test_setting_is_off_at_all_difficulties(self):
        info = (ROOT / "info.nut").read_text(encoding="utf8")
        s = info.split('name = "score_c70_vyear_air_uplift_guard"', 1)[1].split("});", 1)[0]
        for key in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertRegex(s, rf"\b{key}\s*=\s*0\b")

    def test_only_vyear_policy_and_c70(self):
        settings = (ROOT / "settings.nut").read_text(encoding="utf8")
        self.assertIn('AIController.GetSetting("score_c70_vyear_air_uplift_guard") != 0', settings)
        self.assertRegex(settings, r"SCORE_C70_VYEAR_AIR_UPLIFT_GUARD\s*=.*\n\s*&& SCORE_C70_VYEAR_COHORT && C70_MODE_CALIBRATION")

    def test_cap_only_applies_to_air_positive_uplift(self):
        source = (ROOT / "projects_models.nut").read_text(encoding="utf8")
        cap = "if (SCORE_C70_VYEAR_AIR_UPLIFT_GUARD && mode == \"air\" && effectiveK > legacyK)"
        self.assertIn(cap, source)
        self.assertIn("effectiveK = legacyK;", source.split(cap, 1)[1].split(";", 1)[0] + ";")
        self.assertLess(source.index(cap), source.index("C70_MODE_FACTOR[mode] = (SCORE_C70_VYEAR_COHORT ? effectiveK : legacyK)"))

    def test_mathematical_guard_does_not_invent_gain(self):
        def guard(current, historic, mode, enabled):
            return min(current, historic) if enabled and mode == "air" else current

        for legacy, vyear in ((0.42, 0.53), (0.7, 0.5), (1.0, 1.0), (0.0, 0.2), (-0.2, 0.1)):
            self.assertEqual(guard(vyear, legacy, "air", True), min(vyear, legacy))
            self.assertEqual(guard(vyear, legacy, "rail", True), vyear)
            self.assertEqual(guard(vyear, legacy, "air", False), vyear)

    def test_no_save_schema_or_budget_change(self):
        persist = (ROOT / "persist.nut").read_text(encoding="utf8")
        self.assertIn("OpexSaveProjectLineVYear", persist)
        self.assertIn("p4Adjust", persist)
        self.assertNotIn("score_c70_vyear_air_uplift_guard", persist)


if __name__ == "__main__":
    unittest.main()
