#!/usr/bin/env python3
"""Independent, host-only receipt for frozen P4 AIR-guard development/gate runs.

Recomputes the terminal outcome directly from monthly JSONL checkpoints,
not from the campaign's policy_comparison aggregates. Does not start Docker.
"""

import argparse
import collections
import hashlib
import json
import pathlib
import statistics


CAMPAIGNS = (
    "scores_p4_guard_vs_history_dev5x5_20261013",
    "scores_p4_guard_gateA40x5_20261013",
)
SAME_SETTING_KEYS = (
    "c82_engine_calibration", "decision_log", "save_full_state",
    "score_c70_cohort_probe", "score_c70_vyear_measure_shadow",
)


def receipt(folder, name):
    folder = pathlib.Path(folder)
    payload = json.loads((folder / (name + ".json")).read_text(encoding="utf-8"))
    manifest = folder / (name + ".manifest.json")
    digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
    assert digest == payload["manifest_sha256"], f"manifest hash mismatch: {name}"
    assert payload["campaign_id"] == name
    assert payload["years"] == 5 and payload["repeats"] == 1
    assert not payload["failed_runs"]
    policies = {x["role"]: x for x in payload["policies"]}
    assert set(policies) == {"reference", "variant"}
    settings = {role: dict(policy["explicit_settings"])
                for role, policy in policies.items()}
    expected_keys = set(SAME_SETTING_KEYS) | {
        "score_c70_vyear_cohort", "score_c70_vyear_air_uplift_guard"}
    assert set(settings["reference"]) == set(settings["variant"]) == expected_keys
    for key in SAME_SETTING_KEYS:
        assert settings["reference"][key] == settings["variant"][key], (name, key)
    assert {key: settings["reference"][key] for key in SAME_SETTING_KEYS} == {
        "c82_engine_calibration": 0, "decision_log": 0,
        "save_full_state": 1, "score_c70_cohort_probe": 0,
        "score_c70_vyear_measure_shadow": 0,
    }
    assert settings["reference"]["score_c70_vyear_cohort"] == 0
    assert settings["reference"]["score_c70_vyear_air_uplift_guard"] == 0
    assert settings["variant"]["score_c70_vyear_cohort"] == 1
    assert settings["variant"]["score_c70_vyear_air_uplift_guard"] == 1

    seeds = [int(x) for x in payload["seeds"]]
    assert len(seeds) == len(set(seeds))
    assert len(payload["games"]) == 2 * len(seeds)
    assert all(game["game_ok"] and game["game_status"] == "complete"
               and not game["unattributed_errors"]
               and game["source_bundle_sha256"] == payload["source_bundle_sha256"]
               for game in payload["games"])
    counts = collections.Counter()
    first_money = {}
    prev_money = {}
    terminals = {}
    with (folder / (name + ".jsonl")).open(encoding="utf-8") as stream:
        for raw in stream:
            row = json.loads(raw)
            if row.get("run", [None])[0] != "OpexAI":
                continue
            key = (row["policy_id"], int(row["run"][1]))
            assert row["source_bundle_sha256"] == payload["source_bundle_sha256"]
            counts[key] += 1
            if row["date"] == "1974-12-01":
                assert key not in terminals
                assert row["profit_year_quarters_valid"] == 4
                terminals[key] = row
            prev_money[(key[1], key[0], row["date"])] = row.get("money")
    ref = policies["reference"]["id"]
    var = policies["variant"]["id"]
    assert len(terminals) == 2 * len(seeds)
    assert all(counts[(role, seed)] == 60
               for seed in seeds for role in (ref, var))
    deltas = []
    cv_ref = cv_var = 0
    vehicle_deltas = station_deltas = build_sign_deltas = opcode_sign_deltas = 0
    for seed in seeds:
        a, b = terminals[(ref, seed)], terminals[(var, seed)]
        deltas.append((seed, b["profit_year"] - a["profit_year"]))
        cv_ref += a["company_value"]
        cv_var += b["company_value"]
        vehicle_deltas += b["n_vehicles"] - a["n_vehicles"]
        station_deltas += b["n_stations"] - a["n_stations"]
        build_sign_deltas += b.get("project_builds_sign_total", 0) - a.get("project_builds_sign_total", 0)
        opcode_sign_deltas += b.get("observed_opcodes_total", 0) - a.get("observed_opcodes_total", 0)
        dates = sorted(date for s, role, date in prev_money if s == seed and role == ref)
        assert len(dates) == 60
        first_money[seed] = next((date for date in dates
            if prev_money[(seed, ref, date)] != prev_money[(seed, var, date)]), None)

    observed = [difference for _, difference in deltas]
    published = payload["policy_comparison"]
    metric = published["aggregates"]["profit_year"]["policy_delta"]
    assert published["complete_pairs"] == len(seeds) and published["comparison_complete"]
    assert abs(statistics.mean(observed) - metric["mean"]) < 0.000001
    assert metric["wins"] == sum(x > 0 for x in observed)
    assert metric["losses"] == sum(x < 0 for x in observed)
    assert metric["ties"] == sum(x == 0 for x in observed)
    ratio = cv_var / cv_ref
    assert abs(ratio - published["aggregates"]["company_value"]["policy_ratio"]["ratio_of_means"]) < 0.000001
    return {
        "campaign": name,
        "bundle": payload["source_bundle_sha256"],
        "manifest_sha256_verified": digest,
        "complete_seed_pairs": len(seeds),
        "complete_games": len(payload["games"]),
        "checkpoints_per_opex_policy_seed": 60,
        "reference_flags": settings["reference"],
        "variant_flags": settings["variant"],
        "seeds": seeds,
        "profit_year_mean_delta": statistics.mean(observed),
        "profit_year_median_delta": statistics.median(observed),
        "wins": sum(x > 0 for x in observed),
        "losses": sum(x < 0 for x in observed),
        "ties": sum(x == 0 for x in observed),
        "bootstrap_ci95_reported": metric["mean_bootstrap_95pct_ci"],
        "wilcoxon_p_reported": metric["wilcoxon_p"],
        "company_value_change_pct": 100 * (ratio - 1),
        "sum_vehicle_delta": vehicle_deltas,
        "sum_station_delta": station_deltas,
        "sum_build_sign_delta": build_sign_deltas,
        "sum_observed_opcode_sign_delta": opcode_sign_deltas,
        "first_money_difference_pre_1972": [seed for seed, date in first_money.items()
                                              if date is not None and date < "1972-01-01"],
        "first_money_difference_year_counts": dict(sorted(collections.Counter(
            date[:4] if date else "identical" for date in first_money.values()).items())),
        "largest_losses": sorted(deltas, key=lambda pair: pair[1])[:5],
        "largest_wins": sorted(deltas, key=lambda pair: pair[1], reverse=True)[:5],
        "harness_verdict": published["verdict"],
    }


def verify(folder):
    results = [receipt(folder, name) for name in CAMPAIGNS]
    assert results[0]["bundle"] == results[1]["bundle"]
    assert not (set(results[0]["seeds"]) & set(results[1]["seeds"]))
    assert results[0]["complete_seed_pairs"] == 5
    assert results[1]["complete_seed_pairs"] == 40
    assert results[0]["reference_flags"] == results[1]["reference_flags"]
    assert results[0]["variant_flags"] == results[1]["variant_flags"]
    return {"method": "terminal checkpoint audit independent of harness policy delta;"
            " positive/negative sample disjoint; all settings, manifests and bundle verified",
            "campaigns": results, "decision": "reject P4 AIR uplift guard"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_folder", type=pathlib.Path)
    parser.add_argument("--out", type=pathlib.Path)
    args = parser.parse_args()
    report = verify(args.result_folder)
    output = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        args.out.write_text(output, encoding="utf-8")
    else:
        print(output)


if __name__ == "__main__":
    main()
