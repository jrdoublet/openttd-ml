"""Evidence contracts for the archived, disjoint P4 guard 5x5 and 40x5."""

from pathlib import Path
import unittest

from sweeps.verify_p4_guard_gate_20261013 import verify


class GuardEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = verify(Path(__file__).resolve().parent.parent / "results")

    def test_pilot_and_gate_are_distinct_and_reproduce_outcome(self):
        pilot, gate = self.report["campaigns"]
        self.assertEqual((pilot["wins"], pilot["losses"], pilot["ties"]), (5, 0, 0))
        self.assertEqual((gate["wins"], gate["losses"], gate["ties"]), (14, 25, 1))
        self.assertAlmostEqual(pilot["profit_year_mean_delta"], 68191.8)
        self.assertAlmostEqual(gate["profit_year_mean_delta"], -52352.375)
        self.assertGreater(pilot["bootstrap_ci95_reported"][0], 0)
        self.assertLess(gate["bootstrap_ci95_reported"][1], 0)

    def test_all_months_hashes_identical_settings_and_pre_factor_noise(self):
        pilot, gate = self.report["campaigns"]
        self.assertEqual(pilot["bundle"], gate["bundle"])
        self.assertEqual(pilot["reference_flags"], gate["reference_flags"])
        self.assertEqual(pilot["variant_flags"], gate["variant_flags"])
        self.assertEqual(len(set(pilot["seeds"]) & set(gate["seeds"])), 0)
        self.assertEqual(gate["complete_games"], 80)
        self.assertEqual(gate["first_money_difference_pre_1972"], [1])


if __name__ == "__main__":
    unittest.main()
