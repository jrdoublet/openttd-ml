# P4-vyear — garde conservatrice d'uplift AIR (13 octobre 2026)

## Hypothèse et isolation

La mesure véhicule-année ne reconstruit pas les profits des véhicules
vendus/crashés et omet les lignes entièrement démolies ; les renforts
intra-annuels ne sont pas inclus directement dans le numérateur. Le
remplacement du facteur C70 global par une moyenne de panels survivants
et de lignes neutres peut donc **relever** une prévision AIR sans preuve
prospective que ce relèvement améliore une décision rentable. Dans les
archives *matched-shadow* de cinq graines × cinq ans, le nouveau facteur
AIR est supérieur à C70 historique dans les **15/15 publications
annuelles** de 1971 à 1973, tandis que les réalisations AIR matures
demeurent habituellement au-dessous du profit prévu.

Travail exclusivement dans le nouveau worktree détaché
`results/scores_p4_guard_stage_20261013` depuis `c2a5be3`, 12 overlays
P4-vyear (dont `persist.nut`) copiés byte-identiquement du témoin
`scores_p4_adjust_stage_20261013` avant édition. Les données et le code
des anciens témoins sont conservés. Nouvelle option
`score_c70_vyear_air_uplift_guard=0` **OFF pour les quatre difficultés** ;
elle ne s'active qu'avec `score_c70_vyear_cohort=1` et C70 actif.

La seule politique ajoutée se résume à :

```squirrel
if (SCORE_C70_VYEAR_AIR_UPLIFT_GUARD && mode == "air" && effectiveK > legacyK)
  effectiveK = legacyK;
```

Le facteur C70 legacy est calculé sur le même état économique et la même
année, non estimé d'un autre monde. **Aucun coefficient optimisé, ni
modification de C77/V88, financement, priorité C121/R2/V161, moteur,
construction ou état Save/Load v2**. Une correction AIR vers le bas
reste possible ; le mode RAIL reste entièrement en vehicle-year (avec
couverture encore faible). ROAD sans panel conserve son héritage.

## Contrôles et essais achevés

- 35 tests ciblés vyear/matched/guard réussis ; nouvelle suite complète
  `unittest discover -s sweeps -p 'test_*.py' -q` : **2 132 tests OK**,
  `git diff --check` propre, log
  `results/scores_p4_guard_host_suite_20261013.log`.
- Smoke moteur 2 graines × 3 ans, `scores_p4_guard_smoke2x3_20261013` :
  **4/4 parties saines**, garde vs vyear sans garde, Δ moyen
  **−1 567,5 £/an**, 0V/1D/1E, simple sûreté moteur.
- Clean 5 graines de développement × cinq ans, **garde vs vyear non
  gardé** `scores_p4_guard_clean_dev5x5_20261013` : **10/10 parties
  complètes** ; Δ `profit_year` **+37 094,6 £/an**, médiane +29 006,
  3V/2D, Wilcoxon p=0,625, bootstrap IC95 **[−53 542 ; +127 731]**, 
  `company_value` ratio −0,3393 %. `fail_primary`, non qualifiant.
- Clean 5 graines de développement × cinq ans, **garde vs C70 historique**
  `scores_p4_guard_vs_history_dev5x5_20261013`, même bundle
  `10eb475ccfdb87f4964a8560c37d7137c3cbbac0521314dcc53691fdcaafa999` :
  **10/10 complètes**, Δ `profit_year` **+68 191,8 £/an**, médiane
  +37 920, **5V/0D**, Wilcoxon bilatéral **p=0,0625** (minimum possible
  avec cinq effets non nuls), bootstrap IC95 **[+23 476,8 ; +122 707,8]**,
  `company_value` ratio **+1,2475 %**. Le seuil préenregistré +4 %
  correspond à **+74 245,9 £/an** : `fail_primary` malgré l'IC95
  positive et le 5/5. Les graines utilisées sont
  314159,271828,161803,123457,987653.

Les parties de développement ont le même bundle au sein et entre les
deux comparaisons ; elles n'autorisent pas une différence de différences
inter-campagnes comme si le moteur était déterministe (une répétition
A/A antérieure a bifurqué avant tout facteur).

## Gate indépendante déclenchée (à renseigner après résultats)

Le 5/5 positif et IC95 positive, alors que p ne peut être inférieur à
0,05 avec seulement cinq observations, justifient un **A40×5** sur les
40 graines canoniques excluant les cinq graines de développement :
`42 100 7 999 2026 1 17 73 314 512 1024 1337 4096 8191 12345
54321 65537 123456 424242 8675309 423960 613553 515222 781335
375172 999533 442018 746035 455216 230185 706990 983759 802204
232037 723002 313707 701256 292001 841478 59527`.

Campagne `scores_p4_guard_gateA40x5_20261013` : ref C70 historique
avec P4-vyear OFF, variante P4-vyear ON avec garde AIR ON, toutes les
sondes C77/vyear/matched-shadow et le decision_log à 0, C82 à 0,
Save full state=1 des deux côtés, budget 10 CPU/10 workers maximum,
un seul Docker. Critères préétablis : `profit_year` terminal variant−ref
moyen au moins **+4 %** du niveau moyen témoin, Wilcoxon bilatéral
p inférieur à 0,05, IC95 bootstrap basse strictement positive,
`company_value` ratio supérieur à 0,95 et contrôle des 40 paires,
construction/flotte/opcodes/santé. En cas de succès, réserver une
validation **indépendante**, sans intégration immédiate. En cas d'échec,
garder le flag OFF et ne pas annoncer impossibilité d'autres modèles.

Note Save/Load : aucun champ ni version ajoutée ; la preuve moteur réelle
antérieure à 80 lignes concerne la même implémentation de sidecar v2,
et n'a pas été reproduite inutilement. Un contrôle supplémentaire de
budget Save vers 150 lignes ne serait requis que pour une adoption.

## Gate A40×5 — résultat final vérifié sur les archives après exécution

**La qualification indépendante a bien été exécutée.** Le paragraphe
précédent décrit son protocole *préenregistré*, et non une campagne à
lancer. `results/scores_p4_guard_gateA40x5_20261013.json` et son manifeste
indiquent **80/80 jeux complets, 40/40 paires** saines sur quarante graines
sans recouvrement avec celles du 5×5 développement ; aucun échec moteur
non attribué. Même bundle `10eb475ccfdb87f4964a8560c37d7137c3cbbac0521314dcc53691fdcaafa999`,
référence C70 historique et variante P4-vyear + garde AIR, sondes OFF,
C82 OFF et Save full state ON identiques au développement.

La différence variante − référence de `profit_year` terminal vaut
**−52 352,375 £/an**, médiane −38 792, **14V/25D/1E**,
IC95 bootstrap **[−96 109,525 ; −15 266,975]**, Wilcoxon bilatéral
**p=0,008947** ; seuil +4 % de référence **+84 627,198 £/an** non atteint.
Le ratio des `company_value` est **−1,603974 %**, avec une différence
moyenne −114 586,35 £. `verdict=fail_primary` ; **ne pas intégrer la garde**.
Ce résultat négatif ne peut pas être réinterprété comme validation
positive en gardant seulement les cinq premières graines favorables.

Vérification externe au harnais :
`sweeps/verify_p4_guard_gate_20261013.py`, deux tests associés et
`results/scores_p4_guard_gate_independent_receipt_20261013.json`.
Les profits 5×5 et 40×5 sont recalculés depuis tous les checkpoints
mensuels avec contrôle SHA256 des manifestes, hashes de bundles,
paramètres et absence de chevauchement de graines. La graine 1 diverge
en février 1970, avant le facteur P4 (bruit de trajectoire possible) ;
les 39 autres affichent encore une différence moyenne négative de
**−37 200,54 £/an**. Un retrait post-hoc ne remplace pas la porte 40×5.

Consolidation détaillée, autres hypothèses P2/P4 et limites causales :
`docs/scores_p2_p4_qualification_independante_20261013.md` à la racine.
