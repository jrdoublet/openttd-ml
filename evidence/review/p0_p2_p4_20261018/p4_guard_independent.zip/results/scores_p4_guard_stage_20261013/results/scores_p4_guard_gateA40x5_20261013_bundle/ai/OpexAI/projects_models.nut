/* Extrait de projects.nut (R14) : Modeles de projet : cles, facteurs de realisation C70/C82/C121, score. Requis depuis projects.nut. */

/* Cle stable d'un projet dans candidateGroups. */
function OpexProjectKeyFor(project)
{
  local prefix = "";
  if (project.mode == "fleet") {
    /* C34.2 : un achat d'avion n'a pas d'origine-destination -- il appartient a UNE ligne. */
    local lid = (("payload" in project) && project.payload != null
                 && ("line" in project.payload) && ("lineId" in project.payload.line))
                ? project.payload.line.lineId : -1;
    return "fleet|" + lid;
  }
  if (("payload" in project) && project.payload != null
      && ("isSubsidy" in project.payload) && project.payload.isSubsidy) {
    return "subsidy|" + project.payload.subsidyId;
  }
  if (("payload" in project) && project.payload != null
      && ("isChain" in project.payload) && project.payload.isChain) {
    return "chain|" + project.payload.inputCargo + "|" + project.payload.sourceIndustryId + "|"
           + project.payload.factoryId + "|t" + project.payload.dstTown;
  }
  /* Garde de forme conservee pour le cout d'opcodes historique. La generation d'extensions
   * route a disparu, mais retirer ces tests de table deplace les frontieres de suspension NoAI
   * et change les resultats deterministes du smoke. */
  if (("payload" in project) && project.payload != null
      && ("isRoadExtension" in project.payload) && project.payload.isRoadExtension) {
    return "road_extension|" + project.payload.targetLineId + "|"
           + project.payload.extensionTown;
  }
  return prefix + OpexProjectPairKey(project.kind, project.cargo, project.src, project.dst);
}

function OpexProjectPairKey(kind, cargo, src, dst)
{
  if (kind == "pax" && src > dst) {
    local swap = src;
    src = dst;
    dst = swap;
  }
  return kind + "|" + cargo + "|" + src + "|" + dst;
}

/* C70 : facteurs par mode recalcules depuis les cumuls par ligne (sauvegardes avec les lignes).
 * Meme formule que le rapport annuel (task_report.nut) : pseudo-ligne a 1. Appele au chargement
 * pour ne pas repartir de k = 1 jusqu'au rapport suivant. */
function OpexC70RecomputeFactors(lines)
{
  local sums = { rail = [0.0, 0], road = [0.0, 0], air = [0.0, 0], water = [0.0, 0] };
  local stableSums = SCORE_C70_STABLE_COHORT
      ? { rail = [0.0, 0], road = [0.0, 0], air = [0.0, 0], water = [0.0, 0] } : null;
  if (lines != null) {
    foreach (line in lines) {
      if (line == null || !("mode" in line) || !(line.mode in sums)) continue;
      if (stableSums != null && ("p4C70Pred" in line) && ("p4C70Real" in line)
          && line.p4C70Pred > 0) {
        stableSums[line.mode][0] += line.p4C70Real.tofloat() / line.p4C70Pred.tofloat();
        stableSums[line.mode][1]++;
      }
      if (!("c70Pred" in line) || !("c70Real" in line) || line.c70Pred <= 0) continue;
      sums[line.mode][0] += line.c70Real.tofloat() / line.c70Pred.tofloat();
      sums[line.mode][1]++;
    }
  }
  foreach (m, acc in sums) {
    C70_MODE_FACTOR[m] = (acc[0] + 1.0) / (acc[1] + 1).tofloat();
    if (stableSums != null) {
      local stableAcc = stableSums[m];
      C70_MODE_FACTOR[m] = (stableAcc[0] + 1.0) / (stableAcc[1] + 1).tofloat();
    }
    OpexC69Log("phase=c70_reload mode=" + m + " lines=" + acc[1] + " k=" + C70_MODE_FACTOR[m]);
  }
}

/* P4-adjust: jamais une simple moyenne des seuls survivants. Chaque ligne
 * economiquement comparable a exactement une voix : panel complet si valide,
 * sinon facteur NEUTRE = 1 (y compris attrition, absence de snapshot ou
 * premier exercice). Deux pseudo-lignes neutres regulierisent l'ensemble.
 * Les observations sont des ratios par incumbent-vehicle-year en permille,
 * sans precision flottante stockee dans Save. La mesure est calculee AUSSI
 * dans le bras shadow, mais seul le flag economique autorise la publication. */
function OpexC70VYearRecomputeFactors(lines, reportYear)
{
  local sums = { rail = [0.0, 0, 0, 0], road = [0.0, 0, 0, 0],
      air = [0.0, 0, 0, 0], water = [0.0, 0, 0, 0] };
  if (lines != null) {
    foreach (line in lines) {
      if (line == null || !("mode" in line) || !(line.mode in sums)) continue;
      local age = ("year" in line) ? reportYear - line.year : -1;
      if (age < 2 || !("predicted" in line) || line.predicted <= 0
          || !("trains0" in line) || line.trains0 <= 0) continue;
      local acc = sums[line.mode];
      local state = ("p4VYear" in line) ? line.p4VYear : null;
      if (state != null && ("version" in state) && state.version == 2
          && ("reportYear" in state) && state.reportYear == reportYear
          && ("valid" in state) && state.valid == 1
          && ("count" in state) && state.count > 0 && ("sumPm" in state)) {
        acc[0] += state.sumPm.tofloat() / (1000.0 * state.count);
        acc[2]++;
      } else {
        acc[0] += 1.0;
        acc[3]++;
      }
      acc[1]++;
    }
  }
  foreach (mode, acc in sums) {
    local measuredK = (acc[0] + 2.0) / (acc[1] + 2).tofloat();
    local legacyK = C70_MODE_FACTOR[mode];
    /* Sans au moins une observation de flotte complete, le retour neutre
     * ne doit PAS ecraser C70 historique (ROAD n'a pas de panel explicite).
     * Avec couverture positive, les lignes non mesurables restent neutres. */
    local effectiveK = acc[2] > 0 ? measuredK : legacyK;
    /* P4 AIR one-sided exposure guard: apparent AIR uplift with incomplete
     * sold/crashed-vehicle profits and omitted removed lines is unvalidated.
     * Never raise AIR beyond the legacy factor; keep downward corrections.
     * No fitted coefficient or change to funding, ranking tiers or RAIL. */
    if (SCORE_C70_VYEAR_AIR_UPLIFT_GUARD && mode == "air" && effectiveK > legacyK)
      effectiveK = legacyK;
    /* Une affectation pour CHAQUE bras mesureur, meme au cold-start ou le
     * facteur vaut 1 : reduire le decalage VM avant la premiere observation.
     * Le shadow reecrit sa valeur historique, sans appliquer effectiveK. */
    C70_MODE_FACTOR[mode] = (SCORE_C70_VYEAR_COHORT ? effectiveK : legacyK);
    if (SCORE_C70_COHORT_LOG)
      AILog.Info("P4_VYEAR_MODE exercise=" + (reportYear - 1) + " mode=" + mode
          + " covered=" + acc[2] + " neutral=" + acc[3]
          + " comparable=" + acc[1] + " factor=" + effectiveK
          + " measured_k=" + measuredK + " fallback_legacy=" + (acc[2] == 0 ? 1 : 0)
          + " legacy_k=" + legacyK + " applied=" + (SCORE_C70_VYEAR_COHORT ? 1 : 0));
  }
}

/* C121 : le facteur de realisation corrige le revenu brut du modele physique,
 * jamais une prediction deja corrigee. Une pseudo-ligne a 1.0 stabilise les
 * petits echantillons ; sous MIN_LINES on conserve strictement le cold-start. */
function OpexC121RealizationFactor(plan)
{
  /* Les anciens essais r4/r5 appliquaient trop brutalement le facteur appris.
   * Le levier reste separe et ne corrige que les bras reutilisant un hub. */
  if (!C121_AIR_PROJECT_REALIZATION_ADAPTIVE
      || plan == null || !("arm" in plan)) return 1.0;
  local arm = plan.arm;
  if (arm != "hubsite" && arm != "hubhub") return 1.0;
  if (!(arm in C121_AIR_REALIZATION_FACTOR)) return 1.0;
  /* Moyenne directe des ratios C121 matures, uniquement pour les hubs AIR. */
  if (AIR_P0_DIRECT_REALIZATION_ACTIVE && C121_AIR_ECONOMICS)
    return C121_AIR_P0_DIRECT_FACTOR[arm];
  /* La stratégie adaptative reste disponible dans les trois états de pression.
   * Le régime continue de piloter C122, mais ne bloque plus la correction
   * apprise ; sans observation suffisante, learned reste 1.0. */
  local learned = C121_AIR_REALIZATION_FACTOR[arm];
  if (learned < 0.0 || learned >= 1.0) return 1.0;
  /* Appliquer seulement 25 % de l'ecart appris pour preserver la valeur et
   * la capacite d'expansion ; le régime C121/C122 ne bloque plus ce calcul. */
  return 0.75 + 0.25 * learned;
}

function OpexC121RealizationSums()
{
  return { newpair = [0, 0], hubsite = [0, 0], hubhub = [0, 0] };
}

function OpexC121ApplyRealizationSums(sums, year, phase)
{
  if (AIR_P0_DIRECT_REALIZATION && C121_AIR_ECONOMICS)
    AIR_P0_DIRECT_REALIZATION_ACTIVE = false;
  foreach (arm, acc in sums) {
    local n = acc[1];
    local factor = 1.0;
    if (n >= C121_AIR_REALIZATION_MIN_LINES) {
      factor = (acc[0].tofloat() + 1000.0) / ((n + 1).tofloat() * 1000.0);
    }
    local oldFactor = C121_AIR_REALIZATION_FACTOR[arm];
    C121_AIR_REALIZATION_FACTOR[arm] = factor;
    local directChanged = false;
    if (AIR_P0_DIRECT_REALIZATION && C121_AIR_ECONOMICS
        && (arm == "hubsite" || arm == "hubhub")) {
      local direct = n > 0 ? acc[0].tofloat() / (n.tofloat() * 1000.0) : 1.0;
      directChanged = C121_AIR_P0_DIRECT_FACTOR[arm] != direct;
      C121_AIR_P0_DIRECT_FACTOR[arm] = direct;
      if (direct != 1.0) AIR_P0_DIRECT_REALIZATION_ACTIVE = true;
    }
    if (C121_CATALOG_INCREMENTAL && (oldFactor != factor || directChanged))
      C121_CATALOG_ARM_LEARN_REV.rawset(arm,
        (arm in C121_CATALOG_ARM_LEARN_REV ? C121_CATALOG_ARM_LEARN_REV[arm] : 0) + 1);
    AILog.Info("C121_REALIZATION phase=" + phase + " year=" + year
        + " arm=" + arm + " lines=" + n + " factor=" + factor);
  }
}

function OpexC121RecomputeRealizationFactors(lines)
{
  local sums = OpexC121RealizationSums();
  local year = AIDate.GetYear(AIDate.GetCurrentDate());
  if (lines != null) {
    foreach (line in lines) {
      if (line == null || !("mode" in line) || line.mode != "air"
          || !("c121Arm" in line) || !(line.c121Arm in sums)
          || !("c121RealizationPm" in line) || !("c121RealizationYear" in line)
          || line.c121RealizationYear < year - 1) continue;
      sums[line.c121Arm][0] += line.c121RealizationPm;
      sums[line.c121Arm][1]++;
    }
  }
  OpexC121ApplyRealizationSums(sums, year, "reload");
}

function OpexC121ProjectHasRealization(project)
{
  if (!C121_AIR_ECONOMICS || project == null || !("mode" in project)
      || !("payload" in project) || project.payload == null) return false;
  if (project.mode == "air") {
    return ("economics" in project.payload) && project.payload.economics != null
        && ("c121RealizationApplied" in project.payload.economics)
        && project.payload.economics.c121RealizationApplied;
  }
  if (project.mode == "fleet" && ("line" in project.payload) && project.payload.line != null) {
    local line = project.payload.line;
    return ("c121MarginalProfit" in line) && ("c121MarginalRevenue" in line);
  }
  return false;
}

/* C70 : facteur du mode d'un projet. Un projet de flotte ajoute des avions a une ligne aerienne. */
function OpexC70Factor(project)
{
  local mode = ("mode" in project) ? project.mode : "unknown";
  if (mode == "fleet") {
    mode = "air";
  }
  return (mode in C70_MODE_FACTOR) ? C70_MODE_FACTOR[mode] : 1.0;
}

/* C82 : facteurs par moteur d'avion recalcules depuis les cumuls par ligne (sauvegardes avec les lignes).
 * Meme formule que le rapport annuel (task_report.nut) : pseudo-ligne a 1. Appele au chargement. */
function OpexC82RecomputeFactors(lines)
{
  local sums = {};
  if (lines != null) {
    foreach (line in lines) {
      if (line == null || !("mode" in line) || line.mode != "air") continue;
      if (!("planeId" in line) || line.planeId < 0) continue;
      if (!("c70Pred" in line) || !("c70Real" in line) || line.c70Pred <= 0) continue;
      local e = line.planeId;
      if (!(e in sums)) sums[e] <- [0.0, 0];
      sums[e][0] += line.c70Real.tofloat() / line.c70Pred.tofloat();
      sums[e][1]++;
    }
  }
  C82_ENGINE_FACTOR.clear();
  foreach (e, acc in sums) {
    C82_ENGINE_FACTOR[e] <- (acc[0] + 1.0) / (acc[1] + 1).tofloat();
    OpexC69Log("phase=c82_reload engine=" + e + " lines=" + acc[1] + " k=" + C82_ENGINE_FACTOR[e]);
  }
}

/* C82 : facteur d'un moteur d'avion. 1.0 si inactif ou moteur absent de la table. */
function OpexC82EngineFactor(engine)
{
  if (!C82_ENGINE_CALIBRATION && !C110_AIR_ENGINE_CALIBRATION_CHOICE_ONLY) return 1.0;
  return (engine in C82_ENGINE_FACTOR) ? C82_ENGINE_FACTOR[engine] : 1.0;
}

/* C82 : determine le moteur d'avion concerne par un projet air ou flotte. -1 si non identifiable. */
function OpexC82ProjectEngine(project)
{
  if (project == null || !("mode" in project) || !("payload" in project) || project.payload == null) return -1;
  if (project.mode == "air") {
    local payload = project.payload;
    if (("plane" in payload) && payload.plane != null && ("id" in payload.plane) && payload.plane.id != null) {
      return payload.plane.id;
    }
    return -1;
  }
  if (project.mode == "fleet") {
    local payload = project.payload;
    if (("line" in payload) && payload.line != null) {
      local line = payload.line;
      if (("planeId" in line) && line.planeId != null) return line.planeId;
      if (("refleetEngine" in line) && line.refleetEngine != null) return line.refleetEngine;
    }
    return -1;
  }
  return -1;
}

/* C70 : profit servant au classement. Le brut reste dans profitAnnual, et donc dans
 * line.predicted : le facteur mesure le modele, jamais sa propre correction. */
function OpexC70Profit(project)
{
  /* R2 : une observation n'est pas une prediction a recalibrer. Le marqueur
   * vient de la branche qui a fourni profitAnnual, pas de l'etat actuel de la ligne. */
  if (project != null && ("profitIsObserved" in project) && project.profitIsObserved)
    return project.profitAnnual;
  /* Eviter une seconde calibration C70/C82 apres une correction C121 non neutre. */
  if (AIR_P0_DIRECT_REALIZATION_ACTIVE && project != null && ("mode" in project)
      && project.mode == "air" && OpexC121ProjectHasRealization(project)
      && ("realizationFactor" in project.payload.economics)
      && project.payload.economics.realizationFactor != 1.0)
    return project.profitAnnual;
  /* Le learner de realisation AIR C121 reste en shadow (facteur causal = 1.0),
   * donc une nouvelle ligne AIR doit continuer a beneficier de la calibration
   * C70 existante. Seule la flotte C121 porte deja sa propre marge observee. */
  /* V161 : un renfort dont la valeur reste celle du modele perd cette exemption. */
  if (project != null && ("mode" in project) && project.mode == "fleet"
      && !("v161Calibrate" in project)
      && OpexC121ProjectHasRealization(project)) return project.profitAnnual;
  if (!C70_MODE_CALIBRATION) return project.profitAnnual;
  return project.profitAnnual * OpexC70Factor(project);
}

/* C82 : facteur du moteur d'avion s'il est connu, sinon calibration C70 du mode. */
function OpexC82Profit(project)
{
  if (project != null && ("profitIsObserved" in project) && project.profitIsObserved)
    return project.profitAnnual;
  /* Eviter une seconde calibration C70/C82 apres une correction C121 non neutre. */
  if (AIR_P0_DIRECT_REALIZATION_ACTIVE && project != null && ("mode" in project)
      && project.mode == "air" && OpexC121ProjectHasRealization(project)
      && ("realizationFactor" in project.payload.economics)
      && project.payload.economics.realizationFactor != 1.0)
    return project.profitAnnual;
  if (project != null && ("mode" in project) && project.mode == "fleet"
      && !("v161Calibrate" in project)
      && OpexC121ProjectHasRealization(project)) return project.profitAnnual;
  local e = OpexC82ProjectEngine(project);
  if (e >= 0) return project.profitAnnual * OpexC82EngineFactor(e);
  return OpexC70Profit(project);
}

/* Profit calibre des scores : OpexC70Profit, ou OpexC82Profit sous c82_engine_calibration.
 * Choisi une fois dans OpexLoadSettings ; l'appel coute autant qu'un appel direct, ce qui garde
 * la cadence VM de la selection identique quand C82 est inactif. */
OpexCalibratedProfit <- OpexC70Profit;

function OpexProjectScore(value, cost)
{
  if (value <= 0 || cost <= 0) return 0.0;
  return (value.tofloat() * 1000.0) / cost;
}
