"""Passive audit of existing V166 logs and annual telemetry; no game runs."""
from collections import defaultdict, Counter
from datetime import date
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'sweeps'))
from analyse_rail_freight_dlog import decode_line

NAME = 'v166_rail_vs_rail_20x3_20261013_r1'
report = json.loads((ROOT/'results'/(NAME+'.json')).read_text(encoding='utf8'))
manifest = json.loads((ROOT/'results'/(NAME+'.manifest.json')).read_text(encoding='utf8'))
builds, visits, revenues = {}, defaultdict(list), []
events = Counter()
for path in sorted((ROOT/'results'/(NAME+'_engine')).glob('*.log')):
    seed = int(path.stem.split('_seed')[1].split('_')[0])
    for n, raw in enumerate(path.read_text(encoding='utf8').splitlines(),1):
        decoded = decode_line(raw)
        if not decoded:
            continue
        y,m,d,tag,f = decoded
        events[tag] += 1
        if tag == 'RAIL_BUILD':
            key = (seed,int(f['line']))
            assert key not in builds
            builds[key] = dict(seed=seed,date=f'{y:04d}-{m:02d}-{d:02d}',log_line=n,**f)
        elif tag == 'STATION_FIRST_VEHICLE' and f.get('mode') == 'rail' and int(f['line']) >= 0:
            visits[(seed,int(f['line']))].append(dict(date=f'{y:04d}-{m:02d}-{d:02d}',log_line=n,**f))
        elif tag == 'LINE_REVENUE' and f.get('mode') == 'rail':
            revenues.append(dict(seed=seed,log_line=n,**f))

def stats(values):
    xs=list(values)
    return {'n':len(xs),'median':statistics.median(xs) if xs else None,
            'mean':statistics.mean(xs) if xs else None,
            'min':min(xs) if xs else None,'max':max(xs) if xs else None}

joined, missing = [], []
for snap in report['line_telemetry']['snapshots']:
    if snap['arm'] != 'OpexAI':
        continue
    assert snap['ok']
    for line in snap['lines']:
        ids=set(line['station_ids'])
        candidates=[]
        for key,b in builds.items():
            if key[0] != snap['seed'] or b['date'] > snap['date']:
                continue
            ev=[v for v in visits[key] if b['date'] <= v['date'] <= snap['date']]
            if len(ids)==2 and {int(v['station']) for v in ev}==ids:
                candidates.append((key,b,ev))
        if len(candidates)!=1:
            missing.append({'seed':snap['seed'],'year':snap['year'],'stations':sorted(ids),'matches':len(candidates)})
            continue
        key,b,ev=candidates[0]
        assert all(v['cargo']==b['cargo'] for v in ev)
        assert len(line['cargo_types'])==1
        cargo=line['cargo_types'][0]
        joined.append({'seed':key[0],'line_id':key[1],'year':snap['year'],'build':b,
            'stations':sorted(ids),'cargo_id':cargo,'cargo_label':b['cargo'],
            'trains':line['vehicles'],'capacity':line['capacity_by_cargo'][cargo],
            'capacity_per_train':line['capacity_by_cargo'][cargo]/line['vehicles'],
            'profit_ytd':line['profit_this_year_gbp'],
            'initial_vehicle_present':bool({int(v['vehicle']) for v in ev}&set(line['vehicle_ids']))})

coal=[r for r in joined if r['cargo_label']=='COAL']
cohorts=defaultdict(list)
for r in coal:
    cohorts[(r['seed'],r['line_id'])].append(r)
stable=[]
for key,rows in cohorts.items():
    by_year={r['year']:r for r in rows}
    if 1970 in by_year and 1972 in by_year:
        a,b=by_year[1970],by_year[1972]
        stable.append({'seed':key[0],'line_id':key[1],
            'capacity_per_train_1970':a['capacity_per_train'],'capacity_per_train_1972':b['capacity_per_train'],
            'trains_1970':a['trains'],'trains_1972':b['trains']})
ratios=[]
for r in revenues:
    key=(r['seed'],int(r['line']))
    b=builds.get(key)
    if b and r['cargo']=='COAL' and int(r['age'])>=2 and int(r['vehs'])==int(b['trains']) and int(r['pred_rev'])>0:
        ratios.append(dict(seed=r['seed'],line_id=int(r['line']),report_year=int(r['year']),
            revenue_real_over_pred=int(r['real_rev'])/int(r['pred_rev']),vehs=int(r['vehs'])))

unchanged=[]
for f in manifest['sources']['OpexAI']['files']:
    assert hashlib.sha256((ROOT/'ai/OpexAI'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
    unchanged.append(f['path'])
summary={
    'source_files_match_frozen':len(unchanged),'builds':len(builds),
    'opex_service_snapshots':sum(len(s['lines']) for s in report['line_telemetry']['snapshots'] if s['arm']=='OpexAI'),
    'joined_service_snapshots':len(joined),'unmatched_service_snapshots':len(missing),
    'joined_coal_snapshots':len(coal),'coal_cohort_1970_1972':len(stable),
    'coal_cohort_same_capacity_per_train':sum(r['capacity_per_train_1970']==r['capacity_per_train_1972'] for r in stable),
    'coal_cohort_more_trains':sum(r['trains_1972']>r['trains_1970'] for r in stable),
    'coal_capacity_per_initial_wagon':stats(r['capacity_per_train']/int(r['build']['wagons']) for r in coal),
    'mature_same_count_coal_revenue_ratio':stats(r['revenue_real_over_pred'] for r in ratios),
    'line_profit_events':events['LINE_PROFIT'],
    'rail_expand_default':manifest['policies'][0]['settings']['effective']['rail_expand'],
    'retained_savegames':report['retained_savegames'],
    'limitations':['Joins require exact two-station identity and API cargo label. No nearest-station attribution.',
        'First-station event dates are processing dates, not measured departures or cycles.',
        'Same train count is not proof of unchanged fleet throughout an exercise.',
        'max_waiting_cargo is a historical rating-window maximum, not instantaneous backlog.',
        'No physical track length, platform size, loading cycle, production or counterfactual measured by this extraction.']}
out={'summary':summary,'joined':joined,'unmatched':missing,'coal_stable_cohort':stable,'revenue_ratios':ratios}
(ROOT/'results/v166_rail_consist_audit_20261013.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
