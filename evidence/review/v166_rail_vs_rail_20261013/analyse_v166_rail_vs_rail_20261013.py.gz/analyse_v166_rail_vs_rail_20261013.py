"""Read-only analysis; reuse current decoders, never execute another game."""
import collections
from datetime import date
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'sweeps'))
from analyse_rail_freight_dlog import decode_line, count_log
from analyse_p0_service_profit_20261012 import summarize

NAME = 'v166_rail_vs_rail_20x3_20261013_r1'
source = ROOT / 'results' / (NAME + '.json')
d = json.loads(source.read_text(encoding='utf8'))
assert len(d['games']) == 20 and all(g['game_ok'] for g in d['games'])
assert not d['failed_runs'] and d['policy_comparison'] is None
assert len(d['summary']) == 40
for r in d['summary']:
    assert r['profit_year_quarters_valid'] == 4 and r['physical_ok']
    assert r['qualified_modes']['rail']
    assert all(r['primary_vehicles_by_mode'][k] == 0 for k in ('air','road','water'))

def stats(values):
    values = list(values)
    return {'n': len(values), 'sum': sum(values), 'mean': statistics.mean(values) if values else None,
            'median': statistics.median(values) if values else None,
            'min': min(values) if values else None, 'max': max(values) if values else None}

logs = {}
annual = collections.defaultdict(collections.Counter)
attempts, builds, delays, unmatched = [], [], [], []
cargo_labels = {}
for p in sorted((ROOT / 'results' / (NAME + '_engine')).glob('*.log')):
    seed = int(p.stem.split('_seed')[1].split('_')[0])
    lines = p.read_text(encoding='utf8').splitlines()
    logs[str(seed)] = count_log(lines)
    pending = collections.defaultdict(list)
    for n, raw in enumerate(lines, 1):
        parsed = decode_line(raw)
        if not parsed:
            continue
        y,m,day,tag,f = parsed
        when = date(y,m,day)
        if tag == 'BOOTSTRAP_STAGE' and 'freight_label' in f:
            key = f['freight_cargo']
            assert key not in cargo_labels or cargo_labels[key] == f['freight_label']
            cargo_labels[key] = f['freight_label']
        if tag == 'PROJECT_CHOSEN' and f.get('mode') == 'rail':
            pending[(f.get('kind'),f.get('src'),f.get('dst'))].append((when,n,f))
        if tag == 'RAIL_ATTEMPT':
            rec = dict(seed=seed,year=y,date=when.isoformat(),log_line=n,**f)
            attempts.append(rec)
            annual[y]['attempt/' + f['kind'] + '/' + f['reason']] += 1
            annual[y]['search_ops/' + f['kind'] + '/' + f['reason']] += max(0,int(f['search_ops']))
            key = (f.get('kind'),f.get('src'),f.get('dst'))
            chosen = pending.pop(key, [])
            if len(chosen) == 1:
                delays.append(dict(seed=seed,year=y,kind=f['kind'],reason=f['reason'],
                    days=(when-chosen[0][0]).days,chosen_log_line=chosen[0][1],attempt_log_line=n))
            else:
                unmatched.append(dict(seed=seed,log_line=n,chosen_count=len(chosen)))
        if tag == 'RAIL_BUILD':
            builds.append(dict(seed=seed,year=y,date=when.isoformat(),log_line=n,**f))
            annual[y]['build/' + f['cargo']] += 1
    annual['pending_chosen']['events'] += sum(len(v) for v in pending.values())

snapshots = {(s['seed'],s['year'],s['arm']):s for s in d['line_telemetry']['snapshots']}
assert len(snapshots) == 120
services, by_cargo, exclusions = {}, {}, []
for y in (1970,1971,1972):
    eligible = [seed for seed in d['seeds'] if all(
        snapshots[(seed,y,a)]['ok'] and not snapshots[(seed,y,a)]['unresolved_vehicles']
        for a in d['arms'])]
    exclusions.extend({'seed':seed,'year':y,'arm':a,'unresolved':snapshots[(seed,y,a)]['unresolved_vehicles']}
        for seed in d['seeds'] for a in d['arms'] if snapshots[(seed,y,a)]['unresolved_vehicles'])
    services[str(y)] = {'paired_seeds':eligible}
    for a in d['arms']:
        values = [summarize(snapshots[(seed,y,a)])['rail'] for seed in eligible]
        services[str(y)][a] = {k:stats(r[k] for r in values) for k in values[0]}
        cargo = collections.defaultdict(collections.Counter)
        for seed in eligible:
            for line in snapshots[(seed,y,a)]['lines']:
                key = '+'.join(line['cargo_types'])
                cargo[key]['services'] += 1
                cargo[key]['trains'] += line['vehicles']
                cargo[key]['vehicle_profit_ytd'] += line['profit_this_year_gbp']
                for c,cap in line['capacity_by_cargo'].items():
                    cargo[key]['capacity_cargo_' + c] += cap
        by_cargo[f'{y}/{a}'] = {k:dict(v) for k,v in cargo.items()}

annual_economy = {}
monthly = [json.loads(x) for x in (ROOT/'results'/(NAME+'.jsonl')).read_text(encoding='utf8').splitlines()]
for y in (1970,1971,1972):
    annual_economy[str(y)] = {}
    for a in d['arms']:
        rows = [r for r in monthly if r['date'] == f'{y}-12-01' and r['run'][0] == a]
        assert len(rows) == 20 and len({r['run'][1] for r in rows}) == 20
        annual_economy[str(y)][a] = {k:stats(r[k] for r in rows) for k in ('profit_year','company_value','primary_vehicles')}

delay_stats = {f'{kind}/{reason}':stats(r['days'] for r in delays if r['kind']==kind and r['reason']==reason)
    for kind,reason in sorted({(r['kind'],r['reason']) for r in delays})}
manifest = json.loads((ROOT/'results'/(NAME+'.manifest.json')).read_text(encoding='utf8'))
width = 2 ** int(manifest['configuration']['parsed']['game_creation']['map_x'])
coal_id = next(k for k,v in cargo_labels.items() if v == 'COAL')
coal = {}
for a in d['arms']:
    lines = [l for seed in services['1972']['paired_seeds']
        for l in snapshots[(seed,1972,a)]['lines'] if l['cargo_types'] == [coal_id]]
    distances = []
    for l in lines:
        tiles = l['ordered_station_tiles']
        if len(tiles) == 2 and all(isinstance(t,int) for t in tiles):
            x,z = tiles
            distances.append(abs(x%width-z%width)+abs(x//width-z//width))
    coal[a] = {'endpoint_manhattan':stats(distances),
        'capacity_per_train_by_service':stats(l['capacity_by_cargo'][coal_id]/l['vehicles'] for l in lines)}
out = {
    'source':str(source.relative_to(ROOT)), 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'bundle':d['source_bundle_sha256'], 'scope':'descriptive rail-only instrumented, not policy qualification',
    'health':{'games':20,'healthy':20,'complete_company_economics':40},
    'statistics':d['statistics'], 'paired_comparisons':d['paired_comparisons'],
    'annual_economy':annual_economy, 'paired_services':services, 'cargo_ids_observed_labels':cargo_labels,
    'paired_service_cargo_signatures':by_cargo, 'snapshot_exclusions':exclusions,
    'coal_endpoint_distance_not_track_length':coal,
    'opex_events_annual':{str(y):dict(c) for y,c in annual.items()},
    'opex_attempts':attempts,'opex_builds':builds,'chosen_attempt_delays':delays,
    'delay_stats':delay_stats,'unmatched_attempts':unmatched,'funnel_by_seed':logs,
    'limitations':[
        'Company economics use all 20 seeds. Service comparisons exclude BOTH companies for any unresolved snapshot.',
        'Cargo IDs remain IDs unless BOOTSTRAP_STAGE supplies an API-resolved label; no guessed passenger/mail IDs.',
        'Service vehicle profits are December YTD, not company trailing four quarters.',
        'Chosen-to-attempt elapsed time matched only by a single pending same-kind directed OD; no RID causal attribution.',
        'Search ops are reported instrument values, not wall CPU. No opportunity loss or counterfactual gain proved.',
        'Decision logging and rail-only mode define this environment; no inference of multimode adoption.']}
dest = ROOT/'results'/(NAME+'_analysis.json')
dest.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({k:out[k] for k in ('annual_economy','paired_services','opex_events_annual','delay_stats','cargo_ids_observed_labels')},ensure_ascii=False,indent=2))
