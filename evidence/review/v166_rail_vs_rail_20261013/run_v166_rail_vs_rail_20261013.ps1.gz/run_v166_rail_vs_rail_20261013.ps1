param([ValidateSet('smoke','campaign')][string]$Phase = 'smoke')
$ErrorActionPreference = 'Stop'
$env:PATH = 'C:/Users/jr/AppData/Local/Programs/DockerDesktop/resources/bin;' + $env:PATH
$campaignName = if ($Phase -eq 'smoke') { 'v166_rail_vs_rail_smoke_20261013_r1' } else { 'v166_rail_vs_rail_20x3_20261013_r1' }
$durationYears = if ($Phase -eq 'smoke') { 1 } else { 3 }
$campaignSeeds = if ($Phase -eq 'smoke') { @(42) } else { @(42,100,7,999,2026,1,17,73,314,512,1024,1337,4096,8191,12345,54321,65537,123456,424242,8675309) }
$runArgs = @('-B','-X','utf8','sweeps/run_c66_reference.py',
 '--campaign',$campaignName,'--container-name',($campaignName -replace '_','-'),
 '--image','openttd-lab:latest','--policy-id','rail_only',
 '--reference','OpexAI[mode_air=0,mode_rail=1,mode_road=0,mode_water=0,decision_log=1]',
 '--aaahogex-setting','disable_veh_train=0','--aaahogex-setting','disable_veh_roadveh=1',
 '--aaahogex-setting','disable_veh_tram=1','--aaahogex-setting','disable_veh_ship=1',
 '--aaahogex-setting','disable_veh_aircraft=1','--decision-rule','gain_short',
 '--years',$durationYears,'--repeats','1','--cpus','10','--memory','8g','--max-workers','10',
 '--script-debug','--line-telemetry','--out',('results/'+$campaignName+'.json'),'--seeds') + $campaignSeeds
& 'C:/Users/jr/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' @runArgs
exit $LASTEXITCODE
