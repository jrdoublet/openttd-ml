import unittest
from analyse import coverage,extract_log

class CoverageTest(unittest.TestCase):
    def test_unknown_zero_and_absence_are_distinct(self):
        self.assertEqual(coverage([{}, {"x":None}, {"x":0}],"x"),{"missing":1,"null":1,"present":1})
    def test_adversary_is_not_counted(self):
        self.assertEqual(extract_log("[1] [I] OPEX 1970-1-1 SPAN id=1")["trace_counts"],{})
    def test_span_and_aggregate_are_separate(self):
        r=extract_log("[0] [I] OPEX 1970-1-1 SPAN id=1\n[0] [I] OPEX 1970-1-1 SPAN_AGG cnt=6")
        self.assertEqual(r["trace_counts"],{"SPAN":1,"SPAN_AGG":1})
    def test_productive_counts_are_not_visits(self):
        r=extract_log("[0] [I] C75_BYPASS phase=year year=1970 stop_k_pass=1 stop_cash=2 stop_rail_search=0 stop_list_end=4 stop_other=0")
        self.assertEqual(r["productive_years"][1970]["productive_passes_recorded"],7)
        self.assertNotIn("guard_visits",r)
    def test_duplicates_rejected(self):
        line="[0] [I] C75_BYPASS phase=year year=1970 stop_k_pass=0 stop_cash=0 stop_rail_search=0 stop_list_end=0 stop_other=0"
        with self.assertRaises(ValueError): extract_log(line+"\n"+line)
    def test_incomplete_or_negative_rejected(self):
        with self.assertRaises(ValueError): extract_log("[0] [I] C75_BYPASS phase=year year=1970 stop_cash=1")
        with self.assertRaises(ValueError): extract_log("[0] [I] C75_BYPASS phase=year year=1970 stop_k_pass=0 stop_cash=-1 stop_rail_search=0 stop_list_end=0 stop_other=0")

if __name__=="__main__": unittest.main()
