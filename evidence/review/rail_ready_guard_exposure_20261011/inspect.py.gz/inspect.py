import collections
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/"results/rail_ready_readmission_A2"
STEM="rail_ready_readmission_diag_40x5_20261010_r1"
bundle=BASE/(STEM+"_bundle")
manifest=json.loads((BASE/(STEM+".manifest.json")).read_text(encoding="utf-8"))
keys=("rail_ready_readmission","probe_span_trace","probe_scheduler","probe_portfolio","probe_loop_ops","catalog_cost_probe","exp_opcode_exact","decision_log","c75_multi_build")
for policy in manifest["policies"]:
    settings=policy["settings"]
    print("SETTINGS",policy["id"],{kind:{k:settings.get(kind,{}).get(k) for k in keys} for kind in settings})
print("RUNTIME",manifest["runtime"])
print("ARTIFACTS",json.dumps(manifest["artifacts"],ensure_ascii=False)[:3000])
tokens=collections.Counter(); examples={}
for p in sorted((BASE/(STEM+"_engine")).glob("*.log")):
    for n,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
        m=re.search(r"\[0\]\s+\[[IWE]\]\s*OPEX\s+\d+-\d+-\d+\s+(\S+)\s*(.*)",line)
        if m:
            tokens[m[1]]+=1
            examples.setdefault(m[1],{"path":p.relative_to(ROOT).as_posix(),"line":n,"text":line})
print("OPEX_TAGS",tokens)
for name,example in examples.items():
    if any(t in name for t in ("PASS","SCHED","OPS","SPAN","RAIL","FUNNEL")):
        print("TAG_EXAMPLE",name,example)
data=json.loads((BASE/(STEM+".json")).read_text(encoding="utf-8"))
for r in data["summary"]:
    if r["arm"]=="OpexAI" and r["seed"] in (8191,424242,746035):
        print("SUMMARY", {k:v for k,v in r.items() if any(t in k.lower() for t in ("policy","seed","opcode","selection","pass"))})
for fn,ranges in [("probes.nut",[(1940,2070),(2185,2250)]),("persist.nut",[(794,819),(860,878),(935,965)]),("settings.nut",[(220,241),(297,311),(518,553)])]:
    lines=(bundle/"ai/OpexAI"/fn).read_text(encoding="utf-8").splitlines()
    print(fn)
    for lo,hi in ranges:
        print("\n".join(str(i+1)+": "+lines[i] for i in range(lo-1,min(hi,len(lines)))))
