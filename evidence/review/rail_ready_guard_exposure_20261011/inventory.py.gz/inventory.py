"""Read-only census of existing paired engine logs and frozen instrumentation."""
import collections
import importlib.util
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location("autopsy",ROOT/"results/rail_ready_autopsy_20261011_r1/analyse.py")
a=importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
manifest=json.loads((a.ARCHIVE/(a.STEM+".manifest.json")).read_text(encoding="utf-8"))
print("MANIFEST_KEYS",list(manifest))
print("POLICIES",json.dumps(manifest.get("policies"),ensure_ascii=False)[:8000])
counter=collections.Counter(); examples={}; logs=sorted((a.ARCHIVE/(a.STEM+"_engine")).glob("*.log"))
for p in logs:
    for number,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
        m=re.search(r"\[0\]\s+\[[IWE]\]\s*(.*)",line)
        if not m: continue
        key=m[1].split()[0] if m[1].split() else "EMPTY"
        counter[key]+=1
        examples.setdefault(key,{"source":str(p.relative_to(ROOT)),"line":number,"text":m[1]})
print("LOGS",len(logs),"TOKENS",counter.most_common(100))
for key in counter:
    if any(term in key.lower() for term in ("proj","c77","c78","ops","span","task","pass","budget","prof")):
        print("EXAMPLE",examples[key])
data=json.loads((a.ARCHIVE/(a.STEM+".json")).read_text(encoding="utf-8"))
print("RESULT_KEYS",list(data))
for key,value in data.items():
    if isinstance(value,list) and value:
        print("FIRST_LIST",key,str(value[0])[:1800])
out={"logs":len(logs),"message_counts":dict(counter),"first_examples":examples,"manifest_keys":list(manifest),"result_keys":list(data)}
(HERE/"inventory.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
(HERE/"production_before.json").write_text(json.dumps(a.worktree(),ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
p=a.BUNDLE/"ai/OpexAI"
for fn,ranges in [("scheduler.nut",[(1,95),(235,380)]),("task_projects.nut",[(1600,1789),(2500,2570)]),("probes.nut",[(2675,2740)])]:
    lines=(p/fn).read_text(encoding="utf-8").splitlines()
    print(fn)
    for lo,hi in ranges:
        print("\n".join(str(i+1)+": "+lines[i] for i in range(lo-1,min(hi,len(lines)))))
