"""Existing-trace coverage audit; no engine, state replay or policy change."""
from collections import Counter
import csv
import importlib.util
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location("autopsy",ROOT/"results/rail_ready_autopsy_20261011_r1/analyse.py")
a=importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
spec=importlib.util.spec_from_file_location("ready_reader",ROOT/"sweeps/analyse_rail_ready_admission.py")
ready=importlib.util.module_from_spec(spec); spec.loader.exec_module(ready)
OWNER=re.compile(r"\[0\]\s+\[[IWE]\]\s*(.*)")
DATE_HEAD=re.compile(r"^OPEX\s+\d+-\d+-\d+\s+")
STOP_KEYS=("stop_k_pass","stop_cash","stop_rail_search","stop_list_end","stop_other")
PROBES=("probe_span_trace","probe_scheduler","probe_portfolio","probe_loop_ops","catalog_cost_probe")
FIELDS=("guard_visits","guard_left0","guard_tick0","guard_tick1","c75PassDates",
        "observed_opcodes_total","observed_opcode_complete_cpu","selection_kopcodes_total")

def dump(name,value):
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def coverage(rows,key):
    return {"missing":sum(key not in r for r in rows),
            "null":sum(key in r and r[key] is None for r in rows),
            "present":sum(key in r and r[key] is not None for r in rows)}

def extract_log(raw):
    counts=Counter(); years={}; samples=[]
    for number,line in enumerate(raw.splitlines(),1):
        match=OWNER.search(line)
        if not match: continue
        text=match[1]
        body=DATE_HEAD.sub("",text)
        fields=dict(ready.FIELD.findall(body))
        first=body.split()[0] if body.split() else ""
        if first in ("SPAN","SPAN_EVENT","SPAN_AGG","C39_PASS_CLOCK","C41_SLACK_LEDGER",
                     "C41_MONTHLY_BUSY","PROJECTS_COST","RAIL_READY_READMISSION"):
            counts[first]+=1
        if fields.get("phase")=="c75_year": counts["c75_year"]+=1
        if fields.get("phase")=="c75_pass": counts["c75_pass"]+=1
        if first=="C75_BYPASS" and fields.get("phase")=="year":
            year=int(fields["year"])
            if year in years: raise ValueError("duplicate yearly stop record")
            if not all(k in fields for k in STOP_KEYS): raise ValueError("missing stop category")
            stops={k:int(fields[k]) for k in STOP_KEYS}
            if any(v<0 for v in stops.values()): raise ValueError("negative count")
            years[year]={"line":number,"stops":stops,"productive_passes_recorded":sum(stops.values())}
            samples.append({"line":number,"text":text})
    return {"trace_counts":dict(counts),"productive_years":years,"source_samples":samples}

def main():
    if (HERE/"analysis.json").exists(): raise FileExistsError("Existing output must not be replaced")
    before=a.worktree()
    initial=json.loads((HERE/"production_before.json").read_text(encoding="utf-8"))
    assert before==initial
    historical=json.loads((ROOT/"results/rail_ready_autopsy_20261011_r1/inputs_before.json").read_text(encoding="utf-8"))
    for path,h in historical["files"].items(): assert a.digest(ROOT/path)==h, path
    for row in historical["bundle"]["files"]: assert a.digest(a.BUNDLE/row["path"])==row["sha256"], row["path"]
    manifest=json.loads((a.ARCHIVE/(a.STEM+".manifest.json")).read_text(encoding="utf-8"))
    data=json.loads((a.ARCHIVE/(a.STEM+".json")).read_text(encoding="utf-8"))
    settings={p["id"]:{k:p["settings"]["effective"][k] for k in PROBES+("c75_multi_build","rail_ready_readmission","exp_opcode_exact","exp_opcode_exact_check")}
              for p in manifest["policies"]}
    assert all(s[k]==0 for s in settings.values() for k in PROBES)
    records=[]; years=[]; all_counts=Counter(); source_hashes={}; games=set()
    for path in sorted((a.ARCHIVE/(a.STEM+"_engine")).glob("*.log")):
        game=ready.GAME.fullmatch(path.name)
        assert game is not None
        identity=(game["policy"],int(game["seed"]),int(game["repeat"]))
        assert identity not in games; games.add(identity)
        row=extract_log(path.read_text(encoding="utf-8"))
        assert set(row["productive_years"])=={1970,1971,1972,1973}, identity
        row.update(policy=identity[0],seed=identity[1],repeat=identity[2],source=path.relative_to(ROOT).as_posix())
        source_hashes[row["source"]]=a.digest(path)
        all_counts.update(row["trace_counts"])
        for year,r in row["productive_years"].items():
            years.append({"policy":identity[0],"seed":identity[1],"year":year,
                          "productive_passes_recorded":r["productive_passes_recorded"],
                          **r["stops"],"source":row["source"],"line":r["line"]})
        records.append(row)
    assert len(games)==80
    assert games=={(p,s,0) for p in a.POLICIES for s in data["seeds"]}
    rows=[]; seen=set()
    with (a.ARCHIVE/(a.STEM+".jsonl")).open(encoding="utf-8") as f:
        for raw in f:
            r=json.loads(raw)
            if r["run"][0]!="OpexAI": continue
            assert r["source_bundle_sha256"]==a.EXPECTED and r["company_slot"]==0
            key=(r["duel_policy_id"],r["run"][1],r["run"][2],r["date"])
            assert key not in seen; seen.add(key); rows.append(r)
    assert len(rows)==4800
    summaries=[r for r in data["summary"] if r["arm"]=="OpexAI"]
    assert len(summaries)==80
    per_year={}
    for year in (1970,1971,1972,1973):
        per_year[str(year)]={p:sum(r["productive_passes_recorded"] for r in years if r["year"]==year and r["policy"]==p) for p in a.POLICIES}
    # Companion transition-only diagnostic is censored at ready-rail visits.
    companion=ROOT/"results/rail_ready_measure_20261011_r1/snapshot/results/diagnostic.json"
    diagnostic=json.loads(companion.read_text(encoding="utf-8"))
    companion_analysis=json.loads((ROOT/"results/rail_ready_measure_20261011_r1/analysis.json").read_text(encoding="utf-8"))
    result={"source_campaign":a.STEM,"source_bundle_sha256":a.EXPECTED,
            "logs":80,"opex_checkpoints":4800,"settings":settings,
            "trace_counts":{key:all_counts[key] for key in ("SPAN","SPAN_EVENT","SPAN_AGG","C39_PASS_CLOCK","C41_SLACK_LEDGER","C41_MONTHLY_BUSY","PROJECTS_COST","RAIL_READY_READMISSION","c75_year","c75_pass")},
            "checkpoint_coverage":{key:coverage(rows,key) for key in FIELDS},
            "summary_coverage":{key:coverage(summaries,key) for key in FIELDS},
            "retained_savegames":data["retained_savegames"],
            "local_savegame_files_in_declared_campaign_directory":sum(1 for p in a.ARCHIVE.rglob("*") if p.is_file() and p.name.endswith((".sav",".sav.gz",".sav.xz"))),
            "productive_stop_year_records":len(years),"productive_stops_by_year_and_policy":per_year,
            "guard_state_visits":None,"guard_entry_slack":None,"guard_caused_suspensions":None,
            "estimated_global_guard_cost":None,"economic_causation":"not_demonstrated",
            "companion_transition_only_campaign":{"path":companion.relative_to(ROOT).as_posix(),
                "retained_savegames":diagnostic["retained_savegames"],
                "analysis_keys":list(companion_analysis),
                "guard_entry_visits_not_collected":True},
            "limits":["Missing trace is not an observed zero of visits or deferrals",
                      "C75 productive stops omit unsuccessful/empty/pending passes",
                      "C75 pass-date cache is rolling 365-day entry history, not guard history or tick/slack",
                      "No retained savegame available for this historical campaign",
                      "Capacity, k_pass, wall-clock log timestamps and OB are not substitutes for guard entry slack"],
            "per_log":records}
    dump("analysis.json",result)
    with (HERE/"productive_stops.csv").open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(years[0])); writer.writeheader(); writer.writerows(years)
    dump("input_hashes.json",{"historical_source_hashes":source_hashes,"historical_manifest_sha256":a.digest(a.ARCHIVE/(a.STEM+".manifest.json")),
         "historical_result_sha256":a.digest(a.ARCHIVE/(a.STEM+".json")),"historical_checkpoints_sha256":a.digest(a.ARCHIVE/(a.STEM+".jsonl")),
         "bundle_sha256":a.EXPECTED,"companion_manifest_sha256":a.digest(companion.with_suffix(".manifest.json")),"companion_result_sha256":a.digest(companion)})
    assert before==a.worktree()
    dump("verification.json",{"worktree_unchanged":True,"original_file_count":len(before["files"]),"historical_inputs_match_prior_autopsy":True,"bundle_files_verified":len(historical["bundle"]["files"]),"no_engine_or_docker":True})
    print(json.dumps({k:result[k] for k in ("logs","opex_checkpoints","trace_counts","productive_stops_by_year_and_policy","estimated_global_guard_cost","economic_causation")},ensure_ascii=False))

if __name__=="__main__": main()
