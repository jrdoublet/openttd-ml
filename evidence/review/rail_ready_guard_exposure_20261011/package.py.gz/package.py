"""Scoped documentary packaging using the established evidence contract."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DEST=ROOT/"evidence/review/rail_ready_guard_exposure_20261011"
assert {p.name for p in DEST.iterdir()}=={"README.md"}, "Do not replace evidence"
spec=importlib.util.spec_from_file_location("audit",HERE/"analyse.py")
audit=importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)
before=json.loads((HERE/"production_before.json").read_text(encoding="utf-8"))
after=audit.a.worktree()
expected_changes={"docs/taches.md","docs/journaux/journal_2026-10-11.md","docs/rail_ready_guard_vm_20261011.md"}
changed={p for p,h in before["files"].items() if after["files"].get(p)!=h}
added=set(after["files"])-set(before["files"])
assert before["head"]==after["head"] and changed==expected_changes, changed
assert added=={"docs/rail_ready_guard_exposure_20261011.md","evidence/review/rail_ready_guard_exposure_20261011/README.md"}, added
(HERE/"final_verification.json").write_text(json.dumps({"head_unchanged":True,"all_original_files_except_three_documentary_updates_unchanged":True,
    "original_file_count":len(before["files"]),"updated_documents":sorted(changed),"added_documents":sorted(added),
    "no_production_changes":True,"no_commit_or_push":True},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def sha(raw): return hashlib.sha256(raw).hexdigest()
artifacts=[]
for name in ("analyse.py","test_analysis.py","inventory.py","inspect.py","inventory.json","complete.py","package.py",
             "analysis.json","paired_summary.json","productive_stops.csv","paired_productive_stops.csv",
             "input_hashes.json","verification.json","final_verification.json"):
    path=HERE/name; raw=path.read_bytes(); packed=gzip.compress(raw,mtime=0)
    dest=DEST/(name+".gz"); dest.write_bytes(packed)
    artifacts.append({"source":path.relative_to(ROOT).as_posix(),"evidence":dest.relative_to(ROOT).as_posix(),
                      "raw_bytes":len(raw),"raw_sha256":sha(raw),"gzip_bytes":len(packed),"gzip_sha256":sha(packed)})
(DEST/"index.json").write_text(json.dumps({"schema":"opex-review-evidence-v1","scope":"Coverage audit only; no global opcode or economic causation claim","artifacts":artifacts},indent=2)+"\n",encoding="utf-8")
files=[]
for fn,ranges in [("task_projects.nut",[(1649,1668),(1671,1724),(1814,1827),(2146,2174),(2326,2353)]),
                  ("probes.nut",[(1977,2040),(2157,2209),(2233,2239)]),
                  ("settings.nut",[(220,239),(303,311),(539,549)]),
                  ("persist.nut",[(808,815),(866,870),(943,949)]),
                  ("opcode_exact.nut",[(75,115)])]:
    path=audit.a.BUNDLE/"ai/OpexAI"/fn; lines=path.read_text(encoding="utf-8").splitlines()
    files.append({"bundle_relative_path":path.relative_to(audit.a.BUNDLE).as_posix(),"full_file_sha256":sha(path.read_bytes()),
                  "excerpts":[{"start_line":lo,"end_line":hi,"numbered_lines":[{"line":i+1,"text":lines[i]} for i in range(lo-1,hi)]} for lo,hi in ranges]})
(DEST/"source_excerpts.json").write_text(json.dumps({"source_bundle_sha256":audit.a.EXPECTED,"files":files},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
shutil.copy2(ROOT/"evidence/review/rail_ready_autopsy_20261011/verify.py",DEST/"verify.py")
print(json.dumps({"archives":len(artifacts),"gzip_bytes":sum(r["gzip_bytes"] for r in artifacts),"preservation":True}))
