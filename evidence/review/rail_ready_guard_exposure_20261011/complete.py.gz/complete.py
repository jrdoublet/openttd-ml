"""Paired productive-pass census; equal totals are not equal trajectories."""
import csv
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
data=json.loads((HERE/"analysis.json").read_text(encoding="utf-8"))
lookup={(r["policy"],r["seed"]):r for r in data["per_log"]}
seeds=sorted({r["seed"] for r in data["per_log"]})
rows=[]; summary={}
for year in (1970,1971,1972,1973):
    unequal=[]
    for seed in seeds:
        left,right=[lookup[(policy,seed)]["productive_years"][str(year)] for policy in ("reference","rail_ready_readmission")]
        delta=right["productive_passes_recorded"]-left["productive_passes_recorded"]
        if delta: unequal.append(seed)
        rows.append({"year":year,"seed":seed,"reference":left["productive_passes_recorded"],
                     "variant":right["productive_passes_recorded"],"delta":delta,
                     "reference_line":left["line"],"variant_line":right["line"]})
    summary[str(year)]={"paired_seeds":40,"unequal_count":len(unequal),"unequal_seeds":unequal,
                        "delta_sum":sum(r["delta"] for r in rows if r["year"]==year),
                        "interpretation":"Productive exits only, no cadence/guard-count/causality inference"}
with (HERE/"paired_productive_stops.csv").open("x",encoding="utf-8",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
with (HERE/"paired_summary.json").open("x",encoding="utf-8") as f:
    json.dump(summary,f,ensure_ascii=False,indent=2)
print(json.dumps({"paired_summary":summary,"1970_unequal":[r for r in rows if r["year"]==1970 and r["delta"]]},ensure_ascii=False))
