from pathlib import Path
import json

root = Path.cwd()
reports = []
for label, probe in [('defaults', 0), ('coverage', 1)]:
    campaign = 'cleanup_c118_' + label + '_smoke_20261012_r1'
    result = json.loads((root / 'results' / (campaign + '.json')).read_text(encoding='utf-8'))
    manifest = json.loads((root / 'results' / (campaign + '.manifest.json')).read_text(encoding='utf-8'))
    games = result['games']
    assert len(games) == 1 and games[0]['game_ok'] and not result['failed_runs']
    assert not games[0]['unattributed_errors']
    assert all(c['run_ok'] and c['horizon_complete'] and c['activity'] == 'active' for c in games[0]['companies'].values())
    settings = manifest['policies'][0]['settings']
    assert 'c118_air_territorial_expansion' not in settings['defaults']
    assert settings['effective']['c118_air_coverage_probe'] == probe
    assert all(settings['defaults'][k] == 1 for k in ['c121_air_economics', 'c121_catalog_incremental', 'air_c121_physical_payment_days'])
    rows = [json.loads(line) for line in (root / 'results' / (campaign + '.jsonl')).read_text(encoding='utf-8').splitlines()]
    assert all('c118_coverage_event_count' in row for row in rows)
    count = max(row['c118_coverage_event_count'] for row in rows)
    assert count == (10 if probe else 0)
    assert all(row['c118_decision_count'] == 0 for row in rows)
    log = (root / 'results' / (campaign + '_engine/reference_seed42_r0.log')).read_text(encoding='utf-8', errors='replace')
    assert log.count('C118_COVERAGE date=') == count
    opex = next(row for row in result['summary'] if row['arm'] == 'OpexAI')
    reports.append({'campaign': campaign, 'healthy': True, 'source_bundle_sha256': result['source_bundle_sha256'], 'manifest_sha256': result['manifest_sha256'], 'probe': probe, 'distinct_coverage_events': count, 'policy_decisions': 0, 'valid_quarters': opex['profit_year_quarters_valid'], 'quarter_coverage': opex['profit_year_coverage']})
assert reports[0]['source_bundle_sha256'] == reports[1]['source_bundle_sha256']
(root / 'results/cleanup_c118_smokes_audit_20261012.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8')
print(json.dumps(reports, indent=2))
