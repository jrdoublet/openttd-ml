from pathlib import Path
import hashlib
import json
import re

root = Path.cwd()
ai = root / 'ai/OpexAI'
backup = root / 'results/cleanup_c118_sources_backup_20261012'

def function(text, name):
    start = text.index('function ' + name + '(')
    clean = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', lambda m: ' ' * len(m[0]), text, flags=re.S)
    opening = clean.index('{', start)
    depth = 1
    cursor = opening + 1
    while depth:
        depth += (clean[cursor] == '{') - (clean[cursor] == '}')
        cursor += 1
    return text[start:cursor]

before = (backup / 'air_coverage.nut').read_text(encoding='utf-8')
after = (ai / 'air_coverage.nut').read_text(encoding='utf-8')
unchanged = ['OpexC118RememberTown', 'OpexC118StationCoverageTowns', 'OpexC118EngineFitsPlan']
guards = ['OpexC118EndpointCoverageTowns', 'OpexC118PlanCoverageTowns', 'OpexC118OwnCoveredTownSet']
for name in unchanged:
    assert function(before, name) == function(after, name), name
for name in guards:
    expected = function(before, name).replace('!C118_AIR_TERRITORIAL_EXPANSION && !C118_AIR_COVERAGE_PROBE', '!C118_AIR_COVERAGE_PROBE')
    assert expected == function(after, name), name
old_finance = (backup / 'projects_finance.nut').read_text(encoding='utf-8')
new_finance = (ai / 'projects_finance.nut').read_text(encoding='utf-8')
shared_finance = ['OpexProjectFinanceCapital', 'OpexC118SetProjectField', 'OpexC120PrepareSelection', 'OpexC120ReorderAffordableAir', 'OpexC120FinalizeSelection']
for name in shared_finance:
    assert function(old_finance, name) == function(new_finance, name), name
old_builder = (backup / 'projects_builders.nut').read_text(encoding='utf-8')
new_builder = (ai / 'projects_builders.nut').read_text(encoding='utf-8')
expected_builder, count = re.subn(r'  if \(C118_AIR_TERRITORIAL_EXPANSION\) {\n.*?\n  }\n', '', old_builder, flags=re.S)
assert count == 1 and expected_builder == new_builder
assert function(old_builder, 'OpexFleetAmortShadow') == function(new_builder, 'OpexFleetAmortShadow')
strip_probe = lambda s: re.sub(r'\n/\* FLEET_AMORT_SHADOW_BEGIN.*?/\* FLEET_AMORT_SHADOW_END \*/\n?', '', s, flags=re.S)
assert hashlib.sha256(strip_probe(old_builder).encode()).hexdigest() == '7e9493026ebb9e0fdc4408a2ae934eb12c0e4a0082c23cbe973f50d4d910b29a'
assert hashlib.sha256(strip_probe(new_builder).encode()).hexdigest() == '101219e15dc374782b9ccb1582299e7bd11fb20b57a70e23b0aeaafbde29e63a'
for path in ai.glob('*.nut'):
    text = path.read_text(encoding='utf-8')
    for token in ['C118_AIR_TERRITORIAL_EXPANSION', 'c118_air_territorial_expansion', 'C118_AIR_PROJECT_SNAPSHOT', 'C118_AIR_DECISION_SEQ', 'c118C68Plane', 'c118MinFinance', 'c118NewTowns']:
        assert token not in text, (path, token)
manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
for rec in manifest:
    assert hashlib.sha256((backup / Path(rec['source']).name).read_bytes()).hexdigest() == rec['sha256']
output = {'unchanged_coverage_helpers': unchanged, 'guard_only_coverage_helpers': guards, 'unchanged_finance_helpers': shared_finance, 'removed_policy_tokens_absent': True, 'backup_hashes_valid': True, 'save_load_source_unchanged': True}
# C118 did not modify persist.nut, whose current bytes still match HEAD.
import subprocess
persist_at_head = subprocess.check_output(['git', 'show', 'HEAD:ai/OpexAI/persist.nut'])
assert persist_at_head.replace(b'\r\n', b'\n') == (ai / 'persist.nut').read_bytes().replace(b'\r\n', b'\n')
(root / 'results/cleanup_c118_audit_20261012.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
print(json.dumps(output, indent=2))
