"""Synthetic host-side regression tests; never opens a future 40x10 result."""

import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "rail_roi_holdout_decision", ROOT / "sweeps/rail_roi_holdout_decision.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
SEEDS = MODULE.registered_seeds()
CAMPAIGN = "synthetic_holdout_n40_10y"
REF = "rail_roi_holdout_off"
ON = "rail_roi_holdout_on"
SHA = "a" * 64


def fake_result(*, profit_delta=3000, company_value_delta=10000):
    """Construct a structurally complete 40×10 harness-compatible specimen."""
    policies = {
        "reference": {"id": REF, "role": "reference", "settings": {
            "effective": {"rail_magic_simple_roi": 0, "rail_magic_simple_opcode": 0,
                          "other_setting": 123},
            "explicit": {"rail_magic_simple_roi": 0, "rail_magic_simple_opcode": 0}}},
        "variant": {"id": ON, "role": "variant", "settings": {
            "effective": {"rail_magic_simple_roi": 1, "rail_magic_simple_opcode": 0,
                          "other_setting": 123},
            "explicit": {"rail_magic_simple_roi": 1, "rail_magic_simple_opcode": 0}}},
    }
    manifest = {
        "campaign_id": CAMPAIGN,
        "source_bundle": {"sha256": SHA},
        "configuration": {"starting_year": 1970, "years": 10, "repeats": 1,
                          "seeds": SEEDS[:]},
        "adversary": {"id": "AAAHogEx"},
        "policies": [policies["reference"], policies["variant"]],
        "comparison": {
            "reference_policy_id": REF, "variant_policy_id": ON,
            "intervention_settings": ["rail_magic_simple_roi"],
            "effective_differences": {
                "rail_magic_simple_roi": {"reference": 0, "candidate": 1}},
        },
        "games": [],
    }
    result = {
        "campaign_id": CAMPAIGN, "source_bundle_sha256": SHA,
        "years": 10, "repeats": 1, "seeds": SEEDS[:],
        "expected_last_year": 1979, "expected_last_checkpoint": "1979-12-01",
        "games": [], "summary": [], "failed_runs": [],
        "policy_comparison": {
            "reference_policy_id": REF, "variant_policy_id": ON,
            "primary_metric": "profit_year", "value_guard_metric": "company_value",
            "comparison_complete": True, "metric_coverage_complete": True,
            "planned_pairs": 40, "complete_pairs": 40, "incomplete_pairs": [],
            "per_pair": [],
        },
    }
    for seed in SEEDS:
        ids = {
            role: f"{CAMPAIGN}:policy={id}:s{seed}:r0"
            for role, id in (("reference", REF), ("variant", ON))
        }
        statuses = {}
        profit_ref = 100000 + seed % 4000
        value_ref = 500000 + seed % 10000
        metrics = {
            "profit_year": {"reference_opex": profit_ref,
                            "variant_opex": profit_ref + profit_delta,
                            "policy_delta": profit_delta},
            "company_value": {"reference_opex": value_ref,
                              "variant_opex": value_ref + company_value_delta,
                              "policy_delta": company_value_delta},
        }
        for role, id in (("reference", REF), ("variant", ON)):
            manifest["games"].append({
                "company_slots": {"0": {"ai": "OpexAI", "policy_id": id},
                                  "1": {"ai": "AAAHogEx", "policy_id": "AAAHogEx"}},
                "game_id": ids[role], "policy_id": id, "seed": seed, "repeat": 0,
            })
            result["games"].append({
                "campaign_id": CAMPAIGN, "policy_id": id, "game_id": ids[role],
                "source_bundle_sha256": SHA, "seed": seed, "repeat": 0,
                "game_ok": True, "game_status": "complete",
                "unattributed_errors": [],
                "expected_last_checkpoint": "1979-12-01",
                "companies": {company: {
                    "run_ok": True, "horizon_complete": True, "status": "complete",
                    "failure_reason": None
                } for company in ("OpexAI", "AAAHogEx")},
            })
            for company in ("OpexAI", "AAAHogEx"):
                arm_profit = (profit_ref + (profit_delta if role == "variant" else 0)
                              if company == "OpexAI" else profit_ref + 500)
                arm_value = (value_ref + (company_value_delta if role == "variant" else 0)
                             if company == "OpexAI" else value_ref + 5000)
                result["summary"].append({
                    "seed": seed, "repeat": 0, "duel_policy_id": id,
                    "arm": company, "run_ok": True, "game_ok": True,
                    "last_year": 1979, "last_date": "1979-12-01",
                    "profit_year_coverage": "complete",
                    "profit_year_quarters_valid": 4,
                    "profit_year": arm_profit,
                    "company_value": arm_value,
                })
            for suffix in ("opex", "aaahogex"):
                statuses[f"{role}_{suffix}"] = {
                    "present": True, "run_ok": True, "game_ok": True,
                    "status": "complete", "failure_reason": None,
                    "game_id": ids[role],
                }
        result["policy_comparison"]["per_pair"].append({
            "seed": seed, "repeat": 0, "complete": True, "statuses": statuses,
            "metrics": copy.deepcopy(metrics),
            "annual_trajectory": [{
                "year": year,
                "reference_opex": profit_ref,
                "variant_opex": profit_ref + profit_delta,
            } for year in range(1970, 1980)],
        })
    return result, manifest


class HoldoutDecisionTest(unittest.TestCase):
    def test_pre_registration_exact_unique_seed_list(self):
        self.assertEqual(len(SEEDS), 40)
        self.assertEqual(len(set(SEEDS)), 40)
        self.assertEqual(SEEDS[:4], [241283, 362504, 432969, 909182])
        self.assertEqual(SEEDS[-4:], [606161, 746501, 983013, 810908])

    def test_dry_run_no_results_opened(self):
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture):
            code = MODULE.main(["--dry-run"])
        report = json.loads(capture.getvalue())
        self.assertEqual(code, 0)
        self.assertFalse(report["future_results_read"])
        self.assertEqual(report["seeds"], SEEDS)
        self.assertEqual(report["bootstrap_draws"], 20000)

    def test_valid_two_economic_ni_gates_pass_but_adoption_waits_opcode(self):
        data, manifest = fake_result()
        report = MODULE.assess(data, manifest, seeds=SEEDS)
        self.assertEqual(report["economic_verdict"], "PASS")
        self.assertEqual(report["adoption_verdict"], "INDETERMINATE")
        self.assertTrue(report["dataset_valid"])
        self.assertGreater(report["metrics"]["profit_year"]["bootstrap_one_sided95_lower_pct"], -1)
        self.assertGreater(report["metrics"]["company_value"]["bootstrap_one_sided95_lower_pct"], -1)

    def test_noninferiority_not_shown_is_indeterminate_not_proven_loss(self):
        data, manifest = fake_result(profit_delta=-1000)
        for i, pair in enumerate(data["policy_comparison"]["per_pair"]):
            # Centered close to -1%, but uncertainty straddles -1%.
            adjustment = -500 if i < 20 else 500
            values = pair["metrics"]["profit_year"]
            values["variant_opex"] += adjustment
            values["policy_delta"] += adjustment
            pair["annual_trajectory"][-1]["variant_opex"] += adjustment
            for row in data["summary"]:
                if (row["seed"] == pair["seed"] and row["duel_policy_id"] == ON
                        and row["arm"] == "OpexAI"):
                    row["profit_year"] += adjustment
        report = MODULE.assess(data, manifest, seeds=SEEDS)
        self.assertEqual(report["economic_verdict"], "INDETERMINATE")
        self.assertEqual(report["metrics"]["profit_year"]["classification"], "INDETERMINATE")
        self.assertEqual(report["adoption_verdict"], "INDETERMINATE")

    def test_materially_negative_profit_is_fail_even_if_value_passes(self):
        data, manifest = fake_result(profit_delta=-6000)
        report = MODULE.assess(data, manifest, seeds=SEEDS)
        self.assertEqual(report["economic_verdict"], "FAIL")
        self.assertEqual(report["metrics"]["profit_year"]["classification"], "FAIL")
        self.assertEqual(report["metrics"]["company_value"]["classification"], "PASS")
        self.assertEqual(report["adoption_verdict"], "FAIL")

    def test_requires_health_coverage_and_unique_40(self):
        cases = (
            lambda d, m: d["seeds"].pop(),
            lambda d, m: d["policy_comparison"]["per_pair"].append(
                copy.deepcopy(d["policy_comparison"]["per_pair"][0])),
            lambda d, m: d["policy_comparison"]["per_pair"][0].update(complete=False),
            lambda d, m: d["games"][0].update(game_ok=False),
            lambda d, m: d["summary"][0].update(profit_year_coverage="partial"),
            lambda d, m: d["failed_runs"].append({"failure_reason": "crash"}),
            lambda d, m: d["policy_comparison"].update(metric_coverage_complete=False),
            lambda d, m: d["policy_comparison"]["per_pair"][0]["metrics"]["profit_year"].update(
                policy_delta=123456789),
            lambda d, m: d["policy_comparison"]["per_pair"][0]["metrics"]["profit_year"].update(
                reference_opex=None),
            lambda d, m: d["summary"][0].update(company_value=1),
            lambda d, m: m["policies"][1]["settings"]["effective"].update(
                other_setting=124),
            lambda d, m: m["policies"][1]["settings"]["effective"].update(
                rail_magic_simple_opcode=1),
            lambda d, m: m["configuration"]["seeds"].reverse(),
            lambda d, m: d["policy_comparison"]["per_pair"][0]["statuses"][
                "reference_aaahogex"].update(run_ok=False),
        )
        for mutation in cases:
            with self.subTest(mutation=mutation):
                data, manifest = fake_result()
                mutation(data, manifest)
                report = MODULE.assess(data, manifest, seeds=SEEDS)
                self.assertFalse(report["dataset_valid"])
                self.assertEqual(report["economic_verdict"], "INDETERMINATE")
                self.assertEqual(report["adoption_verdict"], "INDETERMINATE")

    def test_cli_manifest_sha_check_and_json_out(self):
        data, manifest = fake_result()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / "fresh_roi_holdout.json"
            manifest_target = target.with_name(target.stem + ".manifest.json")
            raw = json.dumps(manifest).encode("utf-8")
            data["manifest_sha256"] = hashlib.sha256(raw).hexdigest()
            target.write_text(json.dumps(data), encoding="utf-8")
            manifest_target.write_bytes(raw)
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                code = MODULE.main([str(target)])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(stdout.getvalue())["economic_verdict"], "PASS")
            # Tampering with frozen manifest is invalid, not statistical FAIL.
            manifest_target.write_bytes(raw + b"\n")
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                code = MODULE.main([str(target)])
            report = json.loads(stdout.getvalue())
            self.assertEqual(code, 2)
            self.assertEqual(report["economic_verdict"], "INDETERMINATE")
            self.assertIn("SHA256", " ".join(report["errors"]))

    def test_bootstrap_seed0_is_deterministic_and_paired(self):
        data, manifest = fake_result()
        # Make the n=40 observations heterogeneous in both arms.
        for i, pair in enumerate(data["policy_comparison"]["per_pair"]):
            for metric in MODULE.METRICS:
                values = pair["metrics"][metric]
                values["variant_opex"] += i * 17
                values["policy_delta"] += i * 17
            pair["annual_trajectory"][-1]["variant_opex"] += i * 17
            for row in data["summary"]:
                if (row["seed"] == pair["seed"] and row["duel_policy_id"] == ON
                        and row["arm"] == "OpexAI"):
                    row["profit_year"] += i * 17
                    row["company_value"] += i * 17
        first = MODULE.assess(data, manifest, seeds=SEEDS)
        second = MODULE.assess(data, manifest, seeds=SEEDS)
        self.assertEqual(first["metrics"], second["metrics"])
        self.assertEqual(first["economic_verdict"], "PASS")


if __name__ == "__main__":
    unittest.main()
