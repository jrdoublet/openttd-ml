"""Host-only contracts for prospective ROI CI95; synthetic data, never live results."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sweeps"))
import rail_roi_strict_decision as mod


class StrictEconomicDecision(unittest.TestCase):
    def setUp(self):
        self.seeds = list(range(100,140))

    def observations(self, effect, spread=None):
        values={}
        for ix, seed in enumerate(self.seeds):
            ratio = effect if spread is None else effect + (spread if ix%2 else -spread)
            values[seed]={"profit_year":(100_000,100_000*(1+ratio/100)),
                          "company_value":(100_000,100_000*(1+ratio/100))}
        return values

    def test_gain_beyond_margin(self):
        result=mod.metric_interval(self.observations(3),self.seeds,"profit_year")
        self.assertEqual(result["classification"], "POSITIF")
        self.assertAlmostEqual(result["relative_delta_pct"], 3)
        self.assertGreater(result["confidence_interval_two_sided95_pct"][0], 1)

    def test_equivalence_requires_entire_interval(self):
        result=mod.metric_interval(self.observations(0),self.seeds,"company_value")
        self.assertEqual(result["classification"], "NEUTRE")
        uncertain=mod.metric_interval(self.observations(0,25),self.seeds,"profit_year")
        self.assertEqual(uncertain["classification"], "INDETERMINE")

    def test_loss_beyond_margin(self):
        result=mod.metric_interval(self.observations(-3),self.seeds,"profit_year")
        self.assertEqual(result["classification"], "NEGATIF")
        self.assertLess(result["confidence_interval_two_sided95_pct"][1], -1)

    def test_does_not_confuse_ni_with_equivalence(self):
        # Lower confidence bound > -1% but upper is far beyond +1%.
        result=mod.metric_interval(self.observations(1.5,5),self.seeds,"profit_year")
        self.assertEqual(result["classification"], "INDETERMINE")
        self.assertTrue(result["confidence_interval_two_sided95_pct"][0]>-1)

    def test_duplicate_seeds_fail_closed(self):
        with self.assertRaises(ValueError):
            mod.metric_interval(self.observations(0),self.seeds+[self.seeds[0]],"profit_year")

    def test_dry_run_does_not_read_economics(self):
        self.assertEqual(mod.main(["--dry-run"]),0)


if __name__=="__main__":
    unittest.main()
