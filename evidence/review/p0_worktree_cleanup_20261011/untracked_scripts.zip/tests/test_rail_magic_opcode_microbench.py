"""Host-only parity and fail-closed parsing tests for detached RAIL VM microbench."""

import importlib.util
from pathlib import Path
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "sweeps" / "rail_magic_opcode_microbench.py"
SPEC = importlib.util.spec_from_file_location("rail_magic_opcode_microbench", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class RailMagicOpcodeMicrobenchTest(unittest.TestCase):
    def test_detached_fixture_mirrors_production_score_and_topk(self):
        root = Path(__file__).resolve().parents[1]
        fixture = (root / "sweeps/fixtures/RailMagicOpcodeProbe/main.nut").read_text(encoding="utf-8")
        prod = (root / "ai/OpexAI/candidates.nut").read_text(encoding="utf-8")
        formulas = (
            "local adjustedRoi = (((", "* turnoverBonus) / 100) * freightBonus) / 100;",
            "ratio = opcodeRatio + (adjustedRoi * 15);",
            "if (best.len() >= k && candidate.ratio <= floor) continue;",
            "while (pos > 0 && best[pos - 1].ratio < candidate.ratio) pos--;",
            "best.insert(pos, candidate);", "if (best.len() > k) best.pop();",
        )
        for expression in formulas:
            self.assertIn(expression, prod)
            self.assertIn(expression, fixture)
        self.assertIn('if (!RMOP_SIMPLE_ROI && !RMOP_SIMPLE_OPCODE)', fixture)
        self.assertIn('if (!RAIL_MAGIC_SIMPLE_ROI && !RAIL_MAGIC_SIMPLE_OPCODE)', prod)

    def test_identical_pools_and_all_ties_keep_earliest_ids(self):
        self.assertEqual(MODULE.make_pool(64, True), MODULE.make_pool(64, True))
        for mode in ("OFF", "ROI", "OPCODE"):
            pool = MODULE.score_pool(MODULE.make_pool(64, True), mode)
            self.assertEqual([c["id"] for c in MODULE.topk(pool)], list(range(20)))
        self.assertGreater(MODULE.oracle()["mixed200"]["ROI"]["num_score_ties"], 0)
        self.assertGreater(MODULE.oracle()["mixed687"]["ROI"]["num_zero_roi"], 0)

    def test_integer_boundary_and_policy_formulas(self):
        for days, bonus in ((12, 130), (13, 115), (25, 115), (26, 100),
                            (45, 100), (46, 60)):
            x = [{"id": 0, "roi": 77, "profitAnnual": 1234,
                  "iterations": 67, "oneWayDays": days, "ratio": 0}]
            self.assertEqual(MODULE.score_pool(x, "OFF")[0]["ratio"],
                             1234 * 1000 // 67 + (77 * bonus // 100) * 15)
            self.assertEqual(MODULE.score_pool(x, "ROI")[0]["ratio"], 77)
            self.assertEqual(MODULE.score_pool(x, "OPCODE")[0]["ratio"],
                             1234 * 1000 // 67)

    def test_complete_fake_vm_output_and_aa_identical(self):
        expected = MODULE.oracle()
        lines = []
        for case, n, _ties, _shuffled in MODULE.CASE_SPECS:
            for rep in range(4):
                for arm in MODULE.ARMS:
                    op = "OFF" if arm in ("OFFA", "OFFB") else arm
                    e = expected[case][op]
                    score, rank = {"OFF": (100, 200), "ROI": (80, 220),
                                   "OPCODE": (70, 180)}[op]
                    lines.append(f"[script:0] [0] [I] RMOP|case={case}|rep={rep}|arm={arm}"
                                 f"|n={n}|score={score}|rank={rank}|score_ticks=0"
                                 f"|rank_ticks=0|check={e['check']}|best={e['best']}|len=20")
        lines.append("[script:0] [0] [I] RMOP_DONE")
        result = MODULE.report(MODULE.parse_engine_output("\n".join(lines)))
        self.assertTrue(result["a_a_exact_all_cases"])
        self.assertTrue(result["a_a_within_one_opcode_all_cases"])
        self.assertAlmostEqual(result["cases"]["mixed200"]["relative_to_aa_off"]
                               ["ROI"]["total"]["mean_pct"], 0)
        self.assertAlmostEqual(result["cases"]["mixed200"]["relative_to_aa_off"]
                               ["OPCODE"]["total"]["mean_pct"], -100 / 6)

    def test_truncation_and_missing_done_fail_closed(self):
        with self.assertRaisesRegex(ValueError, "missing RMOP_DONE"):
            MODULE.parse_engine_output("not a benchmark record")
        with self.assertRaisesRegex(ValueError, "missing/extra"):
            MODULE.report(MODULE.parse_engine_output("RMOP_DONE"))


if __name__ == "__main__":
    unittest.main()
