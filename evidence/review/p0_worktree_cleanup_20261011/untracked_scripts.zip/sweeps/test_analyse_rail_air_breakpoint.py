"""Fixtures du parseur de bascule AIR/RAIL, sans moteur ni Docker."""

import unittest

from sweeps.analyse_rail_air_breakpoint import parse_lines


class BreakpointParserTests(unittest.TestCase):
    def test_timestamps_and_gate_are_distinct(self):
        rows = [
            "[I] RAIL_AIR_BREAKPOINT date=1972-7-28 "
            "rail_first_rank=0 rail_rank=1 rail_score=500 air_rank=2 air_score=300 "
            "other_rank=2 rail_beats_air=1 rail_ahead_air=2\n",
            "[I] OPEX 1972-7-28 RAIL_N2_GATE admit=1 src=42 dst=99 "
            "rail_score=500 other_score=300\n",
            "[I] OPEX 1972-7-29 RAIL_N2 phase=second_start rid=7 peer=6\n",
        ]
        snaps, gates, second = parse_lines(rows)
        self.assertEqual(snaps[0]["date"], "1972-07-28")
        self.assertEqual(snaps[0]["rail_score"], "500")
        self.assertEqual(gates[0]["admit"], "1")
        self.assertEqual(second[0]["rid"], "7")

    def test_other_events_are_not_misclassified(self):
        snaps, gates, second = parse_lines([
            "[I] OPEX 1972-7-28 RAIL_N2 phase=search_start rid=2\n",
            "[I] OPEX 1972-7-28 RAIL_POOL_AUDIT head_mode=rail\n",
            "[I] RAIL_AIR_BREAKPOINT rail_beats_air=0\n",
            "[I] RAIL_AIR_BREAKPOINT date=1972-7-28 rail_beats_air=0\n",
        ])
        self.assertEqual((len(snaps), len(gates), len(second)), (1, 0, 0))


if __name__ == "__main__":
    unittest.main()
