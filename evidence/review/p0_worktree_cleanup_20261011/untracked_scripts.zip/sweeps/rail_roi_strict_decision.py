"""Strict prospective (not NI-only) ROI 40x10 paired holdout qualification.

The pre-registered populations, historical source provenance and health checks
come from rail_roi_holdout_decision.py. This script NEVER adopts based on
economic results alone: the independent matched-workload opcode and physical
gates remain obligatory. No new data are read with --dry-run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import random
import sys

import rail_roi_holdout_decision as base

# The first attempt (r1) ended without a complete result. The replacement
# campaign r2 retains the exact pre-registered seeds, settings and bundle SHA.
CAMPAIGN = "rail_magic_roi_strict_40x10_20261010_r2"
MARGIN = 1.0
PREREG = Path(__file__).resolve().parents[1] / "docs/rail_magic_roi_strict_40x10_prereg_20261010.md"


def metric_interval(pairs: dict, seeds: list[int], metric: str, draws: int = 20000) -> dict:
    """Paired ratio-of-means, 20k bootstrap, Random(0) and percentile CI95."""
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("Seeds must be non-empty and independent")
    values = [pairs[seed][metric] for seed in seeds]
    refs = [float(ref) for ref, _ in values]
    deltas = [float(var - ref) for ref, var in values]
    if any(ref <= 0 for ref in refs) or draws != 20000:
        raise ValueError("Invalid reference denominator or bootstrap contract")
    n = len(refs)
    rng = random.Random(0)
    ratios = []
    for _ in range(draws):
        chosen = [int(rng.random() * n) for __ in range(n)]
        ratios.append(100.0 * sum(deltas[i] for i in chosen) /
                      sum(refs[i] for i in chosen))
    ratios.sort()
    low, high = ratios[int(draws * .025)], ratios[int(draws * .975)]
    effect = 100.0 * sum(deltas) / sum(refs)
    if low > MARGIN:
        label = "POSITIF"
    elif low >= -MARGIN and high <= MARGIN:
        label = "NEUTRE"
    elif high < -MARGIN:
        label = "NEGATIF"
    else:
        label = "INDETERMINE"
    return {"relative_delta_pct": effect, "confidence_interval_two_sided95_pct": [low, high],
            "classification": label, "paired_seeds": n,
            "bootstrap_draws": draws, "bootstrap_seed": 0,
            "reference_mean": sum(refs)/n,
            "variant_mean": (sum(refs)+sum(deltas))/n,
            "delta_mean": sum(deltas)/n}


def worst_seed_details(result: dict, seeds: list[int], count: int = 5) -> dict:
    """Terminal independent worst/best seeds and observed AIR/RAIL stocks."""
    rows = result["policy_comparison"]["per_pair"]
    by_seed = {p["seed"]: p for p in rows}
    summary = {(p["seed"], p["duel_policy_id"]): p for p in result["summary"]
               if p.get("arm") == "OpexAI"}
    comp = result["policy_comparison"]
    refid, varid = comp["reference_policy_id"], comp["variant_policy_id"]

    def physical(row, mode, group):
        obj = row.get(group) or {}
        return obj.get(mode)

    out = []
    for seed in seeds:
        pair = by_seed[seed]
        p = pair["metrics"]["profit_year"]
        val = pair["metrics"]["company_value"]
        off, on = summary[(seed, refid)], summary[(seed, varid)]
        metric = {"seed": seed, "profit_off": p["reference_opex"],
                  "profit_on": p["variant_opex"], "profit_delta": p["policy_delta"],
                  "profit_delta_pct": (100 * p["policy_delta"] / p["reference_opex"]),
                  "value_delta": val["policy_delta"],
                  "annual_profit_deltas": {str(t["year"]): t["policy_delta"]
                                          for t in pair["annual_trajectory"]}}
        for group, modes in (("primary_vehicles_by_mode", ("rail", "air")),
                             ("stations_by_facility", ("rail", "airport"))):
            for mode in modes:
                a, b = physical(off, mode, group), physical(on, mode, group)
                key = f"{group}_{mode}"
                metric[key] = {"off": a, "on": b,
                               "delta": (b-a) if isinstance(a,(int,float))
                                       and isinstance(b,(int,float)) else None}
        out.append(metric)
    return {"worst_profit": sorted(out,key=lambda x:x["profit_delta"])[:count],
            "best_profit": sorted(out,key=lambda x:x["profit_delta"],reverse=True)[:count]}


def decide(result: dict, manifest: dict, sha: str, seeds: list[int]) -> dict:
    """Underlying validation fails closed, even if favorable metrics supplied."""
    validation = base.assess(result, manifest, seeds=seeds, manifest_sha256=sha)
    response = {"schema": "rail-roi-strict-ci95-v1", "campaign": result.get("campaign_id"),
                "dataset_valid": validation.get("dataset_valid", False),
                "validation_errors": validation.get("errors", []),
                "metrics": {}, "economic_status": "INDETERMINE",
                "opcode_status": "INDETERMINE (VM total non mesuré)",
                "adoption": "REJETER", "reason": "Aucune adoption sans preuve économique/opcode/physique complète"}
    if result.get("campaign_id") != CAMPAIGN:
        response["dataset_valid"] = False
        response["validation_errors"].append("wrong prospective campaign name")
    if not response["dataset_valid"]:
        return response
    pairs = {}
    for pair in result["policy_comparison"]["per_pair"]:
        pairs[pair["seed"]] = {
            metric: (pair["metrics"][metric]["reference_opex"],
                     pair["metrics"][metric]["variant_opex"])
            for metric in base.METRICS}
    response["metrics"] = {metric: metric_interval(pairs, seeds, metric)
                           for metric in base.METRICS}
    kinds = [m["classification"] for m in response["metrics"].values()]
    if all(v in ("POSITIF", "NEUTRE") for v in kinds):
        response["economic_status"] = "PASSE"
        response["reason"] = "Economie qualifiée; adoption toujours bloquée par opcode et physique"
    elif "NEGATIF" in kinds:
        response["economic_status"] = "NEGATIF"
        response["reason"] = "Au moins une régression économique au-delà de -1 % prouvée"
    else:
        response["economic_status"] = "INDETERMINE"
        response["reason"] = "Equivalence/gain économique non démontré; pas une perte prouvée"
    response["extreme_seeds"] = worst_seed_details(result, seeds)
    return response


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("result", nargs="?", type=Path)
    p.add_argument("--manifest", type=Path)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args(argv)
    if args.dry_run:
        if args.result or args.manifest:
            p.error("--dry-run does not permit result/manifest inputs")
        seeds = base.registered_seeds()
        print(json.dumps({"status":"DRY_RUN", "future_results_read":False,
                          "strict_prereg_exists":PREREG.exists(), "n":len(seeds),
                          "seeds":seeds, "bootstrap_draws":20000, "seed":0,
                          "metrics":list(base.METRICS),"margin_pct":MARGIN,
                          "ci":"two-sided 95%; positive L>+1, neutral both within +/-1, negative U<-1"},
                         indent=2))
        return 0
    if not args.result:
        p.error("provide result JSON or --dry-run")
    try:
        result = json.loads(args.result.read_text(encoding="utf-8"))
        mf = args.manifest or args.result.with_name(args.result.stem + ".manifest.json")
        raw = mf.read_bytes()
        manifest = json.loads(raw)
        report = decide(result, manifest, hashlib.sha256(raw).hexdigest(),
                        base.registered_seeds())
    except (OSError, ValueError, TypeError, KeyError) as error:
        report = {"dataset_valid":False,"adoption":"REJETER",
                  "economic_status":"INDETERMINE","error":str(error)}
    print(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))
    return 0 if report.get("dataset_valid") else 2


if __name__ == "__main__":
    sys.exit(main())
