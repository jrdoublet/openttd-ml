"""Fixture verifies that repeated portfolio snapshots are not independent ODs."""

import tempfile
from pathlib import Path
import unittest

from analyse_rail_magic_filter_p0 import analyse


class RailMagicFilterAnalysisTest(unittest.TestCase):
    def test_visits_and_unique_od(self):
        with tempfile.TemporaryDirectory() as d:
            log = Path(d) / "rail_magic_probe_seed42_r0.log"
            log.write_text("\n".join((
                "OPEX 1973-1-1 RAIL_MAGIC_CF phase=full ratio_reject=3 ratio_profit_sum=700 ratio_above_air=1 air_profit=100",
                "OPEX 1973-1-1 RAIL_MAGIC_ITEM kind=freight cargo=2 src=1 dst=2 profit=200",
                "OPEX 1973-2-1 RAIL_MAGIC_CF phase=full ratio_reject=3 ratio_profit_sum=700 ratio_above_air=1 air_profit=100",
                "OPEX 1973-2-1 RAIL_MAGIC_ITEM kind=freight cargo=2 src=1 dst=2 profit=200",
                "OPEX 1974-1-1 RAIL_MAGIC_CF phase=full ratio_reject=1 ratio_profit_sum=300 air_profit=0",
            )), encoding="utf-8")
            result = analyse([log])
            self.assertEqual(len(result), 2)
            self.assertEqual(result[0]["ratio_reject_visits"], 6)
            self.assertEqual(result[0]["ratio_profit_sum_visits"], 1400)
            self.assertEqual(result[0]["distinct_od_above_air"], 1)
            self.assertEqual(result[0]["distinct_od_profit_sum_above_air"], 200)
            self.assertEqual(result[1]["air_scored_snapshots"], 0)


if __name__ == "__main__":
    unittest.main()
