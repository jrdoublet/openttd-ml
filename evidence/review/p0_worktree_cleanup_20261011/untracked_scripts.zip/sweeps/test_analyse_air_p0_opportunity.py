import tempfile
import unittest
from pathlib import Path

from analyse_air_p0_opportunity import analyse, parse_lines


BUY = ("[1] AIR_P0_OPPORTUNITY kind=BUY id=721.434.9.0 "
       "date=1972-7-15 tick=434 line=9 rank=0 before=2 after=3 "
       "cash_before=100000 cash_after=61000 available_before=80000 "
       "selected_air=2 air_before=0 air_after=2 raw_air=3 "
       "raw_only=1 raw_examples=1")
S1 = ("[1] AIR_P0_OPPORTUNITY kind=SELECTED id=721.434.9.0 side=after "
      "seq=0 rank=1 mode=air key=pax|0|111|222 profit=50000 finance=65000 fund_score=290")
S2 = ("[1] AIR_P0_OPPORTUNITY kind=SELECTED id=721.434.9.0 side=after "
      "seq=0 rank=5 mode=air key=pax|0|333|444 profit=60000 finance=75000 fund_score=210")
RAW = ("[1] AIR_P0_OPPORTUNITY kind=RAW_ONLY id=721.434.9.0 reason=unknown "
       "seq=0 rank=-1 mode=air key=pax|0|555|666 profit=5000 finance=120000")
REJECT = ("[1] AIR_P0_OPPORTUNITY kind=PRIOR_REJECT id=721.434.9.0 rank=0 "
          "src=111 dst=222 reason=batch_plan_dead")


class AirOpportunityParserTests(unittest.TestCase):
    def test_complete_group_preserves_identity_rank_and_unknown_constructibility(self):
        purchases, warnings = parse_lines(
            ["unrelated", BUY, S1, S2, RAW, REJECT], "air_seed42_r0.log")
        self.assertEqual(warnings, [])
        self.assertEqual(len(purchases), 1)
        p = purchases[0]
        self.assertEqual(p["seed"], 42)
        self.assertTrue(p["telemetry_complete"])
        self.assertEqual([x["rank"] for x in p["selected"]], ["1", "5"])
        self.assertEqual(p["selected"][0]["key"], "pax|0|111|222")
        self.assertEqual(p["prior_reject"][0]["reason"], "batch_plan_dead")
        self.assertIsNone(p["proven_better_buildable_air"])
        self.assertFalse(p["constructibility_verified"])

    def test_missing_child_is_incomplete_even_when_finance_and_score_exist(self):
        purchases, warnings = parse_lines([BUY, S1, RAW], "air_seed512_r0.log")
        self.assertFalse(purchases[0]["telemetry_complete"])
        self.assertEqual(warnings[0]["issue"], "incomplete_purchase_telemetry")

    def test_orphan_event_and_duplicate_buy_do_not_create_false_purchase(self):
        purchases, warnings = parse_lines([S1, BUY, BUY, S1, S2, RAW],
                                          "air_seed65537_r0.log")
        self.assertEqual(len(purchases), 1)
        self.assertEqual([w["issue"] for w in warnings],
                         ["orphan_event", "duplicate_buy"])
        self.assertTrue(purchases[0]["telemetry_complete"])

    def test_same_event_id_in_different_logs_remains_two_purchases(self):
        with tempfile.TemporaryDirectory() as directory:
            p1 = Path(directory) / "air_seed42_r0.log"
            p2 = Path(directory) / "air_seed512_r0.log"
            for p in (p1, p2):
                p.write_text("\n".join([BUY, S1, S2, RAW]) + "\n",
                             encoding="utf-8")
            report = analyse([p1, p2])
            self.assertEqual(report["summary"]["purchases_logged"], 2)
            self.assertEqual(report["summary"]["telemetry_complete"], 2)
            self.assertEqual(report["summary"]["better_buildable_proven"], 0)
            self.assertEqual([p["seed"] for p in report["purchases"]], [42, 512])


if __name__ == "__main__":
    unittest.main()
