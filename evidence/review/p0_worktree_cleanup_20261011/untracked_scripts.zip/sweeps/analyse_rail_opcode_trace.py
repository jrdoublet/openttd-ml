"""Find first observable decision-log differences in a paired engine replay.

Host-only. AILog with -d script=4 is an intrusive *diagnostic* condition;
event dates are in-game dates and do not expose VM ticks. No causal claim is
made solely from the first mismatched log line.
"""

import argparse
from itertools import zip_longest
import json
from pathlib import Path
import re


EVENT = re.compile(r"\[0\] \[[IEW]\] OPEX (\d{4}-\d{1,2}-\d{1,2}) ([A-Z_0-9]+)(?: (.*))?$")
EVENT_KINDS = (
    "TASK", "VIVIER_GEN", "PROJECT_CHOSEN", "PROJECT_BUILD", "PROJECT_BUILT",
    "RAIL_PREPAIR", "VIVIER_REJECT",
)


def parse_events(path):
    events = []
    with Path(path).open(encoding="utf-8", errors="replace") as stream:
        for line in stream:
            match = EVENT.search(line.rstrip("\r\n"))
            if match:
                date, kind, fields = match.groups()
                date_parts = [int(v) for v in date.split("-")]
                events.append({"date": "%04d-%02d-%02d" % tuple(date_parts),
                               "kind": kind, "fields": fields or ""})
    return events


def first_difference(left, right, kinds=None):
    if kinds is not None:
        left = [x for x in left if x["kind"] in kinds]
        right = [x for x in right if x["kind"] in kinds]
    for index, (a, b) in enumerate(zip_longest(left, right)):
        if a != b:
            return {"index": index, "off": a, "on": b,
                    "before_off": left[max(0, index - 2):index],
                    "before_on": right[max(0, index - 2):index]}
    return None


def compare_logs(left, right):
    off, on = parse_events(left), parse_events(right)
    return {
        "off_event_count": len(off), "on_event_count": len(on),
        "first_all_opex": first_difference(off, on),
        "first_task": first_difference(off, on, {"TASK"}),
        "first_rail_generation": first_difference(off, on, {"VIVIER_GEN"}),
        "first_project_chosen": first_difference(off, on, {"PROJECT_CHOSEN"}),
        "first_project_or_task": first_difference(off, on, {"TASK", "PROJECT_CHOSEN"}),
        "kinds": {k: {"off": sum(e["kind"] == k for e in off),
                       "on": sum(e["kind"] == k for e in on)} for k in EVENT_KINDS},
        "limitations": [
            "first mismatch is only the first logged difference, not necessarily root cause",
            "date has day precision, not tick or scheduler opclock",
            "decision_log=1 and script-debug=4 perturb normal runtime and can move the divergence",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", type=Path, required=True)
    parser.add_argument("--off-policy", required=True)
    parser.add_argument("--on-policy", required=True)
    parser.add_argument("--seeds", type=int, nargs="+", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = {}
    for seed in args.seeds:
        off = args.engine / f"{args.off_policy}_seed{seed}_r0.log"
        on = args.engine / f"{args.on_policy}_seed{seed}_r0.log"
        report[str(seed)] = compare_logs(off, on)
    if args.out.exists():
        parser.error("refusing to overwrite existing report: " + str(args.out))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for seed, row in report.items():
        keys = ("first_all_opex", "first_rail_generation", "first_task", "first_project_chosen")
        print(seed, json.dumps({key: row[key] for key in keys}, ensure_ascii=False))


if __name__ == "__main__":
    main()
