"""Contracts for removing local RAIL ranking bonuses while keeping opcodeRatio."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


class RailMagicSimpleOpcodeTest(unittest.TestCase):
    def test_off_by_default_and_loaded(self):
        info = source("info.nut")
        setting = re.search(
            r'name = "rail_magic_simple_opcode"[\s\S]*?flags = AICONFIG_BOOLEAN',
            info,
        )
        self.assertIsNotNone(setting)
        for difficulty in ("easy", "medium", "hard", "custom"):
            self.assertIn(difficulty + "_value = 0", setting.group())
        self.assertIn('RAIL_MAGIC_SIMPLE_OPCODE <- false;', source("globals_pre.nut"))
        self.assertIn(
            'RAIL_MAGIC_SIMPLE_OPCODE = AIController.GetSetting("rail_magic_simple_opcode") != 0;',
            source("settings.nut"),
        )

    def test_off_preserves_division_order_and_on_needs_no_project_quote(self):
        candidates = source("candidates.nut")
        self.assertIn('local opcodeRatio = (economics.profitAnnual * 1000) / iterations;', candidates)
        self.assertIn('else if (RAIL_MAGIC_SIMPLE_OPCODE) {\n    /* Mesure deja calculee', candidates)
        self.assertIn('ratio = opcodeRatio;', candidates)
        self.assertIn('local adjustedRoi = (((economics.roi * turnoverBonus) / 100) * freightBonus) / 100;', candidates)
        self.assertIn('ratio = opcodeRatio + (adjustedRoi * 15);', candidates)
        self.assertIn('RAIL_MAGIC_SIMPLE_OPCODE ? chainOpcodeRatio : chainOpcodeRatio + (chainRoi * 15)', candidates)
        self.assertIn('if (V88_CHAIN_FORCE) chainCandidate.ratio = 1000000000;', candidates)
        self.assertIn('local best = OpexRailEconomicTopK(all, TOP_K);', candidates)
        for name in ('task_rail.nut', 'projects_selection.nut', 'projects_builders.nut', 'builder_rail.nut'):
            self.assertNotIn('RAIL_MAGIC_SIMPLE_OPCODE', source(name))


if __name__ == "__main__":
    unittest.main()
