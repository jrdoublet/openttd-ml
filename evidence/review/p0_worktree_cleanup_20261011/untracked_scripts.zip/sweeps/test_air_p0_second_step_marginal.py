"""P0 : contracts of the OFF-first depth-correct C121 cold step (no engine)."""
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


class AirP0SecondStepContract(unittest.TestCase):
    def test_setting_is_off_at_every_difficulty(self):
        info = source("info.nut")
        block = info.split('name = "air_p0_second_step_marginal",', 1)[1].split('});', 1)[0]
        for difficulty in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertRegex(block, rf"\b{difficulty}\s*=\s*0\b")
        self.assertIn("AIR_P0_SECOND_STEP_MARGINAL <- false;", source("globals_pre.nut"))
        self.assertIn('AIR_P0_SECOND_STEP_MARGINAL = AIController.GetSetting("air_p0_second_step_marginal") != 0;', source("settings.nut"))

    def test_model_estimates_one_extra_fixed_depth_only_under_toggle(self):
        c = source("air_catalog_c121.nut")
        self.assertIn("local secondCapture = (AIR_P0_MARGIN_PROBE || AIR_P0_SECOND_STEP_MARGINAL)", c)
        self.assertIn("have = actualN + 1, values = {}", c)
        self.assertIn("actualN + 1 < target.planes", c)
        self.assertIn("((actualN + 1) in secondCapture.values)", c)
        self.assertIn("((actualN + 2) in secondCapture.values)", c)
        self.assertIn("secondAfter.profitAnnual - secondBefore.profitAnnual", c)
        self.assertIn("secondAfter.revenueAnnual - secondBefore.revenueAnnual", c)
        econ = source("air_economics_c121.nut")
        self.assertIn("engineContext = null,\n                                 marginalOut = null)", econ)
        self.assertIn("openingOut, engineContext, marginalOut);", econ)
        self.assertIn("line.c121SecondStepHave <- result.c121SecondStepHave", c)
        self.assertIn("line.c121SecondStepProfit <- result.c121SecondStepProfit", c)
        self.assertIn("line.c121SecondStepRevenue <- result.c121SecondStepRevenue", c)
        self.assertIn("line.c121MarginalSamples <- 0;", c)

    def test_reader_requires_cold_sample_and_exact_depth(self):
        c = source("projects_builders.nut")
        pattern = (r"local secondStepAvailable = \(AIR_P0_MARGIN_PROBE \|\| AIR_P0_SECOND_STEP_MARGINAL\)\s*"
                   r"&& !C121_AIR_VISIBLE_COMPETITION && samples <= 0\s*"
                   r"&& \(\"c121SecondStepHave\" in line\) && line.c121SecondStepHave == have\s*"
                   r"&& \(\"c121SecondStepProfit\" in line\) && \(\"c121SecondStepRevenue\" in line\);\s*"
                   r"[^}]*if \(secondStepAvailable && AIR_P0_SECOND_STEP_MARGINAL\) \{\s*"
                   r"perPlaneProfit = line.c121SecondStepProfit;\s*"
                   r"perPlaneRevenue = line.c121SecondStepRevenue;")
        self.assertRegex(c, pattern)
        # The observed C121 feedback remains authoritative once samples>0.
        self.assertIn('if (samples > 0 && ("c121LastMarginalProfit" in line)', c)

    def test_counterexample_old_marginal_is_not_second_marginal(self):
        # Saturating demand: a positive average is not a positive next-unit margin.
        modeled_profit = {1: 100_000, 2: 165_000, 3: 180_000, 4: 172_000}
        first = modeled_profit[2] - modeled_profit[1]
        second = modeled_profit[3] - modeled_profit[2]
        third = modeled_profit[4] - modeled_profit[3]
        self.assertEqual((first, second, third), (65_000, 15_000, -8_000))
        self.assertNotEqual(first, second)


if __name__ == "__main__":
    unittest.main()
