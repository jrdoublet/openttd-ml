from pathlib import Path
import tempfile
import unittest

from analyse_rail_ready_admission import read_logs


class ReadyAdmissionAnalyzerTest(unittest.TestCase):
    def test_repeated_ready_defer_then_built_over_air(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "probe_seed42_r0.log"
            path.write_text(
                "[dbg] OPEX 1973-1-1 RAIL_READY_ADMISSION phase=before search_tick=10 "
                "age_days=200 src=1 dst=2 cargo=3 kind=freight iters=800 "
                "rank=2 score=20 finance=42000 available=100000 first_rank=0 "
                "first_mode=air first_score=25 first_finance=35000 first_tier=1 "
                "ahead_affordable=2 c77_defer=1\n"
                "[dbg] OPEX 1973-1-3 RAIL_READY_ADMISSION phase=before search_tick=10 "
                "age_days=202 src=1 dst=2 cargo=3 kind=freight iters=800 "
                "rank=2 score=20 finance=42000 available=100000 first_rank=0 "
                "first_mode=air first_score=25 first_finance=35000 first_tier=1 "
                "ahead_affordable=2 c77_defer=0\n"
                "[dbg] OPEX 1973-1-3 RAIL_READY_ADMISSION phase=after search_tick=10 built=1\n"
                "[dbg] OPEX 1973-1-4 RAIL_READY_UPGRADE phase=start tick=21 line=7\n",
                encoding="utf-8",
            )
            got = read_logs(Path(tmp))
            self.assertEqual(got["games_with_log"], 1)
            self.assertEqual(got["unique_ready"], 1)
            self.assertEqual(got["upgrade_starts"], 1)
            self.assertEqual(got["summary"]["higher_rank_eligible"], 1)
            self.assertEqual(got["summary"]["built_over_air"], 1)
            self.assertEqual(got["summary"]["c77_deferred"], 1)
            self.assertEqual(got["ready"][0]["visits"], 2)

    def test_absent_in_top64_is_unknown_not_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "arm_seed100_r0.log").write_text(
                "OPEX 1972-8-1 RAIL_READY_ADMISSION phase=before search_tick=33 "
                "src=10 dst=20 cargo=1 kind=pax rank=-1 first_rank=0 "
                "first_mode=fleet available=90000 c77_defer=0\n",
                encoding="utf-8",
            )
            got = read_logs(Path(tmp))
            self.assertEqual(got["summary"]["missing_from_portfolio"], 1)
            self.assertEqual(got["summary"]["no_build_result_observed"], 1)
            self.assertIsNone(got["ready"][0]["built"])


if __name__ == "__main__":
    unittest.main()
