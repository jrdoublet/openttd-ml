"""Annual paired RAIL preselect A/B, using closed-quarter savegame checkpoints.

The signs are retained snapshots, NOT an exhaustive finance/project audit.
`rail_attempt_ops_signs` is a lower-bound diagnostic where available.
"""

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


FIELDS = (
    "profit_year", "company_value", "rail_vehicles", "air_vehicles",
    "rail_station_facilities", "airport_facilities",
    "project_build_signs", "rail_attempt_opcodes_signs",
    "rail_attempt_success_signs", "rail_attempt_fail_signs",
)


def _int_or_none(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def _checkpoint(record):
    date = record.get("date", "")
    if not date.endswith("-12-01"):
        return None
    run = record.get("run")
    if not isinstance(run, list) or len(run) < 3 or run[0] != "OpexAI":
        return None
    year = int(date[:4])
    by_mode = record.get("primary_vehicles_by_mode") or {}
    by_facility = record.get("stations_by_facility") or {}
    all_attempts = record.get("rail_attempt_sign_by_year") or {}
    attempt = all_attempts.get(str(year), {})
    reasons = attempt.get("reasons", {})
    # Signs often drop historical/expired outcomes; absence does not prove zero.
    coverage = record.get("rail_attempt_sign_coverage")
    return {
        "seed": int(run[1]), "repeat": int(run[2]), "year": year,
        "policy": record["policy_id"],
        "profit_year": _int_or_none(record.get("profit_year")),
        "company_value": _int_or_none(record.get("company_value")),
        "rail_vehicles": _int_or_none(by_mode.get("rail")),
        "air_vehicles": _int_or_none(by_mode.get("air")),
        "rail_station_facilities": _int_or_none(by_facility.get("rail")),
        "airport_facilities": _int_or_none(by_facility.get("airport")),
        "project_build_signs": _int_or_none(
            (record.get("project_builds_sign_by_year") or {}).get(str(year))
        ),
        "rail_attempt_opcodes_signs": (
            _int_or_none(attempt.get("opcodes")) if coverage == "retained_signs_only" else None
        ),
        "rail_attempt_success_signs": (
            _int_or_none(reasons.get("OK")) if coverage == "retained_signs_only" else None
        ),
        "rail_attempt_fail_signs": (
            sum(value for key, value in reasons.items() if key != "OK")
            if coverage == "retained_signs_only" else None
        ),
        "rail_attempt_sign_coverage": coverage,
        "profit_coverage": record.get("profit_year_coverage"),
    }


def analyse(jsonl, variant="rail_magic_economic"):
    paired = defaultdict(dict)
    with Path(jsonl).open(encoding="utf-8") as f:
        for line in f:
            item = _checkpoint(json.loads(line))
            if item is None or item["policy"] not in ("reference", variant):
                continue
            key = (item["seed"], item["repeat"], item["year"])
            if item["policy"] in paired[key]:
                raise ValueError(f"duplicate annual checkpoint: {key}, {item['policy']}")
            paired[key][item["policy"]] = item

    rows = []
    for (seed, repeat, year), policies in sorted(paired.items()):
        ref, var = policies.get("reference"), policies.get(variant)
        if ref is None or var is None:
            raise ValueError(f"missing paired annual policy: {seed=} {repeat=} {year=}")
        row = {"seed": seed, "repeat": repeat, "year": year}
        for metric in FIELDS:
            a, b = ref.get(metric), var.get(metric)
            row[f"reference_{metric}"] = a
            row[f"variant_{metric}"] = b
            row[f"delta_{metric}"] = b - a if a is not None and b is not None else None
        row["reference_rail_attempt_coverage"] = ref["rail_attempt_sign_coverage"]
        row["variant_rail_attempt_coverage"] = var["rail_attempt_sign_coverage"]
        row["reference_profit_coverage"] = ref["profit_coverage"]
        row["variant_profit_coverage"] = var["profit_coverage"]
        rows.append(row)
    return rows


def write_report(jsonl, output, variant="rail_magic_economic"):
    rows = analyse(jsonl, variant)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    with output.with_suffix(".csv").open("w", newline="", encoding="utf-8") as file:
        if rows:
            writer = csv.DictWriter(file, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jsonl", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--variant", default="rail_magic_economic")
    args = parser.parse_args()
    rows = write_report(args.jsonl, args.out, args.variant)
    by_year = defaultdict(list)
    for row in rows:
        by_year[row["year"]].append(row)
    for year, subset in sorted(by_year.items()):
        summary = {}
        for name in ("profit_year", "company_value", "rail_vehicles", "air_vehicles",
                     "rail_station_facilities", "airport_facilities", "project_build_signs",
                     "rail_attempt_opcodes_signs"):
            values = [r["delta_" + name] for r in subset if r["delta_" + name] is not None]
            summary[name] = round(sum(values) / len(values), 3) if values else None
            summary[name + "_coverage"] = len(values)
        print(json.dumps({"year": year, "pairs": len(subset), "mean_deltas": summary}))


if __name__ == "__main__":
    main()
