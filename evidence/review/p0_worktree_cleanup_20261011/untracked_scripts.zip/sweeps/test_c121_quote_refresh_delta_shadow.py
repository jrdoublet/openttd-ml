"""Guardrails for the OFF-only causal C121 quote-refresh observation."""
from pathlib import Path
import unittest

AI = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def read(path):
    return (AI / path).read_text(encoding="utf-8")


class QuoteDeltaShadowContracts(unittest.TestCase):
    def test_default_and_activation(self):
        setting = read("info.nut").split('name = "c121_quote_refresh_delta_shadow"', 1)[1].split("});", 1)[0]
        for diff in ("easy", "medium", "hard", "custom"):
            self.assertIn(f"{diff}_value = 0", setting)
        self.assertIn("C121_QUOTE_REFRESH_DELTA_SHADOW <- false;", read("globals_pre.nut"))
        self.assertIn('C121_QUOTE_REFRESH_DELTA_SHADOW = C121_EXACT_PROD_INVALIDATION\n      && AIController.GetSetting("c121_quote_refresh_delta_shadow") != 0;', read("settings.nut"))

    def test_no_repeated_engine_choice_or_endpoint_rebuild(self):
        source = read("air_catalog_c121.nut")
        f = source.split("function OpexC121QuoteRefreshDeltaObserve(", 1)[1].split("\nfunction OpexC121CatalogChoice(", 1)[0]
        for forbidden in ("OpexC121ChooseRoutePlane(", "OpexC121PrepareDemandShadow(",
                          "C121_CATALOG_CACHE.rawset(", "OpexC121InvalidateEndpointGeometry("):
            self.assertNotIn(forbidden, f)
        self.assertIn("old_valid=", f)
        self.assertIn("new_valid=", f)
        self.assertIn("old_profit=", f)
        self.assertIn("new_profit=", f)
        self.assertIn("old_pax_a=", f)
        self.assertIn("new_mail_b=", f)

    def test_only_observes_existing_town_miss_before_cache_replacement(self):
        body = read("air_catalog_c121.nut").split("function OpexC121CatalogChoice(", 1)[1].split("\nfunction ", 1)[0]
        self.assertIn('C121_QUOTE_REFRESH_DELTA_SHADOW && reason == "town"', body)
        self.assertIn("previousQuoteShadow = entry;", body)
        self.assertIn("OpexC121QuoteRefreshDeltaObserve(key, previousQuoteShadow, choice, plan,", body)
        self.assertIn("C121_CATALOG_CACHE.rawset(key, {", body)
        self.assertLess(body.index("OpexC121QuoteRefreshDeltaObserve(key, previousQuoteShadow, choice, plan,"),
                        body.index("C121_CATALOG_CACHE.rawset(key, {"))
        self.assertEqual(body.count("choice = OpexC121ChooseRoutePlane(catalog, plan, lines);"), 1)


if __name__ == "__main__":
    unittest.main()
