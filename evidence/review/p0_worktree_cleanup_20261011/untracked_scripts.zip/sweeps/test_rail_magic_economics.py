"""Contracts for RAIL opportunity-filter isolation (defaults and call sites)."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


class RailMagicContract(unittest.TestCase):
    def test_off_by_default_and_independent_probe(self):
        info, settings, globals_pre = map(
            source, ("info.nut", "settings.nut", "globals_pre.nut")
        )
        for setting, symbol in (
            ("rail_economic_preselect", "RAIL_ECONOMIC_PRESELECT"),
            ("rail_magic_shadow", "RAIL_MAGIC_SHADOW"),
            ("rail_magic_admission_only", "RAIL_MAGIC_ADMISSION_ONLY"),
            ("rail_magic_rank_only", "RAIL_MAGIC_RANK_ONLY"),
            ("rail_magic_astar_only", "RAIL_MAGIC_ASTAR_ONLY"),
        ):
            block = re.search(
                r'name = "' + setting + r'"[\s\S]*?flags = AICONFIG_BOOLEAN', info
            )
            self.assertIsNotNone(block)
            for difficulty in ("easy", "medium", "hard", "custom"):
                self.assertIn(f"{difficulty}_value = 0", block.group())
            self.assertIn(f'{symbol} = AIController.GetSetting("{setting}") != 0;', settings)
            self.assertIn(f'{symbol} <- false;', globals_pre)

    def test_filter_retains_positive_candidate_without_legacy_floor(self):
        candidates = source("candidates.nut")
        self.assertIn(
            "&& !RAIL_MAGIC_ADMISSION_ONLY && !RAIL_MAGIC_SHADOW) return null;",
            candidates,
        )
        self.assertIn(
            "&& !RAIL_ECONOMIC_PRESELECT && !RAIL_MAGIC_ADMISSION_ONLY) {",
            candidates,
        )
        self.assertIn("stats.magicRejected.append(candidate);", candidates)
        self.assertIn("return (RAIL_ECONOMIC_PRESELECT || RAIL_MAGIC_RANK_ONLY)", candidates)
        self.assertIn("? OpexTopKFund(all, k) : OpexTopK(all, k);", candidates)
        # Admission seule : le filtre est la seule lecture de ce drapeau.
        self.assertEqual(candidates.count("RAIL_MAGIC_ADMISSION_ONLY"), 2)
        self.assertNotIn("RAIL_MAGIC_ADMISSION_ONLY", source("task_rail.nut"))

    def test_rail_only_presort_and_search_floor(self):
        candidates = source("candidates.nut")
        projects = source("projects.nut")
        task = source("task_rail.nut")
        self.assertIn("OpexTopK(all, ROAD_TOP_K);", candidates)
        self.assertIn("OpexTopK(liveRoad, ROAD_TOP_K);", projects)
        self.assertIn("OpexRailEconomicTopK(liveRail, TOP_K);", projects)
        self.assertEqual(task.count("(RAIL_ECONOMIC_PRESELECT || RAIL_MAGIC_ASTAR_ONLY) ? 0 : MIN_RATIO"), 2)
        self.assertEqual(task.count("(RAIL_ECONOMIC_PRESELECT || RAIL_MAGIC_ASTAR_ONLY || isPaxNear) ? 0 : MIN_RATIO"), 2)
        self.assertNotIn("RAIL_MAGIC_RANK_ONLY", task)
        self.assertNotIn("RAIL_MAGIC_ADMISSION_ONLY", task)

    def test_shadow_uses_same_quote_then_blocks_legacy_publication(self):
        candidates = source("candidates.nut")
        projects = source("projects.nut")
        self.assertIn("OpexProjectFromCandidate(candidate)", candidates)
        self.assertIn("OpexProjectFundProfit(paper)", candidates)
        self.assertIn("OpexProjectFinanceCapital(paper)", candidates)
        self.assertIn("RAIL_MAGIC_ITEM", candidates)
        self.assertIn("RAIL_MAGIC_CF", candidates)
        self.assertIn("local oldBest = OpexTopKLegacy(floorCandidates, TOP_K);", candidates)
        self.assertIn("local noBonusBest = OpexTopKLegacy(oldNoBonus, TOP_K);", candidates)
        self.assertIn("if (RAIL_MAGIC_SHADOW) OpexRailMagicCounterfactual(rail, alternatives, capitalBudget);", projects)


if __name__ == "__main__":
    unittest.main()
