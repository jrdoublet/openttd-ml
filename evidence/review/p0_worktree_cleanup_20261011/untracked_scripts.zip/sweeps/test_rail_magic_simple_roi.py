"""Contracts for the isolated, low-cost RAIL local ROI ranking experiment."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


class RailMagicSimpleRoiContract(unittest.TestCase):
    def test_flag_off_for_every_difficulty(self):
        info = (ROOT / "info.nut").read_text(encoding="utf-8")
        block = re.search(
            r'name = "rail_magic_simple_roi"[\s\S]*?flags = AICONFIG_BOOLEAN', info
        )
        self.assertIsNotNone(block)
        for difficulty in ("easy", "medium", "hard", "custom"):
            self.assertIn(f"{difficulty}_value = 0", block.group())
        self.assertIn(
            'RAIL_MAGIC_SIMPLE_ROI = AIController.GetSetting("rail_magic_simple_roi") != 0;',
            (ROOT / "settings.nut").read_text(encoding="utf-8"),
        )
        self.assertIn(
            'RAIL_MAGIC_SIMPLE_ROI <- false;',
            (ROOT / "globals_pre.nut").read_text(encoding="utf-8"),
        )

    def test_only_local_rail_rank_changes_and_no_second_quote(self):
        source = (ROOT / "candidates.nut").read_text(encoding="utf-8")
        self.assertIn("if (!RAIL_MAGIC_SIMPLE_ROI && !RAIL_MAGIC_SIMPLE_OPCODE) {", source)
        self.assertIn("if (RAIL_MAGIC_SIMPLE_ROI) {\n    ratio = effectiveRoi;", source)
        self.assertIn("ratio = opcodeRatio + (adjustedRoi * 15);", source)
        self.assertIn(
            "ratio = RAIL_MAGIC_SIMPLE_ROI ? chainRoi\n"
            "                  : (RAIL_MAGIC_SIMPLE_OPCODE ? chainOpcodeRatio : chainOpcodeRatio + (chainRoi * 15))",
            source,
        )
        self.assertIn("local best = OpexRailEconomicTopK(all, TOP_K);", source)
        self.assertNotIn("RAIL_MAGIC_SIMPLE_ROI", (ROOT / "task_rail.nut").read_text(encoding="utf-8"))
        self.assertNotIn("RAIL_MAGIC_SIMPLE_ROI", (ROOT / "projects_selection.nut").read_text(encoding="utf-8"))
        self.assertNotIn("RAIL_MAGIC_SIMPLE_ROI", (ROOT / "projects_builders.nut").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
