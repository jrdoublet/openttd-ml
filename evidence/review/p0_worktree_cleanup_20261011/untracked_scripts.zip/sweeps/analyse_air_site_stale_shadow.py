#!/usr/bin/env python3
"""Comptage des expositions AIR_SITE_STALE, sans conclusion de causalité.

python sweeps/analyse_air_site_stale_shadow.py results/<campaign>_engine --json results/report.json
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re


LINE = re.compile(r"\bAIR_SITE_STALE\s+(.*)$")
SEED = re.compile(r"seed(-?\d+)")


def parse(path):
    records = []
    with path.open(encoding="utf-8", errors="replace") as file:
        for line in file:
            match = LINE.search(line)
            if match is None:
                continue
            kv = dict(word.split("=", 1) for word in match.group(1).split() if "=" in word)
            values = {}
            for name in ("rank", "date", "age", "src", "dst", "new", "anchor_a", "anchor_b",
                         "old_a", "old_b", "now_a", "now_b", "missing", "invalid", "changed",
                         "shift", "need", "fresh_need", "cash", "flip"):
                try:
                    values[name] = int(kv[name])
                except (ValueError, KeyError):
                    values[name] = None
            values["path"] = kv.get("path", "unknown")
            records.append(values)
    seed = SEED.search(path.name)
    ages = [r["age"] for r in records if r["age"] is not None and r["age"] >= 0]
    changed = [r for r in records if r["changed"] == 1]
    risk = [r for r in records if r["invalid"] == 1 or r["missing"] == 1 or r["flip"] == 1]
    return {
        "file": path.name, "seed": int(seed.group(1)) if seed else None,
        "events": len(records), "path_counts": dict(Counter(r["path"] for r in records)),
        "aged_events": sum(x > 0 for x in ages), "known_ages": len(ages),
        "max_age_days": max(ages) if ages else None,
        "changed_events": len(changed),
        "invalid_events": sum(r["invalid"] == 1 for r in records),
        "missing_events": sum(r["missing"] == 1 for r in records),
        "cash_flip_events": sum(r["flip"] == 1 for r in records),
        "changed_rows": changed, "risk_rows": risk,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inputs", nargs="+", type=Path)
    p.add_argument("--json", type=Path)
    args = p.parse_args()
    paths = []
    for item in args.inputs:
        paths.extend(sorted(item.glob("*.log")) if item.is_dir() else [item])
    if not paths:
        p.error("aucun log")
    runs = [parse(path) for path in paths]
    result = {"runs": runs, "counts": {k: sum(r[k] for r in runs) for k in
              ("events", "aged_events", "changed_events", "invalid_events",
               "missing_events", "cash_flip_events")},
              "limitations": ["logs represent selections, not unique projects",
                              "shadow uses extra opcodes and can alter game scheduling",
                              "fresh quote cannot simulate terrain leveling plus airport placement"]}
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for row in runs:
        print(f"seed={row['seed']} events={row['events']} aged={row['aged_events']} "
              f"max_age={row['max_age_days']} changed={row['changed_events']} "
              f"invalid={row['invalid_events']} flip={row['cash_flip_events']}")
    print("TOTAL", result["counts"])


if __name__ == "__main__":
    main()
