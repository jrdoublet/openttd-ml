"""Parser checks: the causal-replay diagnostic must not impute economic gain."""
import sys
import tempfile
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyse_c121_production_only_replay import analyze, parse_line


class ReplayParserTests(unittest.TestCase):
    def test_extracts_real_token_and_discards_false_prefix(self):
        self.assertEqual(parse_line("[I] C121_PRODUCTION_ONLY_REPLAY status=control_mismatch key=abc")["key"], "abc")
        self.assertIsNone(parse_line("NOT_C121_PRODUCTION_ONLY_REPLAY status=compared"))

    def test_counts_controls_and_quote_impact(self):
        line = (
            "C121_PRODUCTION_ONLY_REPLAY status=compared key=k arm=hubsite date=1 "
            "engine=7 planes=2 changed=1 oldprod_profit=20 now_profit=30 "
            "oldprod_revenue=25 now_revenue=35 oldprod_capital=10 now_capital=10 "
            "oldprod_carried_pax=3 now_carried_pax=4 "
            "oldprod_carried_mail=1 now_carried_mail=1 "
            "oldprod_cannibal=4 now_cannibal=5 "
            "oldprod_score=2.0 now_score=3.0 oldprod_viable=1 now_viable=1"
        )
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp)/"log.txt"
            f.write_text("\n".join([line,
                                     "C121_PRODUCTION_ONLY_REPLAY status=control_mismatch key=broken",
                                     line.replace("now_profit=30", "now_profit=no")]), encoding="utf-8")
            report = analyze([f])
            self.assertEqual(report["aggregate"]["compared"], 1)
            self.assertEqual(report["aggregate"]["quote_changed"], 1)
            self.assertEqual(report["aggregate"]["control_mismatch"], 1)
            self.assertEqual(report["aggregate"]["malformed"], 1)
            self.assertEqual(report["aggregate"]["fixed_engine_score_changed"], 1)
            self.assertEqual(report["aggregate"]["profit_up_with_current_production"], 1)
            self.assertEqual(report["aggregate"]["carried_changed"], 1)
            self.assertEqual(report["aggregate"]["cannibal_changed"], 1)
            self.assertEqual(len(report["warnings"]), 1)
            self.assertNotIn("realized profit gain", report["status"])


if __name__ == "__main__":
    unittest.main()
