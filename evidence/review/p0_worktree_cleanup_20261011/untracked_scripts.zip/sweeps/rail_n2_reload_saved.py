"""Recharger une sauvegarde N=2 d'un duel avec A+B actifs.

Entrée : un .sav conservé par run_c66_reference.py --retain-savegames.
La fenêtre A+B doit être confirmée dans le log du MEME bras/graine ;
le contrôle rail_search_dropped=1 prouve que Load a vu une recherche active.
S'appuie sur le harnais de rechargement existant, sans dupliquer le moteur.
"""

import argparse
import json
from pathlib import Path
import re

import bench_v2
import save_load_roundtrip as sl


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--save", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--years", type=int, default=1)
    parser.add_argument("--active-from", default="1972-12-05")
    parser.add_argument("--active-to", default="1973-05-15")
    parser.add_argument("--arm", default="OpexAI[rail_cooperative_n2=1,decision_log=1]")
    args = parser.parse_args()
    save_path = args.save.resolve(strict=True)
    if args.out.exists():
        parser.error("destination exists: " + str(args.out))
    if args.years <= 0:
        parser.error("--years must be positive")

    before = sl.parse_sav_file(str(save_path))
    if not (args.active_from <= before["date"] < args.active_to):
        parser.error("save date outside documented A+B overlap: " + before["date"])
    sl.SCRIPT_DEBUG_LEVEL = "4"
    work = sl.ROOT / ".scratch_rail_n2_active_load"
    work.mkdir(parents=True, exist_ok=True)
    sl.CACHE_DIR = sl.ROOT / ".scratch_saveload" / "cache"
    sl.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cfg = bench_v2.make_cfg(1970)
    installed = bench_v2.build_arms([args.arm, "AAAHogEx"])
    arm = installed[args.arm]
    opponent = installed["AAAHogEx"]
    rows, output, saved = sl.run_phase_b(
        args.seed, args.years, arm, cfg, work / "checkpoint.jsonl",
        str(save_path), work / "phaseB_saves", extra_ais=(opponent,),
    )
    reconcile = [line.strip() for line in output.splitlines() if " LOAD_RECONCILE " in line]
    dropped = [
        int(m.group(1)) for line in reconcile
        if (m := re.search(r"rail_search_dropped=(\d+)", line))
    ]
    failures = sl.scan_markers(output, sl.ENGINE_FAILURE_MARKERS_KNOWN)
    reloaded = sl.parse_sav_file(saved[-1]) if saved else None
    report = {
        "status": "OK" if saved and dropped and dropped[0] == 1 and not failures else "NOT_VALIDATED",
        "source_save": str(save_path),
        "seed": args.seed,
        "arm": args.arm,
        "overlap_window": [args.active_from, args.active_to],
        "before": before,
        "after": reloaded,
        "save_count_after_reload": len(saved),
        "load_reconcile": reconcile,
        "rail_search_dropped": dropped,
        "engine_failures": failures,
        "rail_n2_events_after_reload": [
            line.strip() for line in output.splitlines() if " RAIL_N2 " in line
        ][:150],
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    bench_v2.write_json_atomically(args.out, report)
    print(json.dumps({
        key: report[key] for key in (
            "status", "source_save", "save_count_after_reload",
            "load_reconcile", "rail_search_dropped", "engine_failures"
        )
    }, indent=2))
    if report["status"] != "OK":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
