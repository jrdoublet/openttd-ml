#!/usr/bin/env python3
"""Analyse host des bascules rail/AIR au meme instant et admissions N=2.

Un record RAIL_AIR_BREAKPOINT est une observation du topK selectionne, jamais
une preuve qu'une liaison se construit. Les frequences sont des etats logues,
pas des jours ponderes ni des projets independants. Aucun contrefactuel.
"""

import argparse
from collections import Counter
import json
from pathlib import Path
import re


EVENT = re.compile(r"\bOPEX (\d{4})-(\d{1,2})-(\d{1,2}) (RAIL_AIR_BREAKPOINT|RAIL_N2_GATE|RAIL_N2) (.*)$")
SHADOW = re.compile(r"\bRAIL_AIR_BREAKPOINT (.*)$")
DATE = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")
SEED = re.compile(r"(?:^|[_-])seed(\d+)(?:[_-]|\.)", re.I)


def _int(row, key, default=None):
    try:
        return int(row[key])
    except (KeyError, ValueError, TypeError):
        return default


def parse_lines(lines):
    snapshots, gates, secondary_starts = [], [], []
    for raw in lines:
        # `AILog.Info` est direct dans la sonde et n'ajoute pas le prefixe
        # OPEX yyyy-mm-dd. Le champ date= est donc la source de sa datation.
        shadow = SHADOW.search(raw)
        if shadow:
            fields = dict(piece.split("=", 1) for piece in shadow.group(1).split()
                          if "=" in piece)
            stamp = DATE.match(fields.get("date", ""))
            if stamp:
                year, month, day = map(int, stamp.groups())
                snapshots.append({**fields, "date": f"{year:04d}-{month:02d}-{day:02d}"})
            continue
        match = EVENT.search(raw)
        if not match:
            continue
        year, month, day, kind, tail = match.groups()
        date = f"{int(year):04d}-{int(month):02d}-{int(day):02d}"
        fields = dict(piece.split("=", 1) for piece in tail.split() if "=" in piece)
        # La sonde repete `date=1972-7-28` sans padding : garder la date
        # canonique de l'enveloppe moteur pour l'ordre et les jointures.
        event = {**fields, "date": date}
        if kind == "RAIL_N2_GATE":
            gates.append(event)
        elif fields.get("phase") == "second_start":
            secondary_starts.append(event)
    return snapshots, gates, secondary_starts


def first_matching(rows, predicate):
    return next((row for row in rows if predicate(row)), None)


def summarize(path):
    with path.open(encoding="utf-8", errors="replace") as stream:
        snapshots, gates, secondary = parse_lines(stream)
    ranked_vs_air = lambda p: _int(p, "rail_first_rank", -1) >= 0 and _int(p, "air_rank", -1) > _int(p, "rail_first_rank", -1)
    scored_vs_air = lambda p: _int(p, "rail_beats_air") == 1
    scored_vs_other = lambda p: _int(p, "rail_beats_other") == 1
    backlog = lambda p: ranked_vs_air(p) and scored_vs_air(p) and _int(p, "rail_ahead_air", 0) >= 2
    first_score = first_matching(snapshots, scored_vs_air)
    first_rank = first_matching(snapshots, ranked_vs_air)
    first_both = first_matching(snapshots, lambda p: ranked_vs_air(p) and scored_vs_air(p))
    first_backlog = first_matching(snapshots, backlog)
    distinct_admitted = {(row["date"], row.get("src"), row.get("dst"))
                         for row in gates if _int(row, "admit") == 1}
    seed = SEED.search(path.name)
    return {
        "log": str(path), "seed": int(seed.group(1)) if seed else None,
        "snapshots_observed": len(snapshots),
        "first_rail_score_beats_air": first_score,
        "first_rail_rank_precedes_air": first_rank,
        "first_score_and_rank_domination": first_both,
        "first_competitive_backlog_2": first_backlog,
        "snapshots_no_air": sum(_int(row, "air_rank", -1) < 0 for row in snapshots),
        "snapshots_no_nonrail": sum(_int(row, "other_rank", -1) < 0 for row in snapshots),
        "rail_ahead_air_distribution": dict(sorted(Counter(
            _int(row, "rail_ahead_air", -1) for row in snapshots).items())),
        "rail_ahead_other_distribution": dict(sorted(Counter(
            _int(row, "rail_ahead_other", -1) for row in snapshots).items())),
        "gate_checks": len(gates),
        "gate_positive_checks": sum(_int(row, "admit") == 1 for row in gates),
        "gate_positive_distinct_day_od": len(distinct_admitted),
        "second_starts": len(secondary),
        "second_start_events": secondary,
        "limitations": [
            "topK is censored, particularly when no AIR is visible",
            "log records changed daily signatures, not every selection or elapsed time",
            "score and rank are pre-build and do not prove constructibility",
            "gate can be checked twice for one candidate; distinct_day_od is not a project count",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error("refusing to overwrite existing file " + str(args.out))
    paths = sorted(args.engine.glob("*.log"))
    if not paths:
        parser.error("no engine logs in " + str(args.engine))
    summary = {"logs": [summarize(path) for path in paths]}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for entry in summary["logs"]:
        first = entry["first_score_and_rank_domination"]
        backlog = entry["first_competitive_backlog_2"]
        print(f"{Path(entry['log']).name}: snapshots={entry['snapshots_observed']} "
              f"cross={first['date'] if first else '-'} "
              f"K>=2={backlog['date'] if backlog else '-'} "
              f"gate={entry['gate_positive_checks']}/{entry['gate_checks']} "
              f"second_start={entry['second_starts']}")


if __name__ == "__main__":
    main()
