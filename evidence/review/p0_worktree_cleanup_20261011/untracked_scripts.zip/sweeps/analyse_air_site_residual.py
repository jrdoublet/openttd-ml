#!/usr/bin/env python3
"""Diagnostic AIR V126, par partie / année / 0-1-2 aéroports neufs.

N'admet aucun résultat comme preuve de qualification V102. Les refus TRY sont
des observations répétées ; un `actual` d'échec est une dépense comptabilisée
pendant le chantier, pas nécessairement une perte nette après rollback.

Usage : python sweeps/analyse_air_site_residual.py results/campagne_engine --json results/diag.json
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path
import json
import re

from parse_air_finance_margin import (
    LogRunData,
    calc_percentile,
    parse_kv_payload,
    parse_log_file,
    summarize_distribution,
    v126_residual,
    v126_view,
)


PERF_RE = re.compile(r"\bAIR_PLAN_PERF:\s*(.*)$")


def year_of(value):
    """Année de la date moteur AAAA-MM-JJ ; None si inconnue."""
    if value is None:
        return None
    m = re.fullmatch(r"(\d{4})-\d{1,2}-\d{1,2}", value)
    return int(m.group(1)) if m else None


def _known_sum(items):
    values = [float(x) for x in items if x is not None]
    return sum(values) if len(values) == len(items) else None


def analyze_records(run):
    grouped = defaultdict(lambda: {"tries": [], "revenues": [], "pending": []})
    for rec in run.tries:
        grouped[(year_of(rec.date), rec.new_airports)]["tries"].append(rec)
    for rec in run.first_revenues:
        grouped[(year_of(rec.build_date), rec.new_airports)]["revenues"].append(rec)
    for rec in run.pendings:
        grouped[(year_of(rec.build_date), rec.new_airports)]["pending"].append(rec)
    result = []
    for (year, n), group in sorted(grouped.items(), key=lambda item: (item[0][0] or -1, item[0][1] if item[0][1] is not None else -1)):
        tries = group["tries"]
        built = [t for t in tries if t.outcome == "built"]
        failed = [t for t in tries if t.outcome == "failed"]
        refusals = [t for t in tries if t.outcome.startswith("refused_")]
        successful_quote = [(t, v126_view(t)) for t in built]
        successful_quote = [(t, v) for t, v in successful_quote if v is not None]
        failed_quote = [(t, v126_view(t)) for t in failed]
        failed_quote = [(t, v) for t, v in failed_quote if v is not None]
        quote_fail = sum(1 for t in tries if (v126_view(t) or {}).get("quote_fail", 0) > 0)
        actual_fail_costs = [t.actual for t in failed]
        residuals = [v126_residual(t, v) for t, v in successful_quote]
        residuals = [r for r in residuals if r is not None]
        site_ratios = [r["residual"] / float(v["site_cost"]) * 100
                       for (t, v) in successful_quote for r in [v126_residual(t, v)]
                       if r is not None and (v["site_cost"] or 0) > 0]
        # Diagnostic descriptif sur les REUSSITES seulement : part de site qui
        # aurait couvert l'écart au-delà du plancher de 2 k£. Ne couvre pas
        # les chantiers avortés, les remboursements ni les imprévus futurs.
        observed_pct_to_cover_built = [
            max(0.0, (r["residual"] - 2000.0) / float(v["site_cost"]) * 100.0)
            for (t, v) in successful_quote for r in [v126_residual(t, v)]
            if r is not None and (v["site_cost"] or 0) > 0
        ]
        level_gaps = []
        clearing = []
        for t, v in successful_quote:
            for suffix in ("a", "b"):
                quote = v.get("quote_" + suffix)
                if quote is None or quote == -2:
                    continue
                level = v.get("c_level_" + suffix)
                airport = v.get("c_airport_" + suffix)
                if quote >= 0 and level is not None:
                    level_gaps.append(level - quote)
                if airport is not None:
                    clearing.append(airport - (v["airport_price"] or 0))
        revenues = group["revenues"]
        known_reserve = [r for r in revenues if r.cash_min is not None and r.reserve is not None]
        cash_breaches = sum(r.cash_min < r.reserve for r in known_reserve)
        result.append({
            "year": year, "new_airports": n,
            "attempt_events": len(tries), "unique_town_pairs_seen": len({(t.src_town, t.dst_town) for t in tries
                if t.src_town is not None and t.dst_town is not None}),
            "outcomes": dict(Counter(t.outcome for t in tries)),
            "refusal_events": len(refusals), "built": len(built), "failed": len(failed),
            "failed_reasons": dict(Counter(t.reason or "unknown" for t in failed)),
            "failed_cost_accounted_gbp": _known_sum(actual_fail_costs),
            "failed_cost_known_count": sum(t.actual is not None for t in failed),
            "failed_with_positive_accounting": sum(t.actual is not None and t.actual > 0 for t in failed),
            "failed_cost_distribution_gbp": summarize_distribution([t.actual for t in failed if t.actual is not None]),
            "failed_quote_count": len(failed_quote), "quote_impossible_events": quote_fail,
            "built_quoted": len(successful_quote),
            "built_quote_missing": len(built) - len(successful_quote),
            "built_level_gap_gbp": summarize_distribution(level_gaps),
            "built_clearing_gbp": summarize_distribution(clearing),
            "built_residual_gbp": summarize_distribution([r["residual"] for r in residuals]),
            "built_residual_pct_site": summarize_distribution(site_ratios),
            "observed_success_only_pct_above_2000": summarize_distribution(observed_pct_to_cover_built),
            "built_actual_joined_stops_gbp": summarize_distribution([float(v["c_stops"])
                for t, v in successful_quote if v.get("c_stops") is not None]),
            "built_modeled_joined_stops_gbp": summarize_distribution([float(v["stops_model"])
                for t, v in successful_quote if v.get("stops_model") is not None]),
            "built_residual_above_floor_2000": sum(r["residual"] > 2000 for r in residuals),
            "first_revenue_count": len(revenues),
            "first_revenue_days": summarize_distribution([r.days for r in revenues if r.days is not None]),
            "cash_reserve_observed": len(known_reserve),
            "cash_breaches": cash_breaches,
            "pending_events": len(group["pending"]),
        })
    return result


def perf_rows(path):
    """AIR_PLAN_PERF au fil des scans, pour coût opcode descriptif.

    Les comparaisons par rang entre bras ne sont utilisables que lorsque les
    entrées et le nombre d'appels ont été validés égaux.
    """
    result = []
    with path.open(encoding="utf-8", errors="replace") as stream:
        for line in stream:
            m = PERF_RE.search(line)
            if m is None:
                continue
            kv = parse_kv_payload(m.group(1))
            try:
                result.append({k: int(kv[k]) if k in kv else None for k in (
                    "total_ops", "ops_sites", "ops_eval", "sites", "combos", "plans",
                    "c121_calls", "c121_static_ops", "c121_demand_ops", "c121_scan_ops",
                    "c121_engine_evals", "c121_endpoint_hits", "c121_endpoint_misses")})
            except ValueError:
                continue
    return result


def analyze_files(paths):
    entries = []
    by_arm = {}
    for path in sorted(paths):
        run = parse_log_file(path)
        if run.arm not in by_arm:
            by_arm[run.arm] = LogRunData(seed=-1, arm=run.arm, filename="all")
        by_arm[run.arm].tries.extend(run.tries)
        by_arm[run.arm].first_revenues.extend(run.first_revenues)
        by_arm[run.arm].pendings.extend(run.pendings)
        perfs = perf_rows(path)
        entries.append({
            "file": path.name, "arm": run.arm, "seed": run.seed,
            "year_airports": analyze_records(run),
            "perf_scans_count": len(perfs), "perf_first_scan": perfs[0] if perfs else None,
            "perf_scan_sums": {
                k: _known_sum([p[k] for p in perfs])
                for k in ("total_ops", "c121_calls", "c121_static_ops", "c121_demand_ops")
            },
        })
    return {"analysis": "diagnostic_only", "runs": entries,
            "by_arm": {arm: analyze_records(run) for arm, run in sorted(by_arm.items())},
            "notes": ["TRY refusals are repeated events, not distinct investment projects",
                      "failed_cost_accounted_gbp includes rollback/accounting, not irreversible net loss",
                      "built residual quantiles condition on successful construction and do not measure failed-site risk",
                      "perf_scan_sums differ in the number/inputs of scans and are not causal opcode deltas"]}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inputs", nargs="+", type=Path, help="Répertoire moteur *_engine ou .log")
    p.add_argument("--json", type=Path, help="Fichier JSON exporté")
    args = p.parse_args()
    paths = []
    for item in args.inputs:
        paths.extend(sorted(item.glob("*.log")) if item.is_dir() else [item])
    if not paths:
        p.error("aucun log moteur")
    report = analyze_files(paths)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for run in report["runs"]:
        print(f"{run['arm']} seed={run['seed']} scans={run['perf_scans_count']} ")
        for row in run["year_airports"]:
            res = row["built_residual_gbp"]
            print("  year=%s new=%s tries=%d built=%d failed=%d refusals=%d failed_cost=%s"
                  " quoted=%d residual_med=%s p90=%s breachs=%d/%d" % (
                    row["year"], row["new_airports"], row["attempt_events"], row["built"],
                    row["failed"], row["refusal_events"], row["failed_cost_accounted_gbp"],
                    row["built_quoted"], res["median"], res["p90"],
                    row["cash_breaches"], row["cash_reserve_observed"]))


if __name__ == "__main__":
    main()
