"""Describe observed C121 PASS/MAIL cache staleness without inferring lost profit.

Usage:
  python sweeps/analyse_c121_exact_prod_cache.py --logs results/*_engine/*.log \
      --out results/c121_exact_prod_exposure.json

This tool reads the passive C121_PROD_EXACT_SHADOW and
C121_PROD_CACHE_STALE logs. No estimated fresh price, causal investment
effect, or observed traffic is available in these events.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path
import json
import re

TOKENS = re.compile(r"([a-z][a-z0-9_]*)=([^\s]+)")
EVENTS = ("C121_PROD_EXACT_SHADOW", "C121_PROD_CACHE_STALE")
SIGNED = ("delta_pax_a", "delta_mail_a", "delta_pax_b", "delta_mail_b")
REQUIRED_STALE = ("cache_key", "arm", "town_a", "town_b", "age", *SIGNED)
REQUIRED_BATCH = ("ignored_towns", "ignored_pax_units", "ignored_mail_units")


def parse_event(line: str):
    """Return (kind, fields) for a known log record or None."""
    for kind in EVENTS:
        pos = line.find(kind)
        if pos < 0:
            continue
        # AILog prefixes vary, but the event name must be a full token.
        before = line[pos - 1] if pos else " "
        after = line[pos + len(kind):pos + len(kind) + 1]
        if (before.isalnum() or before == "_") or (after.isalnum() or after == "_"):
            continue
        fields = dict(TOKENS.findall(line[pos + len(kind):]))
        return kind, fields
    return None


def _int_field(fields, name):
    return int(fields[name])


def analyze(files):
    """Analyze each logfile as a separate simulation (never merge seed identity)."""
    sources = {}
    warnings = []
    aggregate = Counter()
    stale_by_arm = Counter()
    stale_by_age = Counter()
    for source_path in files:
        path = Path(source_path)
        source = str(path)
        if source in sources:
            warnings.append(f"duplicate source path: {source}")
            continue
        totals = Counter()
        observed_signatures = set()
        arm_counts = Counter()
        ages = []
        samples = []
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            warnings.append(f"{source}: cannot read: {exc}")
            continue
        for line_no, line in enumerate(text.splitlines(), 1):
            parsed = parse_event(line)
            if parsed is None:
                continue
            kind, data = parsed
            totals[kind] += 1
            required = REQUIRED_BATCH if kind == EVENTS[0] else REQUIRED_STALE
            missing = [field for field in required if field not in data]
            if missing:
                warnings.append(f"{source}:{line_no}: {kind} missing {','.join(missing)}")
                totals["malformed"] += 1
                continue
            try:
                if kind == EVENTS[0]:
                    totals["ignored_town_batch_mentions"] += _int_field(data, "ignored_towns")
                    totals["ignored_pax_units_batch_mentions"] += _int_field(data, "ignored_pax_units")
                    totals["ignored_mail_units_batch_mentions"] += _int_field(data, "ignored_mail_units")
                    continue
                delta = {key: _int_field(data, key) for key in SIGNED}
                age = _int_field(data, "age")
                town_a = _int_field(data, "town_a")
                town_b = _int_field(data, "town_b")
            except ValueError as exc:
                warnings.append(f"{source}:{line_no}: bad numeric field: {exc}")
                totals["malformed"] += 1
                continue
            totals["stale_hit_log_events"] += 1
            if not any(delta.values()):
                warnings.append(f"{source}:{line_no}: zero-delta stale log")
            signature = (data["cache_key"], *(delta[key] for key in SIGNED))
            if signature in observed_signatures:
                totals["duplicate_key_delta_signature"] += 1
            observed_signatures.add(signature)
            arm_counts[data["arm"]] += 1
            stale_by_arm[data["arm"]] += 1
            if age < 0:
                stale_by_age["negative"] += 1
            elif age == 0:
                stale_by_age["same_day"] += 1
            elif age < 30:
                stale_by_age["1_to_29_days"] += 1
            else:
                stale_by_age["at_least_30_days"] += 1
            ages.append(age)
            if len(samples) < 15:
                samples.append({
                    "line": line_no, "cache_key": data["cache_key"],
                    "arm": data["arm"], "town_a": town_a, "town_b": town_b,
                    "age_days": age, "delta": delta,
                    "quoted_profit_old": data.get("quoted_profit"),
                    "quoted_capital_old": data.get("quoted_capital"),
                    "quoted_revenue_old": data.get("quoted_revenue"),
                })
        aggregate.update(totals)
        sources[source] = {
            "counts": dict(totals),
            "stale_hit_events_by_arm": dict(arm_counts),
            "unique_cache_key_delta_signatures": len(observed_signatures),
            "age_days": {
                "min": min(ages) if ages else None,
                "max": max(ages) if ages else None,
            },
            "examples": samples,
        }
    return {
        "status": "passive_exposure_only",
        "limitations": [
            "Batch counts are repeated town mentions, not distinct towns or projects.",
            "Stale-hit events are deduplicated in Squirrel per cache key and delta signature, not an exhaustive count of every cache hit.",
            "A stale cache hit is not proof of a changed fresh quote, score, finance decision, build success, or economic loss.",
            "Changes not revisited by the eight-town batch cannot appear in these records.",
            "Extra logging/opcodes may perturb timing even though shadow never mutates a candidate.",
        ],
        "logs_read": len(sources),
        "aggregate": dict(aggregate),
        "stale_by_arm": dict(stale_by_arm),
        "stale_by_age": dict(stale_by_age),
        "files": sources,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--logs", nargs="+", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    report = analyze(args.logs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{report['logs_read']} logs | stale_hit_events="
          f"{report['aggregate'].get('stale_hit_log_events', 0)} | "
          f"ignored_town_batch_mentions="
          f"{report['aggregate'].get('ignored_town_batch_mentions', 0)} | "
          f"warnings={len(report['warnings'])}")


if __name__ == "__main__":
    main()
