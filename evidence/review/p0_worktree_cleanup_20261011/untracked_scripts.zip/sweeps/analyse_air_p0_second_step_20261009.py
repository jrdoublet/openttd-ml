"""Descriptive paired trajectories for OFF/ON depth-correct C121 fleet margin.

Reads *only* the frozen diagnostic's JSONL and engine logs. No game launches.
The first differing event may be a different selected route, not evidence of
economic profit per individual purchased plane.
"""

from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = "air_p0_second_step_parity_3x5_20261009_r2"
JSONL = ROOT / "results" / f"{CAMPAIGN}.jsonl"
LOGDIR = ROOT / "results" / f"{CAMPAIGN}_engine"
OUTPUT = ROOT / "results" / f"{CAMPAIGN}_analysis.json"


def main():
    rows = defaultdict(dict)
    for raw in JSONL.open(encoding="utf-8"):
        record = json.loads(raw)
        if record.get("run", [None])[0] != "OpexAI":
            continue
        arm = "reference" if Path(record["engine_log_path"]).name.startswith("reference_") else "variant"
        seed = record["run"][1]
        date = record["date"]
        if date.endswith("-12-01"):
            rows[(seed, date)][arm] = {
                "profit_year": record.get("profit_year"),
                "company_value": record.get("company_value"),
                "aircraft": record.get("air_primary_vehicles"),
                "airports": record.get("air_airports"),
                "air_profit_ytd": sum(line["profit_this_year_gbp"] for line in record["line_telemetry"]["lines"]
                                      if line["mode"] == "air"),
                "air_lines": sum(line["mode"] == "air" for line in record["line_telemetry"]["lines"]),
            }
    events = {}
    line_re = re.compile(r"AIR_P0_(BUY|ROUTE) (.*)")
    def readlog(seed, arm):
        name = f"{'reference' if arm == 'reference' else 'air_p0_second_step_on'}_seed{seed}_r0.log"
        out = []
        for line in (LOGDIR / name).read_text(encoding="utf-8", errors="replace").splitlines():
            found = line_re.search(line)
            if found:
                out.append({"kind": found.group(1), "tail": found.group(2),
                            "before": re.search(r"\bbefore=(\d+)", found.group(2)).group(1)
                                      if "before=" in found.group(2) else None})
        return out
    for seed in (42, 512, 65537):
        a, b = readlog(seed, "reference"), readlog(seed, "variant")
        first = 0
        while first < min(len(a), len(b)) and a[first] == b[first]:
            first += 1
        events[str(seed)] = {
            "identical_event_prefix": first,
            "first_reference": a[first] if first < len(a) else None,
            "first_variant": b[first] if first < len(b) else None,
            "reference_total_buys": sum(e["kind"] == "BUY" for e in a),
            "variant_total_buys": sum(e["kind"] == "BUY" for e in b),
            "reference_2_to_3": sum(e["kind"] == "BUY" and e["before"] == "2" for e in a),
            "variant_2_to_3": sum(e["kind"] == "BUY" and e["before"] == "2" for e in b),
        }
    annual = []
    for (seed, date), arms in sorted(rows.items()):
        if set(arms) != {"reference", "variant"}:
            raise ValueError(f"Incomplete seed/year: {seed} {date} {set(arms)}")
        row = {"seed": seed, "date": date, "reference": arms["reference"], "variant": arms["variant"],
               "variant_minus_reference": {
                   k: round(arms["variant"][k] - arms["reference"][k], 3)
                   for k in arms["reference"] if isinstance(arms["reference"][k], (int, float))
                   and isinstance(arms["variant"][k], (int, float))}}
        annual.append(row)
    summary = {"campaign": CAMPAIGN, "yearly": annual, "first_events_and_counts": events,
               "notes": ["Same source bundle within reference/variant, logging common to both.",
                         "3 seeds; pilot diagnostic not V102 and not attributable at per-aircraft level.",
                         "No observed gross revenue/running expenses or event-level counterfactual."]}
    OUTPUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for row in annual:
        if row["date"].startswith(("1972-", "1973-", "1974-")):
            print("TRAJECTORY", row["seed"], row["date"], row["variant_minus_reference"])
    for seed, status in events.items():
        print("EVENTS", seed, status)
    print("OUTPUT", OUTPUT)


if __name__ == "__main__":
    main()
