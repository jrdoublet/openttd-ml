"""Résumer les RID N=2 dans les logs moteurs d'un duel figé (observation, pas qualification)."""

import argparse
from collections import Counter
import json
from pathlib import Path
import re


OPEX_LINE = re.compile(r"\bOPEX (\d{4})-(\d{1,2})-(\d{1,2}) ([A-Z][A-Z0-9_]*) (.*)$")


def extract_events(path):
    counts = Counter()
    states = {}
    events = []
    attempts = []
    with path.open(encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            match = OPEX_LINE.search(raw)
            if match is None:
                continue
            year, month, day, event, detail = match.groups()
            date = f"{int(year):04d}-{int(month):02d}-{int(day):02d}"
            fields = dict(part.split("=", 1) for part in detail.split() if "=" in part)
            if event == "RAIL_ATTEMPT":
                attempts.append({
                    "date": date,
                    "src": fields.get("src"),
                    "dst": fields.get("dst"),
                    "ok": fields.get("ok"),
                    "reason": fields.get("reason"),
                    "search_ops": fields.get("search_ops"),
                })
                continue
            if event != "RAIL_N2":
                continue
            phase = fields.get("phase", "?")
            counts[phase] += 1
            rid = fields.get("rid")
            row = {"date": date, **fields}
            events.append(row)
            if rid is None:
                continue
            state = states.setdefault(rid, {"rid": rid})
            if phase == "search_start":
                state.update(start=date, src=fields.get("src"), dst=fields.get("dst"),
                             kind=fields.get("kind"), cargo=fields.get("cargo"),
                             budget=fields.get("budget"))
            elif phase == "second_start":
                state.update(admitted=date, peer=fields.get("peer"), role="secondary")
            elif phase == "search_done":
                state.update(done=date, outcome=fields.get("outcome"),
                             iters=fields.get("iters"), slices=fields.get("slices"),
                             slice_ops=fields.get("slice_ops"), days=fields.get("days"))
            elif phase == "second_ready":
                state["ready"] = date
            elif phase == "promote":
                state["promoted"] = date
            elif phase == "build_done":
                state.update(built=date, build_ok=fields.get("built"),
                             build_reason=fields.get("reason"))
            elif phase in ("second_wait", "second_discard"):
                state[phase] = {"date": date, "reason": fields.get("reason"),
                                "released": fields.get("released")}

    complete_ops = sum(int(row["slice_ops"]) for row in states.values()
                       if row.get("slice_ops") is not None)
    ready_counts = Counter(e["rid"] for e in events
                           if e.get("phase") == "second_ready" and "rid" in e)
    prior_consumed = set()
    premature_commits = []
    invalid_peers = []
    for event in events:
        rid = event.get("rid")
        phase = event.get("phase")
        if phase == "second_start" and rid == event.get("peer"):
            invalid_peers.append(event)
        if phase == "build_done" and states.get(rid, {}).get("role") == "secondary":
            peer = states[rid].get("peer")
            if peer not in prior_consumed:
                premature_commits.append({"rid": rid, "peer": peer, "date": event["date"]})
        if phase in ("build_done", "second_discard"):
            prior_consumed.add(rid)
        if phase == "second_wait" and event.get("released") == "1":
            prior_consumed.add(rid)
    return {
        "log": str(path),
        "phases": dict(counts),
        "states": sorted(states.values(), key=lambda state: int(state["rid"])),
        "events": events,
        "rail_attempts": len(attempts),
        "rail_builds": sum(item["ok"] == "1" for item in attempts),
        "attempts": attempts,
        "completed_search_slice_ops_sum": complete_ops,
        "second_ready_duplicate_rids": {
            rid: n for rid, n in ready_counts.items() if n > 1
        },
        "invalid_same_rid_peers": invalid_peers,
        "premature_secondary_commits": premature_commits,
        "incomplete_states_excluded_from_ops": [
            rid for rid, state in states.items() if state.get("done") is None
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error("refusing to overwrite " + str(args.out))
    logs = sorted(args.engine.glob("*.log"))
    if not logs:
        parser.error("no .log found in " + str(args.engine))
    result = {"logs": [extract_events(path) for path in logs]}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    for data in result["logs"]:
        print(f"{Path(data['log']).name}: phases={data['phases']} "
              f"rail_attempts={data['rail_attempts']} rail_builds={data['rail_builds']} "
              f"completed_search_ops={data['completed_search_slice_ops_sum']} "
              f"unfinished={len(data['incomplete_states_excluded_from_ops'])} "
              f"ready_duplicates={data['second_ready_duplicate_rids']} "
              f"premature_commits={data['premature_secondary_commits']}")


if __name__ == "__main__":
    main()
