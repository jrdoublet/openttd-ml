#!/usr/bin/env python3
"""Detached Squirrel VM microbenchmark for the three RAIL local score formulas.

This is NOT an OpenTTD economic benchmark. It measures the intrinsic costs of
score evaluation and the historical OpexTopK(k=20) on IDENTICAL, deterministic,
synthetic candidate pools, with OFFA/OFFB A/A controls in every replication.
No file in ai/OpexAI is touched or imported by the temporary AI.

Host (does not use Docker):
    python -m unittest discover -s tests -p test_rail_magic_opcode_microbench.py
    python sweeps/rail_magic_opcode_microbench.py --offline

When Docker is FREE and coordinated with the other campaigns:
    docker ps --format "table {{.Names}}\t{{.Status}}"
    docker run --rm --cpus=2 --memory=2g --memory-swap=2g \
      -v openttd-lab-home:/home/lab -v "$PWD":/work -w /work \
      openttd-lab python sweeps/rail_magic_opcode_microbench.py --engine

The engine mode executes the existing OpenTTDLab cached OpenTTD 15.3 binary
directly with -d script=4, not a multi-year campaign. Logging occurs OUTSIDE
timed blocks. The reported 'opcodes' are per-block NoAI tick/remainder costs:
if a block crosses a tick, its reported budget includes the boundary and is
not a privileged engine instruction-counter reading. Synthetic fixtures do
not estimate the number or distribution of real generated RAIL candidates.
"""

from __future__ import annotations

import argparse
import json
import re
import statistics
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "sweeps" / "fixtures" / "RailMagicOpcodeProbe"
AI_NAME = "RailMagicOpcodeProbe"
VERSION = "15.3"
OPENGFX = "7.1"
CASE_SPECS = (("mixed20", 20, False, False), ("mixed64", 64, False, False),
              ("mixed200", 200, False, False), ("mixed687", 687, False, False),
              ("shuffle687", 687, False, True), ("ties64", 64, True, False))
ARMS = ("OFFA", "OFFB", "ROI", "OPCODE")
ROW_RE = re.compile(r"RMOP\|case=[^\r\n]+")


def make_pool(n: int, ties: bool = False, shuffled: bool = False) -> list[dict]:
    """Independent Python oracle for the fixture's integer-only candidate data."""
    pool = []
    for i in range(n):
        profit = 8000 if ties else 500 + ((i * 733 + 311) % 90000)
        iterations = 32000 if ties else 50 + ((i * 127 + 83) % 18000)
        capital = 100000 if ties else 50000 + ((i * 487 + 19) % 320000)
        if not ties and i % 41 == 0:
            profit, capital = 2, 300000
        pool.append({
            "id": i, "profitAnnual": profit, "iterations": iterations,
            "roi": profit * 1000 // capital,
            "oneWayDays": 30 if ties else (i * 11 + 7) % 75,
            "kind": "freight" if i % 3 == 0 else "pax", "ratio": 0,
        })
    return [pool[j * 269 % n] for j in range(n)] if shuffled else pool


def score_pool(pool: list[dict], policy: str) -> list[dict]:
    """Exact order of integer divisions from candidates.nut:759-784."""
    if policy not in {"OFF", "ROI", "OPCODE"}:
        raise ValueError(f"unsupported policy {policy!r}")
    for c in pool:
        opcode_ratio = c["profitAnnual"] * 1000 // c["iterations"]
        bonus = 100
        if policy == "OFF":
            days = c["oneWayDays"]
            bonus = 130 if days <= 12 else 115 if days <= 25 else 100 if days <= 45 else 60
        effective_roi = c["roi"] * 100 // 100
        if policy == "ROI":
            ratio = effective_roi
        elif policy == "OPCODE":
            ratio = opcode_ratio
        else:
            adjusted_roi = (c["roi"] * bonus // 100) * 100 // 100
            ratio = opcode_ratio + adjusted_roi * 15
        c["ratio"] = ratio
    return pool


def topk(pool: list[dict], k: int = 20) -> list[dict]:
    """Faithful insertion-sort oracle, including stable ties/floor >=20."""
    best: list[dict] = []
    floor = 0
    for c in pool:
        if len(best) >= k and c["ratio"] <= floor:
            continue
        pos = len(best)
        while pos > 0 and best[pos - 1]["ratio"] < c["ratio"]:
            pos -= 1
        best.insert(pos, c)
        if len(best) > k:
            best.pop()
        if len(best) >= k:
            floor = best[-1]["ratio"]
    return best


def signature(best: list[dict]) -> int:
    return sum((i + 1) * (c["id"] + 1) for i, c in enumerate(best))


def topk_operation_counts(pool: list[dict], k: int = 20) -> dict[str, int]:
    """Pure algorithmic counters, explicitly NOT VM opcode counts."""
    best: list[dict] = []
    floor = 0
    comparisons = inserts = shifts = rejected = 0
    for candidate in pool:
        if len(best) >= k:
            comparisons += 1
            if candidate["ratio"] <= floor:
                rejected += 1
                continue
        pos = len(best)
        while pos > 0:
            comparisons += 1
            if best[pos - 1]["ratio"] >= candidate["ratio"]:
                break
            pos -= 1
            shifts += 1
        best.insert(pos, candidate)
        inserts += 1
        if len(best) > k:
            best.pop()
        if len(best) >= k:
            floor = best[-1]["ratio"]
    assert [c["id"] for c in best] == [c["id"] for c in topk(pool, k)]
    return {"comparisons": comparisons, "inserts": inserts,
            "shifts": shifts, "floor_rejects": rejected}


def checksum(pool: list[dict]) -> int:
    s = 0
    for c in pool:
        s = (s + c["ratio"] * (c["id"] % 97 + 1)) % 1000000007
    return s


def oracle() -> dict:
    expected = {}
    for case, n, ties, shuffled in CASE_SPECS:
        expected[case] = {}
        for policy in ("OFF", "ROI", "OPCODE"):
            scored = score_pool(make_pool(n, ties, shuffled), policy)
            best = topk(scored)
            expected[case][policy] = {
                "n": n, "check": checksum(scored), "best": signature(best),
                "len": len(best), "best_ids": [c["id"] for c in best],
                "num_zero_roi": sum(c["roi"] == 0 for c in scored),
                "num_score_ties": n - len(set(c["ratio"] for c in scored)),
                "topk_algorithmic_counts_not_opcodes": topk_operation_counts(scored),
            }
    return expected


def parse_engine_output(raw: str) -> list[dict]:
    records = []
    for match in ROW_RE.finditer(raw):
        parts = match.group().split("|")[1:]
        entry = {}
        for part in parts:
            if "=" not in part:
                raise ValueError(f"malformed RMOP token {part!r}")
            k, v = part.split("=", 1)
            if k in entry:
                raise ValueError(f"duplicate RMOP field {k}")
            entry[k] = v if k in {"case", "arm"} else int(v)
        expected_fields = {"case", "rep", "arm", "n", "score", "rank", "score_ticks",
                           "rank_ticks", "check", "best", "len"}
        if set(entry) != expected_fields:
            raise ValueError(f"unexpected RMOP fields: {set(entry) ^ expected_fields}")
        if min(entry[k] for k in ("score", "rank", "score_ticks", "rank_ticks")) < 0:
            raise ValueError(f"negative measured costs: {entry}")
        records.append(entry)
    if "RMOP_DONE" not in raw:
        raise ValueError("missing RMOP_DONE; AI might not have finished")
    return records


def report(records: list[dict]) -> dict:
    expected = oracle()
    by_case = defaultdict(lambda: defaultdict(dict))
    for row in records:
        case, rep, arm = row["case"], row["rep"], row["arm"]
        if case not in expected or rep not in range(4) or arm not in ARMS:
            raise ValueError(f"unexpected RMOP trial {case}/{rep}/{arm}")
        if arm in by_case[case][rep]:
            raise ValueError(f"duplicate RMOP trial {case}/{rep}/{arm}")
        by_case[case][rep][arm] = row
        policy = "OFF" if arm in {"OFFA", "OFFB"} else arm
        for field in ("n", "check", "best", "len"):
            if row[field] != expected[case][policy][field]:
                raise ValueError(f"oracle mismatch {case}/{rep}/{arm}/{field}: "
                                 f"engine={row[field]} host={expected[case][policy][field]}")

    if len(records) != len(CASE_SPECS) * 4 * 4:
        raise ValueError(f"missing/extra results: {len(records)}, expected {len(CASE_SPECS) * 16}")

    cases = {}
    all_aa_equal = True
    all_aa_within_one = True
    for case, _, _, _ in CASE_SPECS:
        trial = by_case[case]
        diffs = {p: {"score": [], "rank": [], "total": []} for p in ("ROI", "OPCODE")}
        arm_costs = {p: {"score": [], "rank": [], "total": []} for p in ARMS}
        aa_diffs = []
        for rep in range(4):
            arms = trial[rep]
            if set(arms) != set(ARMS):
                raise ValueError(f"incomplete {case}/rep{rep}: {set(arms)}")
            for arm, row in arms.items():
                for field in ("score", "rank"):
                    arm_costs[arm][field].append(row[field])
                arm_costs[arm]["total"].append(row["score"] + row["rank"])
            a, b = arms["OFFA"], arms["OFFB"]
            aa_diffs.append({field: b[field] - a[field] for field in ("score", "rank")})
            for field in ("score", "rank", "total"):
                base = (arm_costs["OFFA"][field][-1] + arm_costs["OFFB"][field][-1]) / 2
                for policy in ("ROI", "OPCODE"):
                    diffs[policy][field].append((arm_costs[policy][field][-1] / base - 1)
                                                 if base else None)
        aa_equal = all(d["score"] == 0 and d["rank"] == 0 for d in aa_diffs)
        aa_within_one = all(abs(d[field]) <= 1 for d in aa_diffs
                            for field in ("score", "rank"))
        all_aa_equal &= aa_equal
        all_aa_within_one &= aa_within_one
        cases[case] = {
            "oracle": expected[case], "aa_equal_opcodes": aa_equal,
            "aa_within_one_opcode": aa_within_one,
            "aa_max_abs_opcode_difference": max(abs(d[field]) for d in aa_diffs
                                                 for field in ("score", "rank")),
            "aa_diffs": aa_diffs,
            "mean_ops": {a: {field: statistics.mean(values)
                             for field, values in d.items()}
                         for a, d in arm_costs.items()},
            "relative_to_aa_off": {
                a: {field: {"mean_pct": 100 * statistics.mean(v),
                            "min_pct": 100 * min(v), "max_pct": 100 * max(v)}
                    for field, v in d.items() if all(x is not None for x in v)}
                for a, d in diffs.items()},
            "ticks_per_trial": {
                a: {field: [trial[r][a][field] for r in range(4)]
                    for field in ("score_ticks", "rank_ticks")}
                for a in ARMS},
        }
    return {"source": "detached synthetic NoAI Squirrel k=20 microbench",
            "a_a_exact_all_cases": all_aa_equal,
            "a_a_within_one_opcode_all_cases": all_aa_within_one,
            "oracle_all_cases": True, "records": len(records), "cases": cases}


def _cached_assets() -> tuple[Path, Path]:
    roots = [Path.home() / ".cache" / "OpenTTDLab"]
    candidates = [(tar, tar.parent / f"opengfx-{OPENGFX}-all.zip")
                  for root in roots if root.exists()
                  for tar in root.glob(f"*/openttd-{VERSION}-linux-generic-amd64.tar.xz")]
    for tar, gfx in candidates:
        if gfx.exists():
            return tar, gfx
    raise FileNotFoundError(
        f"No cached OpenTTD {VERSION}/OpenGFX {OPENGFX} under {roots}; "
        "a short OpenTTDLab normal run must populate it first. Do not run a campaign blindly."
    )


def run_engine(*, seed: int, ticks: int, timeout: int) -> str:
    openttd_tar, opengfx_zip = _cached_assets()
    if not all((FIXTURE / name).is_file() for name in ("main.nut", "info.nut")):
        raise FileNotFoundError(f"detached fixture incomplete: {FIXTURE}")
    with tempfile.TemporaryDirectory(prefix="rail-magic-opcode-microbench-") as root_str:
        temp = Path(root_str)
        run = temp / "rundir"
        for part in ("baseset", "scripts", "ai"):
            (run / part).mkdir(parents=True)
        with tarfile.open(openttd_tar, "r:xz") as tf:
            tf.extractall(temp)
        with zipfile.ZipFile(opengfx_zip) as zf:
            zf.extractall(run / "baseset")
        with tarfile.open(run / "ai" / f"{AI_NAME}.tar", "w") as tf:
            tf.add(FIXTURE, arcname=AI_NAME)
        (run / "scripts" / "game_start.scr").write_text(f"start_ai {AI_NAME}\n")
        (run / "openttdlab.cfg").write_text(
            "[difficulty]\nnumber_towns = 3\nindustry_density = 4\n"
            "[economy]\ninflation = false\n"
            "[game_creation]\nstarting_year = 1970\nmap_x = 8\nmap_y = 8\n"
            "[gui]\nthreaded_saves = false\nautosave = off\n",
            encoding="utf-8",
        )
        binaries = list(temp.glob(f"openttd-{VERSION}-linux-generic-amd64/openttd"))
        if len(binaries) != 1:
            raise RuntimeError(f"expected cached binary directory not found in {openttd_tar}")
        cmd = [str(binaries[0]), "-g", "-G", str(seed), "-snull", "-mnull",
               f"-vnull:ticks={ticks}", "-c", "openttdlab.cfg", "-d", "script=4"]
        proc = subprocess.run(cmd, cwd=run, text=True, capture_output=True, timeout=timeout)
        output = proc.stdout + "\n" + proc.stderr
        if proc.returncode != 0 or "Your script made an error" in output:
            raise RuntimeError(f"OpenTTD failed rc={proc.returncode}; log tail:\n{output[-5500:]}")
        return output


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--offline", action="store_true", help="verify algorithms without Docker")
    mode.add_argument("--engine", action="store_true", help="run one short cached OpenTTD instance")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--ticks", type=int, default=12000,
                   help="null-driver ceiling; 12000 ticks ~162 game days, not a long campaign")
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("--out", type=Path, help="optional report JSON path (default: stdout only)")
    args = p.parse_args(argv)
    if args.offline:
        result = {"oracle": oracle(), "validation": "host-only; NOT Squirrel opcode counts"}
    else:
        result = report(parse_engine_output(run_engine(seed=args.seed, ticks=args.ticks,
                                                      timeout=args.timeout)))
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    else:
        print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
