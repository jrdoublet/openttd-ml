"""Contracts for factual and non-causal analysis of passive C121 logs."""
import tempfile
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyse_c121_exact_prod_cache import analyze, parse_event  # noqa: E402


class CacheProbeDecoderTests(unittest.TestCase):
    def test_reads_prefixed_logs_and_all_fields(self):
        kind, fields = parse_event(
            "[I] C121_PROD_CACHE_STALE date=720100 age=5 cache_key=foo|bar "
            "arm=hubsite town_a=8 town_b=9 delta_pax_a=-2 delta_mail_a=1 "
            "delta_pax_b=4 delta_mail_b=0 quoted_profit=15000"
        )
        self.assertEqual(kind, "C121_PROD_CACHE_STALE")
        self.assertEqual(fields["quoted_profit"], "15000")
        self.assertEqual(fields["cache_key"], "foo|bar")
        self.assertIsNone(parse_event("NOT_C121_PROD_CACHE_STALE date=1"))

    def test_stale_hit_distinct_from_ignored_batch_and_no_profit_inference(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "seed42.log"
            log.write_text(
                "I C121_PROD_EXACT_SHADOW date=10 ignored_towns=2 "
                "ignored_pax_units=3 ignored_mail_units=8 first_town=8 exact_on=0\n"
                "I C121_PROD_CACHE_STALE date=10 age=0 cache_key=a|x "
                "arm=newpair town_a=8 town_b=9 delta_pax_a=1 "
                "delta_mail_a=0 delta_pax_b=-2 delta_mail_b=3 "
                "quoted_profit=1000 quoted_capital=5000 quoted_revenue=4000\n"
                "I C121_PROD_CACHE_STALE date=11 age=1 cache_key=a|x "
                "arm=newpair town_a=8 town_b=9 delta_pax_a=1 "
                "delta_mail_a=0 delta_pax_b=-2 delta_mail_b=3 "
                "quoted_profit=1000 quoted_capital=5000 quoted_revenue=4000\n",
                encoding="utf-8",
            )
            report = analyze([log])
            self.assertEqual(report["aggregate"]["ignored_town_batch_mentions"], 2)
            self.assertEqual(report["aggregate"]["stale_hit_log_events"], 2)
            self.assertEqual(report["aggregate"]["duplicate_key_delta_signature"], 1)
            self.assertEqual(report["files"][str(log)]["unique_cache_key_delta_signatures"], 1)
            self.assertEqual(report["stale_by_age"]["same_day"], 1)
            self.assertEqual(report["stale_by_age"]["1_to_29_days"], 1)
            self.assertEqual(report["files"][str(log)]["examples"][0]["quoted_profit_old"], "1000")
            self.assertIn("not proof", report["limitations"][2])

    def test_keeps_game_files_separate_and_reports_malformed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            lines = (
                "I C121_PROD_EXACT_SHADOW ignored_towns=3 "
                "ignored_pax_units=9 ignored_mail_units=0\n"
                "I C121_PROD_CACHE_STALE date=0 age=3 cache_key=a "
                "arm=hubhub town_a=1 town_b=2 delta_pax_a=-1 "
                "delta_mail_a=0 delta_pax_b=0 delta_mail_b=0\n"
                "I C121_PROD_CACHE_STALE date=0 age=oops cache_key=b "
                "arm=hubhub town_a=1 town_b=2 delta_pax_a=-1 "
                "delta_mail_a=0 delta_pax_b=0 delta_mail_b=0\n"
            )
            p1, p2 = root / "one.log", root / "two.log"
            p1.write_text(lines, encoding="utf-8")
            p2.write_text(lines, encoding="utf-8")
            report = analyze([p1, p2])
            self.assertEqual(report["logs_read"], 2)
            self.assertEqual(report["aggregate"]["stale_hit_log_events"], 2)
            self.assertEqual(report["aggregate"]["ignored_town_batch_mentions"], 6)
            self.assertEqual(report["aggregate"]["malformed"], 2)
            self.assertEqual(len(report["warnings"]), 2)
            self.assertEqual(report["stale_by_arm"]["hubhub"], 2)


if __name__ == "__main__":
    unittest.main()
