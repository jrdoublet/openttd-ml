"""Fail-closed, host-only adjudicator for the pre-registered RAIL ROI 40x10.

Does NOT run Docker or read economic traces from historical/exploratory trials.
Policy: docs/rail_magic_roi_holdout_prereg_20261010.md (10 October 2026).

The economic result is distinct from production authorization: a PASS here
still requires the independently qualified matched-workload opcode microbench
and the physical/Save-Load safety reviews described in that pre-registration.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics


ROOT = Path(__file__).resolve().parents[1]
PREREG = ROOT / "docs/rail_magic_roi_holdout_prereg_20261010.md"
EXPECTED_N = 40
EXPECTED_YEARS = 10
STARTING_YEAR = 1970
BOOTSTRAPS = 20_000
BOOTSTRAP_SEED = 0
MARGIN_PERCENT = -1.0
METRICS = ("profit_year", "company_value")
STATUSES = ("reference_opex", "reference_aaahogex", "variant_opex", "variant_aaahogex")


def registered_seeds(path: Path = PREREG) -> list[int]:
    """Read the unique *recorded* seed block, never derive fresh seeds."""
    doc = path.read_text(encoding="utf-8")
    match = re.search(
        r"Ordre enregistré\s*:\s*```\s*\n(?P<block>[\s\d]+?)\n```",
        doc,
    )
    if match is None:
        raise ValueError("pré-enregistrement: bloc des 40 graines absent ou malformé")
    seeds = [int(word) for word in match.group("block").split()]
    if (len(seeds) != EXPECTED_N or len(set(seeds)) != EXPECTED_N
            or any(not 1 <= seed < 1_000_000 for seed in seeds)):
        raise ValueError("pré-enregistrement: exige exactement 40 graines distinctes et valides")
    return seeds


def _as_dict(value, label, errors):
    if not isinstance(value, dict):
        errors.append(f"{label}: objet absent ou invalide")
        return {}
    return value


def _one_int(value):
    return type(value) is int


def _positive_finite(value):
    return type(value) in (float, int) and math.isfinite(value) and value > 0


def _finite(value):
    return type(value) in (float, int) and math.isfinite(value)


def _unique_game_id(campaign, policy, seed):
    return f"{campaign}:policy={policy}:s{seed}:r0"


def _errors_for_manifest(result: dict, manifest: dict, seeds: list[int]) -> tuple[list[str], dict]:
    errors = []
    campaign = result.get("campaign_id")
    if not isinstance(campaign, str) or not campaign:
        errors.append("campaign_id absent")
    if manifest.get("campaign_id") != campaign:
        errors.append("campaign_id différent du manifeste")
    expected_bundle = _as_dict(manifest.get("source_bundle"), "source_bundle", errors).get("sha256")
    if (not isinstance(expected_bundle, str) or len(expected_bundle) != 64
            or result.get("source_bundle_sha256") != expected_bundle):
        errors.append("empreinte bundle incohérente")
    config = _as_dict(manifest.get("configuration"), "configuration", errors)
    if (config.get("starting_year") != STARTING_YEAR or config.get("years") != EXPECTED_YEARS
            or config.get("repeats") != 1):
        errors.append("configuration: attend 1970-1979, 10 ans et 1 répétition")
    if config.get("seeds") != seeds:
        errors.append("configuration: graines différentes du pré-enregistrement (ordre compris)")
    if (result.get("years") != EXPECTED_YEARS or result.get("repeats") != 1
            or result.get("seeds") != seeds):
        errors.append("résultat: 40 graines pré-enregistrées, 10 ans, 1 répétition requis")
    if (result.get("expected_last_year") != 1979
            or result.get("expected_last_checkpoint") != "1979-12-01"):
        errors.append("horizon final du résultat incorrect")
    if _as_dict(manifest.get("adversary"), "adversary", errors).get("id") != "AAAHogEx":
        errors.append("adversaire différent de AAAHogEx")

    policies = manifest.get("policies")
    roles = {}
    if not isinstance(policies, list) or len(policies) != 2:
        errors.append("manifeste: exactement deux politiques sont requises")
    else:
        for policy in policies:
            if not isinstance(policy, dict) or policy.get("role") in roles:
                errors.append("manifeste: rôles de politique malformés ou doublés")
                continue
            roles[policy["role"]] = policy
    if set(roles) != {"reference", "variant"}:
        errors.append("manifeste: politiques OFF/ON manquantes")
    policy_ids = {}
    for role, wanted_roi in (("reference", 0), ("variant", 1)):
        policy = roles.get(role) or {}
        policy_id = policy.get("id")
        if not isinstance(policy_id, str) or not policy_id:
            errors.append(f"{role}: policy_id manquant")
        policy_ids[role] = policy_id
        settings = _as_dict(policy.get("settings"), f"{role}.settings", errors)
        effective = _as_dict(settings.get("effective"), f"{role}.effective", errors)
        if (effective.get("rail_magic_simple_roi") != wanted_roi
                or effective.get("rail_magic_simple_opcode") != 0):
            errors.append(f"{role}: flags ROI/Opcodes contraires au protocole")
    if roles.get("reference") and roles.get("variant"):
        ref_effective = roles["reference"].get("settings", {}).get("effective", {})
        var_effective = roles["variant"].get("settings", {}).get("effective", {})
        if not isinstance(ref_effective, dict) or not isinstance(var_effective, dict):
            errors.append("paramètres effectifs de politiques invalides")
        elif (set(ref_effective) != set(var_effective)
              or {k for k in ref_effective if ref_effective[k] != var_effective[k]}
              != {"rail_magic_simple_roi"}):
            errors.append("paramètres effectifs des deux bras diffèrent hors ROI")
    comparison = _as_dict(manifest.get("comparison"), "manifest.comparison", errors)
    if (comparison.get("reference_policy_id") != policy_ids.get("reference")
            or comparison.get("variant_policy_id") != policy_ids.get("variant")
            or comparison.get("intervention_settings") != ["rail_magic_simple_roi"]
            or comparison.get("effective_differences") != {
                "rail_magic_simple_roi": {"reference": 0, "candidate": 1}
            }):
        errors.append("manifeste: intervention unique 0→1 non vérifiée")
    recorded = _as_dict(result.get("policy_comparison"), "policy_comparison", errors)
    if (recorded.get("reference_policy_id") != policy_ids.get("reference")
            or recorded.get("variant_policy_id") != policy_ids.get("variant")
            or recorded.get("primary_metric") != "profit_year"
            or recorded.get("value_guard_metric") != "company_value"):
        errors.append("policy_comparison: identité ou métriques incompatibles")
    return errors, policy_ids


def _validate_games(result, manifest, seeds, policy_ids, errors):
    campaign = result.get("campaign_id")
    expected = {
        (seed, role): _unique_game_id(campaign, policy_ids.get(role), seed)
        for seed in seeds for role in ("reference", "variant")
    }
    for source, games in (("results.games", result.get("games")),
                          ("manifest.games", manifest.get("games"))):
        if not isinstance(games, list) or len(games) != 2 * EXPECTED_N:
            errors.append(f"{source}: attend exactement 80 parties")
            continue
        found = set()
        for game in games:
            if not isinstance(game, dict):
                errors.append(f"{source}: partie non objet")
                continue
            seed, policy = game.get("seed"), game.get("policy_id")
            role = next((r for r, p in policy_ids.items() if p == policy), None)
            key = (seed, role)
            if key not in expected or key in found or game.get("game_id") != expected[key]:
                errors.append(f"{source}: partie inconnue, dupliquée ou mauvais game_id")
                continue
            found.add(key)
            if game.get("repeat") != 0:
                errors.append(f"{source}: répétition différente de zéro")
            if source == "results.games":
                if (game.get("game_ok") is not True or game.get("game_status") != "complete"
                        or game.get("unattributed_errors") != []
                        or game.get("source_bundle_sha256") != result.get("source_bundle_sha256")
                        or game.get("expected_last_checkpoint") != "1979-12-01"):
                    errors.append(f"game s{seed}/{role}: non sain, horizon ou bundle incorrect")
                companies = _as_dict(game.get("companies"), "game.companies", errors)
                for company in ("OpexAI", "AAAHogEx"):
                    record = _as_dict(companies.get(company), f"game.{company}", errors)
                    if (record.get("run_ok") is not True or record.get("horizon_complete") is not True
                            or record.get("status") != "complete"
                            or record.get("failure_reason") is not None):
                        errors.append(f"game s{seed}/{role}: société {company} incomplète")
            else:
                slots = _as_dict(game.get("company_slots"), "manifest.company_slots", errors)
                if (slots.get("0") != {"ai": "OpexAI", "policy_id": policy}
                        or slots.get("1") != {"ai": "AAAHogEx", "policy_id": "AAAHogEx"}):
                    errors.append(f"manifest.game s{seed}/{role}: slots d'IA incohérents")
        if len(found) != len(expected):
            errors.append(f"{source}: jeux attendus absents")


def _validate_summary(result, seeds, policy_ids, errors):
    summary = result.get("summary")
    if not isinstance(summary, list) or len(summary) != EXPECTED_N * 4:
        errors.append("summary: attend 160 relevés finaux (Opex+AAAHogEx par partie)")
        return {}
    expected = {(seed, role, company)
                for seed in seeds for role in ("reference", "variant")
                for company in ("OpexAI", "AAAHogEx")}
    found = set()
    index = {}
    for record in summary:
        if not isinstance(record, dict):
            errors.append("summary: ligne malformée")
            continue
        role = next((r for r, p in policy_ids.items()
                     if p == record.get("duel_policy_id")), None)
        key = (record.get("seed"), role, record.get("arm"))
        if key not in expected or key in found:
            errors.append("summary: graine/politique/société inconnue ou dupliquée")
            continue
        found.add(key)
        index[key] = record
        if (record.get("repeat") != 0 or record.get("run_ok") is not True
                or record.get("game_ok") is not True
                or record.get("last_year") != 1979
                or record.get("last_date") != "1979-12-01"
                or record.get("profit_year_coverage") != "complete"
                or record.get("profit_year_quarters_valid") != 4):
            errors.append(f"summary s{key[0]}/{role}/{key[2]}: santé/couverture invalide")
    if found != expected:
        errors.append("summary: relevés attendus absents")
    return index


def _validate_pairs(result, seeds, policy_ids, summary, errors):
    comparison = _as_dict(result.get("policy_comparison"), "policy_comparison", errors)
    if (comparison.get("comparison_complete") is not True
            or comparison.get("metric_coverage_complete") is not True
            or comparison.get("planned_pairs") != EXPECTED_N
            or comparison.get("complete_pairs") != EXPECTED_N
            or comparison.get("incomplete_pairs") != []):
        errors.append("policy_comparison: 40 paires complètes et couverture requises")
    # adoption_sample_complete belongs to the HARNESS decision rule (gain_short,
    # non_erosion, etc.), NOT this independent, pre-registered host-side rule.
    pairs = comparison.get("per_pair")
    if not isinstance(pairs, list) or len(pairs) != EXPECTED_N:
        errors.append("policy_comparison.per_pair: attend exactement 40 paires")
        return {}
    observed = {}
    for pair in pairs:
        if not isinstance(pair, dict):
            errors.append("per_pair: ligne non objet")
            continue
        seed = pair.get("seed")
        if (not _one_int(seed) or seed not in seeds or seed in observed
                or pair.get("repeat") != 0):
            errors.append("per_pair: graine inattendue/doublon ou répétition")
            continue
        observed[seed] = {}
        if pair.get("complete") is not True:
            errors.append(f"per_pair s{seed}: incomplet")
        statuses = _as_dict(pair.get("statuses"), f"per_pair s{seed}.statuses", errors)
        for status_key in STATUSES:
            status = _as_dict(statuses.get(status_key), f"s{seed}.{status_key}", errors)
            role = "reference" if status_key.startswith("reference") else "variant"
            if (status.get("present") is not True or status.get("run_ok") is not True
                    or status.get("game_ok") is not True
                    or status.get("status") != "complete"
                    or status.get("failure_reason") is not None
                    or status.get("game_id") != _unique_game_id(
                        result.get("campaign_id"), policy_ids.get(role), seed)):
                errors.append(f"per_pair s{seed}: {status_key} non sain/identité incorrecte")
        metrics = _as_dict(pair.get("metrics"), f"s{seed}.metrics", errors)
        for metric in METRICS:
            data = _as_dict(metrics.get(metric), f"s{seed}.{metric}", errors)
            ref, var, delta = (data.get("reference_opex"), data.get("variant_opex"),
                               data.get("policy_delta"))
            if not (_positive_finite(ref) and _finite(var) and _finite(delta)
                    and math.isclose(var-ref, delta, rel_tol=1e-12, abs_tol=1e-5)):
                errors.append(f"per_pair s{seed}: {metric} absent/invalide ou delta incohérent")
            else:
                observed[seed][metric] = (float(ref), float(var))
                if (summary.get((seed, "reference", "OpexAI"), {}).get(metric) != ref
                        or summary.get((seed, "variant", "OpexAI"), {}).get(metric) != var):
                    errors.append(f"per_pair s{seed}: {metric} incohérent avec summary Opex")
        trajectory = pair.get("annual_trajectory")
        if (not isinstance(trajectory, list) or len(trajectory) != EXPECTED_YEARS
                or [row.get("year") for row in trajectory if isinstance(row, dict)]
                != list(range(1970, 1980))):
            errors.append(f"per_pair s{seed}: trajectoire 1970–1979 absente/incomplète")
        elif (trajectory[-1].get("reference_opex") !=
              (metrics.get("profit_year") or {}).get("reference_opex")
              or trajectory[-1].get("variant_opex") !=
              (metrics.get("profit_year") or {}).get("variant_opex")):
            errors.append(f"per_pair s{seed}: profit terminal != trajectoire 1979")
    if set(observed) != set(seeds):
        errors.append("per_pair: couverture incomplète des graines pré-enregistrées")
    return observed


def bootstrap_metric(observed: dict, seeds: list[int], metric: str):
    """The exact pre-registered 20k paired index bootstrap, seed 0.

    Each metric has an independent Random(0) stream; the bootstrap uses
    floor(random()*n) indices just as the prior exploratory analysis.
    """
    values = [observed[seed][metric] for seed in seeds]
    refs = [ref for ref, _ in values]
    deltas = [var-ref for ref, var in values]
    n = len(values)
    rng = random.Random(BOOTSTRAP_SEED)
    draws = []
    for _ in range(BOOTSTRAPS):
        indices = [math.floor(rng.random() * n) for __ in range(n)]
        reference = sum(refs[i] for i in indices)
        if reference <= 0:
            raise ValueError("bootstrap: dénominateur référence non positif")
        draws.append(100.0 * sum(deltas[i] for i in indices) / reference)
    draws.sort()
    effect = 100.0 * sum(deltas) / sum(refs)
    lower = draws[int(.05*BOOTSTRAPS)]
    upper = draws[int(.95*BOOTSTRAPS)]
    if lower > MARGIN_PERCENT:
        classification = "PASS"
        interpretation = "non_inférieure à -1 % démontrée"
    elif upper < MARGIN_PERCENT:
        classification = "FAIL"
        interpretation = "infériorité supérieure à 1 % étayée sur cette métrique"
    else:
        classification = "INDETERMINATE"
        interpretation = "non-infériorité non démontrée; perte non prouvée"
    return {
        "reference_mean": statistics.mean(refs),
        "variant_mean": statistics.mean(ref+delta for ref, delta in zip(refs, deltas)),
        "paired_delta_mean": statistics.mean(deltas),
        "paired_delta_median": statistics.median(deltas),
        "paired_delta_sd": statistics.stdev(deltas),
        "effect_ratio_of_means_pct": effect,
        "bootstrap_one_sided95_lower_pct": lower,
        "bootstrap_one_sided95_upper_pct_for_diagnostic": upper,
        "one_sided_95_lower_above_minus_1pct": lower > MARGIN_PERCENT,
        "classification": classification,
        "interpretation": interpretation,
    }


def assess(result: dict, manifest: dict, *, seeds: list[int], manifest_sha256: str | None = None):
    """Return JSON-safe decision; invalid data NEVER turn into a PASS or FAIL."""
    errors, policy_ids = _errors_for_manifest(result, manifest, seeds)
    if manifest_sha256 is not None and result.get("manifest_sha256") != manifest_sha256:
        errors.append("empreinte SHA256 du manifeste incompatible avec le résultat")
    if result.get("failed_runs") != []:
        errors.append("failed_runs: doit être une liste vide")
    _validate_games(result, manifest, seeds, policy_ids, errors)
    summary = _validate_summary(result, seeds, policy_ids, errors)
    pairs = _validate_pairs(result, seeds, policy_ids, summary, errors)
    report = {
        "schema": "rail-roi-holdout-ni-v1",
        "campaign_id": result.get("campaign_id"),
        "bundle_sha256": result.get("source_bundle_sha256"),
        "preregistered_n": EXPECTED_N,
        "horizon": "1970-1979",
        "bootstrap_draws": BOOTSTRAPS,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "economics_margin_pct": MARGIN_PERCENT,
        "dataset_valid": not errors,
        "errors": errors[:40],
        "error_count": len(errors),
        "economic_verdict": "INDETERMINATE",
        "metrics": {},
        "adoption_verdict": "INDETERMINATE",
        "adoption_note": "Sans preuve indépendante du microbench opcode à charge identique et revue des gardes, conserver ROI=0",
        "total_vm_opcodes": "UNMEASURED",
    }
    if errors:
        return report
    for metric in METRICS:
        report["metrics"][metric] = bootstrap_metric(pairs, seeds, metric)
    outcomes = [report["metrics"][metric]["classification"] for metric in METRICS]
    if all(outcome == "PASS" for outcome in outcomes):
        report["economic_verdict"] = "PASS"
    elif "FAIL" in outcomes:
        report["economic_verdict"] = "FAIL"
    else:
        report["economic_verdict"] = "INDETERMINATE"
    if report["economic_verdict"] == "FAIL":
        report["adoption_verdict"] = "FAIL"
        report["adoption_note"] = "Rejet économique; maintenir les flags OFF"
    # PASS *economic* does not certify independent opcode/safety gates.
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result", nargs="?", type=Path, help="résultat JSON du futur 40×10")
    parser.add_argument("--manifest", type=Path, help="manifest gelé (défaut: <result>.manifest.json)")
    parser.add_argument("--dry-run", action="store_true", help="afficher le contrat uniquement, sans ouvrir de résultats")
    args = parser.parse_args(argv)
    if args.dry_run and args.result is not None:
        parser.error("--dry-run ne lit pas de résultats; omettre le chemin")
    if not args.dry_run and args.result is None:
        parser.error("indiquez le résultat JSON du 40×10 ou --dry-run")
    if args.dry_run and args.manifest is not None:
        parser.error("--dry-run n'accepte pas de manifeste")
    seeds = registered_seeds()
    if args.dry_run:
        print(json.dumps({
            "status": "DRY_RUN_ONLY",
            "preregistration": str(PREREG),
            "seeds": seeds,
            "n": len(seeds),
            "years": 10,
            "repeats": 1,
            "bootstrap_draws": BOOTSTRAPS,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "gate": "L95_unilateral(profit_year)>-1% ET L95_unilateral(company_value)>-1%",
            "microbench_gate": "indépendante et obligatoire avant adoption",
            "future_results_read": False,
        }, indent=2, ensure_ascii=False))
        return 0
    manifest_path = args.manifest or args.result.with_name(args.result.stem + ".manifest.json")
    try:
        result = json.loads(args.result.read_text(encoding="utf-8"))
        raw = manifest_path.read_bytes()
        manifest = json.loads(raw)
        report = assess(result, manifest, seeds=seeds,
                        manifest_sha256=hashlib.sha256(raw).hexdigest())
    except (OSError, ValueError, TypeError, KeyError) as exc:
        report = {
            "schema": "rail-roi-holdout-ni-v1",
            "dataset_valid": False,
            "economic_verdict": "INDETERMINATE",
            "adoption_verdict": "INDETERMINATE",
            "error_count": 1,
            "errors": [f"Impossible de vérifier le résultat/manifeste: {exc}"],
        }
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if report.get("dataset_valid") else 2


if __name__ == "__main__":
    raise SystemExit(main())
