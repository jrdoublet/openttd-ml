"""Host-only retrospective RAIL ROI sensitivity and non-inferiority analysis.

Reads existing frozen A40x5 JSON; no Docker, AI instrumentation or harness edit.
The prospective one-sided 95% policy postdates these experiments: its results
here are EXPLORATORY and cannot retroactively qualify a failed 40x5 gate.
"""

import argparse
import json
import math
from pathlib import Path
import random
import statistics


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FILES = (
    ROOT / "results/rail_magic_simple_roi_A40x5_20261010_r1.json",
    ROOT / "results/rail_magic_simple_opcode_A40x5_20261010_r1.json",
)
NORMAL = statistics.NormalDist()
Z95_ONE = NORMAL.inv_cdf(0.95)
Z95_TWO = NORMAL.inv_cdf(0.975)
Z80 = NORMAL.inv_cdf(0.80)


def pairs_from_result(path):
    result = json.loads(Path(path).read_text(encoding="utf-8"))
    comparison = result["policy_comparison"]
    if not (comparison["comparison_complete"]
            and comparison["metric_coverage_complete"]):
        raise ValueError(f"Incomplete pairing in {path}")
    if comparison["complete_pairs"] != len(comparison["per_pair"]):
        raise ValueError(f"Missing completed seed pairs in {path}")
    sample = []
    seen = set()
    for pair in comparison["per_pair"]:
        if not pair["complete"] or pair["seed"] in seen or pair["repeat"] != 0:
            raise ValueError(f"Duplicate or invalid independent seed in {path}")
        seen.add(pair["seed"])
        values = []
        for metric in ("profit_year", "company_value"):
            item = pair["metrics"][metric]
            ref = item["reference_opex"]
            var = item["variant_opex"]
            if not isinstance(ref, (float, int)) or ref <= 0 or not isinstance(var, (float, int)):
                raise ValueError(f"Missing/invalid {metric} denominator in {path}")
            values.append((float(ref), float(var)))
        sample.append(values)
    return result, sample


def percentile(values, quantile):
    sorted_values = sorted(values)
    return sorted_values[min(len(sorted_values) - 1, int(quantile * len(sorted_values)))]


def analyze_metric(sample, index, *, draws, seed):
    values = [row[index] for row in sample]
    refs = [ref for ref, _ in values]
    deltas = [var - ref for ref, var in values]
    n = len(values)
    ref_mean = statistics.mean(refs)
    mean = statistics.mean(deltas)
    sd = statistics.stdev(deltas)
    margin = 0.01 * ref_mean
    bootstrap = []
    rng = random.Random(seed)
    for _ in range(draws):
        # Match sweeps/paired_statistics.bootstrap_mean_ci's seeded sampling
        # index convention: floor(random.Random(seed).random() * n).
        indices = [math.floor(rng.random() * n) for __ in range(n)]
        mean_ref = sum(refs[i] for i in indices) / n
        mean_delta = sum(deltas[i] for i in indices) / n
        bootstrap.append(100 * mean_delta / mean_ref)
    lower = percentile(bootstrap, 0.05)
    upper = percentile(bootstrap, 0.95)
    lower_two = percentile(bootstrap, 0.025)
    upper_two = percentile(bootstrap, 0.975)
    # With the observed mean/SD and an unchanged reference denominator, the
    # normal approximation is useful for design, NOT a proof about year 10.
    scenarios = {}
    for hypothetical_n in (20, 40, 60, 80, 100, 120, 160, 240, 480):
        se = sd / math.sqrt(hypothetical_n)
        # Non-inferiority: L95 > -1%, namely mean_sample > -margin + z95*se.
        p_non_inferior = NORMAL.cdf((mean + margin) / se - Z95_ONE)
        # Historical strict equivalence needs entire TWO-SIDED 95% CI in +/-m.
        inner = margin - Z95_TWO * se
        p_equivalent_at_zero = (2 * NORMAL.cdf(inner / se) - 1) if inner > 0 else 0.0
        scenarios[str(hypothetical_n)] = {
            "profit_or_value_ni_one_sided95_power_at_observed_mean": round(p_non_inferior, 4),
            "strict_equivalence_two_sided95_power_if_true_delta_zero": round(p_equivalent_at_zero, 4),
        }
    ni80 = math.ceil(((Z95_ONE + Z80) * sd / (mean + margin)) ** 2) if mean + margin > 0 else None
    strict80 = math.ceil(((Z95_TWO + NORMAL.inv_cdf(.90)) * sd / margin) ** 2)
    return {
        "n": n,
        "reference_mean": round(ref_mean, 3),
        "paired_delta_mean": round(mean, 3),
        "paired_delta_sd": round(sd, 3),
        "historical_absolute_margin_1pct": round(margin, 3),
        "effect_ratio_of_means_pct": round(100 * mean / ref_mean, 6),
        "exploratory_bootstrap_one_sided95_lower_pct": round(lower, 6),
        "exploratory_bootstrap_one_sided95_upper_pct": round(upper, 6),
        "exploratory_bootstrap_two_sided95_pct": [round(lower_two, 6), round(upper_two, 6)],
        "exploratory_one_sided_NI_lower_above_minus_1pct": lower > -1,
        "normal_approx_seed_n_for_80pct_ni_at_historical_delta": ni80,
        "normal_approx_seed_n_for_80pct_STRICT_equivalence_if_delta_zero": strict80,
        "normal_design_sensitivity_by_n": scenarios,
    }


def joint_noninferiority_normal_sensitivity(sample, *, seed=0, draws=100000):
    """5-year design sensitivity for passing BOTH economic safety gates.

    This deliberately assumes the observed bivariate normal paired-delta
    distribution and frozen reference means; it is not a 10-year prediction.
    """
    profits = [var - ref for row in sample for ref, var in [row[0]]]
    values = [var - ref for row in sample for ref, var in [row[1]]]
    n_original = len(sample)
    means = (statistics.mean(profits), statistics.mean(values))
    sds = (statistics.stdev(profits), statistics.stdev(values))
    margins = tuple(.01 * statistics.mean(row[i][0] for row in sample) for i in range(2))
    covariance = sum((p - means[0]) * (v - means[1]) for p, v in zip(profits, values)) / (n_original - 1)
    rho = covariance / (sds[0] * sds[1])
    if abs(rho) > 1 + 1e-10:
        raise ValueError("Invalid empirical covariance")
    rho = max(-1, min(1, rho))
    orthogonal = math.sqrt(max(0, 1-rho*rho))
    sizes = (20, 40, 60, 80, 100, 120, 160, 240, 480)
    counts = {size: 0 for size in sizes}
    generator = random.Random(seed)
    for _ in range(draws):
        z_profit = generator.gauss(0, 1)
        z_value = rho * z_profit + orthogonal * generator.gauss(0, 1)
        for size in sizes:
            se_profit = sds[0] / math.sqrt(size)
            se_value = sds[1] / math.sqrt(size)
            est_profit = means[0] + se_profit * z_profit
            est_value = means[1] + se_value * z_value
            if (est_profit - Z95_ONE * se_profit > -margins[0]
                    and est_value - Z95_ONE * se_value > -margins[1]):
                counts[size] += 1
    return {
        "empirical_correlation_profit_value_deltas": round(rho, 6),
        "assumptions": "5y bivariate normal deltas, reference denominator frozen, known SD, no matched-load opcode gate",
        "draws": draws,
        "normal_probability_both_economic_NI_gates_by_n": {
            str(size): round(counts[size] / draws, 5) for size in sizes
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", type=Path, default=DEFAULT_FILES)
    parser.add_argument("--draws", type=int, default=20000)
    parser.add_argument("--joint-draws", type=int, default=100000)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    if args.draws < 100:
        parser.error("--draws must be >=100 for percentile analysis")
    if args.joint_draws < 100:
        parser.error("--joint-draws must be >=100")
    output = {
        "notice": "EXPLORATORY reanalysis of completed 5-year trials; not retroactive acceptance. Year-10 variance/power unknown.",
        "samples": [],
    }
    for path in args.paths:
        result, pairs = pairs_from_result(path)
        comparison = result["policy_comparison"]
        output["samples"].append({
            "source": str(path),
            "source_bundle_sha256": result["source_bundle_sha256"],
            "original_decision_rule": comparison["decision_rule"]["rule"],
            "original_harness_verdict": comparison["verdict"],
            "old_40x5_adoption_gate_satisfied": comparison["verdict"] == "pass",
            "profit_year": analyze_metric(pairs, 0, draws=args.draws, seed=args.seed),
            "company_value": analyze_metric(pairs, 1, draws=args.draws, seed=args.seed),
            "joint_economic_sensitivity": joint_noninferiority_normal_sensitivity(
                pairs, seed=args.seed, draws=args.joint_draws),
            "opcodes_matched_load": "unmeasured",
            "opcodes_total_vm": "unmeasured",
        })
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
