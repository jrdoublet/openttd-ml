"""Reduce RAIL_MAGIC_CF/ITEM engine logs by seed/year.

Counts are *visits* of refreshed candidate pools. Only RAIL_MAGIC_ITEM has
identities, so only its AIR-beating OD cohort can be deduplicated. Neither a
score match nor a sum of forecast profits proves buildability or net gain.
"""

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
import re


LOG = re.compile(r"OPEX\s+(\d{4})-\d+-\d+\s+RAIL_MAGIC_(CF|ITEM)\s+(.+)")
KV = re.compile(r"([a-z][a-z_0-9]*)=([^\s]+)")
SEED = re.compile(r"seed(\d+)_r(\d+)\.log$")
TOTALS = (
    "rail_pool", "ratio_exposed", "ratio_reject", "ratio_pax", "ratio_freight",
    "ratio_profit_sum", "ratio_affordable", "ratio_above_air",
    "ratio_above_air_profit_sum", "bonus_top20_missed", "bonus_profit_sum",
    "economic_top20_replaced",
)


def analyse(logs):
    rows = defaultdict(lambda: {
        "snapshots": 0, "air_scored_snapshots": 0,
        "ratio_od_above_air": set(), "ratio_profit_distinct_above_air": {},
        **{name + "_visits": 0 for name in TOTALS},
    })
    for path in logs:
        path = Path(path)
        match = SEED.search(path.name)
        if match is None:
            raise ValueError(f"unrecognized seed/repeat: {path}")
        seed, repeat = map(int, match.groups())
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            parsed = LOG.search(line)
            if parsed is None:
                continue
            year, kind, payload = parsed.groups()
            row = rows[(seed, repeat, int(year))]
            fields = dict(KV.findall(payload))
            if kind == "CF":
                row["snapshots"] += 1
                if int(fields.get("air_profit", 0)) > 0:
                    row["air_scored_snapshots"] += 1
                for field in TOTALS:
                    row[field + "_visits"] += int(fields.get(field, 0))
            else:
                od = (fields.get("kind"), fields.get("cargo"),
                      fields.get("src"), fields.get("dst"))
                row["ratio_od_above_air"].add(od)
                row["ratio_profit_distinct_above_air"][od] = int(fields["profit"])
    report = []
    for (seed, repeat, year), row in sorted(rows.items()):
        od = row.pop("ratio_od_above_air")
        profits = row.pop("ratio_profit_distinct_above_air")
        row.update(seed=seed, repeat=repeat, year=year,
                   distinct_od_above_air=len(od),
                   distinct_od_profit_sum_above_air=sum(profits.values()))
        report.append(row)
    return report


def write_report(logs, output):
    report = analyse(logs)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    csv_path = output.with_suffix(".csv")
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        if report:
            writer = csv.DictWriter(f, fieldnames=list(report[0]))
            writer.writeheader()
            writer.writerows(report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("logs", nargs="+", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    report = write_report(args.logs, args.out)
    print(json.dumps({"rows": len(report), "snapshots": sum(r["snapshots"] for r in report),
                      "ratio_reject_visits": sum(r["ratio_reject_visits"] for r in report),
                      "air_beating_distinct_od_years": sum(r["distinct_od_above_air"] for r in report)}))


if __name__ == "__main__":
    main()
