"""Within-run observational neighbors of 54 logged AIR fleet buys (no simulator).

Run from repository root: python -X utf8 sweeps/analyse_air_p0_nearest_observational_20261009.py
Read-only inputs; outputs are new dated JSON / CSV files under results/.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date
from hashlib import sha256
from pathlib import Path
import csv
import json
import math
import statistics


ROOT = Path('results')
SOURCE_JSONL = ROOT / 'air_p0_probe_3x5_r1.jsonl'
BUY_JSON = ROOT / 'air_marginal_p0_buy_3x5_20261008.json'
ANNUAL_JSON = ROOT / 'air_marginal_p0_20x5_20261008_analysis.json'
OUT = ROOT / 'air_p0_nearest_observational_20261009.json'
EVENT_CSV = ROOT / 'air_p0_nearest_observational_20261009_events.csv'
LINE_CSV = ROOT / 'air_p0_nearest_observational_20261009_lines.csv'
REPORT_MD = ROOT / 'air_p0_nearest_observational_20261009_report.md'


def num(x):
    return round(float(x), 3)


def parse_date(raw):
    # AILog uses 1972-6-8 while save checkpoints use 1972-06-01.
    # Their lexical ordering is incorrect, even when both parse as dates.
    return date(*map(int, raw.split('-')))


def stat(vals):
    vals = [float(x) for x in vals if x is not None and math.isfinite(float(x))]
    return {'n': len(vals), 'mean': num(statistics.mean(vals)) if vals else None,
            'median': num(statistics.median(vals)) if vals else None,
            'sum': num(sum(vals)) if vals else None,
            'negative': sum(x < 0 for x in vals)}


def month_profit(line_before, line_after):
    return (float(line_after['profit_this_year_gbp']) -
            float(line_before['profit_this_year_gbp']))


def ids(line):
    return frozenset(int(v) for v in line['vehicle_ids'])


def line_index(snapshot):
    lines = [line for line in snapshot['line_telemetry']['lines'] if line['mode'] == 'air']
    result = {line['line_key_local']: line for line in lines}
    if len(result) != len(lines):
        raise ValueError('duplicate station-pair keys')
    return result


def check_fixed_geometry(lines):
    for field in ('station_ids', 'ordered_station_tiles', 'town_ids', 'market_key'):
        if len({json.dumps(x[field], sort_keys=True) for x in lines}) != 1:
            raise ValueError(f'line geometry drift on {field}')


def profit_window(lines):
    if len(lines) != 7:
        raise ValueError('need seven snapshots')
    pre = sum(month_profit(lines[j-1], lines[j]) for j in (1, 2, 3))
    post = sum(month_profit(lines[j-1], lines[j]) for j in (4, 5, 6))
    return num(pre), num(post), num(post-pre)


def classify(target, candidate):
    a_stations = set(map(int, target['station_ids']))
    b_stations = set(map(int, candidate['station_ids']))
    a_towns = set(map(int, target['town_ids']))
    b_towns = set(map(int, candidate['town_ids']))
    common_station = len(a_stations & b_stations)
    common_town = len(a_towns & b_towns)
    same_market = target['market_key'] == candidate['market_key']
    if common_station:
        tier = 'shared_station'
    elif same_market:
        tier = 'same_od_other_station'
    elif common_town:
        tier = 'shared_endpoint_town'
    else:
        tier = 'unaffected_town_proxy'
    return {'tier': tier, 'shared_station_count': common_station,
            'shared_town_count': common_town, 'same_od_market': bool(same_market),
            'target_towns': list(map(int, target['town_ids'])),
            'candidate_towns': list(map(int, candidate['town_ids']))}


def event_group(rows):
    stable = [r for r in rows if r['fleet_stable_7m']]
    changed = [r for r in rows if not r['fleet_stable_7m']]
    return {'n_all_lines': len(rows), 'n_stable': len(stable), 'n_changed': len(changed),
            'stable_change': stat(x['profit_delta_3m'] for x in stable),
            'changed_descriptive_change': stat(x['profit_delta_3m'] for x in changed),
            'stable_pre_profit': stat(x['profit_pre_3m'] for x in stable),
            'stable_vehicle_count': stat(x['n_aircraft_pre'] for x in stable)}


def main():
    purchase_report = json.loads(BUY_JSON.read_text(encoding='utf-8'))
    events = purchase_report['isolated_logged_events']
    buys = purchase_report['buy_events']
    if len(events) != 54 or len(buys) != 117:
        raise ValueError(f'unexpected event count {len(events)}, {len(buys)}')
    snapshots = {}
    aaa_snapshots = {}
    with SOURCE_JSONL.open(encoding='utf-8') as source:
        for line in source:
            s = json.loads(line)
            if s.get('duel_policy_id') != 'air_p0_probe_on':
                continue
            arm = s.get('arm', s.get('run', [''])[0])
            if arm not in ('OpexAI', 'AAAHogEx'):
                continue
            key = (int(s['run'][1]), s['date'])
            target_snaps = snapshots if arm == 'OpexAI' else aaa_snapshots
            if key in target_snaps:
                raise ValueError(f'duplicate snapshot {key}')
            if not s['line_telemetry']['ok']:
                raise ValueError(f'invalid telemetry {key}')
            target_snaps[key] = s
    if len(snapshots) != 180 or len(aaa_snapshots) != 180:
        raise ValueError(f'ON checkpoint coverage: {len(snapshots)} Opex, {len(aaa_snapshots)} AAA != 180 each')
    years_by_seed = defaultdict(list)
    indexed = {}
    for (seed, date), s in snapshots.items():
        years_by_seed[seed].append(date)
        indexed[(seed, date)] = line_index(s)
    for seq in years_by_seed.values():
        seq.sort()
    indexed_aaa={(seed, d):line_index(s) for (seed,d),s in aaa_snapshots.items()}

    buys_by_event = defaultdict(list)
    for buy in buys:
        buys_by_event[(int(buy['seed']), buy['date'], int(buy['log_line']))].append(buy)
    all_events = []
    all_neighbors = []
    all_aaa_neighbors = []

    for event in events:
        seed = int(event['seed'])
        checkpoint = event['first_observed_new_vehicle']
        months = years_by_seed[seed]
        ix = months.index(checkpoint)
        local_dates = months[ix-4:ix+3]
        if len(local_dates) != 7 or len({d[:4] for d in local_dates}) != 1:
            raise ValueError(f'non local-year window {event}')
        purchase_match = buys_by_event[(seed, event['date'], int(event['log_line']))]
        if len(purchase_match) != 1:
            raise ValueError(f'purchase uniqueness {seed} {event["date"]}')
        purchase = purchase_match[0]
        after_set = indexed[(seed, local_dates[4])]
        key = event['line_key_local']
        target = after_set[key]
        target_stations = tuple(sorted(int(q) for q in target['ordered_station_tiles']))
        if tuple(purchase['station_tile_pair']) != target_stations:
            raise ValueError(f'exact station tiles changed {seed} {key}')
        target_local = [indexed[(seed, d)][key] for d in local_dates]
        check_fixed_geometry(target_local)
        prior = ids(target_local[3])
        after = ids(target_local[4])
        if ids(target_local[0]) != prior or len(after-prior) != 1 or len(prior-after) or any(ids(l) != prior for l in target_local[:4]) or any(ids(l) != after for l in target_local[4:]):
            raise ValueError(f'event fleet not isolated {seed} {key}')
        old_pre, old_post = [], []
        for j in (1, 2, 3):
            left = {v['vehicle_id']: v for v in target_local[j-1]['vehicle_financials']}
            right = {v['vehicle_id']: v for v in target_local[j]['vehicle_financials']}
            old_pre.append(sum(float(right[i]['profit_this_year_gbp'])-float(left[i]['profit_this_year_gbp']) for i in prior))
        for j in (4, 5, 6):
            left = {v['vehicle_id']: v for v in target_local[j-1]['vehicle_financials']}
            right = {v['vehicle_id']: v for v in target_local[j]['vehicle_financials']}
            old_post.append(sum(float(right[i]['profit_this_year_gbp'])-float(left[i]['profit_this_year_gbp']) for i in prior))
        if abs(sum(old_pre)-event['old_profit_previous_3months']) > .02 or abs(sum(old_post)-event['old_profit_following_3months']) > .02:
            raise ValueError(f'old vehicle accounting differs {seed} {event["date"]}')

        # A neighbor must exist at every checkpoint. New/retired routes are
        # separately counted as concurrent activity, not used as stable controls.
        common = set.intersection(*(set(indexed[(seed,d)]) for d in local_dates))
        common.discard(key)
        neighbors = []
        for other_key in sorted(common):
            series = [indexed[(seed,d)][other_key] for d in local_dates]
            check_fixed_geometry(series)
            pre, post, delta = profit_window(series)
            identity = [ids(x) for x in series]
            relation = classify(target, series[3])
            record = {'seed':seed, 'date':event['date'], 'event_line':key, 'company':'OpexAI',
                      'other_line':other_key, 'before_aircraft':int(event['before']),
                      'tier':relation['tier'], 'same_od_market':relation['same_od_market'],
                      'shared_station_count':relation['shared_station_count'],
                      'shared_town_count':relation['shared_town_count'],
                      'target_towns':relation['target_towns'],
                      'candidate_towns':relation['candidate_towns'],
                      'candidate_station_ids':list(map(int,series[3]['station_ids'])),
                      'fleet_stable_7m':len(set(identity))==1,
                      'fleet_stable_pre_4m':len(set(identity[:4]))==1,
                      'fleet_changes_count':sum(identity[j] != identity[j-1] for j in range(1,7)),
                      'n_aircraft_pre':len(identity[3]), 'n_aircraft_post':len(identity[6]),
                      'profit_pre_3m':pre,'profit_post_3m':post,'profit_delta_3m':delta}
            neighbors.append(record)
            all_neighbors.append(record)

        by_tier={tier: [r for r in neighbors if r['tier']==tier]
                 for tier in ('shared_station','same_od_other_station','shared_endpoint_town','unaffected_town_proxy')}

        # Opponent lines are a separate company and have no AIR_P0_BUY log.
        # Compare their stable aircraft and market exposure, without using them
        # as unexposed controls of Opex's own investment policy.
        aaa_common=set.intersection(*(set(indexed_aaa[(seed,d)]) for d in local_dates))
        aaa_neighbors=[]
        aaa_skipped_changed_geometry=0
        for aaa_key in sorted(aaa_common):
            aaa_series=[indexed_aaa[(seed,d)][aaa_key] for d in local_dates]
            try:
                check_fixed_geometry(aaa_series)
            except ValueError:
                aaa_skipped_changed_geometry+=1
                continue
            aaa_pre,aaa_post,aaa_delta=profit_window(aaa_series)
            aaa_identity=[ids(x) for x in aaa_series]
            rel=classify(target,aaa_series[3])
            aaa_rec={'seed':seed,'date':event['date'],'event_line':key,'company':'AAAHogEx',
                     'other_line':aaa_key,'before_aircraft':int(event['before']),
                     'tier':rel['tier'], 'same_od_market':rel['same_od_market'],
                     'shared_station_count':rel['shared_station_count'],
                     'shared_town_count':rel['shared_town_count'],
                     'target_towns':rel['target_towns'],
                     'candidate_towns':rel['candidate_towns'],
                     'candidate_station_ids':list(map(int,aaa_series[3]['station_ids'])),
                     'fleet_stable_7m':len(set(aaa_identity))==1,
                     'fleet_stable_pre_4m':len(set(aaa_identity[:4]))==1,
                     'fleet_changes_count':sum(aaa_identity[j]!=aaa_identity[j-1] for j in range(1,7)),
                     'n_aircraft_pre':len(aaa_identity[3]),
                     'n_aircraft_post':len(aaa_identity[6]),
                     'profit_pre_3m':aaa_pre,'profit_post_3m':aaa_post,
                     'profit_delta_3m':aaa_delta}
            aaa_neighbors.append(aaa_rec)
            all_aaa_neighbors.append(aaa_rec)
        aaa_by_tier={tier:[r for r in aaa_neighbors if r['tier']==tier]
                     for tier in ('shared_station','same_od_other_station','shared_endpoint_town','unaffected_town_proxy')}
        # Compare with the nearest *stable* town-disjoint line in the same run and
        # same seven months. Rank by pre-profit per existing aircraft and fleet N.
        disjoint = [r for r in by_tier['unaffected_town_proxy'] if r['fleet_stable_7m'] and r['n_aircraft_pre']]
        old_pre_total = num(sum(old_pre))
        old_post_total = num(sum(old_post))
        pre_n = len(prior)
        def distance(r):
            return (abs(r['n_aircraft_pre']-pre_n),
                    abs(r['profit_pre_3m']/r['n_aircraft_pre'] - old_pre_total/pre_n), r['other_line'])
        # All 117 logged purchases in the 6 intervals, including purchases of
        # other lines and other months, can contaminate the economic comparison.
        competing = []
        competing_line_geometries = []
        unknown_competing_geometry = 0
        for b in buys:
            if int(b['seed'])!=seed or b is purchase:
                continue
            bdate=b['date']
            if not (parse_date(local_dates[0]) < parse_date(bdate) <= parse_date(local_dates[-1])):
                continue
            bkey=b.get('matching_saved_line_key')
            related=next((r for r in neighbors if r['other_line']==bkey),None)
            if related is None and bkey:
                observed=indexed.get((seed,b['checkpoint_after_buy']),{}).get(bkey)
                if observed is not None:
                    related=classify(target,observed)
            observed=indexed.get((seed,b['checkpoint_after_buy']),{}).get(bkey) if bkey else None
            if observed:
                competing_line_geometries.append(observed)
            else:
                unknown_competing_geometry+=1
            competing.append({'date':bdate,'line_id':b['line'], 'saved_line':bkey,
                              'tier':related['tier'] if related else ('target_same_line' if bkey==key else 'unknown_or_unstable'),
                              'same_month_as_target':parse_date(bdate).year==parse_date(event['date']).year and parse_date(bdate).month==parse_date(event['date']).month,
                              'purchase_after_target':parse_date(bdate)>parse_date(event['date'])})

        # A disjoint-town comparator might itself be hit by a DIFFERENT purchase
        # during the six-month window. Report both nearest candidates, and use
        # the cleanest available for the adjusted contrast.
        for r in disjoint:
            stations=set(r['candidate_station_ids'])
            towns=set(r['candidate_towns'])
            r['neighbor_touched_by_other_logged_buy'] = any(
                bool(stations & set(map(int, geo['station_ids'])) or
                     towns & set(map(int, geo['town_ids']))) for geo in competing_line_geometries)
        clean_disjoint=[r for r in disjoint if not r['neighbor_touched_by_other_logged_buy']]
        nearest_unfiltered=min(disjoint,key=distance) if disjoint else None
        nearest=min(clean_disjoint,key=distance) if clean_disjoint else nearest_unfiltered
        nearest_scaled_change=(nearest['profit_delta_3m']/nearest['n_aircraft_pre']*pre_n) if nearest else None
        adjusted_old=(old_post_total-old_pre_total-nearest_scaled_change) if nearest else None

        # Count observed extra fleet changes (including purchases without logs,
        # replacements, transfers and changes to opening/closing routes).
        changes=[]
        for j in range(1,7):
            left=indexed[(seed,local_dates[j-1])]
            right=indexed[(seed,local_dates[j])]
            for other_key in left.keys() | right.keys():
                if other_key==key:
                    continue
                old = ids(left[other_key]) if other_key in left else frozenset()
                new = ids(right[other_key]) if other_key in right else frozenset()
                if old == new:
                    continue
                rel=classify(target,(right.get(other_key) or left[other_key]))
                changes.append({'month':local_dates[j], 'line':other_key,
                                'tier':rel['tier'],'added':len(new-old),'removed':len(old-new),
                                'new_route':other_key not in left,
                                'retired_route':other_key not in right})

        old_delta=old_post_total-old_pre_total
        if abs((old_delta+event['new_vehicle_profit_following_3months'])-event['observed_line_increment_net_3months']) > .02:
            raise ValueError(f'old and new profits do not reconstruct line delta {seed} {event["date"]}')
        rec={'seed':seed, 'purchase_date':event['date'], 'purchase_log_line':int(event['log_line']),
             'first_seen':checkpoint,'line_key_local':key, 'market_key':target['market_key'],
             'station_ids':target['station_ids'], 'station_tiles':list(target_stations),
             'endpoint_town_ids':list(map(int,target['town_ids'])),
             'aircraft_before':pre_n, 'aircraft_after':len(after), 'new_vehicle_id':event['new_vehicle_id'],
             'cost_cash':int(event['cost_cash']), 'prediction_3m':num(event['prediction_prorated_3months']),
             'old_pre_3m':old_pre_total,'old_post_3m':old_post_total,'old_delta_3m':num(old_delta),
             'new_profit_3m':num(event['new_vehicle_profit_following_3months']),
             'line_delta_3m':num(event['observed_line_increment_net_3months']),
             'line_delta_net_prediction':num(event['observed_minus_prorated_prediction']),
             'control_same_seed_same_window':nearest['other_line'] if nearest else None,
             'control_matched_exact_n':bool(nearest and nearest['n_aircraft_pre']==pre_n),
             'control_stable_disjoint_town_no_other_logged_overlap':bool(nearest and not nearest.get('neighbor_touched_by_other_logged_buy',False)),
             'number_stable_disjoint_controls':len(disjoint),
             'number_clean_stable_disjoint_controls':len(clean_disjoint),
             'unfiltered_nearest_control':nearest_unfiltered['other_line'] if nearest_unfiltered else None,
             'unknown_competing_geometry':unknown_competing_geometry,
             'control_n':nearest['n_aircraft_pre'] if nearest else None,
             'control_pre_profit_per_plane':num(nearest['profit_pre_3m']/nearest['n_aircraft_pre']) if nearest else None,
             'control_change_per_plane':num(nearest['profit_delta_3m']/nearest['n_aircraft_pre']) if nearest else None,
             'control_trend_scaled_to_old_n':num(nearest_scaled_change) if nearest else None,
             'old_delta_adjusted_control':num(adjusted_old) if adjusted_old is not None else None,
             'total_line_delta_adjusted_control':num(recval) if (recval := (event['observed_line_increment_net_3months']-nearest_scaled_change if nearest_scaled_change is not None else None)) is not None else None,
             'groups':{tier:event_group(rows) for tier,rows in by_tier.items()},
             'aaa_groups':{tier:event_group(rows) for tier,rows in aaa_by_tier.items()},
             'aaa_lines_skipped_unstable_geometry':aaa_skipped_changed_geometry,
             'other_purchases_in_six_months':len(competing),
             'other_purchases_same_month':sum(x['same_month_as_target'] for x in competing),
             'other_purchases_after_buy':sum(x['purchase_after_target'] for x in competing),
             'other_purchases_same_station':sum(x['tier']=='shared_station' for x in competing),
             'other_purchases_same_od_other_station':sum(x['tier']=='same_od_other_station' for x in competing),
             'other_purchases_shared_town':sum(x['tier']=='shared_endpoint_town' for x in competing),
             'other_purchases_unknown_relation':sum(x['tier']=='unknown_or_unstable' for x in competing),
             'other_purchases':competing,
             'other_air_line_fleet_changes_in_six_months':len(changes),
             'other_changes_same_station':sum(x['tier']=='shared_station' for x in changes),
             'other_changes_same_od_other_station':sum(x['tier']=='same_od_other_station' for x in changes),
             'other_changes_shared_town':sum(x['tier']=='shared_endpoint_town' for x in changes),
             'other_line_changes':changes}
        all_events.append(rec)

    tiers=('shared_station','same_od_other_station','shared_endpoint_town','unaffected_town_proxy')
    summary_tiers={}
    summary_aaa_tiers={}
    for tier in tiers:
        rows=[r for r in all_neighbors if r['tier']==tier]
        stable=[r for r in rows if r['fleet_stable_7m']]
        changed=[r for r in rows if not r['fleet_stable_7m']]
        summary_tiers[tier]={
            'number_of_event_line_pairs':len(rows), 'number_of_events_with_stable_lines':sum(e['groups'][tier]['n_stable']>0 for e in all_events),
            'stable':{'n':len(stable),'delta':stat(x['profit_delta_3m'] for x in stable),
                      'negative_pairs':sum(x['profit_delta_3m']<0 for x in stable),
                      'unique_seed_line_month_start_pairs':len({(r['seed'],r['other_line'],r['date'][:7]) for r in stable})},
            'changed':{'n':len(changed),'delta_descriptive':stat(x['profit_delta_3m'] for x in changed)},
            'mean_stable_delta_per_event_with_coverage':stat(stat(x['profit_delta_3m'] for x in rows if x['fleet_stable_7m'])['mean'] for rows in ([r for r in all_neighbors if r['seed']==e['seed'] and r['date']==e['purchase_date'] and r['event_line']==e['line_key_local'] and r['tier']==tier] for e in all_events))}
        rows_aaa=[r for r in all_aaa_neighbors if r['tier']==tier]
        stable_aaa=[r for r in rows_aaa if r['fleet_stable_7m']]
        changed_aaa=[r for r in rows_aaa if not r['fleet_stable_7m']]
        summary_aaa_tiers[tier]={
            'event_line_pairs':len(rows_aaa),
            'events_with_stable':sum(e['aaa_groups'][tier]['n_stable']>0 for e in all_events),
            'stable':{'n':len(stable_aaa),'delta':stat(r['profit_delta_3m'] for r in stable_aaa),
                      'unique_seed_line_event_month_pairs':len({(r['seed'],r['other_line'],r['date'][:7]) for r in stable_aaa})},
            'changed':{'n':len(changed_aaa),'delta_descriptive':stat(r['profit_delta_3m'] for r in changed_aaa)}}
    annual = json.loads(ANNUAL_JSON.read_text(encoding='utf-8'))
    annual_reference={'provenance':annual.get('provenance',{}),
                      'mean_transitions_1972_1974':[r for r in annual.get('mean_transitions',[]) if r['from']==1972 and r['to']==1974 and r['arm']=='OpexAI']}
    source=json.loads((ROOT/'air_p0_probe_3x5_r1.manifest.json').read_text(encoding='utf-8'))
    result={'method':'6 monthly profit intervals: 3 pre and 3 post, same ON run and calendar year; event window covers seven checkpoints; neighbor grouping exclusive exact station / same town-OD / one endpoint town / disjoint towns. Stable controls only where vehicle IDs constant at all seven checkpoints.',
            'provenance':{'buy_report':str(BUY_JSON), 'monthly_jsonl':str(SOURCE_JSONL),
                          'buy_sha256':sha256(BUY_JSON.read_bytes()).hexdigest(),
                          'monthly_jsonl_sha256':sha256(SOURCE_JSONL.read_bytes()).hexdigest(),
                          'buy_summary':purchase_report['summary'],
                          'manifest_campaign':source.get('campaign_id'),
                          'year_and_seed_coverage':{str(k):[v[0],v[-1],len(v)] for k,v in years_by_seed.items()},
                          'annual_20x5_separate_bundle':annual_reference},
            'summary':{'n_events':len(all_events), 'by_seed':dict(Counter(str(e['seed']) for e in all_events)),
                       'by_year':dict(Counter(e['purchase_date'][:4] for e in all_events)),
                       'old_delta':stat(e['old_delta_3m'] for e in all_events),
                       'new_profit':stat(e['new_profit_3m'] for e in all_events),
                       'line_delta':stat(e['line_delta_3m'] for e in all_events),
                       'old_delta_adjusted_stable_disjoint_controls':stat(e['old_delta_adjusted_control'] for e in all_events),
                       'line_delta_adjusted_stable_disjoint_controls':stat(e['total_line_delta_adjusted_control'] for e in all_events),
                       'n_events_with_control':sum(e['control_same_seed_same_window'] is not None for e in all_events),
                       'n_events_with_clean_stable_disjoint_control':sum(e['control_stable_disjoint_town_no_other_logged_overlap'] for e in all_events),
                       'n_events_with_exact_n_control':sum(e['control_matched_exact_n'] for e in all_events),
                       'n_events_with_competing_logged_purchase':sum(e['other_purchases_in_six_months']>0 for e in all_events),
                       'n_events_with_competing_logged_purchase_after_buy':sum(e['other_purchases_after_buy']>0 for e in all_events),
                       'n_events_with_competing_same_station':sum(e['other_purchases_same_station']>0 for e in all_events),
                       'n_events_with_competing_shared_town_or_od':sum(e['other_purchases_same_od_other_station']+e['other_purchases_shared_town']>0 for e in all_events),
                       'n_events_with_other_fleet_change':sum(e['other_air_line_fleet_changes_in_six_months']>0 for e in all_events),
                       'total_competing_logged_purchase_mentions':sum(e['other_purchases_in_six_months'] for e in all_events),
                       'total_competing_logged_post_purchase_mentions':sum(e['other_purchases_after_buy'] for e in all_events),
                       'total_competing_logged_same_station_mentions':sum(e['other_purchases_same_station'] for e in all_events),
                       'sum_positive_prediction_shortfall_3m':num(sum(max(0,e['prediction_3m']-e['line_delta_3m']) for e in all_events)),
                       'sum_negative_observed_line_delta_3m':num(sum(min(0,e['line_delta_3m']) for e in all_events)),
                       'events_new_plane_negative_profit':sum(e['new_profit_3m']<0 for e in all_events),
                       'by_relation':summary_tiers,
                       'opponent_aaa_by_relation':summary_aaa_tiers,
                       'aaa_lines_skipped_unstable_geometry':sum(e['aaa_lines_skipped_unstable_geometry'] for e in all_events),
                       'cash_spent_on_54':int(sum(e['cost_cash'] for e in all_events)),
                       'negative_line_delta_spend':int(sum(e['cost_cash'] for e in all_events if e['line_delta_3m']<0)),
                       'negative_old_delta_spend':int(sum(e['cost_cash'] for e in all_events if e['old_delta_3m']<0))},
            'per_seed':{str(seed):{'events':len(group),'old_delta':stat(e['old_delta_3m'] for e in group),
                                   'line_delta':stat(e['line_delta_3m'] for e in group),
                                   'old_control_adjusted':stat(e['old_delta_adjusted_control'] for e in group),
                                   'line_control_adjusted':stat(e['total_line_delta_adjusted_control'] for e in group),
                                   'cash_spent':sum(e['cost_cash'] for e in group)}
                        for seed in sorted({e['seed'] for e in all_events})
                        for group in [[e for e in all_events if e['seed']==seed]]},
            'per_year':{str(year):{'events':len(group),'old_delta':stat(e['old_delta_3m'] for e in group),
                                   'line_delta':stat(e['line_delta_3m'] for e in group),
                                   'old_control_adjusted':stat(e['old_delta_adjusted_control'] for e in group),
                                   'line_control_adjusted':stat(e['total_line_delta_adjusted_control'] for e in group),
                                   'cash_spent':sum(e['cost_cash'] for e in group)}
                        for year in (1972,1973,1974)
                        for group in [[e for e in all_events if int(e['purchase_date'][:4])==year]]},
            'events':all_events,
            'caveats':['Observational contrast cannot identify causal cannibalization or lost return. Buying decisions and fleet size correlate with unobserved demand, age, market competition and trend.',
                       'The disjoint-town matched control is a single contemporaneous stable line selected first by fleet size and then pre-profit per aircraft. Lines untouched by other logged purchases on the same stations or endpoint towns are preferred; if no such line exists the nearest potentially exposed stable control is used. It is not a randomized counterfactual.',
                       'Purchases have overlapping six-month windows; sums across 54 are purchase-window exposures, not additive lost company profit. Changed-fleet neighbors are excluded from stable comparator stats.',
                       'Vehicle YTD profit is net of running cost but excludes aircraft purchase and airport capital; quarter-year prediction uses annual/4 and is not a causal treatment effect.',
                       'Same station uses physical station IDs; same town/OD uses saved town IDs, not physical catchment polygons. Town IDs cannot establish passenger travel direction. AAAHogEx lines are analyzed separately, and AIGroup route keys can differ from Opex station pairs.',
                       'Annual historical 20x5 and this 3x5 have distinct frozen source bundles; no difference-in-differences across them.']}
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    cols=('seed','purchase_date','line_key_local','market_key','endpoint_town_ids','station_ids','aircraft_before','aircraft_after','cost_cash','prediction_3m','old_pre_3m','old_post_3m','old_delta_3m','new_profit_3m','line_delta_3m','control_same_seed_same_window','control_matched_exact_n','control_stable_disjoint_town_no_other_logged_overlap','number_stable_disjoint_controls','number_clean_stable_disjoint_controls','control_trend_scaled_to_old_n','old_delta_adjusted_control','total_line_delta_adjusted_control','other_purchases_in_six_months','other_purchases_after_buy','other_purchases_same_station','other_purchases_shared_town','other_air_line_fleet_changes_in_six_months')
    with EVENT_CSV.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');writer.writeheader()
        for row in all_events:
            writer.writerow({k:(json.dumps(row[k]) if isinstance(row.get(k),list) else row.get(k)) for k in cols})
    with LINE_CSV.open('w',newline='',encoding='utf-8') as f:
        cols=tuple(k for k in all_neighbors[0].keys() if k not in ('target_towns','candidate_towns','candidate_station_ids'))
        writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');writer.writeheader();writer.writerows(all_neighbors + all_aaa_neighbors)
    sm=result['summary']
    report=f'''# P0 AIR — observation de 54 achats et lignes voisines (09/10/2026)

**Sources figées** : `air_p0_probe_3x5_r1.jsonl` et `air_marginal_p0_buy_3x5_20261008.json`, campagne ON `a199cca49...`, graines 42/512/65537. Les événements appartiennent aux **mêmes simulations** que les lignes comparées. Les 20 graines annuelles `chrono_opex_aaa_20x5_20261008_r1` ont un autre bundle `3d159220...`, utilisé séparément pour vérifier l'ordre de grandeur historique et **jamais** comme contrefactuel des achats 3×5.

Les 54 achats réellement logués et identifiés par paire exacte de tuiles d'aéroport ont sept sauvegardes consécutives au sein d'une année civile, chacune séparée d'un mois. On recompose les profits moteurs des trois intervalles avant et des trois après le renfort, en recalculant les différences des profits cumulés annuels **pour les anciens identifiants d'avions inchangés**. Les 54 reconstructions concordent avec le rapport initial. Les témoins demeurent sous leur même identifiant de ligne physique dans toute la fenêtre ; on les sépare entre flottes constantes sur sept checkpoints et flottes modifiées.

| Mesure sur 54 fenêtres de trois mois | Valeur |
|---|---:|
| Achat en 1972 / 1973 / 1974 | 10 / 29 / 15 |
| Anciens appareils : Δ profit brut avant/après, médiane / moyenne | {sm['old_delta']['median']:,.0f} / {sm['old_delta']['mean']:,.0f} £ |
| Anciens appareils : Δ négatif | {sm['old_delta']['negative']}/54 |
| Profit du nouvel appareil sur trois mois, médiane | {sm['new_profit']['median']:,.0f} £ |
| Δ total de la ligne, médiane / moyenne | {sm['line_delta']['median']:,.0f} / {sm['line_delta']['mean']:,.0f} £ |
| Δ total négatif | {sm['line_delta']['negative']}/54 |
| Ancien Δ corrigé par la tendance du témoin contemporain, médiane / moyenne | {sm['old_delta_adjusted_stable_disjoint_controls']['median']:,.0f} / {sm['old_delta_adjusted_stable_disjoint_controls']['mean']:,.0f} £ |
| Ancien Δ corrigé négatif | {sm['old_delta_adjusted_stable_disjoint_controls']['negative']}/54 |
| Δ ligne corrigé par tendance, médiane / moyenne | {sm['line_delta_adjusted_stable_disjoint_controls']['median']:,.0f} / {sm['line_delta_adjusted_stable_disjoint_controls']['mean']:,.0f} £ |
| Δ ligne corrigé négatif | {sm['line_delta_adjusted_stable_disjoint_controls']['negative']}/54 |

## Lignes voisines observées

| Relation à la ligne renforcée (catégories exclusives) | Couples achat×ligne à flotte constante | Δ médian de profit sur trois mois | Δ négatifs | Flotte modifiée (descriptif seul) |
|---|---:|---:|---:|---:|
| StationID physique partagé | 145 | {summary_tiers['shared_station']['stable']['delta']['median']:,.0f} £ | 66 | 37 |
| Même paire de villes (marché OD), gares distinctes | 0 | n.d. | 0 | 0 |
| Une ville d'extrémité commune, gares distinctes | 4 | {summary_tiers['shared_endpoint_town']['stable']['delta']['median']:,.0f} £ | 4 | 0 |
| Villes d'extrémité disjointes | 1 490 | {summary_tiers['unaffected_town_proxy']['stable']['delta']['median']:,.0f} £ | 594 | 431 |

La comparaison adversaire est **séparée** : AAAHogEx utilise des clés `AIGroup` et une flotte dont la stabilité doit aussi être vérifiée. Paires achat Opex × ligne AAA conservées et à flotte stable : même marché OD autre station {summary_aaa_tiers['same_od_other_station']['stable']['n']}, une ville commune {summary_aaa_tiers['shared_endpoint_town']['stable']['n']}, villes disjointes {summary_aaa_tiers['unaffected_town_proxy']['stable']['n']}. Δ médians trois mois respectifs : {summary_aaa_tiers['same_od_other_station']['stable']['delta']['median']} / {summary_aaa_tiers['shared_endpoint_town']['stable']['delta']['median']} / {summary_aaa_tiers['unaffected_town_proxy']['stable']['delta']['median']} £. La concurrence AAA peut être associée à la variation, mais ne fournit pas de contrefactuel de décision Opex.

Ces couples se répètent dans des fenêtres d'achat rapprochées, donc leurs sommes ne représentent **pas** des profits additionnables. Le groupe partagé-station dispose d'au moins un témoin stable dans 53/54 fenêtres. Les quatre cas ville seule réutilisent trois couples graine/ligne/mois distincts ; leur perte est une exposition à approfondir, sans test statistique ni effet causal identifié. Il n'existe **aucune** autre ligne stable de même marché OD et d'aéroports distincts dans ces 54 fenêtres : on ne peut pas tester directement cet angle mort C121 à partir du lot.

## Témoin temporel le plus proche

Chaque achat est comparé à une autre ligne OpexAI, **sur la même graine et les mêmes sept mois**, avec une flotte identique sur toute cette période et des villes d'extrémité disjointes. Si possible, le témoin est choisi parmi les lignes ne partageant ni ville ni station avec **aucun autre achat AIR logué** pendant les six intervalles ; puis même taille de flotte et profit d'avant achat par avion le plus proche. Il existe un tel témoin pour {sm['n_events_with_clean_stable_disjoint_control']}/54 événements, dont {sm['n_events_with_exact_n_control']} avec la même taille de flotte. L'ajustement soustrait la variation du témoin, multipliée par le nombre d'anciens avions pour la ramener à la taille de la ligne acheteuse.

**Contamination constatée** : chaque fenêtre a d'autres changements de flotte et d'autres achats logués ; {sm['total_competing_logged_purchase_mentions']} occurrences événement×achat concurrent sur les 54 fenêtres, dont {sm['total_competing_logged_post_purchase_mentions']} achats ultérieurs dans leur fenêtre respective. {sm['n_events_with_competing_same_station']} fenêtres contiennent un autre achat lié à au moins une station de la ligne cible (38 occurrences). Ces nombres comptent les répétitions de fenêtres et ne représentent **pas** autant d'achats distincts. L'absence de recouvrement de villes ne garantit pas absence d'effets indirects, de changements concurrentiels ou de différences de demande.

À titre de sensibilité, le Δ ajusté des anciens avions est de {result['per_year']['1974']['old_control_adjusted']['mean']:,.0f} £ moyens par fenêtre en **1974** ({result['per_year']['1974']['old_control_adjusted']['negative']}/15 baisses), mais de {result['per_year']['1972']['old_control_adjusted']['mean']:,.0f} £ en **1972** (4/10 baisses). L'échantillon est **très asymétrique** : 30 achats graine 42, 7 graine 512, 17 graine 65537. Les effets communs aux graines, aux périodes et aux flottes sont impossibles à corriger avec ces seules données.

## Poids économique et verdict

Ces 54 achats représentent **{sm['cash_spent_on_54']:,.0f} £ de trésorerie dépensée** ; {sm['negative_line_delta_spend']:,.0f} £ concernent les 17 achats suivis d'une baisse de profit total de ligne pendant la fenêtre, et {sm['negative_old_delta_spend']:,.0f} £ les 26 achats suivis d'une baisse de profit des anciens appareils. **12 nouveaux avions** ont un profit moteur négatif pendant leurs trois premiers mois observés. Le total des baisses observées de profit de ligne pour les 17 fenêtres est {sm['sum_negative_observed_line_delta_3m']:,.0f} £, et la somme des parties positives de l'écart devis trimestrialisé moins réalisé est {sm['sum_positive_prediction_shortfall_3m']:,.0f} £. Ce sont des **expositions descriptives dans des fenêtres qui se recouvrent**, et non des pertes financières additionnables, des rendements nets du capital ou des estimations d'économies par suppression d'avions.

**Perte causalement attribuable aux renforts : non identifiée, borne inférieure prouvée = 0 £.** Dans ce lot, le signal le plus robuste est l'absence d'apprentissage marginal avant beaucoup d'achats et la faible marge corrigée sur les anciens avions, surtout en 1974. Le réseau voit aussi des déclins de profits de lignes qui ne changent pas de flotte (594/1 490 couples témoins disjoints). La comparaison partageant exactement une station donne 66/145 baisses mais aucune baisse moyenne systématique qui permettrait de déclarer une cannibalisation causale. Le manque de répétitions indépendantes et les achats concurrents rendent une borne haute causale impossible.

**Étape utile suivante** : relever, juste avant les premiers 1→2 sous cible et sans échantillon, le débit PASS/MAIL réel, les capacités disponibles et les aires de captage exactes (mêmes tuiles couvertes par gares distinctes). Suivre ensuite les mêmes cohortes après leur mise en régime et documenter la concurrence. Pour attribuer une perte de profit ou un coût d'opportunité, il faudra un bras témoin figé dont le seul changement est le renfort choisi, avec répétitions sur graines indépendantes. Aucun paramètre de flotte numérique n'est déduit de cette étude.

**Reproductibilité** : `python -X utf8 sweeps/analyse_air_p0_nearest_observational_20261009.py`. Détail des 54 achats : `_events.csv` ; {len(all_neighbors)+len(all_aaa_neighbors):,} couples ligne voisine×achat Opex ou AAA avec profits avant/après et flotte stable/changée : `_lines.csv` ; provenance, fenêtres et achats concurrents complets : `.json`.
'''
    REPORT_MD.write_text(report,encoding='utf-8')
    print('OUTPUT', OUT, EVENT_CSV, LINE_CSV, REPORT_MD)
    print('SUMMARY',json.dumps({k:v for k,v in result['summary'].items() if k!='by_relation'},ensure_ascii=False))
    print('RELATIONS',json.dumps(summary_tiers,ensure_ascii=False))


if __name__=='__main__':
    main()
