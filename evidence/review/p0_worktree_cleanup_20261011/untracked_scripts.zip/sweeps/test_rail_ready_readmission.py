"""P0: contrats statiques du report RAIL A* pret devant le portefeuille live.

Les tests ne remplacent pas la compilation Squirrel et le duel moteur.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def src(name):
    return (ROOT / name).read_text(encoding="utf-8")


class ReadyReadmissionContracts(unittest.TestCase):
    def test_all_difficulties_off(self):
        self.assertIn("RAIL_READY_READMISSION <- false;", src("globals_pre.nut"))
        self.assertIn(
            'RAIL_READY_READMISSION = AIController.GetSetting("rail_ready_readmission") != 0;',
            src("settings.nut"),
        )
        info = src("info.nut")
        self.assertEqual(info.count('name = "rail_ready_readmission"'), 1)
        block = info.split('name = "rail_ready_readmission"', 1)[1].split("});", 1)[0]
        for difficulty in ("easy", "medium", "hard", "custom"):
            self.assertRegex(block, rf"{difficulty}_value\s*=\s*0\b")

    def test_old_path_preserved_if_off(self):
        task = src("task_projects.nut")
        helper = task.split("function OpexAI::_railReadyReadmissionShouldDefer(alreadyDeferred)", 1)[1].split(
            "/* Diagnostics communs", 1
        )[0]
        self.assertIn("if (!RAIL_READY_READMISSION", helper)
        self.assertIn("this._projects.best[0]", helper)
        self.assertIn("this._projectsRankOfAttemptKey(railKey)", helper)
        self.assertIn("OpexProjectFinanceCapital(head) > available", helper)
        self.assertIn('state.rawset("readyReadmissionHeadKey", headKey)', helper)
        self.assertIn("return !alreadyDeferred;", helper)
        self.assertIn(
            "local readyReAdmissionDeferred = RAIL_READY_READMISSION\n"
            "      && this._railReadyReadmissionShouldDefer(c77DeferCompletedRail);",
            task,
        )
        self.assertIn(
            "&& !c77DeferCompletedRail && !readyReAdmissionDeferred)", task
        )

    def test_c121_and_save_load_guards(self):
        task = src("task_projects.nut")
        helper = task.split("function OpexAI::_railReadyReadmissionShouldDefer(alreadyDeferred)", 1)[1].split(
            "/* Diagnostics communs", 1
        )[0]
        self.assertIn('"isC121RailPrep" in this._railSearch', helper)
        self.assertIn('state.readyReadmissionHeadKey == headKey', helper)
        self.assertNotIn("_railSearch = null", helper)
        self.assertNotIn("OpexProjectSelectAffordable", helper)
        self.assertNotIn("OpexBuild", helper)
        self.assertIn(
            "function _railReadyReadmissionShouldDefer(alreadyDeferred);",
            src("main.nut"),
        )


if __name__ == "__main__":
    unittest.main()
