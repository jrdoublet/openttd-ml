"""Tests du décodeur observationnel de devis AIR (événements, non projets)."""

from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).parent))
from analyse_air_site_stale_shadow import parse


class AnalyzeStaleShadowTest(unittest.TestCase):
    def run_fixture(self, lines):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "reference_seed42_r0.log"
            path.write_text("\n".join(lines), encoding="utf-8")
            return parse(path)

    def test_valid_age_change_and_cash_flip(self):
        d = self.run_fixture([
            "[script] AIR_SITE_STALE path=portfolio rank=0 date=719500 age=3 "
            "src=3 dst=9 new=2 old_a=100 old_b=200 now_a=400 now_b=200 "
            "missing=0 invalid=0 changed=1 shift=300 need=999 fresh_need=1299 cash=1000 flip=1",
            "[script] AIR_SITE_STALE path=legacy rank=1 date=719500 age=-1 "
            "src=4 dst=7 new=1 old_a=0 old_b=-2 now_a=0 now_b=-2 "
            "missing=0 invalid=0 changed=0 shift=0 need=500 fresh_need=500 cash=600 flip=0",
        ])
        self.assertEqual(d["events"], 2)
        self.assertEqual(d["aged_events"], 1)
        self.assertEqual(d["max_age_days"], 3)
        self.assertEqual(d["changed_events"], 1)
        self.assertEqual(d["cash_flip_events"], 1)
        self.assertEqual(d["path_counts"], {"portfolio": 1, "legacy": 1})

    def test_impossible_quote_not_counted_as_a_cash_flip(self):
        d = self.run_fixture([
            "AIR_SITE_STALE path=portfolio age=4 old_a=100 old_b=-2 "
            "now_a=-1 now_b=-2 missing=0 invalid=1 changed=1 shift=0 "
            "need=900 fresh_need=900 cash=1000 flip=0",
        ])
        self.assertEqual(d["invalid_events"], 1)
        self.assertEqual(d["changed_events"], 1)
        self.assertEqual(d["cash_flip_events"], 0)
        self.assertEqual(d["risk_rows"][0]["now_a"], -1)

    def test_repeated_logs_remain_separate_events(self):
        line = "AIR_SITE_STALE path=portfolio age=1 changed=0 invalid=0 missing=0 flip=0"
        d = self.run_fixture([line, line])
        self.assertEqual(d["events"], 2)
        self.assertEqual(d["aged_events"], 2)


if __name__ == "__main__":
    unittest.main()
