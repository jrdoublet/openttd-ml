/* Detached measurement fixture. NO imports from or modifications to OpexAI.
 * The score body matches candidates.nut 745,759-784; the TOPK loop matches
 * candidates.nut 875-887. Synthetic workload, not a production trace.
 * All instrumented operations use the same materialized pool and K=20.
 */
RMOP_SIMPLE_ROI <- false;
RMOP_SIMPLE_OPCODE <- false;

function RMOPMark() {
  return { tick = AIController.GetTick(), left = AIController.GetOpsTillSuspend() };
}

function RMOPCost(mark) {
  local left = AIController.GetOpsTillSuspend();
  local dt = AIController.GetTick() - mark.tick;
  return { ops = (dt <= 0) ? mark.left - left
      : mark.left + (dt - 1) * 10000 + (10000 - left), ticks = dt };
}

function RMOPMaterialize(n, ties, shuffled) {
  local pool = [];
  for (local i = 0; i < n; i++) {
    local profit = ties ? 8000 : 500 + ((i * 733 + 311) % 90000);
    local iterations = ties ? 32000 : 50 + ((i * 127 + 83) % 18000);
    local capital = ties ? 100000 : 50000 + ((i * 487 + 19) % 320000);
    /* The first seven rows deliberately exercise truncation-to-zero ROI. */
    if (!ties && i % 41 == 0) { profit = 2; capital = 300000; }
    local roi = (profit * 1000) / capital;
    local days = ties ? 30 : (i * 11 + 7) % 75;
    pool.append({ id = i, profitAnnual = profit, iterations = iterations,
      roi = roi, oneWayDays = days, kind = (i % 3 == 0) ? "freight" : "pax",
      ratio = 0 });
  }
  if (!shuffled) return pool;
  local reordered = [];
  /* 269 and 687 are coprime: a deterministic full permutation, not a
   * cherry-picked ranking. Original candidate ids and economics unchanged. */
  for (local j = 0; j < n; j++) reordered.append(pool[(j * 269) % n]);
  return reordered;
}

function RMOPSetArm(arm) {
  RMOP_SIMPLE_ROI = arm == "ROI";
  RMOP_SIMPLE_OPCODE = arm == "OPCODE";
}

function RMOPScoreAll(pool) {
  foreach (candidate in pool) {
    local opcodeRatio = (candidate.profitAnnual * 1000) / candidate.iterations;
    local turnoverBonus = 100;
    if (!RMOP_SIMPLE_ROI && !RMOP_SIMPLE_OPCODE) {
      if (candidate.oneWayDays <= 12) turnoverBonus = 130;
      else if (candidate.oneWayDays <= 25) turnoverBonus = 115;
      else if (candidate.oneWayDays <= 45) turnoverBonus = 100;
      else turnoverBonus = 60;
    }
    local freightBonus = 100;
    local effectiveRoi = (candidate.roi * freightBonus) / 100;
    local ratio;
    if (RMOP_SIMPLE_ROI) {
      ratio = effectiveRoi;
    } else if (RMOP_SIMPLE_OPCODE) {
      ratio = opcodeRatio;
    } else {
      local adjustedRoi = (((candidate.roi * turnoverBonus) / 100) * freightBonus) / 100;
      ratio = opcodeRatio + (adjustedRoi * 15);
    }
    candidate.ratio = ratio;
  }
}

function RMOPTopK(all, k) {
  local best = [];
  local floor = 0;
  foreach (candidate in all) {
    if (best.len() >= k && candidate.ratio <= floor) continue;
    local pos = best.len();
    while (pos > 0 && best[pos - 1].ratio < candidate.ratio) pos--;
    best.insert(pos, candidate);
    if (best.len() > k) best.pop();
    if (best.len() >= k) floor = best[best.len() - 1].ratio;
  }
  return best;
}

function RMOPChecksum(pool) {
  local sum = 0;
  foreach (candidate in pool) sum = (sum + candidate.ratio * (candidate.id % 97 + 1)) % 1000000007;
  return sum;
}

function RMOPSignature(best) {
  local sig = 0;
  for (local i = 0; i < best.len(); i++) sig += (i + 1) * (best[i].id + 1);
  return sig;
}

class RailMagicOpcodeProbe extends AIController {
  function Start() {
    local cases = [ [20, false, false, "mixed20"], [64, false, false, "mixed64"],
                    [200, false, false, "mixed200"], [687, false, false, "mixed687"],
                    [687, false, true, "shuffle687"], [64, true, false, "ties64"] ];
    foreach (testCase in cases) {
      local pool = RMOPMaterialize(testCase[0], testCase[1], testCase[2]);
      for (local rep = 0; rep < 4; rep++) {
        /* Each replicate contains an A/A OFF measurement, not an OFF inferred
         * from some other map state. Alternate middle arms to expose order bias. */
        local arms = rep % 2 == 0
            ? ["OFFA", "ROI", "OFFB", "OPCODE"]
            : ["OFFA", "OPCODE", "OFFB", "ROI"];
        foreach (arm in arms) {
          RMOPSetArm(arm == "OFFA" || arm == "OFFB" ? "OFF" : arm);
          local scoreMark = RMOPMark();
          RMOPScoreAll(pool);
          local scoreCost = RMOPCost(scoreMark);
          local checksum = RMOPChecksum(pool);
          local rankMark = RMOPMark();
          local best = RMOPTopK(pool, 20);
          local rankCost = RMOPCost(rankMark);
          local signature = RMOPSignature(best);
          AILog.Info("RMOP|case=" + testCase[3] + "|rep=" + rep + "|arm=" + arm
            + "|n=" + testCase[0] + "|score=" + scoreCost.ops
            + "|rank=" + rankCost.ops + "|score_ticks=" + scoreCost.ticks
            + "|rank_ticks=" + rankCost.ticks + "|check=" + checksum
            + "|best=" + signature + "|len=" + best.len());
        }
      }
    }
    AILog.Info("RMOP_DONE");
    while (true) AIController.Sleep(1);
  }
}
