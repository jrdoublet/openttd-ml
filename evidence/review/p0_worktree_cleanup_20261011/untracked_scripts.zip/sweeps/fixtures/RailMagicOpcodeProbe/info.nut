class RailMagicOpcodeProbeInfo extends AIInfo {
  function GetAuthor() { return "OpenTTD-ML"; }
  function GetName() { return "RailMagicOpcodeProbe"; }
  function GetShortName() { return "RMOP"; }
  function GetDescription() { return "Detached deterministic RAIL score and TOP20 opcode microbenchmark"; }
  function GetVersion() { return 1; }
  function GetDate() { return "2026-10-10"; }
  function CreateInstance() { return "RailMagicOpcodeProbe"; }
  function GetAPIVersion() { return "15"; }
}
RegisterAI(RailMagicOpcodeProbeInfo());
