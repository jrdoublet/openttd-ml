import json
from pathlib import Path
import tempfile
import unittest

from analyse_rail_opcode_first_divergence import first_divergences, summarise


class OpcodeFirstDivergenceTest(unittest.TestCase):
    def _record(self, policy, repeat, date, money, rail_rank=None):
        budget = {} if rail_rank is None else {date[:4]: {"cand_rank": rail_rank}}
        return {"run": ["OpexAI", 73, repeat], "policy_id": policy,
                "date": date, "money": money,
                "company_value": 100, "profit_year": None,
                "primary_vehicles_by_mode": {"air": 1, "rail": 0, "road": 0},
                "stations_by_facility": {"airport": 2, "rail": 0},
                "project_builds_sign_total": 1,
                "rail_budget_sign_by_year": budget}

    def test_repeated_off_identifies_first_month_without_interpreting_null(self):
        data = [
            self._record("off", 0, "1970-03-01", 100),
            self._record("off", 1, "1970-03-01", 100),
            self._record("off", 0, "1970-04-01", 100, rail_rank=10),
            self._record("off", 1, "1970-04-01", 99, rail_rank=11),
            {"run": ["AAAHogEx", 73, 0], "date": "1970-04-01"},
        ]
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "checkpoints.jsonl"
            path.write_text("\n".join(json.dumps(item) for item in data) + "\n", encoding="utf-8")
            rows = first_divergences(path, "off", "off", 0, 1)
            self.assertEqual(rows[0]["first"]["money"], {
                "date": "1970-04-01", "left": 100, "right": 99, "delta": -1})
            self.assertEqual(rows[0]["first"]["cand_rank"]["delta"], 1)
            self.assertNotIn("profit_year", rows[0]["first"])
            self.assertEqual(summarise(rows)["money"]["first_month_counts"], {"1970-04": 1})

    def test_missing_pair_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "data.jsonl"
            path.write_text(json.dumps(self._record("off", 0, "1970-03-01", 100)), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "unpaired checkpoint"):
                first_divergences(path, "off", "on")

    def test_cross_campaign_same_policy_same_repeat(self):
        with tempfile.TemporaryDirectory() as root:
            left, right = Path(root) / "left.jsonl", Path(root) / "right.jsonl"
            left.write_text(json.dumps(self._record("off", 0, "1970-03-01", 100)), encoding="utf-8")
            right.write_text(json.dumps(self._record("off", 0, "1970-03-01", 98)), encoding="utf-8")
            rows = first_divergences(left, "off", "off", 0, 0, right)
            self.assertEqual(rows[0]["first"]["money"]["delta"], -2)


if __name__ == "__main__":
    unittest.main()
