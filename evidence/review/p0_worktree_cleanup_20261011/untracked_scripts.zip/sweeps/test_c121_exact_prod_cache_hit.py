"""Static contracts for a non-invasive C121 stale-production cache-hit probe.

The runtime Squirrel test remains mandatory before economic qualification.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def text(name):
    return (ROOT / name).read_text(encoding="utf-8")


class ProductionCacheHitTests(unittest.TestCase):
    def test_observes_existing_api_results_only_when_shadow_enabled(self):
        source = text("catalog.nut")
        func = source.split("function OpexC121CatalogTownProductionBatch(catalog)", 1)[1]
        func = func.split("\nfunction ", 1)[0]
        first_read = func.index("AITown.GetLastMonthProduction(id, catalog.paxCargo)")
        obs = func.index("C121_EXACT_PROD_LAST_OBS.rawset(id, { pax = pax, mail = mail });")
        self.assertGreater(obs, first_read)
        self.assertIn("if (C121_EXACT_PROD_SHADOW)\n      C121_EXACT_PROD_LAST_OBS.rawset", func)
        self.assertIn("if (legacyChanged || (C121_EXACT_PROD_INVALIDATION && exactChanged))", func)

    def test_shadow_on_cache_hit_not_in_selection_policy(self):
        source = text("air_catalog_c121.nut")
        helper = source.split("function OpexC121ExactProductionCacheHitShadow(key, entry, date)", 1)[1]
        helper = helper.split("\nfunction ", 1)[0]
        self.assertNotIn("AITown.GetLastMonthProduction", helper)
        self.assertNotIn("AIDate.GetCurrentDate", helper)
        self.assertNotIn("OpexC121ChooseRoutePlane", helper)
        self.assertNotIn("C121_CATALOG_CACHE.rawset", helper)
        self.assertIn('AILog.Info("C121_PROD_CACHE_STALE', helper)
        self.assertIn('" cache_key=" + key', helper)
        hit = source.split("function OpexC121CatalogChoice(catalog, plan, lines)", 1)[1]
        hit = hit.split("\nfunction ", 1)[0]
        self.assertIn("if (C121_EXACT_PROD_SHADOW)\n        OpexC121ExactProductionCacheHitShadow(key, entry, date);", hit)
        self.assertLess(hit.index("OpexC121ExactProductionCacheHitShadow(key, entry, date);"),
                        hit.index("return entry.choice;"))

    def test_one_signature_per_cached_choice_and_reset_after_refresh(self):
        source = text("air_catalog_c121.nut")
        self.assertIn("C121_EXACT_PROD_STALE_REPORTED[key] == signature", source)
        self.assertIn("C121_EXACT_PROD_STALE_REPORTED.rawset(key, signature);", source)
        self.assertIn("delete C121_EXACT_PROD_STALE_REPORTED[key];", source)
        globals_pre = text("globals_pre.nut")
        self.assertIn("C121_EXACT_PROD_LAST_OBS <- {};", globals_pre)
        self.assertIn("C121_EXACT_PROD_STALE_REPORTED <- {};", globals_pre)
        settings = text("settings.nut")
        self.assertIn("C121_EXACT_PROD_LAST_OBS.clear();", settings)
        self.assertIn("C121_EXACT_PROD_STALE_REPORTED.clear();", settings)
        self.assertIn("if (C121_EXACT_PROD_SHADOW) {", settings)


if __name__ == "__main__":
    unittest.main()
