"""Compare monthly OpexAI checkpoints: OFF repeats or a genuine OFF/ON pair.

Host-only diagnostic. Dates are checkpoint dates, not exact scheduler event times.
The first difference is observational: it does not establish causation.
"""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path


METRICS = (
    "money", "company_value", "profit_year", "air_vehicles", "rail_vehicles",
    "road_vehicles", "airport_facilities", "rail_facilities", "build_signs",
    "cand_pax", "cand_freight", "cand_rank", "budget_util_per_mille",
)


def _checkpoint(rec):
    run = rec.get("run")
    if not isinstance(run, list) or len(run) < 3 or run[0] != "OpexAI":
        return None
    date = rec.get("date")
    if not isinstance(date, str) or len(date) != 10 or date[4] != "-":
        return None
    modes = rec.get("primary_vehicles_by_mode") or {}
    facilities = rec.get("stations_by_facility") or {}
    year_budget = (rec.get("rail_budget_sign_by_year") or {}).get(date[:4]) or {}
    return {
        "seed": int(run[1]), "repeat": int(run[2]),
        "policy": rec.get("policy_id"), "date": date,
        "money": rec.get("money"), "company_value": rec.get("company_value"),
        "profit_year": rec.get("profit_year"),
        "air_vehicles": modes.get("air"), "rail_vehicles": modes.get("rail"),
        "road_vehicles": modes.get("road"),
        "airport_facilities": facilities.get("airport"),
        "rail_facilities": facilities.get("rail"),
        "build_signs": rec.get("project_builds_sign_total"),
        "cand_pax": year_budget.get("cand_pax"),
        "cand_freight": year_budget.get("cand_freight"),
        "cand_rank": year_budget.get("cand_rank"),
        "budget_util_per_mille": year_budget.get("budget_util_per_mille"),
    }


def first_divergences(jsonl, left_policy, right_policy, left_repeat=0, right_repeat=0,
                      right_jsonl=None, seeds=None, through_date=None):
    """Return first differing *checkpoint* for each metric and seed.

    Exact value comparison only. Missing/null data is not interpreted as zero.
    The same source file is opened once; other companies are ignored.
    """
    by_seed_date = defaultdict(dict)

    def read_one(path, allowed_sides):
        with Path(path).open(encoding="utf-8") as stream:
            for line in stream:
                rec = _checkpoint(json.loads(line))
                if rec is None:
                    continue
                if seeds is not None and rec["seed"] not in seeds:
                    continue
                if through_date is not None and rec["date"] > through_date:
                    continue
                sides = [side for side, policy, repeat in allowed_sides
                         if rec["policy"] == policy and rec["repeat"] == repeat]
                if len(sides) > 1:
                    raise ValueError("same checkpoint requested as both left and right")
                if not sides:
                    continue
                side = sides[0]
                key = (rec["seed"], rec["date"])
                if side in by_seed_date[key]:
                    raise ValueError(f"duplicate checkpoint: {key} {side}")
                by_seed_date[key][side] = rec

    left = ("left", left_policy, left_repeat)
    right = ("right", right_policy, right_repeat)
    if right_jsonl is None:
        read_one(jsonl, (left, right))
    else:
        read_one(jsonl, (left,))
        read_one(right_jsonl, (right,))

    by_seed = defaultdict(list)
    for (seed, date), pair in sorted(by_seed_date.items()):
        if set(pair) != {"left", "right"}:
            raise ValueError(f"unpaired checkpoint: {seed=} {date=} sides={sorted(pair)}")
        by_seed[seed].append((date, pair["left"], pair["right"]))

    if not by_seed:
        raise ValueError("no matching OpexAI checkpoint pair")
    report = []
    for seed, rows in sorted(by_seed.items()):
        first = {}
        for date, left, right in rows:
            for metric in METRICS:
                a, b = left.get(metric), right.get(metric)
                # No claim from missing measurements; a fully missing series remains null.
                if metric in first or a is None or b is None or a == b:
                    continue
                first[metric] = {
                    "date": date, "left": a, "right": b,
                    "delta": b - a if isinstance(a, (int, float)) and
                                         isinstance(b, (int, float)) else None,
                }
        report.append({"seed": seed, "checkpoint_pairs": len(rows), "first": first})
    return report


def summarise(rows):
    return {
        metric: {
            "divergent_seeds": sum(metric in row["first"] for row in rows),
            "first_month_counts": dict(sorted(Counter(
                row["first"][metric]["date"][:7]
                for row in rows if metric in row["first"]
            ).items())),
        }
        for metric in METRICS
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jsonl", type=Path)
    parser.add_argument("--right-jsonl", type=Path,
                        help="read right checkpoints from another campaign (requires matching bundle/settings for causal use)")
    parser.add_argument("--left-policy", required=True)
    parser.add_argument("--right-policy", required=True)
    parser.add_argument("--left-repeat", type=int, default=0)
    parser.add_argument("--right-repeat", type=int, default=0)
    parser.add_argument("--seeds", nargs="+", type=int,
                        help="restrict an inter-campaign comparison to matching seeds")
    parser.add_argument("--through-date", help="inclusive last checkpoint YYYY-MM-DD")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    rows = first_divergences(args.jsonl, args.left_policy, args.right_policy,
                             args.left_repeat, args.right_repeat, args.right_jsonl,
                             set(args.seeds) if args.seeds is not None else None,
                             args.through_date)
    result = {
        "provenance": str(args.jsonl),
        "right_provenance": str(args.right_jsonl or args.jsonl),
        "left": {"policy": args.left_policy, "repeat": args.left_repeat},
        "right": {"policy": args.right_policy, "repeat": args.right_repeat},
        "scope": "monthly checkpoints, not first scheduler/opcode event",
        "through_date": args.through_date,
        "seeds": len(rows), "summary": summarise(rows), "by_seed": rows,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.out.exists():
        parser.error("refusing to overwrite existing diagnostic: " + str(args.out))
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"seeds": len(rows), "summary": result["summary"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
