#!/usr/bin/env python3
"""Décodage host des instantanés AIR_P0_OPPORTUNITY (aucune simulation).

Une identité ne vaut que dans un même journal de partie. Des traces tronquées
ou orphelines restent explicitement incomplètes ; aucun statut de
constructibilité ou de profit causal n'est inféré depuis le classement.
"""

import argparse
import json
import re
from pathlib import Path


EVENT = "AIR_P0_OPPORTUNITY "
KV = re.compile(r"([a-zA-Z][a-zA-Z_0-9]*)=([^\s]+)")
SEED = re.compile(r"(?:^|[_-])seed([0-9]+)(?:[_-]|\.)", re.IGNORECASE)
KINDS = {"BUY": "buy", "SELECTED": "selected", "RAW_ONLY": "raw_only", "PRIOR_REJECT": "prior_reject"}


def _as_int(record, key):
    try:
        return int(record[key])
    except (KeyError, TypeError, ValueError):
        return None


def parse_lines(lines, source):
    """Retourne les achats observés et les anomalies d'appariement, par fichier."""
    groups = {}
    warnings = []
    seed_match = SEED.search(Path(source).name)
    seed = int(seed_match.group(1)) if seed_match else None
    for line_number, line in enumerate(lines, 1):
        index = line.find(EVENT)
        if index < 0:
            continue
        fields = dict(KV.findall(line[index + len(EVENT):]))
        kind, event_id = fields.get("kind"), fields.get("id")
        if not event_id or kind not in KINDS:
            warnings.append({"line": line_number, "issue": "missing_id_or_kind"})
            continue
        if kind == "BUY":
            if event_id in groups:
                warnings.append({"line": line_number, "issue": "duplicate_buy", "id": event_id})
                continue
            groups[event_id] = {
                "source": source, "seed": seed, "id": event_id,
                "buy": fields, "selected": [], "raw_only": [],
                "prior_reject": [], "first_log_line": line_number,
            }
        elif event_id not in groups:
            warnings.append({"line": line_number, "issue": "orphan_event",
                             "id": event_id, "kind": kind})
        else:
            groups[event_id][KINDS[kind]].append(fields)
    purchases = list(groups.values())
    for purchase in purchases:
        buy = purchase["buy"]
        expected_selected = _as_int(buy, "selected_air")
        expected_raw_examples = _as_int(buy, "raw_examples")
        expected_before = _as_int(buy, "air_before")
        expected_after = _as_int(buy, "air_after")
        selected = purchase["selected"]
        ranks = [_as_int(row, "rank") for row in selected]
        purchase["telemetry_complete"] = (
            expected_selected is not None and expected_selected == len(selected)
            and expected_raw_examples is not None
            and expected_raw_examples == len(purchase["raw_only"])
            and expected_before is not None and expected_after is not None
            and expected_before + expected_after == len(selected)
            and all(rank is not None for rank in ranks)
        )
        purchase["proven_better_buildable_air"] = None
        purchase["constructibility_verified"] = False
        if not purchase["telemetry_complete"]:
            warnings.append({"line": purchase["first_log_line"],
                             "issue": "incomplete_purchase_telemetry", "id": purchase["id"],
                             "seen_selected": len(selected),
                             "expected_selected": expected_selected,
                             "seen_raw_examples": len(purchase["raw_only"]),
                             "expected_raw_examples": expected_raw_examples})
    return purchases, warnings


def analyse(paths):
    purchases, warnings = [], []
    for path in paths:
        filename = str(path)
        with Path(path).open("r", encoding="utf-8", errors="replace") as stream:
            part, errors = parse_lines(stream, filename)
        purchases.extend(part)
        warnings.extend({"source": filename, **error} for error in errors)
    return {
        "source_logs": [str(path) for path in paths],
        "purchases": purchases,
        "warnings": warnings,
        "summary": {
            "purchases_logged": len(purchases),
            "telemetry_complete": sum(bool(p["telemetry_complete"]) for p in purchases),
            "telemetry_incomplete": sum(not p["telemetry_complete"] for p in purchases),
            "better_buildable_proven": 0,
            "better_buildable_unidentified": len(purchases),
            "note": "Un score/financement théorique ne prouve jamais une construction réussie.",
        },
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--logs", nargs="+", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--strict", action="store_true",
                        help="Échouer si des événements sont manquants ou non appariables.")
    args = parser.parse_args(argv)
    report = analyse(args.logs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False))
    if args.strict and report["warnings"]:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
