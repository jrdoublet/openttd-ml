"""Paired annual checkpoints must never combine player companies or months."""

import json
from pathlib import Path
import tempfile
import unittest

from analyse_rail_magic_ab_annual import analyse


class AnnualMagicPairingTest(unittest.TestCase):
    def test_closed_year_paired_and_missing_metrics_unknown(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "checkpoints.jsonl"
            rows = []
            for policy, profit in (("reference", 1000), ("rail_magic_economic", 1150)):
                rows.extend((
                    {"date": "1972-11-01", "run": ["OpexAI", 42, 0],
                     "policy_id": policy, "profit_year": 0},
                    {"date": "1972-12-01", "run": ["AAAHogEx", 42, 0],
                     "policy_id": policy, "profit_year": 12345},
                    {"date": "1972-12-01", "run": ["OpexAI", 42, 0],
                     "policy_id": policy, "profit_year": profit, "company_value": 100,
                     "primary_vehicles_by_mode": {"rail": 3, "air": 5},
                     "stations_by_facility": {"rail": 4, "airport": 6},
                     "rail_attempt_sign_coverage": "missing_sign_chunk"},
                ))
            path.write_text("\n".join(json.dumps(x) for x in rows), encoding="utf-8")
            actual = analyse(path)
            self.assertEqual(len(actual), 1)
            self.assertEqual(actual[0]["delta_profit_year"], 150)
            self.assertIsNone(actual[0]["delta_rail_attempt_opcodes_signs"])
            self.assertEqual(actual[0]["delta_air_vehicles"], 0)


if __name__ == "__main__":
    unittest.main()
