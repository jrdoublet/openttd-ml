"""Contrats structurels du prototype P0 rail N=2 (pas un test moteur Squirrel)."""
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


def body(name, signature):
    text = source(name)
    start = text.index(signature)
    brace = text.index("{", start)
    depth = 0
    for index in range(brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[brace + 1:index]
    raise AssertionError(f"Fonction non fermée : {signature}")


class RailN2Contracts(unittest.TestCase):
    def test_default_off(self):
        info = source("info.nut")
        setting = re.search(r'name = "rail_cooperative_n2",(.*?)\}\);', info, re.S)
        self.assertIsNotNone(setting)
        self.assertIn("easy_value = 0, medium_value = 0, hard_value = 0", setting.group(1))
        self.assertIn("custom_value = 0", setting.group(1))
        self.assertIn("RAIL_COOPERATIVE_N2 <- false;", source("globals_pre.nut"))

    def test_opportunity_gate_and_shadow_default_off(self):
        info = source("info.nut")
        settings = source("settings.nut")
        globals_pre = source("globals_pre.nut")
        for name in ("rail_n2_opportunity_gate", "rail_air_breakpoint_shadow"):
            setting = re.search(r'name = "' + name + r'",(.*?)\}\);', info, re.S)
            self.assertIsNotNone(setting, name)
            self.assertIn("easy_value = 0, medium_value = 0, hard_value = 0", setting.group(1))
            self.assertIn("custom_value = 0", setting.group(1))
            self.assertIn('AIController.GetSetting("' + name + '") != 0', settings)
        self.assertIn("RAIL_N2_OPPORTUNITY_GATE <- false;", globals_pre)
        self.assertIn("RAIL_AIR_BREAKPOINT_SHADOW <- false;", globals_pre)
        self.assertIn("RAIL_N2_OPPORTUNITY_GATE = RAIL_COOPERATIVE_N2", settings)

    def test_second_requires_live_finance_and_same_portfolio_dominance(self):
        admission = body("task_rail.nut", "function OpexAI::_railN2CanStart(candidate)")
        compare = body("task_rail.nut", "function OpexAI::_railN2Competitive(candidate)")
        self.assertIn("if (!distinct) return false;", admission)
        self.assertIn("return !RAIL_N2_OPPORTUNITY_GATE || this._railN2Competitive(candidate);", admission)
        self.assertIn("OpexAvailableCapital()", compare)
        self.assertIn("OpexProjectFinanceCapital(p) > available", compare)
        self.assertIn('p.payload == candidate', compare)
        self.assertIn("primaryRank >= 0", compare)
        self.assertIn("firstOtherRank > candidateRank && firstOtherRank > primaryRank", compare)
        self.assertIn("candidateScore > bestOtherScore && primaryScore > bestOtherScore", compare)
        self.assertIn("bestOtherScore > 0", compare)
        self.assertIn("firstOtherRank < 0 && best.len() >= PROJECT_TOP_K", compare)
        self.assertIn("railAhead >= 2", compare)
        self.assertIn('OpexProjectSelectionScore(p, "fundScore")', compare)
        self.assertIn('p.mode == "air" || p.mode == "fleet" || p.mode == "road"', compare)

    def test_breakpoint_shadow_reads_final_selection_only(self):
        select = body("projects_selection.nut", "function OpexProjectSelectAffordable(")
        shadow = body("projects_selection.nut", "function OpexRailAirBreakpointShadow(")
        self.assertIn("if (RAIL_AIR_BREAKPOINT_SHADOW && realSelection)", select)
        self.assertLess(select.index("OpexC120FinalizeSelection(affordable, capitalBudget);"),
                        select.index("OpexRailAirBreakpointShadow(affordable, capitalBudget);"))
        self.assertIn("OpexProjectFinanceCapital(p) > capitalBudget", shadow)
        self.assertIn('p.mode == "rail"', shadow)
        self.assertIn('p.mode == "air" || p.mode == "fleet"', shadow)
        self.assertIn('RAIL_AIR_BREAKPOINT_LAST = signature;', shadow)
        self.assertNotIn("OpexProjectSelectAffordable(", shadow)

    def test_incompatible_worker_and_stock_disabled(self):
        settings = source("settings.nut")
        self.assertRegex(settings, r'RAIL_COOPERATIVE_N2 = RAIL_SEARCH_RESUMABLE && !C80_WORKER_RAIL\s+&& !C80_RAIL_STOCK_WORKER && !C80_RAIL_STOCK_GATE')
        self.assertIn("if (V131_RAIL_REPAIR) RAIL_COOPERATIVE_N2 = false;", settings)
        self.assertIn("!RAIL_ORIGIN_REUSE_SEARCH_SUPERSEDE", settings)

    def test_transient_state_not_serialized(self):
        main = source("main.nut")
        self.assertIn("_railN2Secondary = null;", main)
        self.assertIn("_railN2Staging = false;", main)
        persist = source("persist.nut")
        self.assertIn("railSearchPending = this._railSearch != null || this._railN2Secondary != null", persist)
        self.assertIn("|| (RAIL_COOPERATIVE_N2 && this._railN2Staging)", persist)
        self.assertIn("this._railN2Secondary = null;", persist)
        self.assertIn("this._railN2Staging = false;", persist)
        self.assertNotIn("railN2Secondary = this._railN2Secondary", persist)

    def test_exclusive_admission_and_deduplication(self):
        test = body("task_rail.nut", "function OpexAI::_railN2CanStart(candidate)")
        self.assertIn("this._railN2Secondary != null", test)
        self.assertIn('active.kind != "primary"', test)
        self.assertIn('active.phase != "search"', test)
        self.assertIn('"isC121RailPrep" in active', test)
        self.assertIn("candidate.cargo != old.cargo", test)
        self.assertIn("candidate.kind != old.kind", test)
        self.assertIn('"isChainStep2" in candidate', test)
        self.assertIn('!(RAIL_COOPERATIVE_N2 && this._railN2CanStart(candidate))', source("task_rail.nut"))

    def test_second_staged_with_no_immediate_build(self):
        start = body("task_rail.nut", "function OpexAI::_startRailSearch(candidate, alternativeRatio, hardCap, posPacked)")
        self.assertIn("this._railN2Staging = true;", start)
        self.assertIn("this._railN2Staging = false;", start)
        self.assertIn("second.railN2Second <- true;", start)
        self.assertIn("second.railN2NeedsRevalidation <- true;", start)
        self.assertIn('if (DECISION_LOG && second.phase == "build")', start)
        self.assertIn("if (RAIL_COOPERATIVE_N2 && this._railN2Staging)", start)
        self.assertIn("return { pending = true, plan = null };", start)

    def test_ordered_commit(self):
        park = body("task_rail.nut", "function OpexAI::_railN2ParkCompleted()")
        self.assertIn('this._railSearch.phase != "build"', park)
        self.assertIn("this._railSearch = this._railN2Secondary;", park)
        self.assertIn("this._railN2Secondary = second;", park)
        self.assertIn("this._railN2Promote();", source("task_projects.nut"))
        self.assertIn("this._railN2ParkCompleted();", source("scheduler.nut"))
        promote = body("task_rail.nut", "function OpexAI::_railN2Promote()")
        self.assertIn("this._railSearch.railN2Second = false;", promote)

    def test_secondary_revalidated_on_live_map_before_build(self):
        consume = body("task_rail.nut", "function OpexAI::_consumeRailSearch(year)")
        self.assertIn('("railN2NeedsRevalidation" in state) && state.railN2NeedsRevalidation', consume)
        self.assertIn("this._tooClose(candidate)", consume)
        self.assertIn("this._revalidateRailStockPlan(candidate, candidate.railPlan, true)", consume)
        self.assertLess(consume.index("this._revalidateRailStockPlan(candidate, candidate.railPlan, true)"),
                        consume.index("OpexBuildLine(this._catalog, this._budget, candidate"))
        self.assertIn('n2AllowTownDestination = false', source("task_rail.nut"))

    def test_temporary_cash_wait_and_attributed_search_cost(self):
        rail = source("task_rail.nut")
        consume = body("task_rail.nut", "function OpexAI::_consumeRailSearch(year)")
        self.assertIn('if (live.reason == "cash" || live.reason == "no_vehicle_slot")', consume)
        self.assertIn('return { outcome = "cash", reason = "n2_" + live.reason, error = 0 };', consume)
        live_guard = consume[consume.index('local live = this._revalidateRailStockPlan'):]
        self.assertLess(live_guard.index('if (live.reason == "cash" || live.reason == "no_vehicle_slot")'),
                        live_guard.index('reason=" + live.reason'))
        self.assertIn('this._railSearch.n2Rid <- this._railN2NextRid++;', rail)
        self.assertIn('state.n2SliceOps += searchSliceOps;', rail)
        self.assertIn('phase=search_done rid=', rail)
        self.assertIn('phase=build_done rid=', rail)

    def test_secondary_uses_builder_quote_not_c80_raw_station_precheck(self):
        reval = body("task_rail.nut", "function OpexAI::_revalidateRailStockPlan(candidate, plan, n2AllowTownDestination = false)")
        self.assertIn('if (n2AllowTownDestination) {', reval)
        self.assertIn('OpexSimulateRailInfraCost(plan, quoteFailure)', reval)
        self.assertLess(reval.index('if (n2AllowTownDestination) {'),
                        reval.index('if (!V131_RAIL_REPAIR) {'))
        self.assertIn('return { ok = true, reason = "quote_ok" };', reval)
        builder = source("builder_rail.nut")
        self.assertIn('function OpexSimulateRailInfraCost(plan, failure = null)', builder)
        self.assertIn('AITile.DemolishTile(tile)', builder)

    def test_one_global_slack_budget(self):
        throughput = body("scheduler.nut", "function OpexAI::_advanceRailSearchThroughput(maxSlices = -1)")
        self.assertIn("AIController.GetOpsTillSuspend() >= minThreshold", throughput)
        self.assertEqual(throughput.count("this._advanceRailSearchSliceWithLedgers();"), 1)
        slice_body = body("scheduler.nut", "function OpexAI::_advanceRailSearchSliceWithLedgers()")
        self.assertIn("if (RAIL_COOPERATIVE_N2) this._railN2RotateSlice();", slice_body)
        self.assertNotIn("_railN2RotateSlice", body("task_rail.nut", "function OpexAI::_continueRailSearch()"))

    def test_legacy_upgrade_stock_catalog_guard(self):
        rail = source("task_rail.nut")
        self.assertIn("(RAIL_COOPERATIVE_N2 && this._railN2Secondary != null)", rail)
        scheduler = source("scheduler_tasks.nut")
        self.assertIn("(!RAIL_COOPERATIVE_N2 || owner._railN2Secondary == null)", scheduler)


if __name__ == "__main__":
    unittest.main()
