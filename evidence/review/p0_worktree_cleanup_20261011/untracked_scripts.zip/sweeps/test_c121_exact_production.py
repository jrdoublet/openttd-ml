"""P0 C121 strict production revision and non-mutating shadow contracts."""
from pathlib import Path
import unittest

AI = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (AI / name).read_text(encoding="utf-8")


def original_update(pax, old_pax, mail, old_mail):
    return ((abs(pax - old_pax) >= 10 and abs(pax - old_pax) * 100 >= old_pax * 20)
            or (abs(mail - old_mail) >= 10 and abs(mail - old_mail) * 100 >= old_mail * 20))


class ExactTownProductionTests(unittest.TestCase):
    def test_settings_off_for_all_difficulties(self):
        info = source("info.nut")
        settings = source("settings.nut")
        globals_pre = source("globals_pre.nut")
        for name, symbol in (
            ("c121_exact_prod_shadow", "C121_EXACT_PROD_SHADOW"),
            ("c121_exact_prod_invalidation", "C121_EXACT_PROD_INVALIDATION"),
        ):
            s = info.split('name = "' + name + '"')[1].split("});")[0]
            for difficulty in ("easy", "medium", "hard", "custom"):
                self.assertIn(difficulty + "_value = 0", s)
            self.assertIn(symbol + " <- false;", globals_pre)
            self.assertEqual(settings.count('AIController.GetSetting("' + name + '")'), 1)

    def test_shadow_observes_but_does_not_invalidate(self):
        c = source("catalog.nut")
        body = c.split("function OpexC121CatalogTownProductionBatch(catalog)")[1].split(
            "\nfunction ", 1)[0]
        self.assertIn("if (C121_EXACT_PROD_SHADOW && exactChanged && !legacyChanged)", body)
        self.assertIn("ignoredByTolerance++;", body)
        self.assertIn("ignoredPaxUnits += abs(pax - old.pax);", body)
        self.assertIn("ignoredMailUnits += abs(mail - old.mail);", body)
        self.assertIn("if (legacyChanged || (C121_EXACT_PROD_INVALIDATION && exactChanged))", body)
        self.assertIn("C121_CATALOG_TOWN_REV.rawset(id,", body)
        self.assertIn('C121_PROD_EXACT_SHADOW date=', body)

    def test_exact_invalidation_without_new_threshold(self):
        c = source("catalog.nut")
        self.assertIn("local exactChanged = pax != old.pax || mail != old.mail;", c)
        self.assertIn("AITown.GetLastMonthProduction(id, catalog.paxCargo)", c)
        self.assertIn("AITown.GetLastMonthProduction(id, catalog.mailCargo)", c)
        examples = [
            (100, 100, 20, 20, False),
            (101, 100, 20, 20, True),
            (100, 100, 19, 20, True),
            (70, 100, 20, 20, True),
            (0, 100, 0, 20, True),
        ]
        for pax, old_pax, mail, old_mail, expected in examples:
            exact = pax != old_pax or mail != old_mail
            self.assertEqual(exact, expected)
            if not expected:
                self.assertFalse(original_update(pax, old_pax, mail, old_mail))
        self.assertFalse(original_update(101, 100, 20, 20))
        self.assertFalse(original_update(100, 100, 19, 20))
        self.assertTrue(original_update(70, 100, 20, 20))

    def test_cache_revision_is_same_mechanism(self):
        choice = source("air_catalog_c121.nut")
        self.assertIn("entry.townA != revA || entry.townB != revB", choice)
        self.assertIn("if (entry.demand != null) plan.c121Demand <- entry.demand;", choice)
        self.assertIn("C121_CATALOG_TOWN_REV", source("catalog.nut"))


if __name__ == "__main__":
    unittest.main()
