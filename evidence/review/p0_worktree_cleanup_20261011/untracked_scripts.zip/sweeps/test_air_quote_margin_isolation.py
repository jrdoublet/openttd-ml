"""Contrat statique d'orthogonalisation V126 devis vs marge.

La variante compare deux bras avec devis actif ; ce test ne compile pas Squirrel.
"""

from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parent.parent
AI = ROOT / "ai" / "OpexAI"


def source(filename):
    return (AI / filename).read_text(encoding="utf-8")


class AirQuoteMarginIsolationTest(unittest.TestCase):
    def test_setting_declared_and_defaults_off(self):
        info = source("info.nut")
        setting = 'name = "air_site_quote_keep_legacy_margin"'
        self.assertEqual(info.count(setting), 1)
        block = info[info.index(setting):info.index("});", info.index(setting))]
        for key in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertRegex(block, rf"\b{key}\s*=\s*0\b")
        self.assertIn("flags = AICONFIG_BOOLEAN", block)
        self.assertIn("AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN <- false;", source("globals_pre.nut"))
        self.assertIn(
            'AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN = AIController.GetSetting("air_site_quote_keep_legacy_margin") != 0;',
            source("settings.nut"),
        )

    def test_only_one_behavioral_use_in_margin_calculation(self):
        code = source("projects_builders.nut")
        self.assertIn("if (AIR_SITE_COST_QUOTE && !AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN", code)
        self.assertIn("return 2000 + (st.v126SiteCost * AIR_SITE_COST_MARGIN_PCT) / 100;", code)
        self.assertIn("return (newAirports == 2) ? 30000 : (newAirports == 1 ? 12000 : 2000);", code)
        usage = [p.name for p in AI.glob("*.nut") if "AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN" in p.read_text(encoding="utf-8")]
        # Le shadow lit ce parametre pour publier le besoin cash frais mais
        # ne le change pas. La seule branche DECISIONNELLE est dans builders.
        self.assertEqual(sorted(usage), ["globals_pre.nut", "projects_builders.nut", "settings.nut", "task_air.nut"])
        shadow = source("task_air.nut").split("function OpexAirStaleQuoteObserve(", 1)[1].split("\nfunction ", 1)[0]
        self.assertEqual(shadow.count("AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN"), 1)

    def test_quote_capital_not_gated_by_margin_mode(self):
        c121 = source("air_economics_c121.nut")
        self.assertIn("local extra = AIR_SITE_COST_QUOTE ? levelKnown + stopsModel : 0;", c121)
        self.assertIn("if (AIR_SITE_COST_QUOTE) {", c121)
        self.assertIn("state.airportCapital = newAirportCount * plan.airport.price + extra;", c121)
        self.assertNotIn("AIR_SITE_QUOTE_KEEP_LEGACY_MARGIN", c121)

    def test_finance_probe_exposes_both_margins(self):
        task = source("task_air.nut")
        self.assertIn('" margin=" + margin', task)
        self.assertIn('" margin_legacy=" + legacyMargin', task)
        self.assertIn('" margin_v126=" + (st.v126QuoteFail > 0', task)
        self.assertIn("local requiredMargin = OpexAirRequiredMargin(newAirports, buildPlan);", task)


if __name__ == "__main__":
    unittest.main()
