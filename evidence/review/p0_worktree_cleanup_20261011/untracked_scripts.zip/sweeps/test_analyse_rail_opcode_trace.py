import tempfile
from pathlib import Path
import unittest

from analyse_rail_opcode_trace import compare_logs


class TraceComparatorTest(unittest.TestCase):
    def test_first_logged_event_vs_first_task(self):
        off_text = "\n".join([
            "[x] dbg: [script:4] [0] [I] OPEX 1970-1-23 VIVIER_GEN mode=rail produced=4 kept=2",
            "[x] dbg: [script:4] [0] [I] OPEX 1970-1-24 TASK name=projects",
            "[x] dbg: [script:4] [0] [I] OPEX 1970-1-25 PROJECT_CHOSEN rank=0 mode=air",
        ])
        on_text = off_text.replace("kept=2", "kept=3").replace("1970-1-24", "1970-1-26")
        with tempfile.TemporaryDirectory() as temp:
            off, on = Path(temp) / "off.log", Path(temp) / "on.log"
            off.write_text(off_text, encoding="utf-8")
            on.write_text(on_text, encoding="utf-8")
            result = compare_logs(off, on)
            self.assertEqual(result["first_all_opex"]["off"]["kind"], "VIVIER_GEN")
            self.assertEqual(result["first_task"]["on"]["date"], "1970-01-26")
            self.assertEqual(result["first_project_chosen"], None)


if __name__ == "__main__":
    unittest.main()
