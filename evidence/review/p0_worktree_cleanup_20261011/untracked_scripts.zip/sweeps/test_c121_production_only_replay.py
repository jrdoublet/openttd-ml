"""Contracts for C121 isolated production-only fixed-fleet quote experiment."""
from pathlib import Path
import unittest

AI = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name):
    return (AI / name).read_text(encoding="utf-8")


def project(prod, tiles, covered, div):
    usable = min(tiles, covered) if tiles > 0 else covered
    raw = prod * usable // tiles if tiles > 0 else 0
    return raw, raw // div


class ReplayContracts(unittest.TestCase):
    def test_disabled_and_bounded_to_incremental_catalog(self):
        info = source("info.nut")
        body = info.split('name = "c121_production_only_replay_shadow"', 1)[1].split("});", 1)[0]
        for level in ("easy", "medium", "hard", "custom"):
            self.assertIn(level + "_value = 0", body)
        self.assertIn("C121_PRODUCTION_ONLY_REPLAY_SHADOW <- false;", source("globals_pre.nut"))
        self.assertIn('AIController.GetSetting("c121_production_only_replay_shadow") != 0;',
                      source("settings.nut"))

    def test_exact_integer_reprojection_and_zero_town_tiles(self):
        source_text = source("air_catalog_c121.nut")
        method = source_text.split("function OpexC121ProductionOnlyReprojectCargo(", 1)[1].split(
            "\nfunction ", 1)[0]
        self.assertIn("if (usable > denominator && denominator > 0) usable = denominator;", method)
        self.assertIn("local raw = denominator > 0 ? (production * usable) / denominator : 0;", method)
        self.assertIn("demand[allocatedKey] = raw / demand[routeKey];", method)
        self.assertEqual(project(91, 100, 35, 2), (31, 15))
        self.assertEqual(project(91, 20, 40, 3), (91, 30))
        self.assertEqual(project(91, 0, 10, 1), (0, 0))
        self.assertEqual(project(0, 100, 35, 2), (0, 0))

    def test_no_mutations_to_current_plan_or_cache(self):
        src = source("air_catalog_c121.nut")
        helper = src.split("function OpexC121ProductionOnlyReplay(", 1)[1].split(
            "\nfunction OpexC121CatalogChoice(", 1)[0]
        self.assertIn("local replayPlan = clone plan;", helper)
        self.assertIn("replayPlan.c121Demand <- clone currentDemand;", helper)
        self.assertIn("replayPlan.c121EngineStatic <- clone plan.c121EngineStatic;", helper)
        self.assertIn('stat["existingPaxBefore" + side] =', helper)
        self.assertIn('stat["existingMailBefore" + side] =', helper)
        self.assertIn("check.profitAnnual != choice.economics.profitAnnual", helper)
        self.assertIn("check.revenueAnnual != choice.economics.revenueAnnual", helper)
        self.assertIn("check.capital != choice.economics.capital", helper)
        self.assertEqual(helper.count("OpexC121EngineEconomics("), 2)
        self.assertNotIn("OpexC121ChooseRoutePlane(", helper)
        self.assertNotIn("C121_CATALOG_CACHE.rawset(", helper)
        self.assertNotIn("C121_CATALOG_TOWN_REV.rawset(", helper)
        self.assertIn('C121_PRODUCTION_ONLY_REPLAY status=compared', helper)
        self.assertIn("oldprod_carried_pax=", helper)
        self.assertIn("oldprod_cannibal=", helper)

    def test_natural_miss_only_and_safe_side_channel(self):
        src = source("air_catalog_c121.nut")
        f = src.split("function OpexC121CatalogChoice(", 1)[1].split("\nfunction ", 1)[0]
        self.assertIn('if (C121_PRODUCTION_ONLY_REPLAY_SHADOW && reason == "town")', f)
        self.assertIn("previousProductionReplay = entry;", f)
        self.assertIn("if (previousProductionReplay != null)", f)
        self.assertLess(f.index("OpexC121ProductionOnlyReplay(catalog, key, previousProductionReplay"),
                        f.index("C121_CATALOG_CACHE.rawset(key, {"))
        self.assertEqual(f.count("choice = OpexC121ChooseRoutePlane(catalog, plan, lines);"), 1)


if __name__ == "__main__":
    unittest.main()
