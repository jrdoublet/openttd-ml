"""Descriptive AIR marginal analysis of the frozen C66.3 20x5 duel.

No engine is launched.  December snapshots observe line net vehicle profit YTD,
not purchase transactions, revenue, operating expenses or causal marginal profit.

Run: python -X utf8 sweeps/analyse_air_marginal_p0.py
"""

from __future__ import annotations

from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path
import re
import statistics


REPORT = Path("results/chrono_opex_aaa_20x5_20261008_r1.json")
OUT = Path("results/air_marginal_p0_20x5_20261008_analysis.json")
VEHICLE_MONTHLY_REPORT = Path("results/air_p0_veh3_r1.json")
VEHICLE_MONTHLY_OUT = Path("results/air_marginal_p0_vehicle3_20261008_analysis.json")
BUY_ENGINE_REPORT = Path("results/air_p0_probe_3x5_r1.json")
BUY_ENGINE_FOLDER = Path("results/air_p0_probe_3x5_r1_engine")
BUY_CSV = Path("results/air_marginal_p0_buy_3x5_20261008.csv")
BUY_JSON = Path("results/air_marginal_p0_buy_3x5_20261008.json")
LOGGED_EVENT_CSV = Path("results/air_marginal_p0_logged54_20261008.csv")
REINFORCE_CSV = Path("results/air_marginal_p0_reinforcement48_20261008.csv")
BUY_ENGINE_FOLDER = Path("results/air_p0_probe_3x5_r1_engine")
BUY_ENGINE_MANIFEST = Path("results/air_p0_probe_3x5_r1.manifest.json")
BUY_CSV = Path("results/air_marginal_p0_buy_3x5_20261008.csv")
BUY_JSON = Path("results/air_marginal_p0_buy_3x5_20261008.json")
REINFORCE_CSV = Path("results/air_marginal_p0_reinforcement48_20261008.csv")
ARMS = ("OpexAI", "AAAHogEx")
PAIRS = ((1972, 1973), (1973, 1974), (1972, 1974))


def average(records, key):
    return round(statistics.mean(r[key] for r in records), 3)


def stat(records, columns):
    return {key: average(records, key) for key in columns}


def air_lines(snapshot):
    lines = [x for x in snapshot["lines"] if x["mode"] == "air"]
    mapping = {x["line_key_local"]: x for x in lines}
    if len(mapping) != len(lines):
        raise ValueError("Duplicate local line keys in snapshot")
    return mapping


def line_profit(line):
    return line["profit_this_year_gbp"]


def summarize_one_transition(before, after, seed, arm, y0, y1):
    old, now = air_lines(before), air_lines(after)
    common_keys, fresh_keys, retired_keys = old.keys() & now.keys(), now.keys() - old.keys(), old.keys() - now.keys()
    for key in common_keys:
        for field in ("station_ids", "town_ids", "ordered_station_tiles"):
            if old[key][field] != now[key][field]:
                raise ValueError(f"Line key {seed} {arm} {key} changed {field} between {y0} and {y1}")

    common = [(old[k], now[k]) for k in common_keys]
    fresh = [now[k] for k in fresh_keys]
    retired = [old[k] for k in retired_keys]
    increased = [(a, b) for a, b in common if b["vehicles"] > a["vehicles"]]
    unchanged = [(a, b) for a, b in common if b["vehicles"] == a["vehicles"]]
    decreased = [(a, b) for a, b in common if b["vehicles"] < a["vehicles"]]
    all_old_ids = {vid for line in old.values() for vid in line["vehicle_ids"]}
    all_now_ids = {vid for line in now.values() for vid in line["vehicle_ids"]}
    if len(all_old_ids) != sum(line["vehicles"] for line in old.values()):
        raise ValueError(f"Duplicate air vehicle IDs in {arm} {seed} {y0}")
    if len(all_now_ids) != sum(line["vehicles"] for line in now.values()):
        raise ValueError(f"Duplicate air vehicle IDs in {arm} {seed} {y1}")
    fresh_towns = {t for line in fresh for t in line["town_ids"]}
    overlaps = [(a, b) for a, b in common if any(t in fresh_towns for t in a["town_ids"])]
    nonoverlaps = [(a, b) for a, b in common if not any(t in fresh_towns for t in a["town_ids"])]
    delta = lambda pairs: sum(line_profit(b) - line_profit(a) for a, b in pairs)
    new_profit = sum(map(line_profit, fresh))
    retired_profit = sum(map(line_profit, retired))
    old_change = delta(common)
    total_old = sum(map(line_profit, old.values()))
    total_now = sum(map(line_profit, now.values()))
    if abs(total_now - total_old - (new_profit - retired_profit + old_change)) > 1e-4:
        raise ValueError(f"Line profit partition failed {arm} {seed} {y0}-{y1}")

    return {
        "seed": seed, "arm": arm, "from": y0, "to": y1,
        "old_lines": len(old), "now_lines": len(now),
        "new_lines": len(fresh), "retired_lines": len(retired), "matched_lines": len(common),
        "old_aircraft": len(all_old_ids), "now_aircraft": len(all_now_ids),
        "net_aircraft_delta": len(all_now_ids) - len(all_old_ids),
        "ids_first_seen_at_end": len(all_now_ids - all_old_ids),
        "ids_absent_at_end": len(all_old_ids - all_now_ids),
        "ids_surviving": len(all_old_ids & all_now_ids),
        "new_line_aircraft_at_end": sum(line["vehicles"] for line in fresh),
        "new_line_surviving_ids": len({vid for line in fresh for vid in line["vehicle_ids"]} & all_old_ids),
        "old_line_aircraft_change": sum(b["vehicles"]-a["vehicles"] for a,b in common),
        "retired_line_aircraft_at_start": sum(line["vehicles"] for line in retired),
        "added_aircraft_to_matched_lines_net": sum(b["vehicles"]-a["vehicles"] for a,b in increased),
        "removed_aircraft_from_matched_lines_net": sum(a["vehicles"]-b["vehicles"] for a,b in decreased),
        "reinforced_line_count": len(increased), "unchanged_line_count": len(unchanged),
        "decreased_line_count": len(decreased),
        "reinforced_lines_with_lower_profit_ytd": sum(line_profit(b) < line_profit(a) for a,b in increased),
        "reinforced_lines_with_negative_profit_ytd": sum(line_profit(b) < 0 for a,b in increased),
        "unchanged_lines_with_lower_profit_ytd": sum(line_profit(b) < line_profit(a) for a,b in unchanged),
        "old_profit_ytd": total_old, "now_profit_ytd": total_now,
        "delta_air_profit_ytd": total_now-total_old,
        "new_lines_profit_ytd": new_profit,
        "new_lines_negative_ytd": sum(line_profit(line) < 0 for line in fresh),
        "new_lines_nonpositive_ytd": sum(line_profit(line) <= 0 for line in fresh),
        "new_lines_negative_aircraft_at_end": sum(line["vehicles"] for line in fresh if line_profit(line) < 0),
        "new_lines_profit_last_year": sum(line["profit_last_year_gbp"] for line in fresh),
        "retired_lines_profit_ytd_start": retired_profit,
        "matched_lines_profit_change_ytd": old_change,
        "reinforced_lines_profit_change_ytd": delta(increased),
        "unchanged_lines_profit_change_ytd": delta(unchanged),
        "decreased_lines_profit_change_ytd": delta(decreased),
        "overlapping_new_towns_matched_count": len(overlaps),
        "overlapping_new_towns_matched_profit_change_ytd": delta(overlaps),
        "other_matched_count": len(nonoverlaps),
        "other_matched_profit_change_ytd": delta(nonoverlaps),
        "negative_line_count_at_end": sum(line_profit(line) < 0 for line in now.values()),
        "negative_line_aircraft_at_end": sum(line["vehicles"] for line in now.values() if line_profit(line) < 0),
        "unprofitable_line_count_at_end": sum(line_profit(line) <= 0 for line in now.values()),
    }


def monthly_vehicle_cohorts():
    """Follow individual vehicle IDs in the 3-seed monthly engine snapshots."""
    report = json.loads(VEHICLE_MONTHLY_REPORT.read_text(encoding="utf-8"))
    sha_ok = sha256(VEHICLE_MONTHLY_REPORT.with_suffix(".manifest.json").read_bytes()).hexdigest() == report["manifest_sha256"]
    snapshots = {}
    unresolved_by_key = {}
    inconsistent_lines = []
    unresolved = []
    for snap in report["line_telemetry"]["snapshots"]:
        key = (snap["seed"], snap["arm"], snap["date"])
        if key in snapshots or snap["ok"] is not True:
            raise ValueError(f"Duplicate/invalid monthly snapshot: {key}")
        vehicle_map = {}
        station_pairs = {}
        for line in snap["lines"]:
            if line["mode"] != "air":
                continue
            station_pairs[line["line_key_local"]] = line
            fin = line.get("vehicle_financials")
            if fin is None or len(fin) != line["vehicles"]:
                raise ValueError(f"Missing financials in monthly snapshot: {key} {line['line_key_local']}")
            if abs(sum(v["profit_this_year_gbp"] for v in fin) - line["profit_this_year_gbp"]) > .1:
                inconsistent_lines.append([key,line["line_key_local"],"profit"])
            if abs(sum(v["vehicle_value"] for v in fin) - line["vehicle_value"]) > .1:
                inconsistent_lines.append([key,line["line_key_local"],"value"])
            for vehicle in fin:
                id_ = vehicle["vehicle_id"]
                if id_ in vehicle_map:
                    raise ValueError(f"Vehicle {id_} assigned twice at {key}")
                vehicle_map[id_] = {**vehicle,"line_key_local":line["line_key_local"],
                    "market_key":line["market_key"],"town_ids":line["town_ids"]}
        if snap["unresolved_vehicles"]:
            unresolved.append({"seed":snap["seed"],"arm":snap["arm"],"date":snap["date"],
                               "vehicles":snap["unresolved_vehicles"]})
        unresolved_by_key[key] = snap["unresolved_vehicles"]
        snapshots[key] = {"vehicles":vehicle_map, "lines":station_pairs}

    monthly_rows = [json.loads(z) for z in VEHICLE_MONTHLY_REPORT.with_suffix(".jsonl").read_text(encoding="utf-8").splitlines()]
    company = {}
    for row in monthly_rows:
        arm,seed,repeat = row["run"]
        key = (seed,arm,row["date"])
        if key in company or repeat != 0 or key not in snapshots:
            raise ValueError(f"Bad monthly company checkpoint {key}")
        company[key] = row
        physical = row["air_primary_vehicles"]
        measured = len(snapshots[key]["vehicles"])
        if physical != measured and not any(v.get("mode")=="air" for v in unresolved_by_key[key]):
            raise ValueError(f"Cannot reconcile air vehicles {key}")

    if inconsistent_lines:
        raise ValueError(f"Inconsistent line vs aircraft economic totals: {inconsistent_lines[:3]}")
    if len(snapshots)!=len(report["seeds"])*len(ARMS)*report["years"]*12 or len(company)!=len(snapshots):
        raise ValueError("Monthly coverage incomplete")

    cohorts = []
    isolated_reinforcements = []
    for arm in ARMS:
        for seed in report["seeds"]:
            dates = sorted(date for (s,a,date) in snapshots if s==seed and a==arm)
            if len(dates)!=60:
                raise ValueError(f"Incomplete monthly dates {seed}, {arm}")
            first_seen = {}
            arrivals = []
            returning = []
            all_prior = set()
            for i,date in enumerate(dates):
                current = snapshots[(seed,arm,date)]
                prior = snapshots[(seed,arm,dates[i-1])] if i else None
                if len(current["vehicles"]) != company[(seed,arm,date)]["air_primary_vehicles"]:
                    unresolved.append({"seed":seed,"arm":arm,"date":date,
                          "physical":company[(seed,arm,date)]["air_primary_vehicles"],
                          "attributed":len(current["vehicles"])})
                prior_vehicles = prior["vehicles"] if prior else {}
                for vid in current["vehicles"]:
                    if vid not in first_seen:
                        first_seen[vid] = date
                    if not i or vid in prior_vehicles:
                        continue
                    event = {"seed":seed,"arm":arm,"first_observed":date,"vehicle_id":vid,
                        "line_key_local":current["vehicles"][vid]["line_key_local"],
                        "market_key":current["vehicles"][vid]["market_key"],
                        "kind":"first_appearance" if vid not in all_prior else "return_after_gap",
                        "line_state":"previously_seen_route" if current["vehicles"][vid]["line_key_local"] in prior["lines"] else "new_station_pair"}
                    if vid in all_prior:
                        returning.append(event)
                    else:
                        arrivals.append(event)
                all_prior.update(current["vehicles"])

            old = snapshots[(seed,arm,"1972-12-01")]["vehicles"]
            now = snapshots[(seed,arm,"1974-12-01")]["vehicles"]
            old_lines = snapshots[(seed,arm,"1972-12-01")]["lines"]
            now_lines = snapshots[(seed,arm,"1974-12-01")]["lines"]
            old_ids, now_ids = set(old),set(now)
            survived, gone, added = old_ids & now_ids, old_ids - now_ids, now_ids - old_ids
            survivors_old_ytd = sum(old[v]["profit_this_year_gbp"] for v in survived)
            survivors_new_ytd = sum(now[v]["profit_this_year_gbp"] for v in survived)
            gone_old_ytd = sum(old[v]["profit_this_year_gbp"] for v in gone)
            added_new_ytd = sum(now[v]["profit_this_year_gbp"] for v in added)
            cohorts_year = {year:[v for v in added if first_seen[v][:4]==str(year)] for year in (1973,1974)}
            historical_reappearance = [v for v in added if first_seen[v] < "1973-01-01"]
            survivor_gap_ids = [v for v in survived if any(
                v not in snapshots[(seed,arm,date)]["vehicles"]
                for date in dates if "1972-12-01" < date < "1974-12-01")]
            old_sum=sum(v["profit_this_year_gbp"] for v in old.values())
            now_sum=sum(v["profit_this_year_gbp"] for v in now.values())
            if abs((survivors_new_ytd-survivors_old_ytd) + added_new_ytd - gone_old_ytd - (now_sum-old_sum))>.1:
                raise ValueError(f"Per-aircraft decomposition mismatch: {seed} {arm}")
            at_end_arrivals = [v for v in arrivals if v["vehicle_id"] in added and v["first_observed"] >= "1973-01-01"]
            if len(at_end_arrivals) != len(added)-len(historical_reappearance):
                raise ValueError(f"First appearances do not cover newcomers {seed} {arm}")
            old_survivors_reinforced_line = [v for v in survived if
                now[v]["line_key_local"] in old_lines and
                now_lines[now[v]["line_key_local"]]["vehicles"] > old_lines[now[v]["line_key_local"]]["vehicles"]]
            old_survivors_other_line = survived - set(old_survivors_reinforced_line)
            old_ytd_change = lambda ids: sum(now[v]["profit_this_year_gbp"] - old[v]["profit_this_year_gbp"] for v in ids)

            # A conservative before/after observation: one new aircraft on an
            # otherwise unchanged line, four earlier and three later monthly
            # snapshots in the *same* calendar year. No parallel line turnover.
            for i in range(4,len(dates)-2):
                window=dates[i-4:i+3]
                if dates[i][:4] not in ("1973","1974") or len({z[:4] for z in window})!=1:
                    continue
                s_prev = snapshots[(seed,arm,dates[i-1])]
                s_curr = snapshots[(seed,arm,dates[i])]
                for linekey in s_prev["lines"].keys() & s_curr["lines"].keys():
                    pids=set(s_prev["lines"][linekey]["vehicle_ids"])
                    cids=set(s_curr["lines"][linekey]["vehicle_ids"])
                    new_ids=cids-pids
                    if len(new_ids)!=1 or cids-pids != new_ids or pids-cids:
                        continue
                    new_id=next(iter(new_ids))
                    if first_seen.get(new_id)!=dates[i]:
                        continue
                    before_ok=all(linekey in snapshots[(seed,arm,z)]["lines"] and
                        set(snapshots[(seed,arm,z)]["lines"][linekey]["vehicle_ids"]) == pids for z in window[:4])
                    after_ok=all(linekey in snapshots[(seed,arm,z)]["lines"] and
                        set(snapshots[(seed,arm,z)]["lines"][linekey]["vehicle_ids"]) == cids for z in window[4:])
                    if not before_ok or not after_ok:
                        continue

                    def cohort_period(start,end):
                        return sum(snapshots[(seed,arm,dates[j])]["vehicles"][v]["profit_this_year_gbp"] -
                                   snapshots[(seed,arm,dates[j-1])]["vehicles"][v]["profit_this_year_gbp"]
                                   for j in range(start,end) for v in pids)

                    prior_old = cohort_period(i-3,i)
                    later_old = cohort_period(i,i+3)
                    new_ytd = snapshots[(seed,arm,dates[i+2])]["vehicles"][new_id]["profit_this_year_gbp"]
                    isolated_reinforcements.append({"seed":seed,"arm":arm,"first_seen":dates[i],
                        "line_key_local":linekey,"market_key":s_curr["lines"][linekey]["market_key"],
                        "aircraft_before":len(pids),"new_vehicle_id":new_id,
                        "old_aircraft_profit_three_months_before":round(prior_old,3),
                        "old_aircraft_profit_three_months_after":round(later_old,3),
                        "old_aircraft_profit_delta_three_months":round(later_old-prior_old,3),
                        "new_aircraft_profit_three_months_after":round(new_ytd,3),
                        "combined_route_profit_delta_three_months":round(later_old+new_ytd-prior_old,3)})
            cohorts.append({
                "seed":seed,"arm":arm,
                "old_aircraft_1972":len(old),"now_aircraft_1974":len(now),
                "old_profit_ytd_1972":round(old_sum,3),"now_profit_ytd_1974":round(now_sum,3),
                "profit_ytd_delta_1972_74":round(now_sum-old_sum,3),
                "surviving_1972_aircraft":len(survived),
                "survivors_profit_ytd_1972":round(survivors_old_ytd,3),
                "survivors_profit_ytd_1974":round(survivors_new_ytd,3),
                "survivors_profit_ytd_delta":round(survivors_new_ytd-survivors_old_ytd,3),
                "old_surviving_aircraft_on_reinforced_lines":len(old_survivors_reinforced_line),
                "old_survivors_on_reinforced_lines_profit_ytd_delta":round(old_ytd_change(old_survivors_reinforced_line),3),
                "old_surviving_aircraft_on_other_lines":len(old_survivors_other_line),
                "old_survivors_on_other_lines_profit_ytd_delta":round(old_ytd_change(old_survivors_other_line),3),
                "surviving_ids_with_unobserved_month_gap":len(survivor_gap_ids),
                "survivor_aircraft_profit_ytd_lower":sum(now[v]["profit_this_year_gbp"] < old[v]["profit_this_year_gbp"] for v in survived),
                "survivors_changed_line_key":sum(now[v]["line_key_local"]!=old[v]["line_key_local"] for v in survived),
                "departed_since_1972":len(gone),"departed_profit_ytd_1972":round(gone_old_ytd,3),
                "new_1974_december_aircraft":len(added),
                "new_aircraft_profit_ytd_1974":round(added_new_ytd,3),
                "new_aircraft_negative_profit_ytd_1974":sum(now[v]["profit_this_year_gbp"]<0 for v in added),
                "added_ids_seen_before_dec1972":len(historical_reappearance),
                "added_ids_seen_before_dec1972_profit_ytd_1974":round(sum(now[v]["profit_this_year_gbp"] for v in historical_reappearance),3),
                "new_1973_surviving_to_1974":len(cohorts_year[1973]),
                "new_1973_profit_ytd_1974":round(sum(now[v]["profit_this_year_gbp"] for v in cohorts_year[1973]),3),
                "new_1974_surviving_to_1974":len(cohorts_year[1974]),
                "new_1974_profit_ytd_1974":round(sum(now[v]["profit_this_year_gbp"] for v in cohorts_year[1974]),3),
                "first_appearance_new_station_pair":sum(v["line_state"]=="new_station_pair" for v in at_end_arrivals),
                "first_appearance_previous_route":sum(v["line_state"]=="previously_seen_route" for v in at_end_arrivals),
                "new_aircraft_book_value_1974":sum(now[v]["vehicle_value"] for v in added),
                "new_aircraft_profit_details":[{
                    "vehicle_id":v,"first_seen":first_seen[v],"line_key_local":now[v]["line_key_local"],
                    "market_key":now[v]["market_key"],"profit_ytd_1974":round(now[v]["profit_this_year_gbp"],3),
                    "vehicle_value_1974":now[v]["vehicle_value"]} for v in sorted(added)],
                "first_appearances_1973_74":[a for a in arrivals if a["first_observed"]>="1973-01-01"],
                "returned_vehicles_1973_74":[a for a in returning if a["first_observed"]>="1973-01-01"],
            })

    fields=("old_aircraft_1972","now_aircraft_1974","profit_ytd_delta_1972_74",
            "surviving_1972_aircraft","survivors_profit_ytd_delta",
            "old_surviving_aircraft_on_reinforced_lines",
            "old_survivors_on_reinforced_lines_profit_ytd_delta",
            "old_surviving_aircraft_on_other_lines",
            "old_survivors_on_other_lines_profit_ytd_delta",
            "survivor_aircraft_profit_ytd_lower","departed_since_1972","departed_profit_ytd_1972",
            "new_1974_december_aircraft","new_aircraft_profit_ytd_1974",
            "new_aircraft_negative_profit_ytd_1974","new_1973_surviving_to_1974",
            "surviving_ids_with_unobserved_month_gap","added_ids_seen_before_dec1972",
            "added_ids_seen_before_dec1972_profit_ytd_1974",
            "new_1973_profit_ytd_1974","new_1974_surviving_to_1974","new_1974_profit_ytd_1974",
            "first_appearance_new_station_pair","first_appearance_previous_route")
    means={arm:stat([c for c in cohorts if c["arm"]==arm],fields) for arm in ARMS}
    event_stats={}
    for arm in ARMS:
        events=[e for e in isolated_reinforcements if e["arm"]==arm]
        event_stats[arm]={"n":len(events),
            "mean_old_aircraft_profit_change_three_months":average(events,"old_aircraft_profit_delta_three_months") if events else None,
            "median_old_aircraft_profit_change_three_months":round(statistics.median(e["old_aircraft_profit_delta_three_months"] for e in events),3) if events else None,
            "mean_new_aircraft_profit_three_months":average(events,"new_aircraft_profit_three_months_after") if events else None,
            "mean_combined_route_profit_change_three_months":average(events,"combined_route_profit_delta_three_months") if events else None,
            "median_combined_route_profit_change_three_months":round(statistics.median(e["combined_route_profit_delta_three_months"] for e in events),3) if events else None,
            "count_by_seed":{str(seed):sum(e["seed"]==seed for e in events) for seed in report["seeds"]},
            "old_aircraft_profit_declines":sum(e["old_aircraft_profit_delta_three_months"]<0 for e in events),
            "combined_route_profit_declines":sum(e["combined_route_profit_delta_three_months"]<0 for e in events)}
    out={"campaign_id":report["campaign_id"],"seeds":report["seeds"],
         "source_bundle_sha256":report["source_bundle_sha256"],
         "manifest_sha256_verified":sha_ok,
         "n_games":len(report["games"]),"n_monthly_snapshots":len(snapshots),
         "n_monthly_company_checkpoints":len(company),
         "n_line_financial_mismatches":len(inconsistent_lines),
         "unresolved_vehicles_or_count_mismatches":unresolved,
         "means":means,"per_seed":cohorts,
         "isolated_reinforcement_events":isolated_reinforcements,
         "isolated_reinforcement_stats":event_stats,
         "notes":["Cohorts use vehicle IDs in snapshots 1972-12-01 and 1974-12-01, and first monthly observation in 1973/74 for newcomers. IDs can be recycled; historical reappearances and survivor IDs with gaps are counted separately.",
                  "No purchase dates, prices or costs. A first appearance dates an ID's appearance to the interval between checkpoints; replacement and ID reuse cannot always be distinguished.",
                  "All vehicle profit data are net profit this calendar year to the observed save date; same line YTD changes and changes to surviving vehicles include traffic and other network effects."]}
    VEHICLE_MONTHLY_OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f"VEHICLE_MONTHLY_OUT {VEHICLE_MONTHLY_OUT}")
    print("VEHICLE_INTEGRITY", {key:out[key] for key in ("n_games","n_monthly_snapshots","n_monthly_company_checkpoints","manifest_sha256_verified","n_line_financial_mismatches","unresolved_vehicles_or_count_mismatches")})
    print("ISOLATED_REINFORCEMENTS",event_stats)
    for c in cohorts:
        print("VEH_COHORT",c["seed"],c["arm"],"air",c["old_aircraft_1972"],"->",c["now_aircraft_1974"],
              "YTD_DELTA",round(c["profit_ytd_delta_1972_74"]),"survivors",c["surviving_1972_aircraft"],
              "survivor_YTD_delta",round(c["survivors_profit_ytd_delta"]),
              "new_ac",c["new_1974_december_aircraft"],"new_profit_YTD",round(c["new_aircraft_profit_ytd_1974"]),
              "new_1973_profit_YTD",round(c["new_1973_profit_ytd_1974"]),
              "new_1974_profit_YTD",round(c["new_1974_profit_ytd_1974"]),
              "departed_YTD",round(c["departed_profit_ytd_1972"]))
        if c["arm"]=="OpexAI":
            print("OLD_SURVIVOR_LINES",c["seed"],"reinforced_aircraft",c["old_surviving_aircraft_on_reinforced_lines"],
                  "reinforced_old_profit_delta",round(c["old_survivors_on_reinforced_lines_profit_ytd_delta"]),
                  "other_aircraft",c["old_surviving_aircraft_on_other_lines"],
                  "other_old_profit_delta",round(c["old_survivors_on_other_lines_profit_ytd_delta"]))


def buy_log_autopsy():
    """AIR_P0_BUY quotes in engine logs and matching ON game-line snapshots."""
    report = json.loads(BUY_ENGINE_REPORT.read_text(encoding="utf-8"))
    manifest_sha_ok = sha256(BUY_ENGINE_REPORT.with_suffix(".manifest.json").read_bytes()).hexdigest() == report["manifest_sha256"]
    policy="air_p0_probe_on"
    snaps={}
    for s in report["line_telemetry"]["snapshots"]:
        if s["duel_policy_id"]==policy and s["arm"]=="OpexAI":
            if (s["seed"],s["date"]) in snaps:
                raise ValueError(f"Duplicate ON AIR snapshot {s['seed']} {s['date']}")
            snaps[(s["seed"],s["date"])]=s
    if len(snaps)!=180 or not all(s["ok"] for s in snaps.values()):
        raise ValueError("Incomplete/invalid ON monthly line snapshots")

    def checkpoint_after(date_raw):
        y,m,d=[int(t) for t in date_raw.split("-")]
        if d>1:
            y+=int(m==12)
            m=1 if m==12 else m+1
        return f"{y:04d}-{m:02d}-01"

    def pair_index(snapshot):
        result=defaultdict(list)
        if snapshot:
            for line in snapshot["lines"]:
                if line["mode"]=="air":
                    result[tuple(sorted(int(x) for x in line["ordered_station_tiles"]))].append(line)
        return result

    lines_by_checkpoint={key:pair_index(s) for key,s in snaps.items()}
    buys=[]
    for logfile in sorted(BUY_ENGINE_FOLDER.glob("air_p0_probe_on_seed*_r0.log")):
        match=re.fullmatch(r"air_p0_probe_on_seed(\d+)_r0\.log",logfile.name)
        if not match:
            raise ValueError(logfile.name)
        seed=int(match.group(1))
        for lineno,raw in enumerate(logfile.open(encoding="utf-8", errors="replace"),1):
            tag="AIR_P0_BUY "
            i=raw.find(tag)
            if i<0:
                continue
            fields={}
            for t in raw[i+len(tag):].strip().split():
                if "=" in t:
                    k,v=t.split("=",1)
                    fields[k]=v
            required=("date","line","station_a","station_b","before","after","added","replaced",
                      "target","regime","cost_cash","cost_quote","pred_profit","roi")
            if any(k not in fields for k in required):
                raise ValueError(f"Malformed AIR_P0_BUY {logfile}:{lineno} {fields}")
            pair=tuple(sorted((int(fields["station_a"]),int(fields["station_b"]))))
            checkpoint=checkpoint_after(fields["date"])
            current_month=f"{int(fields['date'].split('-')[0]):04d}-{int(fields['date'].split('-')[1]):02d}-01"
            after_hits=lines_by_checkpoint.get((seed,checkpoint),{}).get(pair,[])
            before_hits=lines_by_checkpoint.get((seed,current_month),{}).get(pair,[])
            matching=after_hits[0] if len(after_hits)==1 else None
            rec={"seed":seed,"log_file":logfile.name,"log_line":lineno,
                 "checkpoint_after_buy":checkpoint,"checkpoint_before_buy":current_month,
                 "station_tile_pair":list(pair),
                 "station_pair_match":"unique_exact" if len(after_hits)==1 else (
                     "ambiguous_exact" if after_hits else "no_exact_match"),
                 "matching_saved_line_key":matching["line_key_local"] if matching else None,
                 "matching_saved_market_key":matching["market_key"] if matching else None,
                 "before_snapshot_aircraft_count":before_hits[0]["vehicles"] if len(before_hits)==1 else None,
                 "after_snapshot_aircraft_count":matching["vehicles"] if matching else None,
                 **fields}
            buys.append(rec)
    if len(buys)!=117:
        raise ValueError(f"Unexpected AIR_P0_BUY count {len(buys)}")

    buy_fields=("seed","date","line","before","after","added","replaced","target","regime",
                "station_a","station_b","cost_cash","cost_quote","fleet_rank","waiting_a","waiting_b",
                "plane_capacity","pred_profit","pred_revenue","roi","fund_score","budget_score","opcode_score",
                "observed_line_profit","observed_line_revenue","marginal_pred_cached","marginal_last_observed",
                "marginal_samples","next_air_rank","next_air_key","next_air_capital","next_air_profit",
                "next_air_score","checkpoint_before_buy","checkpoint_after_buy","station_pair_match",
                "matching_saved_line_key","matching_saved_market_key","before_snapshot_aircraft_count",
                "after_snapshot_aircraft_count","log_file","log_line")
    with BUY_CSV.open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=buy_fields,extrasaction="ignore")
        writer.writeheader()
        writer.writerows(buys)

    # The 48 independent OFF/no-log events stay in a separate file.
    previous=json.loads(VEHICLE_MONTHLY_OUT.read_text(encoding="utf-8"))
    independent=[x for x in previous["isolated_reinforcement_events"] if x["arm"]=="OpexAI"]
    event_cols=("seed","first_seen","line_key_local","market_key","new_vehicle_id",
           "aircraft_before","old_aircraft_profit_three_months_before",
           "old_aircraft_profit_three_months_after","old_aircraft_profit_delta_three_months",
           "new_aircraft_profit_three_months_after","combined_route_profit_delta_three_months")
    with REINFORCE_CSV.open("w",encoding="utf-8",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=event_cols,extrasaction="ignore")
        writer.writeheader()
        writer.writerows(independent)

    # Same-run log-to-save matching is exact by both airport station tiles.
    # The following 3-month measurement additionally excludes other additions,
    # removals or route changes in the seven-month local window.
    study=[]
    buy_counts=Counter((b["seed"],b["checkpoint_after_buy"],tuple(b["station_tile_pair"])) for b in buys)
    for buy in buys:
        if int(buy["added"])!=1 or int(buy["replaced"])!=0 or buy["station_pair_match"]!="unique_exact":
            continue
        seed=buy["seed"]
        months=sorted(date for s,date in snaps if s==seed)
        date=buy["checkpoint_after_buy"]
        if date not in months:
            continue
        index=months.index(date)
        if index<4 or index+2>=len(months):
            continue
        local_dates=months[index-4:index+3]
        if len({d[:4] for d in local_dates})!=1 or int(date[:4])<1972:
            continue
        if buy_counts[(seed,date,tuple(buy["station_tile_pair"]))]!=1:
            continue
        pair=tuple(buy["station_tile_pair"])
        local=[]
        for d in local_dates:
            ls=lines_by_checkpoint.get((seed,d),{}).get(pair,[])
            if len(ls)!=1:
                break
            local.append(ls[0])
        if len(local)!=7:
            continue
        prior_ids=set(local[3]["vehicle_ids"])
        after_ids=set(local[4]["vehicle_ids"])
        diff=after_ids-prior_ids
        if len(diff)!=1 or prior_ids-after_ids:
            continue
        if len(prior_ids)!=int(buy["before"]) or len(after_ids)!=int(buy["after"]):
            continue
        if any(set(l["vehicle_ids"])!=prior_ids for l in local[:4]):
            continue
        if any(set(l["vehicle_ids"])!=after_ids for l in local[4:]):
            continue

        old_pre=0.0
        old_post=0.0
        for j in range(1,4):
            prev={v["vehicle_id"]:v for v in local[j-1]["vehicle_financials"]}
            curr={v["vehicle_id"]:v for v in local[j]["vehicle_financials"]}
            old_pre+=sum(curr[id_]["profit_this_year_gbp"]-prev[id_]["profit_this_year_gbp"] for id_ in prior_ids)
        for j in range(4,7):
            prev={v["vehicle_id"]:v for v in local[j-1]["vehicle_financials"]}
            curr={v["vehicle_id"]:v for v in local[j]["vehicle_financials"]}
            old_post+=sum(curr[id_]["profit_this_year_gbp"]-prev[id_]["profit_this_year_gbp"] for id_ in prior_ids)
        new_id=next(iter(diff))
        previous_month_all_air_ids={v for line in snaps[(seed,months[index-1])]["lines"]
                                    if line["mode"]=="air" for v in line["vehicle_ids"]}
        if new_id in previous_month_all_air_ids:
            continue
        new_vehicle=next(v for v in local[6]["vehicle_financials"] if v["vehicle_id"]==new_id)
        new_profit=new_vehicle["profit_this_year_gbp"]
        observed_net_change=old_post+new_profit-old_pre
        prediction_3mo=float(buy["pred_profit"])/4
        study.append({"seed":seed,"date":buy["date"],"line_id":int(buy["line"]),
           "line_key_local":local[4]["line_key_local"],"station_a":buy["station_a"],
           "station_b":buy["station_b"],"new_vehicle_id":new_id,
           "before":int(buy["before"]),"after":int(buy["after"]),"target":int(buy["target"]),
           "regime":buy["regime"],"cost_cash":int(buy["cost_cash"]),"roi":float(buy["roi"]),
           "prediction_annual":float(buy["pred_profit"]),
           "prediction_prorated_3months":round(prediction_3mo,3),
           "old_profit_previous_3months":round(old_pre,3),
           "old_profit_following_3months":round(old_post,3),
           "old_profit_delta":round(old_post-old_pre,3),
           "new_vehicle_profit_following_3months":round(new_profit,3),
           "observed_line_increment_net_3months":round(observed_net_change,3),
           "observed_minus_prorated_prediction":round(observed_net_change-prediction_3mo,3),
           "first_observed_new_vehicle":date,"log_line":buy["log_line"]})

    debug_stats={"n_games":len(report["games"]),"n_snapshots_on_opex":len(snaps),
         "manifest_sha_verified":manifest_sha_ok,
         "source_bundle_sha256":report["source_bundle_sha256"],
         "n_buy_events":len(buys),"by_seed":dict(Counter(str(b["seed"]) for b in buys)),
         "by_year":dict(Counter(b["date"].split("-")[0] for b in buys)),
         "regimes":dict(Counter(b["regime"] for b in buys)),
         "station_pair_mapping":dict(Counter(b["station_pair_match"] for b in buys)),
         "n_isolated_exact_logged_3m":len(study),
         "n_isolated_exact_logged_3m_negative":sum(e["observed_line_increment_net_3months"]<0 for e in study),
         "n_isolated_exact_logged_3m_prediction_overshoot":sum(e["observed_minus_prorated_prediction"]<0 for e in study),
         "n_independent_unlogged_3m":len(independent)}
    if study:
        debug_stats["mean_observed_line_increment_3m"]=average(study,"observed_line_increment_net_3months")
        debug_stats["mean_prediction_3m"]=average(study,"prediction_prorated_3months")
        debug_stats["median_observed_line_increment_3m"]=round(statistics.median(e["observed_line_increment_net_3months"] for e in study),3)
        debug_stats["median_prediction_3m"]=round(statistics.median(e["prediction_prorated_3months"] for e in study),3)
        with LOGGED_EVENT_CSV.open("w",encoding="utf-8",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=list(study[0]))
            writer.writeheader()
            writer.writerows(study)
    out={"summary":debug_stats,"buy_events":buys,"isolated_logged_events":study,
         "notes":["Logged AIR_P0_BUY events and ON monthly line snapshots come from the same frozen game run and source bundle.",
                  "Matching uses exact unordered airport tile pair in the next monthly snapshot, then exactly one new vehicle ID and no line fleet turnover in an all-same-year seven-month window.",
                  "Predicted profit is logged annualized AIR model profit; division by four to compare with a 3-month vehicle YTD segment assumes a uniform annual trajectory. Three-month before/after is observational, seasonal and competitor confounded.",
                  "cost_cash records the logged cash cost, NOT the company cash balance; alternative next_air_* values are retained in the CSV.",
                  "The separate 48 isolated reinforcements were observed in air_p0_veh3_r1, a different source bundle, and must not be joined as same decisions."]}
    BUY_JSON.write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print("BUY_FILES",BUY_CSV,BUY_JSON,LOGGED_EVENT_CSV,REINFORCE_CSV)
    print("BUY_SUMMARY",json.dumps(debug_stats,ensure_ascii=False))
    for event in sorted(study,key=lambda e:e["observed_minus_prorated_prediction"])[:10]:
        print("BUY_COUNTEREXAMPLE",event["seed"],event["date"],"line",event["line_id"],
              "N",event["before"],"->",event["after"],"quote3m",round(event["prediction_prorated_3months"]),
              "obs3m",round(event["observed_line_increment_net_3months"]),
              "old3mΔ",round(event["old_profit_delta"]),
              "new3m",round(event["new_vehicle_profit_following_3months"]),
              "roi",round(event["roi"]),"regime",event["regime"])


def main():
    report = json.loads(REPORT.read_text(encoding="utf-8"))
    mani = REPORT.with_suffix(".manifest.json")
    manifest_match = sha256(mani.read_bytes()).hexdigest() == report["manifest_sha256"]
    snapshots = {}
    snapshot_rows = report["line_telemetry"]["snapshots"]
    for snap in snapshot_rows:
        key = (snap["seed"], snap["arm"], snap["year"])
        if key in snapshots or not snap["ok"]:
            raise ValueError(f"Bad/duplicate line snapshot {key}")
        snapshots[key] = snap
    for year in range(1970, 1975):
        for arm in ARMS:
            for seed in report["seeds"]:
                if (seed, arm, year) not in snapshots:
                    raise ValueError(f"Missing line snapshot {seed}, {arm}, {year}")

    checkpoints = {}
    monthly = defaultdict(list)
    for raw in REPORT.with_suffix(".jsonl").open(encoding="utf-8"):
        if not raw.strip():
            continue
        row = json.loads(raw)
        arm, seed, repeat = row["run"]
        if arm not in ARMS or repeat != 0 or row.get("duel_policy_id") != report["policy_id"]:
            raise ValueError("Unexpected JSONL arm/repeat/policy")
        key = (seed, arm, row["date"])
        if key in checkpoints:
            raise ValueError(f"Duplicate checkpoint {key}")
        checkpoints[key] = row
        monthly[(arm, row["date"])].append(row)

    monthly_yearly = []
    per_seed_annual = []
    air_vehicle_count_mismatches = []
    quarterly = []
    for year in range(1970, 1975):
        date = f"{year}-12-01"
        for arm in ARMS:
            rows = monthly[(arm, date)]
            if len(rows) != len(report["seeds"]):
                raise ValueError(f"Invalid December month coverage: {year} {arm}")
            coverage = Counter(r["profit_year_coverage"] for r in rows)
            line_rows = [snapshots[(seed, arm, year)] for seed in report["seeds"]]
            for r in rows:
                seed = r["run"][1]
                snap = snapshots[(seed,arm,year)]
                lines = air_lines(snap)
                resolved = sum(x["vehicles"] for x in lines.values())
                if r["air_primary_vehicles"] != resolved:
                    air_vehicle_count_mismatches.append({"arm":arm,"seed":seed,"year":year,
                        "physical_aircraft":r["air_primary_vehicles"],"assigned_to_lines":resolved,
                        "unresolved":snap["unresolved_vehicles"]})
                per_seed_annual.append({
                    "seed":seed, "arm":arm,"year":year,"date":date,
                    "profit_year_rolling":r["profit_year"],
                    "profit_last_closed_quarter":r["profit"],
                    "profit_year_coverage":r["profit_year_coverage"],
                    "company_value":r["company_value"],"cash":r["money"],
                    "aircraft":r["air_primary_vehicles"],"airport_count":r["air_airports"],
                    "rail_vehicles":r["primary_vehicles_by_mode"]["rail"],
                    "road_vehicles":r["primary_vehicles_by_mode"]["road"],
                    "air_book_value":r["air_vehicle_book_value"],
                    "air_lines":len(lines),"aircraft_assigned_to_lines":resolved,
                    "air_profit_ytd":round(sum(line_profit(x) for x in lines.values()),3),
                    "air_profit_last_year":round(sum(x["profit_last_year_gbp"] for x in lines.values()),3),
                    "negative_air_lines_ytd":sum(line_profit(x)<0 for x in lines.values()),
                    "air_line_keys":[{"line_key_local":x["line_key_local"],
                        "market_key":x["market_key"],"aircraft":x["vehicles"],
                        "vehicle_ids":x["vehicle_ids"],"profit_ytd":x["profit_this_year_gbp"]}
                        for x in lines.values()],
                    "retained_project_build_signs_this_year":r["project_builds_sign_by_year"].get(str(year)),
                    "unresolved_aircraft":sum(x.get("mode")=="air" for x in snap["unresolved_vehicles"]),
                })
            monthly_yearly.append({
                "year": year, "arm": arm, "n": len(rows), "coverage": coverage,
                "profit_year": average(rows, "profit_year"),
                "value": average(rows, "company_value"),
                "cash": average(rows, "money"),
                "aircraft": average(rows, "air_primary_vehicles"),
                "airports": average(rows, "air_airports"),
                "aircraft_book_value": average(rows, "air_vehicle_book_value"),
                "air_lines": round(statistics.mean(len(air_lines(s)) for s in line_rows),3),
                "air_profit_ytd": round(statistics.mean(sum(line_profit(x) for x in air_lines(s).values()) for s in line_rows),3),
                "air_profit_last_year": round(statistics.mean(sum(x["profit_last_year_gbp"] for x in air_lines(s).values()) for s in line_rows),3),
            })

    # Each month's company snapshot retains its last *closed* quarter profit.
    # The last closed quarter changes in February/May/August/November on this
    # campaign calendar, verified below against December rolling profit_year.
    for year in range(1971,1975):
        for arm in ARMS:
            for month in (2,5,8,11):
                date = f"{year}-{month:02d}-01"
                vals = monthly[(arm,date)]
                if len(vals)!=len(report["seeds"]):
                    raise ValueError(f"Quarter coverage mismatch {date} {arm}")
                quarterly.append({"arm":arm,"year":year,"last_closed_quarter_observed_on":date,
                    "mean_company_quarter_profit":average(vals,"profit"),
                    "mean_aircraft_at_checkpoint":average(vals,"air_primary_vehicles")})
            for seed in report["seeds"]:
                observed = sum(checkpoints[(seed,arm,f"{year}-{month:02d}-01")]["profit"]
                               for month in (2,5,8,11))
                reported = checkpoints[(seed,arm,f"{year}-12-01")]["profit_year"]
                if abs(observed-reported)>1e-6:
                    raise ValueError(f"Rolling year did not match four quarter observations {seed} {arm} {year}")

    transitions = []
    for y0, y1 in PAIRS:
        for arm in ARMS:
            for seed in report["seeds"]:
                transitions.append(summarize_one_transition(snapshots[(seed,arm,y0)],
                    snapshots[(seed,arm,y1)], seed, arm, y0, y1))

    fields = [k for k,v in transitions[0].items() if isinstance(v,(float,int)) and k not in ("seed","from","to")]
    mean_transitions = []
    for y0, y1 in PAIRS:
        for arm in ARMS:
            rows = [r for r in transitions if r["from"]==y0 and r["to"]==y1 and r["arm"]==arm]
            summary = {"from":y0,"to":y1,"arm":arm,"n_seeds":len(rows),"mean":stat(rows,fields),
                "total_new_lines_negative":sum(r["new_lines_negative_ytd"] for r in rows),
                "total_new_lines":sum(r["new_lines"] for r in rows),
                "n_seed_air_ytd_decline":sum(r["delta_air_profit_ytd"] < 0 for r in rows),
                "n_seed_matched_line_profit_decline":sum(r["matched_lines_profit_change_ytd"] < 0 for r in rows),
                "n_seed_added_aircraft":sum(r["net_aircraft_delta"]>0 for r in rows),
            }
            mean_transitions.append(summary)

    logs = list(Path(report["engine_log_dir"].replace("/work/", "")).glob("*.log"))
    monthly_counts = Counter(len(rows) for rows in monthly.values())
    out = {
        "provenance": {
            "campaign_id":report["campaign_id"], "source_bundle_sha256":report["source_bundle_sha256"],
            "manifest_sha256":report["manifest_sha256"], "manifest_sha256_verified":manifest_match,
            "n_games":len(report["games"]), "n_failed_runs":len(report["failed_runs"]),
            "n_line_snapshots":len(snapshots), "n_monthly_company_checkpoints":len(checkpoints),
            "air_vehicle_count_mismatches":air_vehicle_count_mismatches,
            "checkpoints_per_month_distribution":dict(monthly_counts),
            "engine_logs":len(logs), "engine_logs_nonempty":sum(p.stat().st_size>0 for p in logs),
            "line_observed_fields":report["line_telemetry"]["observed_fields"],
            "line_unavailable_fields":report["line_telemetry"]["unavailable_fields"],
            "station_supply_telemetry":report.get("station_supply_telemetry"),
            "retained_savegames":report.get("retained_savegames"),
        },
        "annual":monthly_yearly, "per_seed_annual":per_seed_annual,
        "observed_closed_quarters":quarterly,
        "mean_transitions":mean_transitions,
        "per_seed_transitions":transitions,
        "notes":[
            "AIR line_key_local is a station-pair reconstruction from saves; unchanged keys have unchanged station geometry, verified for every matched line.",
            "At December 1 profit_this_year_gbp is vehicle net profit within the current calendar year, not the rolling company profit_year or an additive company income statement.",
            "AIR aircraft ID first appearing at later December snapshot is not proven purchased there: replacement/transfer/vehicle churn between snapshots is unobserved.",
            "Changes of same line revenue are observational. Aircraft ages, competition, passenger delivery and timetable/network effects change, so no causal attribution to increments or cannibalization.",
            "Project build signs are retained signs for projects across modes, not full purchase and line IDs; neither engine logs nor separate revenue/running costs available.",
            "Monthly company profit reports the most recently closed quarter; February, May, August and November observations sum exactly to the same year's December rolling profit for all 20 seeds and both companies (1971-74). This is not quarter-level AIR line telemetry.",
        ],
    }
    OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False,default=dict)+"\n",encoding="utf-8")
    print(f"OUT {OUT}")
    print("INTEGRITY", json.dumps(out["provenance"], ensure_ascii=False))
    for r in mean_transitions:
        m=r["mean"]
        print("TRANS",r["arm"],r["from"],r["to"],"air",m["old_aircraft"],"->",m["now_aircraft"],
            "lines",m["old_lines"],"->",m["now_lines"],"new",m["new_lines"],"reinforced",m["reinforced_line_count"],
            "YTD profit delta",round(m["delta_air_profit_ytd"]),"new lines profit",round(m["new_lines_profit_ytd"]),
            "existing profit change",round(m["matched_lines_profit_change_ytd"]),
            "retired old profit",round(m["retired_lines_profit_ytd_start"]),
            "new negative",r["total_new_lines_negative"],"/",r["total_new_lines"],
            "decline seeds",r["n_seed_air_ytd_decline"])
    if VEHICLE_MONTHLY_REPORT.exists():
        monthly_vehicle_cohorts()
    if BUY_ENGINE_REPORT.exists() and BUY_ENGINE_FOLDER.exists() and VEHICLE_MONTHLY_OUT.exists():
        buy_log_autopsy()


if __name__ == "__main__":
    main()
