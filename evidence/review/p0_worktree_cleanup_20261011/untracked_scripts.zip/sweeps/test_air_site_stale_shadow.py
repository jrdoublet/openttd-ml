"""Contrats V126 : comparer des devis sans altérer les choix (pas de VM Squirrel)."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def read(name):
    return (ROOT / name).read_text(encoding="utf-8")


class TestAirSiteStaleShadow(unittest.TestCase):
    def test_toggle_off_everywhere_by_default(self):
        info = read("info.nut")
        k = 'name = "air_site_stale_shadow"'
        self.assertEqual(info.count(k), 1)
        entry = info[info.index(k):info.index("});", info.index(k))]
        for name in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertIn(f"{name} = 0", entry)
        self.assertIn("flags = AICONFIG_BOOLEAN", entry)
        self.assertIn("AIR_SITE_STALE_SHADOW <- false;", read("globals_pre.nut"))
        self.assertIn(
            'AIR_SITE_STALE_SHADOW = AIController.GetSetting("air_site_stale_shadow") != 0;',
            read("settings.nut"),
        )

    def test_shadow_directly_uses_fresh_v95_avoid_daily_cache(self):
        task = read("task_air.nut")
        body = task.split("function OpexAirStaleQuoteObserve(", 1)[1].split("\nfunction ", 1)[0]
        self.assertIn("!AIR_SITE_STALE_SHADOW || !AIR_SITE_COST_QUOTE || !C121_AIR_ECONOMICS", body)
        self.assertEqual(body.count("OpexAirV95LevelCost("), 2)
        self.assertNotIn("OpexAirSiteLevelQuote(", body)
        self.assertIn("oldA != freshA || oldB != freshB", body)
        self.assertIn("oldA < 0 || freshA < 0", body)
        self.assertIn("oldB < 0 || freshB < 0", body)
        self.assertIn("newNeed += (cashShift * AIR_SITE_COST_MARGIN_PCT) / 100;", body)
        self.assertIn('AILog.Info("AIR_SITE_STALE path=" + path', body)
        self.assertNotIn("return false", body)
        self.assertNotIn("return true", body)
        self.assertNotIn("BuildAirport", body)

    def test_both_final_cash_paths_call_only_when_enabled(self):
        code = read("task_air.nut")
        self.assertEqual(code.count('if (AIR_SITE_STALE_SHADOW) OpexAirStaleQuoteObserve('), 2)
        self.assertIn('"legacy", builtCount, plan, -1, money, baseReserve, need);', code)
        self.assertIn('"portfolio", i, buildPlan,', code)
        self.assertLess(code.index('"portfolio", i, buildPlan,'), code.index('if (money < need) {', code.index('"portfolio", i, buildPlan,')))


if __name__ == "__main__":
    unittest.main()
