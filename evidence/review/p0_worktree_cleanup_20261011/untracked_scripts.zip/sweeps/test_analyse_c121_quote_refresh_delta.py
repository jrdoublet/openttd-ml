"""Regression for natural C121 quote delta log accounting."""
import sys
import tempfile
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyse_c121_quote_refresh_delta import analyze, parse


def event(**kw):
    vals = dict(key="a", age=1, arm="hubsite", only_town=1, old_valid=1, new_valid=1,
                old_pax_a=100, new_pax_a=101, old_pax_b=90, new_pax_b=90,
                old_mail_a=3, new_mail_a=3, old_mail_b=2, new_mail_b=2,
                old_profit=200, new_profit=210, old_revenue=400, new_revenue=410,
                old_capital=100, new_capital=100, old_engine=8, new_engine=8)
    vals.update(kw)
    return "[Info] C121_QUOTE_REFRESH_DELTA " + " ".join(f"{k}={v}" for k, v in vals.items())


class QuoteRefreshDecoderTests(unittest.TestCase):
    def test_parse_exact_token_only(self):
        self.assertEqual(parse(event())["key"], "a")
        self.assertIsNone(parse("NO_C121_QUOTE_REFRESH_DELTA age=1"))

    def test_count_quote_and_viability_changes_without_profit_inference(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / "part.log"
            p.write_text("\n".join((event(), event(new_pax_a=100, new_profit=200),
                                     event(new_valid=0, only_town=0), event(old_profit="bad"))),
                         encoding="utf-8")
            report = analyze([p])
            n = report["aggregate"]
            self.assertEqual(n["events"], 4)
            self.assertEqual(n["comparable_quotes"], 2)
            self.assertEqual(n["demand_changed"], 1)
            self.assertEqual(n["demand_unchanged"], 1)
            self.assertEqual(n["profit_quotes_up"], 1)
            self.assertEqual(n["profit_quotes_equal"], 1)
            self.assertEqual(n["viability_flips"], 1)
            self.assertEqual(n["mixed_stamp_revision"], 1)
            self.assertEqual(n["malformed"], 1)
            self.assertEqual(n["score_ratio_changed"], 1)
            self.assertEqual(len(report["warnings"]), 1)


if __name__ == "__main__":
    unittest.main()
