"""Summarise same-state C121 production-only replay, not realized profit.

The probe computes two financial quotations with fixed engine and fleet at the
same game date and with identical current geometry/service/competition, but
different source PASS/MAIL monthly production. The engine is never reselected.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

EVENT = "C121_PRODUCTION_ONLY_REPLAY"
TOKENS = re.compile(r"([a-z][a-z0-9_]*)=([^\s]+)")
AMOUNTS = ("oldprod_profit", "now_profit", "oldprod_revenue", "now_revenue",
           "oldprod_capital", "now_capital")
PHYSICAL = ("oldprod_carried_pax", "now_carried_pax",
            "oldprod_carried_mail", "now_carried_mail",
            "oldprod_cannibal", "now_cannibal")
FIELDS = ("key", "arm", "date", "engine", "planes", "changed", *AMOUNTS,
          *PHYSICAL, "oldprod_score", "now_score", "oldprod_viable", "now_viable")


def parse_line(line):
    p = line.find(EVENT)
    if p < 0 or (p > 0 and (line[p-1].isalnum() or line[p-1] == "_")):
        return None
    suffix = line[p + len(EVENT):]
    if suffix and (suffix[0].isalnum() or suffix[0] == "_"):
        return None
    return dict(TOKENS.findall(suffix))


def analyze(log_paths):
    out = {}
    all_counts = Counter()
    by_arm = Counter()
    warnings = []
    for path in log_paths:
        file = Path(path)
        cnt = Counter()
        changes = []
        examples = []
        try:
            content = file.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            warnings.append(f"{file}: {exc}")
            continue
        for line_number, line in enumerate(content.splitlines(), 1):
            values = parse_line(line)
            if values is None:
                continue
            status = values.get("status")
            if status == "control_mismatch":
                cnt["control_mismatch"] += 1
                continue
            if status != "compared":
                cnt["unrecognized_status"] += 1
                warnings.append(f"{file}:{line_number}: unknown status {status!r}")
                continue
            missing = [k for k in FIELDS if k not in values]
            if missing:
                cnt["malformed"] += 1
                warnings.append(f"{file}:{line_number}: missing {','.join(missing)}")
                continue
            try:
                old_profit = int(values["oldprod_profit"])
                new_profit = int(values["now_profit"])
                old_capital = int(values["oldprod_capital"])
                new_capital = int(values["now_capital"])
                old_revenue = int(values["oldprod_revenue"])
                new_revenue = int(values["now_revenue"])
                old_pax = int(values["oldprod_carried_pax"])
                new_pax = int(values["now_carried_pax"])
                old_mail = int(values["oldprod_carried_mail"])
                new_mail = int(values["now_carried_mail"])
                old_cannibal = int(values["oldprod_cannibal"])
                new_cannibal = int(values["now_cannibal"])
                old_viable = int(values["oldprod_viable"])
                new_viable = int(values["now_viable"])
                changed = int(values["changed"])
                old_score = float(values["oldprod_score"])
                new_score = float(values["now_score"])
            except ValueError as exc:
                cnt["malformed"] += 1
                warnings.append(f"{file}:{line_number}: {exc}")
                continue
            cnt["compared"] += 1
            if values["arm"] not in by_arm:
                by_arm[values["arm"]] = 0
            by_arm[values["arm"]] += 1
            change = new_profit - old_profit
            changes.append(change)
            if changed:
                cnt["quote_changed"] += 1
            else:
                cnt["quote_equal"] += 1
            if new_viable != old_viable:
                cnt["profit_sign_flip"] += 1
            if old_score != new_score:
                cnt["fixed_engine_score_changed"] += 1
            if new_capital != old_capital:
                cnt["capital_changed"] += 1
            if new_revenue != old_revenue:
                cnt["revenue_changed"] += 1
            if new_pax != old_pax or new_mail != old_mail:
                cnt["carried_changed"] += 1
            else:
                cnt["carried_unchanged"] += 1
            if new_cannibal != old_cannibal:
                cnt["cannibal_changed"] += 1
            if change > 0:
                cnt["profit_up_with_current_production"] += 1
            elif change < 0:
                cnt["profit_down_with_current_production"] += 1
            if len(examples) < 10:
                examples.append({
                    "key": values["key"], "date": values["date"], "arm": values["arm"],
                    "engine": values["engine"], "planes": values["planes"],
                    "profit_delta_current_minus_former_production": change,
                    "revenue_delta_current_minus_former_production": new_revenue-old_revenue,
                    "carried_pax_delta": new_pax-old_pax,
                    "carried_mail_delta": new_mail-old_mail,
                    "cannibal_loss_delta": new_cannibal-old_cannibal,
                    "old_score": old_score, "new_score": new_score,
                })
        all_counts.update(cnt)
        out[str(file)] = {
            "counts": dict(cnt),
            "mean_profit_delta": sum(changes)/len(changes) if changes else None,
            "examples": examples,
        }
    return {
        "status": "fixed_engine_same_state_physical_production_sensitivity",
        "limits": [
            "Former production means the last source production stored with the old C121 quote, reprojected using current coverage; no reconstruction of historical map.",
            "The engine, number of planes and current competition/rating/tariff remain fixed. A different chosen engine or portfolio rank is NOT inferred.",
            "Quote profit is predicted, not realized annual profit. Cash/constructibility unchanged by this passive probe.",
            "The probe executes two extra fixed-engine valuations and can perturb game time/opcode budgets; no policy-benefit estimate from its ON/OFF terminal profit.",
        ],
        "logs_read": len(out), "aggregate": dict(all_counts),
        "by_arm": dict(by_arm), "files": out, "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--logs", nargs="+", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.logs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print("logs", result["logs_read"], "compared", result["aggregate"].get("compared", 0),
          "control_mismatch", result["aggregate"].get("control_mismatch", 0),
          "quote_changed", result["aggregate"].get("quote_changed", 0),
          "warnings", len(result["warnings"]))


if __name__ == "__main__":
    main()
