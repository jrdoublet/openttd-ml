"""P0 AIR: contracts for observed-revenue calibration (Docker smoke compiles Squirrel)."""
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def code(filename):
    return (ROOT / filename).read_text(encoding="utf-8")


def stable_observations(observations):
    """Reference business rule: choose a factor only if LOO beats k=1."""
    valid = [(observed, predicted) for observed, predicted in observations
             if observed >= 0 and predicted > 0]
    if len(valid) < 2:
        return 1.0
    total_observed = sum(a for a, _ in valid)
    total_predicted = sum(b for _, b in valid)
    baseline = sum(abs(a - b) for a, b in valid)
    cross_validated = sum(abs(a - b * ((total_observed - a) / (total_predicted - b)))
                          for a, b in valid if total_predicted - b > 0)
    return total_observed / total_predicted if cross_validated < baseline else 1.0


class TestAirP0LearnedRevenue(unittest.TestCase):
    def test_toggle_off_and_loaded_once(self):
        info = code("info.nut")
        block = info.split('name = "air_p0_learned_revenue",')[1].split('});')[0]
        for difficulty in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertIn(f"{difficulty} = 0", block)
        self.assertIn("AIR_P0_LEARNED_REVENUE <- false;", code("globals_pre.nut"))
        self.assertEqual(code("settings.nut").count('AIController.GetSetting("air_p0_learned_revenue")'), 1)

    def test_unobserved_is_exactly_one(self):
        model = code("projects_models.nut")
        self.assertIn("local factor = 1.0;", model)
        self.assertIn("factor = OpexC121P0CrossValidatedFactor(acc);", model)
        self.assertIn("return crossValidatedError < rawError ? acc[0] / acc[2] : 1.0;", model)
        self.assertIn("return C121_AIR_REALIZATION_FACTOR[plan.arm];", model)
        self.assertIn("} else if (n >= C121_AIR_REALIZATION_MIN_LINES)", model)
        self.assertNotIn("1.0 / 3801", model)
        self.assertEqual(stable_observations([]), 1.0)
        self.assertEqual(stable_observations([(90, 100)]), 1.0)

    def test_leave_one_out_and_revenue_weighting(self):
        self.assertEqual(stable_observations([(80, 100), (60, 100)]), 0.7)
        self.assertEqual(stable_observations([(130, 100), (140, 100)]), 1.35)
        self.assertEqual(stable_observations([(80, 100), (120, 100)]), 1.0)
        self.assertEqual(stable_observations([(120, 100), (80, 100)]), 1.0)
        self.assertEqual(stable_observations([(100, 100), (100, 100)]), 1.0)
        self.assertEqual(stable_observations([(150, 100), (100, 100)]), 1.0)
        # A busy line contributes more expected revenue than a small one.
        observations = [(160, 200), (1500, 1000)]
        self.assertAlmostEqual(sum(x for x, _ in observations)
                               / sum(y for _, y in observations), 1660 / 1200)
        report = code("task_report.nut")
        self.assertIn("c121Age >= 2 && c121N0 > 0 && vehCount == c121N0", report)
        self.assertIn("line.c121P0ObservedYear <- year;", report)
        self.assertIn("OpexC121P0AddObservation(c121RealizationSums, line.c121Arm,", report)

    def test_no_double_revenue_and_profit_calibration(self):
        model = code("projects_models.nut")
        self.assertEqual(model.count('project.mode == "air" && OpexC121ProjectHasRealization(project, false)'), 2)
        self.assertEqual(model.count('project.payload.economics.realizationFactor != 1.0'), 2)
        self.assertIn("if (AIR_P0_LEARNED_REVENUE && C121_AIR_ECONOMICS) return 1.0;", model)
        econ = code("air_economics_c121.nut")
        self.assertIn("return totalIncomePerUnit; /* cold-start unitaire 1.0", econ)
        self.assertIn("OpexAirP0KnownMailShare(plane)", econ)
        self.assertIn("OpexAirP0KnownMailShare(line)", code("air_planning.nut"))

    def test_save_load_restores_only_observed_scalar_state(self):
        model = code("projects_models.nut")
        persist = code("persist.nut")
        self.assertIn('("c121P0ObservedYear" in line) && line.c121P0ObservedYear >= year - 1', model)
        self.assertIn('("c121P0ObservedRevenue" in line) && ("c121P0ObservedPred" in line)', model)
        self.assertIn("OpexC121RecomputeRealizationFactors(this._lines)", persist)
        self.assertIn('key == "c121PaxCapacity" || key == "c121MailCapacity"', persist)

    def test_fleet_epoch_requotes_actual_n_and_preserves_complete_year(self):
        fleet = code("air_fleet.nut")
        catalog = code("air_catalog_c121.nut")
        report = code("task_report.nut")
        air_task = code("task_air.nut")
        self.assertIn("function OpexC121P0CaptureFleetEpoch(catalog, line, lines)", fleet)
        self.assertIn("OpexC121P0InvalidateFleetEpoch(line);", fleet)
        self.assertIn("OpexC121AirEconomics(catalog, quote, plane, pax, mail, have);", fleet)
        self.assertIn("line.c121P0EpochRawRevenue <- physical.rawRevenueAnnual;", fleet)
        self.assertIn("OpexC121P0CaptureFleetEpoch(catalog, line, lines);", fleet)
        self.assertIn("OpexC121P0CaptureFleetEpoch(this._catalog, line, this._lines);", air_task)
        self.assertIn("line.c121P0EpochRawRevenue <- actual.rawRevenueAnnual;", catalog)
        self.assertIn("year - line.c121P0EpochYear < 2", report)
        self.assertIn("OpexC121P0FleetEpochMatches(line, this._catalog, vehicles, vehCount)", report)
        self.assertIn("AIVehicle.GetCapacity(v, catalog.paxCargo)", report)
        self.assertIn("AIVehicle.GetCapacity(v, catalog.mailCargo)", report)
        # GetProfitLastYear lags the fleet change: Y+1 is mixed; Y+2 is the
        # earliest calendar-year report with a complete post-change year.
        event_year = 1973
        self.assertFalse(1974 - event_year >= 2)
        self.assertTrue(1975 - event_year >= 2)

    def test_epoch_invalidates_old_observations_and_survives_save(self):
        fleet = code("air_fleet.nut")
        for key in ("c121P0ObservedYear", "c121P0ObservedRevenue",
                    "c121P0ObservedPred", "c121P0EpochYear",
                    "c121P0EpochRawRevenue"):
            self.assertIn(f'"{key}"', fleet)
        persist = code("persist.nut")
        self.assertNotIn("c121P0EpochRawRevenue = true", persist)
        self.assertNotIn("c121P0EpochYear = true", persist)
        self.assertIn("OpexC121RecomputeRealizationFactors(this._lines)", persist)
        # No vehicle change in OFF: the expensive recapture call is inert.
        self.assertIn("if (!AIR_P0_LEARNED_REVENUE || !C121_AIR_ECONOMICS", fleet)


if __name__ == "__main__":
    unittest.main()
