"""Contrats structurels d'une sonde P0 sans effet au defaut.

Ne compile pas Squirrel : smoke moteur requis en sus.
"""
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1] / "ai" / "OpexAI"


def source(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


class RailReadyAdmissionShadowContracts(unittest.TestCase):
    def test_off_default_every_difficulty(self):
        glob = source("globals_pre.nut")
        info = source("info.nut")
        settings = source("settings.nut")
        self.assertIn("RAIL_READY_ADMISSION_SHADOW <- false;", glob)
        self.assertEqual(info.count('name = "rail_ready_admission_shadow"'), 1)
        stanza = info.split('name = "rail_ready_admission_shadow"', 1)[1].split("});", 1)[0]
        for field in ("easy_value", "medium_value", "hard_value", "custom_value"):
            self.assertRegex(stanza, rf"\b{field}\s*=\s*0\b")
        self.assertIn('RAIL_READY_ADMISSION_SHADOW = AIController.GetSetting("rail_ready_admission_shadow") != 0;', settings)

    def test_shadow_does_not_drive_behavior(self):
        task = source("task_projects.nut")
        rail = source("task_rail.nut")
        self.assertIn("function OpexAI::_railReadyAdmissionShadow(deferred)", task)
        self.assertIn("RAIL_READY_ADMISSION phase=after", task)
        self.assertIn('"isC121RailPrep" in this._railSearch', task)
        self.assertIn("if (auditReady) {", task)
        self.assertIn("RAIL_READY_UPGRADE phase=start", rail)
        self.assertIn("RAIL_READY_UPGRADE phase=end", rail)
        # Instrumentation must neither suppress the historical ready build
        # nor branch into a second, more expensive selection.
        self.assertIn("local railBuilt = this._consumeResumableRailAtPassStart", task)
        helper = task.split("function OpexAI::_railReadyAdmissionShadow(deferred)", 1)[1].split(
            "/* Diagnostics communs", 1
        )[0]
        self.assertNotIn("OpexProjectSelectAffordable(", helper)
        self.assertNotIn("OpexBuild", helper)
        self.assertNotIn("_railSearch = null", helper)

    def test_slot_and_result_linked_by_search_tick(self):
        task = source("task_projects.nut")
        self.assertIn('" phase=before search_tick="', task)
        self.assertIn('" RAIL_READY_ADMISSION phase=after search_tick="', task)
        self.assertIn('" c77_defer=" + (deferred ? 1 : 0)', task)
        self.assertIn('" ahead_affordable=" + aheadAffordable', task)
        self.assertIn('" rank=" + rank + " score=" + score', task)


if __name__ == "__main__":
    unittest.main()
