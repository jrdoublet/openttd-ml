"""Tests des décompositions passives de risques AIR (sans moteur)."""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from analyse_air_site_residual import analyze_files, analyze_records, year_of
from parse_air_finance_margin import parse_log_stream


def fixture(arm):
    body = """
AIR_FINANCE_TRY date=1970-03-01 rank=0 src_town=1 dst_town=2 new_airports=2 margin=30000 reserve=5000 capital=42000 need=77000 cash=76000 outcome=refused_margin path=portfolio
AIR_FINANCE_TRY date=1970-03-02 rank=0 src_town=1 dst_town=2 new_airports=2 margin=30000 reserve=5000 capital=42000 need=77000 cash=76000 outcome=refused_margin path=portfolio
AIR_FINANCE_TRY date=1970-04-03 rank=0 src_town=1 dst_town=3 new_airports=2 margin=2000 reserve=5000 capital=60000 need=67000 cash=80000 outcome=built path=portfolio planned=60000 actual=58000 reason=OK line=3 quoted=1 v126=1 quote_a=3000 quote_b=2000 quote_fail=0 stops_model=9000 site_cost=37400 extra=14000 margin_legacy=30000 margin_v126=2000 airport_price=16200 c_level_a=3000 c_level_b=2000 c_airport_a=16500 c_airport_b=16500 c_planes=20000 c_stops=0
AIR_FINANCE_TRY date=1971-05-01 rank=0 src_town=1 dst_town=4 new_airports=1 margin=12000 reserve=5000 capital=22000 need=39000 cash=80000 outcome=failed path=portfolio planned=22000 actual=5000 reason=BFAIL line=4 quoted=1 v126=0 quote_a=2000 quote_b=-2 quote_fail=0 stops_model=4500 site_cost=18200 extra=0 margin_legacy=12000 margin_v126=2000 airport_price=16200 c_level_a=3000 c_level_b=0 c_airport_a=2000 c_airport_b=0 c_planes=0 c_stops=0
AIR_FINANCE_FIRST_REVENUE line=3 build_date=1970-04-03 first_date=1970-06-01 days=60 cash_min=4000 reserve=5000 new_airports=2
"""
    return parse_log_stream(body.splitlines(), seed=42, arm=arm, filename=f"{arm}_seed42_r0.log")


class AirResidualBreakdownTest(unittest.TestCase):
    def test_year_disambiguates_unknown_dates(self):
        self.assertEqual(year_of("1970-1-3"), 1970)
        self.assertIsNone(year_of("bad"))
        self.assertIsNone(year_of(None))

    def test_repeated_refusals_arent_distinct_projects(self):
        rows = analyze_records(fixture("reference"))
        year70two = next(r for r in rows if r["year"] == 1970 and r["new_airports"] == 2)
        self.assertEqual(year70two["attempt_events"], 3)
        self.assertEqual(year70two["refusal_events"], 2)
        self.assertEqual(year70two["unique_town_pairs_seen"], 2)
        self.assertEqual(year70two["built"], 1)
        self.assertEqual(year70two["built_residual_gbp"]["count"], 1)
        self.assertEqual(year70two["built_residual_gbp"]["median"], -2000)
        self.assertEqual(year70two["cash_breaches"], 1)
        self.assertEqual(year70two["cash_reserve_observed"], 1)
        year71one = next(r for r in rows if r["year"] == 1971 and r["new_airports"] == 1)
        self.assertEqual(year71one["failed"], 1)
        self.assertEqual(year71one["failed_cost_accounted_gbp"], 5000)
        self.assertEqual(year71one["failed_quote_count"], 1)
        self.assertEqual(year71one["built_residual_gbp"]["count"], 0)

    def test_analyzer_keeps_arms_with_same_seed_separate(self):
        with tempfile.TemporaryDirectory() as dirpath:
            folder = Path(dirpath)
            event = "AIR_FINANCE_TRY date=1970-03-01 new_airports=2 outcome=refused_margin\n"
            (folder / "reference_seed42_r0.log").write_text(event, encoding="utf-8")
            (folder / "variant_seed42_r0.log").write_text(event.replace("refused_margin", "built"), encoding="utf-8")
            result = analyze_files(folder.glob("*.log"))
            self.assertEqual(len(result["runs"]), 2)
            self.assertEqual({r["arm"] for r in result["runs"]}, {"reference", "variant"})
            self.assertEqual(sum(r["year_airports"][0]["built"] for r in result["runs"]), 1)

    def test_opcode_scan_is_labeled_descriptive(self):
        with tempfile.TemporaryDirectory() as dirpath:
            log = Path(dirpath) / "reference_seed42_r0.log"
            log.write_text("AIR_PLAN_PERF: total_ops=100 c121_static_ops=20 c121_calls=2\n", encoding="utf-8")
            result = analyze_files([log])["runs"][0]
            self.assertEqual(result["perf_scans_count"], 1)
            self.assertEqual(result["perf_first_scan"]["c121_static_ops"], 20)
            self.assertEqual(result["perf_scan_sums"]["total_ops"], 100)


if __name__ == "__main__":
    unittest.main()
