"""Vérifications des extracteurs propres à l'autopsie, sans moteur."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("autopsy", Path(__file__).with_name("analyse.py"))
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class ExtractionTests(unittest.TestCase):
    def test_missing_is_not_zero(self):
        paired = {"1970-01-01": [{"money": None}, {"money": 4}]}
        self.assertIsNone(a.first_month_difference(paired, "money"))
        self.assertIsNone(a.delta(None, 4))

    def test_full_annual_coverage(self):
        paired = {"1970-04-01": [{"profit_year": 10, "profit_year_quarters_valid": 1}, {"profit_year": 20, "profit_year_quarters_valid": 1}],
                  "1971-02-01": [{"profit_year": 30, "profit_year_quarters_valid": 4}, {"profit_year": 40, "profit_year_quarters_valid": 4}]}
        self.assertEqual(a.first_month_difference(paired, "profit_year", True)["date"], "1971-02-01")

    def test_company_namespace_and_date_bounds(self):
        content = "[2000-01-01 00:00:00] [0] [I] C121_GE date=1970-07-07\n[1] [I] OPEX 1971-01-01 C121_BUILD town_a=0\n[0] [I] C121_BUILD town_a=2 town_b=3\n[0] [I] OPEX 1970-7-11 C83_REACTION\n"
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "log"
            path.write_text(content, encoding="utf-8")
            old = a.ROOT
            try:
                a.ROOT = Path(tmp)
                result = a.parse_log(path)
            finally:
                a.ROOT = old
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(result["events"][0]["prior_anchor"]["date"], "1970-07-07")
        self.assertEqual(result["events"][0]["next_anchor"]["date"], "1970-07-11")

    def test_market_aggregation_and_decomposition(self):
        lines = [{"mode": "air", "market_key": "air|1|2", "vehicles": 1, "profit_this_year_gbp": 12},
                 {"mode": "air", "market_key": "air|1|2", "vehicles": 2, "profit_this_year_gbp": 20}]
        self.assertEqual(a.air_markets(lines)["air|1|2"], {"lines": 2, "vehicles": 3, "profit": 32})

    def test_identity_separate_from_quote(self):
        left = [{"fields": {"town_a": "1", "town_b": "2", "decision_profit": "20"}}]
        right = [{"fields": {"town_a": "1", "town_b": "2", "decision_profit": "21"}}]
        self.assertIsNone(a.first_event_difference(left, right, a.IDENTITY))
        self.assertEqual(a.first_event_difference(left, right, a.ECONOMICS)["ordinal"], 1)

if __name__ == "__main__":
    unittest.main()
