"""Complément de chronologie brute et contrôle final de préservation."""
import bisect
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("autopsy", HERE / "analyse.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
data = json.loads((HERE / "analysis.json").read_text(encoding="utf-8"))
result = {}
owner = re.compile(r"\[0\]\s+\[[IWE]\]\s*(.*)")
for seed in a.FOCUS:
    records, anchors = {}, {}
    for policy in a.POLICIES:
        path = a.ARCHIVE / (a.STEM + "_engine") / f"{policy}_seed{seed}_r0.log"
        records[policy], anchors[policy] = [], []
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            m = owner.search(line)
            if not m:
                continue
            records[policy].append({"log_line": number, "text": m[1]})
            date = a.GAME_DATE.search(line)
            if date:
                anchors[policy].append({"log_line": number, "date": a.iso(date[1] or date[2]), "text": m[1]})
    index = next(i for i, (x, y) in enumerate(zip(*(records[p] for p in a.POLICIES))) if x["text"] != y["text"])
    first = {"opex_record_ordinal": index + 1}
    for policy in a.POLICIES:
        r = records[policy][index].copy()
        j = bisect.bisect_left([v["log_line"] for v in anchors[policy]], r["log_line"])
        r["prior_anchor"] = anchors[policy][j - 1] if j else None
        r["next_anchor"] = anchors[policy][j] if j < len(anchors[policy]) else None
        first[policy] = r
    identity = data["focus"][str(seed)]["first_build_identity"]
    matches = {}
    for policy, other, event_key in (("reference", "rail_ready_readmission", "reference"), ("rail_ready_readmission", "reference", "variant")):
        event = identity[event_key]
        fields = event["fields"]
        od = tuple(sorted((fields["town_a"], fields["town_b"])))
        found = []
        for ordinal, event_other in enumerate(data["focus"][str(seed)]["logs"][other]["events"], 1):
            f = event_other["fields"]
            if tuple(sorted((f["town_a"], f["town_b"]))) == od:
                found.append({"ordinal": ordinal, "log_line": event_other["log_line"], "prior_anchor": event_other["prior_anchor"], "next_anchor": event_other["next_anchor"]})
        matches[policy] = {"town_pair": od, "found_in_other_policy": found}
    result[str(seed)] = {"first_opex_log_difference": first, "first_different_market_other_arm": matches}
a.dump("first_log_differences.json", result)
before = json.loads((HERE / "production_before.json").read_text(encoding="utf-8"))
now = a.worktree()
inputs = json.loads((HERE / "inputs_before.json").read_text(encoding="utf-8"))
inputs_unchanged = all(a.digest(a.ROOT / path) == h for path, h in inputs["files"].items())
# Recheck the saved bundle's exact files without changing import paths or source files.
bundle_unchanged = all(a.digest(a.BUNDLE / r["path"]) == r["sha256"] for r in inputs["bundle"]["files"])
assert before == now and inputs_unchanged and bundle_unchanged
a.dump("final_verification.json", {"production_files": len(before["files"]), "worktree_unchanged": before == now,
                                  "historical_files_unchanged": inputs_unchanged, "bundle_files_unchanged": bundle_unchanged,
                                  "bundle_sha256": a.EXPECTED})
print(json.dumps(result, ensure_ascii=False, indent=2))
