"""Autopsie descriptive hors ligne; ne lance aucun moteur ni ne change de politique."""
from __future__ import annotations
import bisect
import collections
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "results/rail_ready_readmission_A2"
STEM = "rail_ready_readmission_diag_40x5_20261010_r1"
BUNDLE = ARCHIVE / (STEM + "_bundle")
FOCUS = (746035, 424242, 8191)
POLICIES = ("reference", "rail_ready_readmission")
EXPECTED = "250223deaebfb849cde5717888fd2b16942de22798c1385158d4a5ad51757ff8"
FIELDS = re.compile(r"([a-z][a-z_0-9]*)=([^\s]+)")
GAME_DATE = re.compile(r"(?:OPEX\s+(\d{4}-\d{1,2}-\d{1,2})\s|C121_GE\b.*\bdate=(\d{4}-\d{1,2}-\d{1,2}))")
IDENTITY = ("arm", "engine", "town_a", "town_b", "station_id_a", "station_id_b", "actual_n")
ECONOMICS = IDENTITY + ("decision_n", "decision_profit", "decision_capital", "decision_kdec")
MONTH_METRICS = ("profit_year", "company_value", "money", "current_loan", "air_primary_vehicles", "air_airports", "airport_slots_opex", "airport_towns_opex_present", "primary_vehicles_by_mode", "rail_attempt_sign_or", "rail_attempt_sign_ob")

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def worktree():
    def git(*args):
        return subprocess.check_output(["rtk", "proxy", "git", *args], cwd=ROOT)
    paths = git("ls-files", "-z", "--cached", "--others", "--exclude-standard").decode("utf-8").split("\0")
    return {"head": git("rev-parse", "HEAD").decode().strip(), "status": git("status", "--porcelain=v1", "-z").decode(),
            "files": {p: digest(ROOT / p) if (ROOT / p).is_file() else None for p in sorted(set(paths)) if p}}

def csv_write(name, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with (OUT / name).open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list, tuple)) else v for k, v in r.items()} for r in rows)

def iso(value):
    return dt.date(*(int(x) for x in value.split("-"))).isoformat()

def parse_log(path):
    anchors, events = [], []
    counts = collections.Counter()
    for number, line in enumerate(path.read_text(encoding="utf-8", errors="strict").splitlines(), 1):
        if not re.search(r"\[0\]\s+\[[IWE]\]", line):
            continue
        m = GAME_DATE.search(line)
        if m:
            anchors.append({"log_line": number, "date": iso(m[1] or m[2]), "text": line})
        for name in ("RAIL_READY_READMISSION", "RAIL_READY_ADMISSION", "C83_REACTION", "C121_BUILD", "FLEET_PROJECT"):
            if name in line:
                counts[name] += 1
        if "C121_BUILD " in line:
            events.append({"log_line": number, "fields": dict(FIELDS.findall(line))})
    indexes = [a["log_line"] for a in anchors]
    for event in events:
        i = bisect.bisect_left(indexes, event["log_line"])
        event["prior_anchor"] = anchors[i - 1] if i else None
        event["next_anchor"] = anchors[i] if i < len(anchors) else None
        if event["prior_anchor"] and event["next_anchor"]:
            if event["prior_anchor"]["date"] > event["next_anchor"]["date"]:
                raise ValueError(f"non-monotonic date bound: {path}:{event['log_line']}")
    return {"path": str(path.relative_to(ROOT)), "counts": dict(counts), "events": events}

def first_event_difference(left, right, keys):
    for ordinal, (a, b) in enumerate(zip(left, right), 1):
        changed = {k: {"reference": a["fields"].get(k), "variant": b["fields"].get(k)}
                   for k in keys if a["fields"].get(k) != b["fields"].get(k)}
        if changed:
            return {"ordinal": ordinal, "changed": changed, "reference": a, "variant": b}
    if len(left) != len(right):
        return {"ordinal": min(len(left), len(right)) + 1, "unmatched_tail": True}
    return None

def delta(a, b):
    return b - a if isinstance(a, (int, float)) and isinstance(b, (int, float)) else None

def first_month_difference(paired, metric, full_profit=False):
    for date, (a, b) in sorted(paired.items()):
        if full_profit and any(r.get("profit_year_quarters_valid") != 4 for r in (a, b)):
            continue
        av, bv = a.get(metric), b.get(metric)
        # Missing is unknown, never zero or an observed economic difference.
        if av is not None and bv is not None and av != bv:
            return {"date": date, "reference": av, "variant": bv, "delta": delta(av, bv),
                    "profit_coverage_reference": a.get("profit_year_coverage"), "profit_coverage_variant": b.get("profit_year_coverage")}
    return None

def mode_totals(lines, mode):
    group = [l for l in lines if l["mode"] == mode]
    result = {"lines": len(group)}
    for key in ("vehicles", "profit_this_year_gbp", "profit_last_year_gbp"):
        values = [l.get(key) for l in group]
        result[key] = sum(values) if all(v is not None for v in values) else None
    return result

def air_markets(lines):
    markets = collections.defaultdict(list)
    for line in lines:
        if line["mode"] == "air":
            markets[line["market_key"]].append(line)
    return {key: {"lines": len(group), "vehicles": sum(l["vehicles"] for l in group),
                  "profit": sum(l["profit_this_year_gbp"] for l in group)} for key, group in markets.items()}

def main():
    if (OUT / "analysis.json").exists():
        raise FileExistsError("Sortie déjà produite; choisir un dossier neuf pour une nouvelle analyse.")
    before = worktree()
    dump("production_before.json", before)
    # Use the tested harness helper, not a new bundle hash convention.
    sys.path.insert(0, str(BUNDLE / "harness/sweeps"))
    from campaign_freeze import fingerprint_tree
    frozen = fingerprint_tree(BUNDLE)
    assert frozen["sha256"] == EXPECTED, frozen["sha256"]
    input_paths = [ARCHIVE / (STEM + ext) for ext in (".json", ".jsonl", ".manifest.json")]
    input_paths += sorted((ARCHIVE / (STEM + "_engine")).glob("*.log"))
    input_before = {str(p.relative_to(ROOT)): digest(p) for p in input_paths}
    dump("inputs_before.json", {"bundle": frozen, "files": input_before})
    data = json.loads(input_paths[0].read_text(encoding="utf-8"))
    manifest = json.loads(input_paths[2].read_text(encoding="utf-8"))
    checkpoints = {}
    count = 0
    with input_paths[1].open(encoding="utf-8") as f:
        for number, raw in enumerate(f, 1):
            r = json.loads(raw)
            if r["run"][0] != "OpexAI":
                continue
            if r.get("source_bundle_sha256") != EXPECTED:
                raise ValueError("Unexpected source hash")
            key = (int(r["run"][1]), r["duel_policy_id"], int(r["run"][2]), r["date"])
            if key in checkpoints:
                raise ValueError(f"duplicate checkpoint: {key}")
            checkpoints[key] = r
            count += 1
    annual = {(r["seed"], r["duel_policy_id"], r["year"]): r for r in data["line_telemetry"]["snapshots"] if r["arm"] == "OpexAI"}
    focused, cohort, monthly_table, annual_table, rail_signs, build_table = {}, [], [], [], [], []
    for seed in data["seeds"]:
        dates = sorted({k[3] for k in checkpoints if k[0] == seed})
        paired = {}
        for date in dates:
            pair = [checkpoints.get((seed, p, 0, date)) for p in POLICIES]
            if any(r is None for r in pair):
                raise ValueError(f"missing paired month: {seed}/{date}")
            paired[date] = pair
        first = {metric: first_month_difference(paired, metric) for metric in MONTH_METRICS}
        first["profit_year_full_four_quarters"] = first_month_difference(paired, "profit_year", True)
        cohort.append({"seed": seed, **{metric: event["date"] if event else None for metric, event in first.items()}})
        logs = {p: parse_log(ARCHIVE / (STEM + "_engine") / f"{p}_seed{seed}_r0.log") for p in POLICIES}
        economic = first_event_difference(logs[POLICIES[0]]["events"], logs[POLICIES[1]]["events"], ECONOMICS)
        identity = first_event_difference(logs[POLICIES[0]]["events"], logs[POLICIES[1]]["events"], IDENTITY)
        # A paired ordinal is only a common prefix comparison, not a causal match after divergence.
        cohort[-1]["first_build_economic"] = economic
        cohort[-1]["first_build_identity"] = identity
        if seed not in FOCUS:
            continue
        pair_report = next(r for r in data["policy_comparison"]["per_pair"] if r["seed"] == seed)
        focused[str(seed)] = {"first_month_differences": first, "first_build_economic": economic,
                              "first_build_identity": identity, "logs": logs, "terminal_metrics": pair_report["metrics"], "annual": []}
        for date, (a, b) in paired.items():
            row = {"seed": seed, "date": date}
            for metric in MONTH_METRICS:
                row[metric + "_reference"] = a.get(metric)
                row[metric + "_variant"] = b.get(metric)
                row[metric + "_delta"] = delta(a.get(metric), b.get(metric))
            row["profit_valid_quarters_reference"] = a.get("profit_year_quarters_valid")
            row["profit_valid_quarters_variant"] = b.get("profit_year_quarters_valid")
            monthly_table.append(row)
        for p, log in logs.items():
            for ordinal, event in enumerate(log["events"], 1):
                build_table.append({"seed": seed, "policy": p, "ordinal": ordinal, "log_line": event["log_line"],
                                    "date_lower": event["prior_anchor"]["date"] if event["prior_anchor"] else None,
                                    "date_upper": event["next_anchor"]["date"] if event["next_anchor"] else None,
                                    **{k: event["fields"].get(k) for k in ECONOMICS}})
            seen = set()
            for date in dates:
                r = checkpoints[(seed, p, 0, date)]
                for family in ("OR", "OB"):
                    for sign in r.get("rail_attempt_sign_" + family.lower(), []):
                        # Retained signs can disappear; exact-content dedup, no claim of full event coverage.
                        key = (family, json.dumps(sign, sort_keys=True))
                        if key not in seen:
                            seen.add(key)
                            rail_signs.append({"seed": seed, "policy": p, "family": family, "first_seen": date, **sign})
        for year in range(1970, 1975):
            aa, bb = (annual[(seed, p, year)] for p in POLICIES)
            assert aa["ok"] and bb["ok"]
            row = {"seed": seed, "year": year}
            for mode in ("air", "rail", "road"):
                ma, mb = mode_totals(aa["lines"], mode), mode_totals(bb["lines"], mode)
                for metric in ma:
                    row[f"{mode}_{metric}_reference"] = ma[metric]
                    row[f"{mode}_{metric}_variant"] = mb[metric]
                    row[f"{mode}_{metric}_delta"] = delta(ma[metric], mb[metric])
            am, bm = air_markets(aa["lines"]), air_markets(bb["lines"])
            common, lost, new = set(am) & set(bm), set(am) - set(bm), set(bm) - set(am)
            row.update(common_air_markets=len(common), lost_air_markets=len(lost), new_air_markets=len(new),
                       common_air_profit_delta=sum(bm[k]["profit"] - am[k]["profit"] for k in common),
                       lost_air_profit=sum(am[k]["profit"] for k in lost), new_air_profit=sum(bm[k]["profit"] for k in new))
            assert math.isclose(row["common_air_profit_delta"] - row["lost_air_profit"] + row["new_air_profit"], row["air_profit_this_year_gbp_delta"], abs_tol=1e-6), row
            focused[str(seed)]["annual"].append(row)
            annual_table.append(row)
    dump("analysis.json", {"campaign": data["campaign_id"], "source_bundle_sha256": EXPECTED,
                           "comparison": {k: v for k, v in data["policy_comparison"].items() if k != "per_pair"},
                           "checkpoint_count": count, "policies": manifest["policies"],
                           "focus": focused, "all_seeds_first_divergences": cohort,
                           "limits": ["dates C121_BUILD encadrées par événements Opex datés, pas timestamps exacts",
                                      "signes rail conservés seulement; OB non assimilable à CPU A* pur",
                                      "profits des véhicules distincts du profit annuel compagnie",
                                      "coût opcode global et visites de réadmission absents"]})
    csv_write("monthly.csv", monthly_table)
    csv_write("annual_modes.csv", annual_table)
    csv_write("rail_retained_signs.csv", rail_signs)
    csv_write("air_builds.csv", build_table)
    csv_write("all_seeds_first_month.csv", [{k: v for k, v in row.items() if not k.startswith("first_build")} for row in cohort])
    after = worktree()
    input_after = {str(p.relative_to(ROOT)): digest(p) for p in input_paths}
    frozen_after = fingerprint_tree(BUNDLE)
    verification = {"production_file_count": len(before["files"]), "worktree_unchanged": before == after,
                    "historical_files_unchanged": input_before == input_after, "historical_file_count": len(input_paths),
                    "bundle_unchanged": frozen == frozen_after, "bundle_sha256": frozen_after["sha256"]}
    dump("verification.json", verification)
    assert all(verification[k] for k in ("worktree_unchanged", "historical_files_unchanged", "bundle_unchanged"))
    print(json.dumps(verification, ensure_ascii=False))

if __name__ == "__main__":
    main()
