"""Create a unique test-only snapshot; never edit production or old bundles."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import difflib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SNAP = BASE / "snapshot"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replace_once(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new, 1)

def main():
    assert not SNAP.exists(), "never overwrite a snapshot"
    status = subprocess.check_output(["git", "status", "--porcelain=v1", "-uall"], cwd=ROOT).decode("utf-8")
    names = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=ROOT).decode("utf-8").split("\0")
    hashes = {name: sha(ROOT / name) for name in names if name and (ROOT / name).is_file() and not name.startswith("results/")}
    (BASE / "production_before.json").write_text(json.dumps({"status": status, "hashes": hashes}, indent=2), encoding="utf-8")
    SNAP.mkdir()
    for name in ("OpexAI", "AAAHogEx-115"):
        shutil.copytree(ROOT / "ai" / name, SNAP / "ai" / name)
    shutil.copytree(ROOT / "sweeps", SNAP / "sweeps", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ("Dockerfile", "requirements.txt", "requirements-ml.txt"):
        shutil.copy2(ROOT / name, SNAP / name)

    path = SNAP / "ai/OpexAI/task_projects.nut"
    original = path.read_text(encoding="utf-8")
    text = original
    # Transient telemetry only: no state read by selection or persistence.
    helpers = '''
RRM_CONTEXT <- -1;
function OpexRRMFields(project)
{
  return " key=" + OpexProjectAttemptKey(project) + " mode=" + project.mode
      + " profit_raw=" + project.profitAnnual
      + " profit_cal=" + OpexProjectFundProfit(project)
      + " capital=" + (("capital" in project) ? project.capital : -1)
      + " budget_capital=" + project.budgetCapital
      + " finance=" + OpexProjectFinanceCapital(project)
      + " decision_finance=" + (("decisionFinanceCapital" in project) ? project.decisionFinanceCapital : -1)
      + " fund_score=" + (("fundScore" in project) ? project.fundScore : -1)
      + " selection_score=" + (("fundScore" in project) ? OpexProjectSelectionScore(project, "fundScore") : -1)
      + " tier=" + OpexProjectDefensiveAirPriority(project)
      + " expected_ops=" + (("expectedOpcodes" in project) ? project.expectedOpcodes : -1)
      + " planning_ops=" + (("planningOpcodes" in project) ? project.planningOpcodes : -1)
      + " economics_date=" + (("economicsDate" in project) ? project.economicsDate : -1);
}
function OpexRRMEnd(mark, phase)
{
  local ops = OpexOpsMeasureEnd(mark);
  local ticks = AIController.GetTick() - mark.tick;
  AILog.Info("RRM_COST phase=" + phase + " date=" + AIDate.GetCurrentDate()
      + " search_tick=" + RRM_CONTEXT + " ops=" + ops + " ticks=" + ticks);
}
function OpexRRMActual(project, rank, attempt)
{
  local mark = OpexOpsMeasureBegin();
  local reason = attempt.outcome;
  if (("reason" in attempt)) reason = attempt.reason;
  if (("discards" in attempt) && attempt.discards != null && attempt.discards.len() > 0) {
    local last = attempt.discards[attempt.discards.len() - 1];
    if (last != null && ("rank" in last) && last.rank == rank
        && ("mode" in last) && last.mode == project.mode && ("reason" in last)) reason = last.reason;
  }
  AILog.Info("RRM_ACTUAL search_tick=" + RRM_CONTEXT + " date=" + AIDate.GetCurrentDate()
      + " tick=" + AIController.GetTick() + " rank=" + rank
      + " outcome=" + attempt.outcome + " reason=" + reason + OpexRRMFields(project));
  OpexRRMEnd(mark, "actual");
}
'''
    text = replace_once(text, "function OpexAI::_railReadyAdmissionShadow(deferred)", helpers + "\nfunction OpexAI::_railReadyAdmissionShadow(deferred)")
    text = replace_once(text, "  local state = this._railSearch;\n  local candidate = state.candidate;\n  local key = \"rail|\"", "  local rrmMark = OpexOpsMeasureBegin();\n  local state = this._railSearch;\n  RRM_CONTEXT = (\"startTick\" in state) ? state.startTick : -1;\n  local rrmRail = null;\n  local rrmFirst = null;\n  local candidate = state.candidate;\n  local key = \"rail|\"")
    text = replace_once(text, "        rank = i;\n        score =", "        rrmRail = project;\n        rank = i;\n        score =")
    text = replace_once(text, "        firstRank = i;\n        firstMode =", "        rrmFirst = project;\n        firstRank = i;\n        firstMode =")
    tail = '''
  local kData = this._projects != null && ("c69KDecData" in this._projects)
      ? this._projects.c69KDecData : null;
  AILog.Info("RRM_STATE search_tick=" + RRM_CONTEXT + " date=" + date
      + " tick=" + AIController.GetTick() + " available=" + available
      + " k_dec=" + (kData != null && ("K_dec" in kData) ? kData.K_dec : -1)
      + " cached_tpd=" + TENSION_TICKS_PER_DAY + " defer=" + (deferred ? 1 : 0));
  if (rrmRail != null) AILog.Info("RRM_CAND search_tick=" + RRM_CONTEXT
      + " date=" + date + " role=ready rank=" + rank + OpexRRMFields(rrmRail));
  else AILog.Info("RRM_MISSING search_tick=" + RRM_CONTEXT + " date=" + date
      + " key=" + key + " profit_raw=" + (("profitAnnual" in candidate) ? candidate.profitAnnual : -1)
      + " capital=" + (("capital" in candidate) ? candidate.capital : -1));
  if (rrmFirst != null) AILog.Info("RRM_CAND search_tick=" + RRM_CONTEXT
      + " date=" + date + " role=first rank=" + firstRank + OpexRRMFields(rrmFirst));
  OpexRRMEnd(rrmMark, "ready");
'''
    text = replace_once(text, '+ " c77_defer=" + (deferred ? 1 : 0));\n}', '+ " c77_defer=" + (deferred ? 1 : 0));\n' + tail + '}')
    text = replace_once(text, "function OpexAI::_tryBuildProjects(year)\n{", "function OpexAI::_tryBuildProjects(year)\n{\n  if (RAIL_READY_ADMISSION_SHADOW) RRM_CONTEXT = -1;")
    # Dispatch return is recorded only in the pass that observed a ready primary.
    for mode, call in (
        ("fleet", "this._tryBuildFleetProject(year, project, i, passDiscards);"),
        ("air", "this._tryBuildAirProject(year, project, i, liveBuiltCount, passDiscards,\n                                                anchor, yy);"),
        ("road", "this._tryBuildRoadProject(year, project, i, passDiscards, anchor, yy);"),
        ("rail", "this._tryBuildRailProject(year, project, i, liveBuiltCount, passDiscards,\n                                                 anchor, yy);"),
        ("water", "this._tryBuildWaterProject(year, project, i, liveBuiltCount, passDiscards,\n                                                  anchor, yy);"),
    ):
        old = "local attempt = " + call
        text = replace_once(text, old, old + "\n      if (RAIL_READY_ADMISSION_SHADOW && RRM_CONTEXT >= 0) OpexRRMActual(project, i, attempt);")
    # Outcome copied before any state cleanup; no rail result is changed.
    text = replace_once(text, "  local outcome = railResult.outcome;", '''  local outcome = railResult.outcome;
  if (RAIL_READY_ADMISSION_SHADOW && RRM_CONTEXT >= 0) {
    local rrmMark = OpexOpsMeasureBegin();
    AILog.Info("RRM_READY_RESULT search_tick=" + RRM_CONTEXT + " date=" + AIDate.GetCurrentDate()
        + " tick=" + AIController.GetTick() + " outcome=" + outcome
        + " reason=" + (("reason" in railResult) ? railResult.reason : "unknown")
        + " error=" + (("error" in railResult) ? railResult.error : -1));
    OpexRRMEnd(rrmMark, "result");
  }''')
    path.write_text(text, encoding="utf-8", newline="\n")
    (BASE / "snapshot_probe.patch").write_text("".join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile="production/task_projects.nut", tofile="snapshot/task_projects.nut")), encoding="utf-8")
    # Common metadata on a log ALREADY emitted in both arms: no new event,
    # no second model and no changed selection. This shared modification is explicit.
    air = SNAP / "ai/OpexAI/air_catalog_c121.nut"
    a0 = air.read_text(encoding="utf-8")
    a1 = replace_once(a0, 'AILog.Info("C121_BUILD line=" + lineId', 'AILog.Info("C121_BUILD date=" + AIDate.GetCurrentDate() + " tick=" + AIController.GetTick() + " line=" + lineId')
    air.write_text(a1, encoding="utf-8", newline="\n")
    with (BASE / "snapshot_probe.patch").open("a", encoding="utf-8") as handle:
        handle.write("".join(difflib.unified_diff(a0.splitlines(True), a1.splitlines(True), fromfile="production/air_catalog_c121.nut", tofile="snapshot/air_catalog_c121.nut")))
    (BASE / "snapshot_source_hashes.json").write_text(json.dumps({p.relative_to(SNAP).as_posix(): sha(p) for p in (SNAP / "ai").rglob("*") if p.is_file()}, indent=2), encoding="utf-8")
    print(json.dumps({"snapshot": str(SNAP), "preserved_files": len(hashes), "probe_patch_sha256": sha(BASE / "snapshot_probe.patch")}, indent=2))

if __name__ == "__main__":
    main()
