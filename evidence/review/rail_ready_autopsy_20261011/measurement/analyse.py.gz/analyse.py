"""OFF/ON neutrality and transition-only, censored ready-rail observations.

Uses the frozen/current harness extractors and paired statistics; never runs
physics, pathfinding or another game. Output lives outside all frozen bundles.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import re
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SNAP = BASE / "snapshot"
sys.path.insert(0, str(SNAP / "sweeps"))
from paired_statistics import bootstrap_mean_ci, exact_wilcoxon_signed_rank_p
from analyse_rail_ready_admission import read_logs, FIELD, GAME

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def number(fields, key):
    try:
        value = float(fields[key])
        return value
    except (KeyError, ValueError, TypeError):
        return None

def metric_equivalence(pairs, metric):
    records = [x["metrics"][metric] for x in pairs]
    assert all(x["reference_opex"] is not None and x["variant_opex"] is not None for x in records)
    reference = statistics.mean(x["reference_opex"] for x in records)
    delta = [x["policy_delta"] for x in records]
    ci = bootstrap_mean_ci(delta)
    pct_ci = [100 * x / reference for x in ci] if reference > 0 else [None, None]
    return {"reference_mean": reference, "delta_mean": statistics.mean(delta),
            "delta_median": statistics.median(delta), "ci95_gbp": ci,
            "delta_mean_pct": 100 * statistics.mean(delta) / reference if reference > 0 else None,
            "ci95_pct": pct_ci, "margin_pct": 1,
            "equivalence": reference > 0 and pct_ci[0] >= -1 and pct_ci[1] <= 1,
            "wilcoxon_p": exact_wilcoxon_signed_rank_p(delta),
            "wins_losses_ties": [sum(x > 0 for x in delta), sum(x < 0 for x in delta), sum(x == 0 for x in delta)]}

def parse_transition_logs(directory):
    visits, builds, costs, events = [], defaultdict(list), [], []
    for path in sorted(directory.glob("*.log")):
        game = GAME.match(path.name)
        assert game, path
        namespace = {"policy": game["policy"], "seed": int(game["seed"]), "repeat": int(game["repeat"])}
        latest = {}
        pending_before = None
        for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            # Restrict all custom traces to OpexAI slot zero.
            if "[0]" not in line:
                continue
            m = re.search(r"\b(RRM_[A-Z_]+|C121_BUILD|RAIL_READY_ADMISSION)\s+(.+)", line)
            if not m:
                continue
            event, payload = m.groups()
            fields = dict(FIELD.findall(payload))
            fields.update(namespace, log=path.name, line=line_no)
            if event == "C121_BUILD":
                builds[(namespace["policy"], namespace["seed"], namespace["repeat"])].append(fields)
                continue
            events.append({"event": event, **fields})
            if event == "RAIL_READY_ADMISSION" and fields.get("phase") == "before":
                explicit_date = re.search(r"OPEX (\d+)-(\d+)-(\d+)", line)
                assert explicit_date, (path, line_no)
                fields["iso_date"] = "-".join((explicit_date[1], explicit_date[2].zfill(2), explicit_date[3].zfill(2)))
                pending_before = fields
            if event == "RRM_STATE":
                row = {"state": fields, "before": pending_before, "candidates": [], "actual": [], "results": []}
                visits.append(row)
                latest[fields["search_tick"]] = row
                pending_before = None
            elif event == "RRM_COST":
                costs.append(fields)
            elif event in ("RRM_CAND", "RRM_MISSING", "RRM_ACTUAL", "RRM_READY_RESULT"):
                row = latest.get(fields.get("search_tick"))
                assert row is not None, (path, line_no, event)
                row[{"RRM_CAND": "candidates", "RRM_MISSING": "candidates", "RRM_ACTUAL": "actual", "RRM_READY_RESULT": "results"}[event]].append({"event": event, **fields})
    return visits, builds, costs, events

def early_build_comparison(builds):
    rows = []
    for seed in (42, 100, 999, 746035, 424242):
        sides = {}
        for policy in ("ready_off", "ready_on"):
            counts = Counter()
            data = {}
            for event in builds.get((policy, seed, 0), []):
                key0 = (event["town_a"], event["town_b"])
                counts[key0] += 1
                key = (*key0, counts[key0])
                data[key] = event
            sides[policy] = data
        for key in sorted(sides["ready_off"].keys() | sides["ready_on"].keys()):
            off, on = sides["ready_off"].get(key), sides["ready_on"].get(key)
            # Squirrel date integer is Gregorian absolute day. Infer boundary
            # directly from observed dates of known year checkpoint (below).
            rows.append({"seed": seed, "od": key, "off": off, "on": on,
                         "day_delta": number(on or {}, "date") - number(off or {}, "date") if off and on else None,
                         "tick_delta": number(on or {}, "tick") - number(off or {}, "tick") if off and on else None})
    return rows

def score_sensitivity(visits):
    rows = []
    for visit in visits:
        state = visit["state"]
        # phase=build also carries failed A* results in production. Never
        # give an ABND/NOPATH candidate the cheap successful-ready proxy.
        if not any(r.get("outcome") in ("built", "cash") for r in visit["results"]):
            continue
        ready = next((c for c in visit["candidates"] if c.get("role") == "ready"), None)
        first = next((c for c in visit["candidates"] if c.get("role") == "first"), None)
        if not ready or not first or ready["key"] == first["key"]:
            continue
        kdec, available = number(state, "k_dec"), number(state, "available")
        kdec_source = "logged_cached_field"
        if kdec is None or kdec < 0:
            # The production cached c69KDecData is absent in these games. A
            # shared score denominator can only be inferred conditionally,
            # never substituted for a measured field without this label.
            denoms = []
            for c in (ready, first):
                p, s, f = number(c, "profit_cal"), number(c, "fund_score"), number(c, "finance")
                decision = number(c, "decision_finance")
                if p is None or s is None or s <= 0 or f is None:
                    break
                denom = 1000 * p / s
                if denom <= max(f, decision or 0) + 2:
                    break
                denoms.append(denom)
            if len(denoms) != 2 or abs(denoms[0] - denoms[1]) > max(2, max(denoms) * 0.00001):
                continue
            kdec = statistics.mean(denoms)
            kdec_source = "inferred_shared_denominator: assumes logged profit calibration equals that at selection; rounding tolerance 2 GBP"
        if not available or available <= 0:
            continue
        for annual_ops in (1_000_000, 10_000_000, 67_525_000):
            scores = {}
            for role, candidate in (("ready", ready), ("first", first)):
                profit, finance = number(candidate, "profit_cal"), number(candidate, "finance")
                omega = 200_000 if role == "ready" else number(candidate, "expected_ops")
                if profit is None or finance is None or omega is None or omega < 0 or finance <= 0:
                    continue
                scores[role] = {"historical_fund_score": number(candidate, "fund_score"),
                                "selection_score": number(candidate, "selection_score"),
                                "tier": number(candidate, "tier"),
                                "profit_cal": profit, "finance": finance, "omega_proxy": omega,
                                "S_proxy": profit / (finance / available + omega / annual_ops),
                                "S_star_proxy": profit / (max(finance, kdec) / available + omega / annual_ops)}
            if len(scores) == 2:
                rows.append({"seed": state["seed"], "search_tick": state["search_tick"], "date": state["date"],
                             "annual_ops_scenario": annual_ops, "available": available, "k_dec": kdec, "k_dec_source": kdec_source,
                             "ready_key": ready["key"], "first_key": first["key"],
                             "scores": scores, "S_ready_above_first": scores["ready"]["S_proxy"] > scores["first"]["S_proxy"],
                             "S_star_ready_above_first": scores["ready"]["S_star_proxy"] > scores["first"]["S_star_proxy"]})
    return rows

def main():
    result_path = SNAP / "results/diagnostic.json"
    result = json.loads(result_path.read_text(encoding="utf-8"))
    comparison = result["policy_comparison"]
    assert comparison["complete_pairs"] == 5 and comparison["comparison_complete"]
    assert comparison["metric_coverage_complete"] and all(g["game_ok"] for g in result["games"])
    engine = result_path.with_name("diagnostic_engine")
    ready = read_logs(engine)
    visits, builds, costs, events = parse_transition_logs(engine)
    checkpoint_rows = [json.loads(line) for line in result_path.with_suffix(".jsonl").read_text(encoding="utf-8").splitlines()]
    opex = [r for r in checkpoint_rows if r["run"][0] == "OpexAI"]
    indexed = {(r["duel_policy_id"], r["run"][1], r["run"][2], r["date"]): r for r in opex}
    monthly = []
    for key, off in sorted(indexed.items()):
        policy, seed, repeat, date = key
        if policy != "ready_off":
            continue
        on = indexed.get(("ready_on", seed, repeat, date))
        assert on, key
        metrics = {}
        for metric in ("profit_year", "company_value", "money", "air_primary_vehicles", "air_airports",
                       "airport_slots_opex", "airport_towns_opex_present", "early_slot_build_claims"):
            a, b = off.get(metric), on.get(metric)
            metrics[metric] = {"off": a, "on": b, "delta": b - a if a is not None and b is not None else None}
        metrics["rail_vehicles"] = {"off": off["primary_vehicles_by_mode"]["rail"], "on": on["primary_vehicles_by_mode"]["rail"],
                                     "delta": on["primary_vehicles_by_mode"]["rail"] - off["primary_vehicles_by_mode"]["rail"]}
        monthly.append({"seed": seed, "date": date, "coverage": off["profit_year_coverage"], "metrics": metrics})
    annual = [r for r in monthly if r["date"].endswith("-12-01")]
    early_monthly = [r for r in monthly if r["date"] < "1972-01-01"]
    early_physical_divergences = [r for r in early_monthly if any(r["metrics"][m]["delta"] != 0 for m in ("air_primary_vehicles", "air_airports", "airport_slots_opex", "airport_towns_opex_present", "early_slot_build_claims"))]
    # OpenTTD starts at day zero of leap year zero; Python ordinal starts at
    # day one of year one: OpenTTD day = ordinal + 365. Verify against logs.
    import datetime
    for visit in visits:
        date = datetime.date.fromordinal(int(visit["state"]["date"]) - 365)
        visit["state"]["iso_date"] = date.isoformat()
        assert date.isoformat() == visit["before"]["iso_date"], visit
    build_comparison = early_build_comparison(builds)
    early_build_rows = [r for r in build_comparison if any(e and int(e["date"]) < datetime.date(1972, 1, 1).toordinal() + 365 for e in (r["off"], r["on"]))]
    early_build_retards = [r for r in early_build_rows if r["off"] and r["on"] and
                          int(r["off"]["date"]) < datetime.date(1972, 1, 1).toordinal() + 365 and
                          (r["day_delta"] > 0 or r["tick_delta"] > 0)]
    early_unmatched = [r for r in early_build_rows if r["off"] is None or r["on"] is None]
    sequence_divergences = []
    for seed in (42, 100, 999, 746035, 424242):
        off = builds[("ready_off", seed, 0)]
        on = builds[("ready_on", seed, 0)]
        for idx, (a, b) in enumerate(zip(off, on)):
            fields = ("date", "tick", "town_a", "town_b", "engine", "actual_n")
            if any(a.get(f) != b.get(f) for f in fields):
                sequence_divergences.append({"seed": seed, "ordinal": idx,
                                             "off": {f: a.get(f) for f in fields},
                                             "on": {f: b.get(f) for f in fields}})
                break
    costs_by_phase = {}
    for phase in sorted({r["phase"] for r in costs}):
        values = [int(r["ops"]) for r in costs if r["phase"] == phase]
        ticks = [int(r["ticks"]) for r in costs if r["phase"] == phase]
        costs_by_phase[phase] = {"n": len(values), "sum": sum(values), "median": statistics.median(values), "max": max(values), "cross_tick_blocks": sum(t > 0 for t in ticks)}
    previous = json.loads((BASE / "production_before.json").read_text(encoding="utf-8"))
    changes = [name for name, expected in previous["hashes"].items() if not (ROOT / name).is_file() or digest(ROOT / name) != expected]
    after_status = subprocess.check_output(["git", "status", "--porcelain=v1", "-uall"], cwd=ROOT).decode("utf-8")
    source_hashes = json.loads((BASE / "snapshot_source_hashes.json").read_text(encoding="utf-8"))
    snapshot_changes = [name for name, expected in source_hashes.items() if digest(SNAP / name) != expected]
    manifest = json.loads(result_path.with_suffix(".manifest.json").read_text(encoding="utf-8"))
    smoke = json.loads((SNAP / "results/smoke.json").read_text(encoding="utf-8"))
    report = {"campaign": result["campaign_id"], "bundle": result["source_bundle_sha256"],
              "same_smoke_bundle": result["source_bundle_sha256"] == smoke["source_bundle_sha256"],
              "manifest": result["manifest_sha256"], "intervention": manifest["comparison"],
              "games": len(result["games"]), "healthy_games": sum(g["game_ok"] for g in result["games"]),
              "coverage_complete": comparison["metric_coverage_complete"], "raw_verdict": comparison["verdict"],
              "neutrality": {m: metric_equivalence(comparison["per_pair"], m) for m in ("profit_year", "company_value")},
              "per_pair": comparison["per_pair"], "annual": annual,
              "early_monthly_physical_divergences": early_physical_divergences,
              "early_air_builds": early_build_rows, "early_air_retards": early_build_retards,
              "early_air_unmatched": early_unmatched, "first_air_sequence_divergences": sequence_divergences,
              "cost_by_phase_partial": costs_by_phase,
              "opcode_equivalence": "not_demonstrated: no comparable global pure VM denominator; cost-log and guards excluded",
              "ready_summary": {k: v for k, v in ready.items() if k not in ("ready", "upgrades")},
              "ready": ready["ready"], "upgrades": ready["upgrades"], "visits": visits,
              "score_proxy_sensitivity": score_sensitivity(visits),
              "score_scope": "counterfactual arithmetic only: ready transaction=200000 estimated; rival expectedOpcodes unchanged; annual capacity scenarios, NOT actual residual cost/throughput or buildable alternatives",
              "preservation": {"production_hash_count": len(previous["hashes"]), "changed_production_files": changes,
                               "git_status_identical": after_status == previous["status"], "snapshot_changed_files": snapshot_changes}}
    (BASE / "analysis.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (BASE / "events.json").write_text(json.dumps(events, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    rows = []
    for r in annual:
        rows.append({"seed": r["seed"], "date": r["date"], "coverage": r["coverage"],
                     **{f"{m}_{side}": v[side] for m, v in r["metrics"].items() for side in ("off", "on", "delta")}})
    with (BASE / "annual.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({k: report[k] for k in ("campaign", "bundle", "games", "healthy_games", "raw_verdict", "neutrality", "cost_by_phase_partial", "ready_summary", "preservation")}, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
