# Mesure RAIL prêt — pré-enregistrement, 11 octobre 2026

Autorisation : « Fais cette mesure ». Aucun commit/push ni activation d'une
politique RAIL. Production et campagnes historiques conservées ; seule une
copie neuve dans `snapshot/` est instrumentée. Image Docker locale
`sha256:f4b2b9b3b7399cbfecacfe03b3b8dda49bff2921de36a61fed4e9441e5d44659`.
10 CPU / 8 Go RAM / 8 Go swap maximum / 10 workers. Aucun conteneur actif
constaté avant préparation. Code témoin : arbre courant dirty, HEAD 220b5fa.

## Question falsifiable

À la consommation d'un A* primaire terminé, le classement peut être absent
ou périmé alors que des concurrents finançables le devancent. Observer le
classement disponible, le résultat véritable de la pose et les tentatives
concurrentes de cette même passe. Un concurrent mieux classé n'est jamais
considéré constructible sans résultat réel. Une construction historique qui
le précède ne permet pas d'observer son contrefactuel : censure explicite.
Les upgrades restent un canal séparé de la sonde existante. Le dépôt C121
en stock n'est pas couvert par la frontière primaire historique : pas de
conclusion exhaustive sur tout le stock ni sur son rendement futur.

## Bras et séquence

Même copie et même bundle dans chaque campagne ; différence unique :
`OpexAI[rail_ready_admission_shadow=0]` contre
`OpexAI[rail_ready_admission_shadow=1]`.
Les réglages readmission, simple_opcode, simple_roi et cooperative_n2 restent
à leurs défauts 0. Tous les autres défauts courants sont conservés.
Logs script-debug identiques, télémétrie supplémentaire de lignes désactivée.
L'ajout de date/tick au C121_BUILD existant est commun aux deux bras : la
neutralité mesurée est différentielle sur cette copie, pas une qualification
de cette métadonnée commune par rapport à la production.

Contrats ciblés → smoke apparié 42×1 → diagnostic apparié
**42, 100, 999, 746035, 424242 × 5 ans**, une répétition, dix duels.
Graines fixées ici avant toute mesure, issues de diagnostics d'exposition ;
échantillon ciblé, non représentatif. Aucun ajout/retrait ni relance favorable.
Un smoke sain autorise le diagnostic même sans événement prêt à un an.
Une erreur technique bloque jusqu'à diagnostic ; aucune correction invisible
d'un bundle figé. Le verdict harnais sera `diagnostic_only` (gain_short,
40 graines / 3 ans requis, seuil 4 %, garde valeur 5 %), sans adoption.

## Instrumentation

Extension isolée de la sonde existante : deux projets au plus (RAIL présent
dans TOP64, premier finançable), champs économiques déjà existants,
calibration via le même helper pur de profit, aucun nouveau modèle physique,
tri, recherche de terrain ni revalidation. Identité namespace partie +
startTick ; visites répétées conservées mais pas traitées comme recherches
indépendantes. Coût mesuré du bloc lecture/log via OpexOpsMeasureBegin/End ;
ticks traversés publiés. Aucune commande de construction dans ce bloc.
Le coût du log COST et des gardes n'est pas inclus : mesure partielle explicite.
Les attentes de commandes contaminent les compteurs globaux ; ils ne seront
pas présentés comme opcodes VM purs. Les estimations expectedOpcodes restent
des estimations, pas des mesures résiduelles. Comparaison S/S* uniquement
hors ligne, avec valeurs Omega explicitement paramétriques si débit et coût
résiduels réels inconnus ; aucun rang calculé ne pilote l'IA.

## Critères fixés avant résultats

Profit annuel terminal Opex et company_value : IC95 bootstrap apparié du
delta, divisé par moyenne référence, entièrement dans [-1 %, +1 %].
Bootstrap partagé 20 000 rééchantillonnages, graine 0. Rapporter aussi chaque
delta et les trajectoires annuelles, santé, horizon, couverture, V/D/E.
AIR 1970–1971 : dates/ticks/OD des constructions C121, captures et compteurs
physiques aux checkpoints ; aucun retard observé accepté pour revendiquer
une préservation stricte. Les renforts non horodatés restent inconnus.
Opcode : surcoût global réel ≤1 % exigé pour qualifier la sonde. La mesure
directe partielle et une capacité théorique ne prouvent pas ce critère ; faute
de compteur comparable, verdict opcode **non démontré**, même si coût faible.
Échec ou IC trop large : sonde non qualifiée, résultat observationnel
uniquement ; pas de politique active ni extension automatique de campagne.

Rapporter présence/absence TOP64, âge A*, C77, profit calibré/capital,
résultat construit/cash/échec, concurrent réellement tenté/construit ou
censuré ; dédupliquer par recherche. Ne pas conclure que modifier TOP20
aurait modifié la construction. Préserver provenance complète et hashes.
