from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyse import metric_equivalence, score_sensitivity

class MeasurementContracts(unittest.TestCase):
    def pairs(self, deltas):
        return [{"metrics": {"profit_year": {"reference_opex": 10000, "variant_opex": 10000 + d, "policy_delta": d}}} for d in deltas]

    def test_absence_of_significance_is_not_equivalence(self):
        result = metric_equivalence(self.pairs([-500, 500, 0, 0, 0]), "profit_year")
        self.assertFalse(result["equivalence"])
        self.assertGreaterEqual(result["wilcoxon_p"], 0.05)

    def test_missing_metric_is_not_zero(self):
        pairs = self.pairs([0])
        pairs[0]["metrics"]["profit_year"]["variant_opex"] = None
        with self.assertRaises(AssertionError):
            metric_equivalence(pairs, "profit_year")

    def test_failed_astar_never_receives_ready_transaction_cost(self):
        self.assertEqual(score_sensitivity([{"state": {}, "results": [{"outcome": "failed", "reason": "ABND"}]}]), [])

    def test_constant_bounded_difference_can_meet_equivalence(self):
        self.assertTrue(metric_equivalence(self.pairs([50] * 5), "profit_year")["equivalence"])

if __name__ == "__main__":
    unittest.main()
